import { spawnSync } from "node:child_process";
import process from "node:process";

const isWindows = process.platform === "win32";
const npmStep = (args, label) => isWindows
  ? ["cmd.exe", ["/d", "/s", "/c", `npm.cmd ${args.join(" ")}`], label]
  : ["npm", args, label];
const cargoBin = isWindows ? "cargo.exe" : "cargo";
const steps = [
  npmStep(["run", "release:preflight"], "preflight"),
  npmStep(["run", "verify"], "architecture + regression verification"),
  npmStep(["run", "build"], "Vite production build"),
  [cargoBin, ["test", "--manifest-path", "src-tauri/Cargo.toml"], "Rust integration tests"],
  npmStep(["run", "tauri:build"], "Tauri NSIS bundle"),
];

for (const [bin, args, label] of steps) {
  console.log(`\n=== ${label} ===`);
  const result = spawnSync(bin, args, { stdio: "inherit", shell: false });
  if (result.error || result.status !== 0) {
    console.error(`RELEASE GATE FAILED: ${label}`);
    process.exit(result.status ?? 1);
  }
}
console.log("\nRELEASE GATE PASSED");
