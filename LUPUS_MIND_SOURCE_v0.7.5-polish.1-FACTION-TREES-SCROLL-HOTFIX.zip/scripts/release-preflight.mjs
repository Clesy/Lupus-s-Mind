import { execFileSync } from "node:child_process";
import { existsSync, readFileSync } from "node:fs";
import process from "node:process";

const fail = (message) => { console.error(`FAIL ${message}`); process.exitCode = 1; };
const pass = (message) => console.log(`PASS ${message}`);
const run = (bin, args = []) => {
  try { return execFileSync(bin, args, { encoding: "utf8", stdio: ["ignore", "pipe", "pipe"] }).trim(); }
  catch { return null; }
};

const node = process.versions.node.split(".").map(Number);
const nodeOk = node[0] > 22 || (node[0] === 22 && node[1] >= 12);
nodeOk ? pass(`Node ${process.versions.node}`) : fail(`Node ${process.versions.node}; Vite 8 requires Node 22.12+ on the Node 22 line`);

const npm = process.platform === "win32"
  ? run("cmd.exe", ["/d", "/s", "/c", "npm.cmd --version"])
  : run("npm", ["--version"]);
npm ? pass(`npm ${npm}`) : fail("npm is not available");
const cargo = run("cargo", ["--version"]);
cargo ? pass(cargo) : fail("Cargo is not available; install Rust stable with the MSVC toolchain on Windows");
const rustc = run("rustc", ["--version"]);
rustc ? pass(rustc) : fail("rustc is not available");

for (const file of ["package.json", "src-tauri/Cargo.toml", "src-tauri/tauri.conf.json", "frontend/index.html"]) {
  existsSync(file) ? pass(`${file} present`) : fail(`${file} missing`);
}

for (const lock of ["package-lock.json", "src-tauri/Cargo.lock"]) {
  existsSync(lock) ? pass(`${lock} present`) : fail(`${lock} missing; run scripts/windows-bootstrap.ps1 before sealing an RC`);
}

if (!existsSync("node_modules/.bin/vite") && !existsSync("node_modules/.bin/vite.cmd")) {
  fail("frontend dependencies are not installed; run npm install");
} else pass("local Vite binary present");

const pkg = JSON.parse(readFileSync("package.json", "utf8"));
const tauri = JSON.parse(readFileSync("src-tauri/tauri.conf.json", "utf8"));
const cargoToml = readFileSync("src-tauri/Cargo.toml", "utf8");
const cargoVersion = cargoToml.match(/^version\s*=\s*"([^"]+)"/m)?.[1];
if (pkg.version === tauri.version && pkg.version === cargoVersion) pass(`version aligned at ${pkg.version}`);
else fail(`version mismatch package=${pkg.version} tauri=${tauri.version} cargo=${cargoVersion ?? "missing"}`);

if (process.platform === "win32") pass("Windows host detected: native NSIS bundle can be sealed here");
else console.log("INFO non-Windows host: verify/build/cargo tests can run, but the official RC installer seal is Windows NSIS");

if (process.exitCode) process.exit(process.exitCode);
