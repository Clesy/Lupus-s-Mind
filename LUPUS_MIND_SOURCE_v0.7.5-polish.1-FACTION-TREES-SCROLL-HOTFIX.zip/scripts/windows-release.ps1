$ErrorActionPreference = "Stop"
Write-Host "LUPUS'S MIND - Windows RC Gate" -ForegroundColor Cyan
node scripts/release-preflight.mjs
npm.cmd run verify
npm.cmd run build
cargo test --manifest-path src-tauri/Cargo.toml
npm.cmd run tauri:build
Write-Host "RC gate complete. Inspect src-tauri/target/release/bundle/nsis/" -ForegroundColor Green
