$ErrorActionPreference = "Stop"
Write-Host "LUPUS'S MIND - Windows Toolchain Bootstrap" -ForegroundColor Cyan

function Require-Command($Name, $Hint) {
  if (-not (Get-Command $Name -ErrorAction SilentlyContinue)) {
    Write-Host "Missing: $Name" -ForegroundColor Red
    Write-Host $Hint -ForegroundColor Yellow
    exit 1
  }
}

Require-Command "node" "Install Node.js 22.12+ (LTS recommended), then reopen PowerShell."
Require-Command "npm.cmd" "npm should be installed with Node.js."
Require-Command "cargo" "Install Rust stable MSVC via rustup, then reopen PowerShell."
Require-Command "rustc" "Install Rust stable MSVC via rustup, then reopen PowerShell."

Write-Host "Installing pinned frontend dependencies..." -ForegroundColor DarkCyan
npm.cmd install --no-audit --no-fund

Write-Host "Generating Cargo.lock..." -ForegroundColor DarkCyan
cargo generate-lockfile --manifest-path src-tauri/Cargo.toml

Write-Host "Running release preflight..." -ForegroundColor DarkCyan
node scripts/release-preflight.mjs

Write-Host "Bootstrap complete. package-lock.json and Cargo.lock are now part of the local RC workspace." -ForegroundColor Green
