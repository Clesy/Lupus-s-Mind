# v0.7.4-alpha.2 Windows Smoke Test

From a clean extracted source folder:

```powershell
npm.cmd install
npm.cmd run verify
npm.cmd run build
cargo test --manifest-path .\src-tauri\Cargo.toml
npm.cmd run tauri:dev
```

## Atlas viewport

1. Open **Atlas** on a 1920x1080 desktop window.
2. Confirm the map begins directly below the map toolbar; there should be no giant empty panel above the terrain.
3. Confirm the bottom of the map remains visible above the Windows taskbar/app window boundary.
4. Scroll the right Map Inspector and confirm the map viewport does not move vertically with it.

## Zoom / pan

1. Put the pointer over a settlement and scroll up: the map should zoom toward that pointer location.
2. Use `+` to zoom in and `-` to zoom back out.
3. Confirm `-` stops at the full-map Fit state and `+` stops at 600%.
4. Press **Fit** and confirm the complete map returns to view.
5. Zoom in, then drag empty terrain: the camera should pan.
6. Drag a location pin: only the pin should move, not the camera.
7. Select an unpinned Location, zoom/pan, then click the map to place it. Reopen the map and confirm its placement persisted correctly.

## Regression

- Generator remains deterministic for the same seed/settings.
- Generate/Regenerate does not write canon before **Accept into World**.
- Nested maps, Locations and Global Search continue to work.
