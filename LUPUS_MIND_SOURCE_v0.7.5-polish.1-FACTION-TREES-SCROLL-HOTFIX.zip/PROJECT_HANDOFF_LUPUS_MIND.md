# LUPUS'S MIND — PROJECT HANDOFF

## Purpose

This file is the portable memory / continuation contract for the LUPUS'S MIND project.

If a new ChatGPT conversation is started, upload the latest project ZIP/folder together with this file and say:

> This is the latest LUPUS'S MIND project. Read PROJECT_HANDOFF.md and the source tree first. Preserve the existing architecture and continue from the current checkpoint.

The source code is authoritative. This document summarizes the decisions that must not be silently changed.

---

# 1. Product

**Name:** LUPUS'S MIND  
**Current checkpoint:** v0.7.5-polish.1 — Full #001–#010 polish candidate (Windows validation pending)  
**Technology:** Tauri 2 + Rust + TypeScript + SQLite  
**Product direction:** Offline-first author/worldbuilding studio with temporal knowledge, structured lore, deterministic simulation tools, and future commercial licensing potential.

The project began as a single-file HTML prototype and was progressively rebuilt as a modular native desktop application.

The simple HTML prototype remains an important UX reference: the native architecture should be robust, but user-facing interactions should not be made more complicated than necessary.

---

# 2. Core Architecture

Preferred flow:

```text
Domain
  -> Application Use Case
    -> Repository / Read Port
      -> SQLite Adapter
        -> Tauri IPC
          -> Frontend Gateway
            -> Obsidian UI
```

Hard rules:

- UI components do NOT call Tauri `invoke()` directly.
- Only frontend infrastructure gateways call `invoke()`.
- Rust application/domain code must not know concrete SQLite adapters or Tauri `AppState`.
- SQLite is the durable local source of truth for the desktop application.
- Domain types remain independent from storage representation.
- Write and read responsibilities are separated where it materially improves correctness.
- Canonical world state and combat/runtime state are strictly separated.
- AI or creative generators must never write directly to canonical state.
- Transactions must not leave partial state.
- Never fake a successful build/test result.

---

# 3. Completed Modules

## C1 — Characters

Frozen foundation.

Character domain includes identity, name, canonical base stats and other core character data.

Important:
- Base stats are canonical.
- Derived/effective stats are projections.
- Character detail UI was later expanded to show:
  - Base stats
  - Effective stats
  - Equipped items
  - Learned skills
  - Links to manage equipment/skills

## I1 — Items / Equipment

Frozen foundation.

Critical distinction:

```text
Item != Equipment
```

- Item = canonical world entity.
- Equipment = relationship/status between Character and Item.
- Typed equipment slots.
- Item cannot be equipped by two characters simultaneously.
- Transaction-safe equip/unequip.
- CharacterSheet derives effective stats from base stats + equipment modifiers.

## S1 — Skills

Frozen foundation.

Critical distinction:

```text
Skill != SkillEvaluation != CharacterSkill != CombatAction
```

- Skills are canonical definitions.
- CharacterSkill is the learned-skill relationship.
- Deterministic evaluator is pure.
- Preview/evaluation must not mutate canonical state.
- Skill definitions can have scaling/resource/cooldown information.

## R1 — Temporal Relationships

Frozen foundation.

Critical distinction:

```text
Relationship != RelationshipState != RelationshipTransition
```

- Temporal intervals use half-open semantics.
- Directed and symmetric relationship types supported.
- Historical relationship states are immutable.
- Graph/matrix views are read models.

## T1 — Narrative Timeline

Frozen foundation.

Critical distinction:

```text
RelationshipTransition != StateTransition != TimelineEvent != TimelineProjection
```

- TimelineEvent is canonical narrative fact, not a projection.
- Point and span events supported.
- Spans are half-open.
- Provenance/source does not imply participation.
- Chronicle and character-thread views are projections.

## C2.1 — Durable Combat Runtime

Frozen architecture.

Critical distinctions:

```text
CombatSession != Canonical World
CombatantSnapshot != CombatantRuntimeState
CombatAction != TimelineEvent
```

- Combat snapshots canonical data at start.
- Running combat never writes HP/mana/cooldown data back to Character.
- Durable sessions and action logs use SQLite.
- Deterministic seeded RNG.
- Transaction rollback verified.
- Restart persistence verified.

## C2.2 — Status / Turn Effects

Frozen architecture.

Critical distinction:

```text
StatusEffectDefinition
  != CombatStatusEffectSpec
  != ActiveStatusEffect
  != StatusTick
  != CombatAction
```

Features:
- DoT
- HoT
- Stun
- Runtime modifiers
- Refresh stacking policy
- Exact duration semantics
- Same-turn duration protection
- Atomic status-tick transaction behavior

Stacking design:

```text
StackingPolicy
- Refresh     (currently supported)
- Independent (future)
- Intensity   (future)
- StrongestWins (future)
```

Refresh semantics:
- Same target + definition refreshes existing runtime instance.
- Instance identity is preserved.
- Incoming source/power/duration replace previous values.

## C2.3 — Deterministic Replay / Debugger

Architecture implemented and preserved, but not part of the simple default combat UX.

Critical distinction:

```text
CombatUnitOfWork -> writes future runtime state
CombatReplayService -> reads/reconstructs history
```

Replay principles:
- Pure state reconstruction.
- Append-only replay mutations.
- Replay does not reroll RNG.
- Historical inspection is read-only.
- Replay does not mean rewind/branch.
- Golden invariant:

```text
REPLAY(latest) == LIVE(runtime_state)
```

The advanced replay/debugger should remain available as an internal/advanced capability if useful, but must not make the everyday combat UI complicated.

## G1 — Creative Generators

Foundation implemented.

Generators:
- Character names
- Location names
- Item/artifact names

Critical distinction:

```text
GeneratedCandidate != Canonical Entity
```

Generator output never automatically becomes a Character/Location/Item.

Possible future generators:
- Factions/clans
- Skills/spells
- Quests
- Taverns
- Deities
- Monsters
- Titles/books

## P1 — Productization

Implemented:
- Unified shell
- Dashboard/overview
- Character route
- Structured sidebar
- Route loading/error/retry handling
- Stale async route-render protection

## P2 — Desktop Hardening

Implemented:
- Workspace/settings
- SQLite health checks
- Backup/export
- Migration recovery points
- Persistent UI settings
- Keyboard ergonomics

Backup principle:
- Do not blindly copy an active WAL SQLite DB.
- Use a SQLite-consistent snapshot mechanism.

## P3 — Native Release Candidate

Implemented:
- Native Windows toolchain/release path
- Version alignment
- Release scripts/preflight
- Windows NSIS configuration
- Native build verification path

Current version used during RC work:

```text
0.6.0-rc.1
```

---

# 4. Final Combat UX Decision

This is especially important.

The user explicitly rejected an overly automated battle simulator.

The DEFAULT combat screen must be a **manual damage-testing arena**, inspired by the original HTML prototype.

Desired interaction:

```text
Choose Attacker
Choose Target
Choose Attack
Optionally force Critical
Press Execute
```

No character should attack automatically.

Core UX:

- Attacker dropdown
- Target dropdown
- Swap sides button
- Attack/skill dropdown
- Manual execute button
- Critical checkbox
- HP/Mana visible
- Fill HP/Mana reset
- Clear log
- Simple human-readable combat log

Critical option:
- When forced critical is enabled, attack should be treated as guaranteed hit + critical multiplier according to current manual-arena contract.

The arena is intended primarily to answer:

> "If this character uses this attack on that character, how much damage will it deal?"

The main manual arena should NOT require durable CombatSession creation.

Manual arena state may be ephemeral UI/RAM state while damage math is still calculated by the Rust backend.

This avoids accumulating test battles in SQLite.

Existing durable combat/replay architecture may remain for future advanced features but should not dominate the simple UI.

---

# 5. Native Windows Validation Achieved

The project was tested on the user's Windows machine.

Environment observed:

- Node: 24.19.0
- npm: 11.17.0
- rustc: 1.98.0
- cargo: 1.98.0
- MSVC/Visual C++ Build Tools installed
- Windows SDK installed

Frontend production build succeeded:

```text
vite v8.2.2
56 modules transformed
production dist generated successfully
```

Rust native compilation succeeded after fixes.

Native Rust test suite passed:

```text
Unit tests                 6/6
Combat Effects             4/4
Combat Runtime             2/2
Combat Replay              1/1
Equipment                  4/4
Relationships              3/3
Skills                     2/2
Timeline                   3/3

Total                      25/25 PASS
```

Important fixes discovered through real compiler/runtime testing:

1. Missing `src-tauri/icons/icon.ico`
2. Windows PowerShell 5.1 encoding/runner issues
3. Windows `.cmd` preflight invocation issue
4. `rusqlite` does not directly support `u64` SQLite INTEGER mapping:
   - Domain remains `u64`
   - SQLite adapter uses checked `i64 <-> u64` conversion
5. Status-effect integration test fixture had incorrect `applied_sequence`; production same-turn protection was correct.

---

# 6. Current Windows App Status

A real Windows executable was successfully produced:

```text
src-tauri/target/release/lupus-mind.exe
```

Observed executable size was approximately:

```text
4.71 MB
```

The overall development folder was several GB because of:

```text
src-tauri/target/
node_modules/
build caches
debug artifacts
incremental Rust compilation
```

These caches are NOT the application itself.

Safe-to-regenerate directories:

```text
node_modules/
src-tauri/target/
dist/
```

Do not confuse deleting build caches with deleting source.

The user can use the compiled `lupus-mind.exe` directly without opening PowerShell.

---

# 7. Installer Status

Tauri successfully built the application executable.

NSIS bundling later failed during installer generation with a macro error similar to:

```text
NSISCOMCALL requires 4 parameters, passed 7
Error in macro IsShortcutTarget
```

This does NOT prevent use of the compiled `.exe`.

Installer is therefore an open polish/release task, not a blocker for local application use.

Future task:
- Repair/upgrade NSIS bundler path
- Produce clean setup.exe
- Optionally code-sign releases

---

# 8. Files / Build Artifacts to Preserve

For everyday use:
- `lupus-mind.exe`

For future development:
- Latest complete source ZIP
- `frontend/`
- `src-tauri/src/`
- `src-tauri/migrations/`
- tests
- `package.json`
- `package-lock.json`
- `src-tauri/Cargo.toml`
- `src-tauri/Cargo.lock`
- `src-tauri/tauri.conf.json`
- README/freeze/handoff docs

Build caches do not need archival:
- `node_modules/`
- `src-tauri/target/`
- `dist/`

Recommended archive structure:

```text
LUPUS_MIND_ARCHIVE/
├── 01_RELEASES/
├── 02_SOURCE_BACKUPS/
├── 03_DATABASE_BACKUPS/
└── 04_NOTES_HANDOFF/
```

Keep at least one additional copy outside the development machine (cloud drive or external disk).

---

# 9. Running / Building

Development setup:

```powershell
npm.cmd install
npm.cmd run verify
cargo test --manifest-path .\src-tauri\Cargo.toml
npm.cmd run tauri:dev
```

Frontend production build:

```powershell
npm.cmd run build
```

Native Tauri build:

```powershell
.\node_modules\.bin\tauri.cmd build
```

Direct Windows application:

```text
src-tauri\target\release\lupus-mind.exe
```

---

# 10. Commercial Product Direction

The user believes the application could become license-sellable with further development. This is a valid future product direction.

Recommended commercial milestone:

## v0.7 Commercial Foundation

Prioritize:
- Multi-project/workspace support
- Installer fix
- Auto-update
- License activation
- Trial mode
- First-run onboarding
- Crash/recovery UX
- Signed Windows releases
- Commercial-grade backup/export
- EULA/privacy/license UI
- Website/license delivery flow

Potential positioning:

> Offline-first worldbuilding studio for authors managing long-form fictional universes, characters, items, skills, relationships, timeline continuity and simulation tools.

Do not rely on "AI" as the only value proposition.

Possible future tiers were discussed:
- Creator
- Studio
- Studio Pro

But a single one-time Windows license may be simpler for an initial market test.

---

# 11. Future Feature Ideas

Potential additions, not required for current v0.6 checkpoint:

- Inventory / item ownership
- Factions / clans
- Quest system
- Map / region editor
- Family tree
- Character progression / level-up
- Magic/spell expansion
- AoE/multi-target combat
- Reactions/counters
- Faction wars
- NPC generator
- Quest generator
- Lore generator
- World-aware AI assistant
- Canon consistency checker
- Combat branching
- Apply combat results to canon
- PDF/EPUB/world-bible export
- Cloud sync

When adding features, preserve modular boundaries.

---

# 12. Product Philosophy Learned During Development

Important lesson from this project:

Robust architecture is valuable, but the user-facing workflow must remain simple.

Do not automatically turn every feature into a large simulation subsystem.

For example, the combat architecture can remain sophisticated internally while the primary screen remains:

```text
Attacker -> Target -> Attack -> Execute
```

Use the original HTML prototype as a reference when it offers a clearer/faster workflow.

Avoid unnecessary complexity unless the user explicitly wants advanced behavior.

---

# 13. Conversation / Continuation Instructions

If ChatGPT context is lost:

1. Upload the latest source ZIP.
2. Upload this `PROJECT_HANDOFF.md`.
3. Say:

> Continue LUPUS'S MIND from this checkpoint. Read PROJECT_HANDOFF.md and inspect the current source before making changes. Preserve frozen architectural boundaries. The current default Combat UX is the simple manual arena.

4. Do not reconstruct the project from memory alone when source files are available.
5. Treat the current source tree as authoritative if this document and code disagree.

---

# 14. Current Checkpoint

At the end of the original long conversation:

- Native Windows app runs.
- User is happy with the result.
- Project is considered a stable **v0.6 final checkpoint**.
- Future changes should generally be:
  - bug fixes
  - UX improvements
  - installer polish
  - optional v0.7 commercial/product development
- New features are allowed; "final" means stable checkpoint, not permanent freeze.

LUPUS'S MIND can be extended without starting over.

---

# 15. v0.7.0-alpha.1 — Current Work After v0.6 Handoff

A first v0.7 Authoring & Navigation slice was implemented after the v0.6 checkpoint.

Implemented in this alpha:

- Multi-Project: centered top-bar switcher, separate SQLite DB file per project, legacy v0.6 database preserved as first project.
- Project safety: missing registered DB fails closed; registry-write failure rolls the active connection back.
- Manuscript / Chapters: chapter editor, status, content, notes, tags, word count, debounced autosave, Focus Mode.
- Cross-project autosave safety: pending/in-flight Manuscript saves are flushed before a DB switch.
- Quick Notes / “Aklımda Bulunsun”.
- Global Search / Ctrl+K over characters, items, skills, timeline, manuscript and relationships for the active project.
- Quick Create / Ctrl+N for Character, Item, Skill and Chapter.
- Character Card Gallery + Table view + contextual inspector for base/effective stats, equipment and learned skills.
- Top-bar breadcrumbs / search / quick-create / workspace controls.
- Migration 010; expected schema version 10.
- New Rust integration-test source: `src-tauri/tests/authoring_project_flow.rs`.

The packaging environment passed `npm run verify`; Cargo is not installed there, so the new v0.7 Rust integration test still requires the user's Windows machine to seal it.

Explicit next-wave backlog remains: Atlas + seeded random map builder, Factions/Clans, relationship matrix, armies/wars, inventory ownership, quests, Lore Wiki/backlinks, family tree, custom calendar, secret knowledge matrix, relic/crafting, progression, analytics/compare, Lore Bible export and world-aware AI.

The source tree remains authoritative over this handoff.

# 16. Agreed v0.7+ Product Roadmap (Do Not Lose)

The following feature directions were explicitly agreed after the v0.6 checkpoint. They are backlog / roadmap unless already listed as implemented in section 15.

## UX / Navigation

- Centered Project Switcher in the top bar.
- Global Search field at top-right plus `Ctrl/Cmd + K` command palette.
- Quick Create (`+`, `Ctrl/Cmd + N`).
- Breadcrumbs.
- Favorites / pinned entities and recent-history navigation.
- Contextual right Inspector.
- Split View for two entities or manuscript + lore.
- Quick Peek on entity references.
- Saved filters / views.
- Bulk actions and inline editing where safe.
- Card / Table / Graph / Tree view modes.
- Autosave status indicator.
- Undo / Redo for authoring-oriented interactions.
- Accessibility / density options (comfortable, compact, dense).

## Character UX / Visual Direction

The user specifically likes the original HTML character-card concept.

Future Character Gallery should emphasize:

- Visual character cards as the default view.
- Optional local portrait / character-art assets.
- Stats visible directly on cards.
- Equipment summary.
- Learned-skill summary.
- Faction / status / tags.
- Base stat -> effective stat differences where useful.
- Table view for dense workflows.
- Character profile lenses such as Profile / Timeline / Network / Inventory / Manuscript Mentions.

Do NOT store image files as base64 blobs in SQLite. Use a local Asset Library / asset reference model when portrait support is implemented.

## Authoring Expansion

- Manuscript / chapter writing area (foundation already implemented).
- Full-screen / Focus writing mode (foundation already implemented).
- Rich text / improved editor later.
- Advanced in-text search and highlight.
- Entity mentions / links from manuscript to world entities.
- Character Arc Tracker.
- Scene planner using Goal -> Obstacle -> Outcome.
- Quick Notes / “Aklımda Bulunsun” (foundation already implemented).
- Canon consistency checker: written prose can suggest inconsistencies but must not silently mutate canon.

Invariant:

```text
ChapterDraft != TimelineEvent != Canonical State
```

## Atlas / Maps

- Interactive Atlas / map editor.
- World -> Continent -> Region -> City -> Location / POI hierarchy.
- Region / location node connections (road, portal, sea route, border, etc.).
- Faction territory overlays and temporal ownership.
- Timeline/chapter scrubber integration where useful.
- Seeded procedural / random map generator.
- Procedural options such as map size, continents, ocean ratio, mountains, rivers, lakes, biomes, islands, settlements, roads, ruins and territories.
- Generated maps are not canonical until accepted.

Invariant:

```text
GeneratedMap != CanonicalMap
```

## World / Canon Expansion

- Faction / Clan management.
- Relationship / Faction matrix visualizations.
- Army / Unit management.
- Faction wars, alliances, vassalage and diplomacy.
- Inventory / item ownership.

Invariant:

```text
Item != Ownership != Equipment
```

- Quest system.
- Magic / spell system.
- Relic / legendary item / crafting system.
- Character progression / level-up history.
- Family tree / bloodlines.
- Organizational hierarchy tree views.
- Lore Wiki / Lore Pages / backlinks.
- Tag and colored category system.
- User-defined dynamic status badges.
- Duplicate / clone actions for Character, Item, Skill, Location, etc. with new identity.
- Custom world calendar / time progression.
- Secret / Knowledge Flow Matrix: who knew which secret and from what chapter/date.

Suggested invariant:

```text
Secret != CharacterKnowledge
```

## Creative Tools

Expand G1 into a Universal Creation Wizard:

- Character
- NPC
- Item
- Relic
- Location
- City / settlement
- Kingdom
- Faction / Clan
- Quest
- Event
- Lore
- Spell / Skill
- Monster
- Religion / deity
- Army

Keep generated candidates non-canonical until explicit acceptance.

## Analytics / Visualization

- Dashboard statistics and charts.
- Character / faction / quest / timeline summaries.
- Card views with stat bars.
- Compare Mode for characters/items/builds.
- Character development / progression graphs.
- Relationship density and event analytics.
- Word-count / manuscript progress analytics.

## Search

Global Search should evolve beyond simple names:

- advanced filters by type, tag, status, faction, location, chapter/date and relationship;
- full-text manuscript/lore search with highlight;
- command actions from the same palette;
- eventually temporal/world-aware queries.

## Export / Publishing

- JSON import/export with preview + conflict detection.
- Full-world and selected-entity backup/export.
- Lore Bible / World Bible export.
- PDF / EPUB / HTML export.
- Map exports such as PNG/SVG where appropriate.

## Advanced Combat (Separate From Default Arena)

The default Manual Arena MUST stay simple.

Advanced combat may later add:

- AoE / multi-target attacks.
- More buff/debuff variants.
- Reactions / counters.
- Combat branching / alternate simulations.
- Apply combat results to canon through explicit review/confirmation.

Do not reintroduce automatic fighting into the default Manual Arena unless the user explicitly asks for it.

## World-Aware AI (Later)

AI should be built only after the structured world and authoring data are strong enough to ground it.

Potential uses:

- temporal canon questions;
- consistency checking;
- relevant context retrieval for a chapter;
- lore / NPC / quest assistance;
- character-knowledge-aware reasoning.

AI must not directly mutate canonical data.

## Cloud / Collaboration (Later)

- Cloud sync is future work, not current scope.
- Collaboration can be considered later.
- Offline-first/local ownership remains a key product value.

## Commercial / Advertising Direction

Commercialization is future work after product value and user adoption are stronger.

Agreed direction:

```text
Free
- genuinely usable product
- optional tasteful sponsor placements later

Supporter / Paid
- removes sponsor placements
- supports development

Studio / advanced tiers can be considered later
```

Advertising is NOT a current priority.

If sponsor placements are ever implemented:

- no popups;
- no full-screen ads;
- no forced video/audio;
- no ads inside writing/combat actions;
- no layout shifts that disrupt editing;
- no lore/manuscript data used for ad targeting;
- ad service failure must never break the app;
- ads should be isolated from Canon/Domain/Application logic.

Principle:

> Advertising may fund the user experience; the user experience must never be designed around advertising.

## Competitor-Learning Principle

Study good ideas from tools such as World Anvil, Campfire, RealmWright, LegendKeeper, Novelcrafter and other worldbuilding/authoring products, but do not copy their proprietary UI, branding or text.

Learn from the problems they solve and implement those capabilities in LUPUS'S MIND's own architecture and visual language.

The long-term differentiator should be the connected combination of:

```text
Authoring
+ Structured World Data
+ Temporal Canon
+ Search
+ Atlas
+ Relationships
+ Stats / Equipment / Skills
+ Deterministic Sandbox
```

---

# 17. Current Scope Freeze

At this checkpoint the user explicitly requested that ideation stop temporarily so the agreed v0.7 improvements can be implemented and stabilized before adding more new ideas.

The first implementation slice is `v0.7.0-alpha.1 — Authoring & Navigation Foundation`.

Before starting the heavier second wave (Atlas, procedural maps, factions, armies, secrets, etc.), seal the alpha on the user's Windows machine with:

```powershell
npm.cmd install
npm.cmd run verify
npm.cmd run build
cargo test --manifest-path .\src-tauri\Cargo.toml
npm.cmd run tauri:dev
```

Then complete `V0_7_WINDOWS_SMOKE_TEST.md`.


---

# 18. v0.7.1 Visual UX Checkpoint

Current follow-up checkpoint: **0.7.1-alpha.1**.

The user requested a more professional interface and clearer visual differentiation of stats/effects. The agreed visual principle is:

```text
Color = semantic information, not decoration.
```

Implemented in this slice:

- Professional Character Card Gallery refresh.
- Professional Item Card Gallery + Item Inspector.
- Persistent Cards/Table modes.
- Semantic stat palette shared across Character and Item surfaces.
- Rarity-aware item visuals.
- Positive vs negative modifier visual semantics.
- Character Favorites (UI preference only).
- Character Compare Mode (read-only CharacterSheet comparison).
- Explicit Duplicate Character / Duplicate Item actions; new records receive new identities.
- Portrait-ready Character card area, but actual portrait asset storage/upload is intentionally deferred. Do not store image base64 blobs in the canonical Character row just to add portraits. Use a proper local Asset Library when portrait support is implemented.

The Obsidian shell should remain restrained. Do not regress to the old neon/cyber aesthetic.

The next feature wave remains the previously agreed world/authoring backlog; do not add more ideation until this UX slice is Windows-smoke-tested.

---

# 19. v0.7.1 Portrait + Timeline Hotfix

Windows smoke testing revealed two issues after `0.7.1-alpha.1`:

1. Character cards were only `portrait-ready`; real image persistence was not implemented.
2. Timeline layout was broken/clipped in the new shell and dense timelines could overlap after five lanes.

These are now addressed in the hotfix source.

## Portrait rule

Character art is a project-local Asset capability, not canonical Character data:

```text
Character != PortraitAsset
```

Portraits are resized client-side and saved by Rust to the asset directory derived from the active project SQLite database. Do not regress to base64 blobs inside the Character row.

UI workflow:

```text
Character Inspector -> Portrait -> choose JPEG/PNG/WebP
```

`Remove art` deletes it.

## Timeline rule

Timeline must size to its route host, never to raw viewport height. Event cards use dynamic lane packing, not fixed nth-child rows. Timeline opens fitted to actual DB bounds and supports `Fit all`. Search deep-links can open/select a timeline event and frame its chapter range.

See `V0_7_1_PORTRAIT_TIMELINE_HOTFIX.md`.


---

# v0.7.1-alpha.2 Item Card / Switcher checkpoint

- Items now follow the Character Gallery card hierarchy.
- Item artwork is persisted in active-project local assets via AssetGateway / FileSystemAssetStore (`items/`).
- Item artwork is not stored as base64 in SQLite.
- Item cards preserve semantic rarity + stat/effect coloring.
- Project Switcher arrow glyph was removed by user request; switcher is now project dot + name only.
- Character Inspector portrait fallback initial is forced hidden whenever a portrait is present.
- `npm run verify` passes including the new `test:v0.7.1-item-cards` suite.
- New Rust integration test source checks item-art isolation across project switches; run `cargo test` on Windows to seal native compilation.


---

# 20. v0.7.2 Lore & Authoring Checkpoint

Current implementation checkpoint: **0.7.2-alpha.1**.

The app now connects authored prose to structured world records without treating prose as canon.

Implemented:

- Lore Bible / Lore Page CRUD with autosave, category, summary, tags and word count.
- Natural exact `@Entity` mentions in Manuscript and Lore.
- Rebuildable `entity_mentions` projection for two-way mentions/backlinks.
- Recognized targets: Character names/aliases, Items, Skills and Lore Pages.
- Linked navigation + Quick Peek for recognized entities.
- Global Search includes Lore.
- Manuscript Find / Next / Previous with native selection highlight.
- Scene Planner: order/title + Goal / Obstacle / Outcome + POV + location label + notes.
- Character Arc points in Character Inspector.
- Quick Notes may link back to a chapter/supported entity; deleting that target preserves the note and clears only link metadata.
- SQLite cleanup triggers prevent dangling mention projections after source/target deletion.
- Project Switcher flushes pending/in-flight Manuscript AND Lore saves before switching the active SQLite database.

Frozen conceptual boundaries:

```text
Chapter/Lore authored text != Canonical State
EntityMention               != Canonical Relation
CharacterArcPoint           != Character StateTransition
ScenePlan                   != TimelineEvent
```

Mention indexes are projection data and may be deleted/rebuilt without changing authored or canonical records. Mention refresh failure must not make a successfully persisted Chapter/Lore save look failed.

Current limitation: mention resolution is intentionally exact name/alias matching. Location/Faction targets join later when those domains are implemented. Rich text is intentionally deferred; v0.7.2 preserves the reliable plain textarea authoring model.

Packaging environment: `npm run verify` + TypeScript strict PASS. Vite production build and Cargo/native test remain Windows promotion gates because those local tools are unavailable here.

Next planned product wave after v0.7.2 is stabilized: **v0.7.3 Factions / Inventory / Quests / Secrets**. Do not begin it until the user smoke-tests this checkpoint.


---

# 21. v0.7.3 World Systems Checkpoint

Current implementation checkpoint: **0.7.3-alpha.1**.

Implemented: Factions/Clans, temporal Faction Membership, chapter-aware Faction diplomacy matrix, Inventory/Item Ownership history, Quest CRUD + ordered objectives + related-record storage foundation, Secrets + temporal Character Knowledge Matrix, Global Search/Quick Create routes, Character world-context summaries and Item current-owner summary.

Frozen boundaries:

```text
FactionMembership != Relationship
ItemOwnership     != Equipment
Quest             != TimelineEvent
Secret            != CharacterKnowledge
```

Migration: `012_world_systems.sql`. Native Windows integration test: `src-tauri/tests/world_systems_flow.rs`.

Packaging environment: full `npm run verify` PASS. `npm run build` is blocked here only because local Vite is not installed; Cargo is unavailable in this environment. Windows smoke test remains the native promotion gate.

Next planned wave after user smoke test: **v0.7.4 Atlas / Region Editor / Map Pins / Seeded Random Map Builder**.

## v0.7.3-alpha.2 Inventory UI Hotfix
- Inventory layout compacted: controls and cards now flow from the top with no giant empty panel.
- Inventory cards reuse Item artwork, rarity and semantic stat/effect colors.
- Added ownership state filters/counts and current owner/chapter summary.
- No migration/domain behavior change; ItemOwnership remains separate from Equipment.


---

# 22. v0.7.3-alpha.3 Hierarchies & Lineages Checkpoint

Feature slice name: **v0.7.3.1 — Hierarchies & Lineages**. Package semver: **0.7.3-alpha.3**.

Implemented before Atlas:
- Faction Hierarchy lens with custom role tree, parent role, tier, capacity, color and ordering.
- Temporal role/office assignments: users can answer who was Clan Leader / Monarch / Prime Minister / Captain at Chapter X.
- Editable recommended structures for clan, kingdom, guild, order, house and generic factions.
- Lineages lens for Family / Dynasty / Bloodline / House membership with branch/title and chapter history.
- Relationship Family Tree read model. It filters active temporal kinship relationships; it does not own duplicate family canon.
- New built-in relationship types: parent, adoptive_parent, spouse, betrothed; existing sibling remains.
- DB protection against cross-faction role parents, role cycles and open capacity overflow.

Frozen boundaries:
```text
FactionMembership != HierarchyRoleAssignment
LineageMembership != FamilyRelationship
FamilyTree        != Canonical Family Database
```

Migration: `013_hierarchies_and_lineages.sql`. Native test: `src-tauri/tests/hierarchy_lineage_flow.rs`.

After this checkpoint is Windows-smoke-tested, resume the planned **Atlas / Region / Location / Map Pin / Seeded Random Map Builder** wave.


# 23. v0.7.3-alpha.4 Faction Tree UX Checkpoint

- Faction Hierarchy presentation changed from indented role cards to a true SVG node/connector tree.
- Role nodes remain interactive and open the existing inspector; temporal office assignment semantics are unchanged.
- Lineages changed from card gallery to `Lineage -> Branch -> Members` tree presentation.
- No fake faction-parent tree was introduced because the domain currently has no canonical subfaction relation.
- Relationships -> Family Tree remains the only kinship tree; lineage membership must never fabricate parent/spouse/sibling edges.
- `npm run verify`: PASS. TypeScript strict: PASS. Production Vite build was not executed in the sandbox because a local/global `vite` binary is unavailable. Native Rust compilation remains a Windows smoke-test step.


# 24. v0.7.4 Atlas & Map Systems Checkpoint

Current implementation checkpoint: **0.7.4-alpha.1**.

Implemented:
- Canonical `Location` hierarchy with World/Continent/Country/Region/Province/City/Town/Village/District/Building/Landmark/Dungeon/Biome/general Location kinds.
- Canonical `AtlasMap`, project-local nested maps, map scope and accepted generated terrain.
- `MapPin` projection: a Location can be placed once per map with normalized X/Y coordinates and dragged without mutating the Location itself.
- `MapConnection` projection for road / sea_route / portal / border / path links.
- Three Atlas lenses: Atlas canvas, Locations tree/editor, Generator.
- Pure deterministic seeded map generation for landmasses, mountains, rivers and settlements.
- Generate/Regenerate is RAM-only; no canonical database write occurs before explicit `Accept into World`.
- Accept is transactional and can create generated continents/settlements + pins. Settlements are parented to the nearest generated landmass.
- Global Search includes Locations and Atlas Maps; Quick Create exposes Location.
- Location parent and nested-map parent UI exclude descendants; SQLite recursive triggers remain the final cycle guard.

Frozen boundaries:
```text
Location          = Canonical Place
AtlasMap          = Canonical Map Record
MapPin            != Location Ownership
MapConnection     != Relationship / Timeline Event
GeneratedMapDraft != Canon
```

Migration: `014_atlas.sql`. Native Windows integration test: `src-tauri/tests/atlas_flow.rs`.

Sandbox gate: TypeScript strict + full `npm run verify` PASS. Production Vite and native Cargo are Windows promotion gates because this source-only sandbox has neither local Vite nor Cargo.

Deferred after this alpha: custom map image backgrounds, freehand terrain editing, polygon faction territories, temporal territorial overlays, pathfinding and climate simulation. Do not bypass Location/Atlas ports when adding them.

After user smoke-testing, next planned product wave is the remaining Time/Calendar + broader simulation/world systems work; do not rush into it before Atlas UX is validated.


# 25. v0.7.4-alpha.2 Atlas Viewport / Zoom Checkpoint

Frontend-only Atlas polish over alpha.1:
- fixed oversized/vertically centered Atlas canvas layout; the map viewport now fills the available route height,
- Map Inspector scrolls independently,
- mouse-wheel cursor-anchored zoom, +/- controls and Fit,
- bounded 100%-600% zoom and drag-to-pan on empty map space,
- pin drag remains independent from camera pan and placement coordinates remain correct under camera transforms,
- deterministic label offsets reduce dense settlement-label overlap.

No migration/domain change. Camera state is UI-only and must never be persisted as canonical world data. Full `npm run verify` PASS in sandbox; production Vite/native Cargo remain Windows promotion gates.


---

# GENERATOR QUALITY FREEZE — v0.7.4-alpha.3

User explicitly froze new feature development to improve World Generator output quality. Current priority is generator realism, not roadmap expansion. v0.7.4-alpha.3 replaces polygonal coast generation, centroid-jitter settlements and downward random-walk rivers with a deterministic layered generator: 160-sample organic coastlines, mountain ranges, elevation-driven hydrology, suitability/spacing-based settlements, unique names and distinct city/town/village markers. No new migration; `GeneratedMapDraft` remains backward-compatible. Do not resume new major features until the user is satisfied with generator output.

---

# 26. v0.7.5-polish.1 — Product Polish Candidate

This is the **current continuation checkpoint**. It supersedes v0.7.4-alpha.3 for new work while preserving all prior architectural freezes. The user chose to complete the existing product-polish backlog before opening another major module.

Authoritative backlog implemented in this candidate:

```text
#001 Workspace — Schema 14/10 / false Needs attention
#002 Overview — Arena panel replaced by Quick Notes
#003 Workspace — Reset settings
#004 Workspace — Recovery Restore
#005 Manuscript & Lore — default View Mode + explicit Edit
#006 Atlas — manual world map drawing
#007 Atlas — Location deletion
#008 Atlas — generated map quality pass
#009 Atlas — pin/icon scaling + zoom-aware visibility
#010 Atlas — empty-state / Create first map UX
```

Important v0.7.5 boundaries:
- `LATEST_SCHEMA_VERSION = 14`; do not reintroduce a separate Workspace expected-schema constant.
- Overview may summarize Quick Notes, but Combat remains a separate dedicated system.
- Reset Settings persists `AppSettings::default()`; it is not a UI-only reset.
- Recovery Restore must stage + validate the selected SQLite artifact and create a pre-restore safety snapshot before active-database replacement.
- Existing Manuscript Chapters and Lore Pages are read-first; new records may open directly in Edit.
- Manual Atlas drawing modifies map terrain only; it must not fabricate canonical Locations.
- Location deletion is transactional and explicitly cleans/detaches dependent Atlas projections.
- Generator remains pure/deterministic and non-canonical before Accept. v0.7.5 raises coastline sampling to 256 and adds more silhouette variation.
- Pin screen-legibility/label visibility is a frontend camera concern, not canonical map state.
- Zero-map Atlas projects must present an actionable first-map workflow.

Manifest version: `0.7.5-polish.1`.

Verification status at packaging time:
- TypeScript strict + Python architecture/domain/UI invariant suites: run in the packaging environment.
- New `tests/v0_7_5_polish_invariants.py` covers #001–#010 source contracts.
- Production Vite build requires local dependencies; native Cargo tests require the Windows/Rust toolchain.
- Before promotion, run `V0_7_5_WINDOWS_SMOKE_TEST.md`.

When starting a new conversation, treat the **latest source tree as authoritative**, then read this section and `V0_7_5_POLISH.md`. Do not fall back to the historical v0.6 handoff checkpoint.

