# v0.7.4-alpha.3 Windows Smoke Test — Generator Quality

Run from the extracted source folder in PowerShell:

```powershell
npm.cmd install
npm.cmd run verify
npm.cmd run build
cargo test --manifest-path .\src-tauri\Cargo.toml
npm.cmd run tauri:dev
```

## Visual generator checks

Open **Atlas -> Generator**.

Use this baseline first:

```text
Seed:        482193
Continents:  3
Ocean:       55%
Mountains:   55
Rivers:      6
Settlements: 12
```

Confirm:

1. Generate twice with the exact same settings. The complete map must be identical.
2. Coastlines should be smooth and irregular, with visible bays / peninsulas rather than 18-sided polygons.
3. Rivers should originate inland / around mountain ranges and reach a coast or another river. They must not all drift downward.
4. Settlements must be on land and should not form one tight centroid cluster.
5. Cities, towns and villages must use visibly different marker sizes/shapes.
6. Cities/towns should often appear near rivers or useful coastal areas; villages can be more distributed.
7. Settlement names in one draft should not duplicate.
8. Before **Accept into World**, Maps/Locations counts must not change.
9. Accept with generated locations enabled. Reopen the resulting Atlas map and verify city/town/village pin visual differences remain.
10. Existing maps created with v0.7.4-alpha.1/alpha.2 must still open.

## Stress samples

Also try several seeds, not just the baseline:

```text
11883
991271
20480017
```

Try:

- 1 continent / high ocean,
- 5 continents / medium ocean,
- 0 mountains + several rivers,
- 0 rivers + 20 settlements,
- 30 rivers / 80 settlements.

The application must remain responsive and generated points must stay on/inside valid land where applicable.

## Native quality assertions

`cargo test` now additionally checks that generated coastlines use high-resolution geometry, generated settlement names are unique, settlements are on land and non-stacked for the fixture, primary cities exist when capacity allows, and accepted city pins preserve the city visual kind.
