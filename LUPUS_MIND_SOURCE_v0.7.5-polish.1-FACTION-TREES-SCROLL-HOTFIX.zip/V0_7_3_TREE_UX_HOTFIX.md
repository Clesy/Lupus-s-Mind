# v0.7.3-alpha.4 — Faction Tree UX Hotfix

## Scope

This checkpoint changes presentation only. The hierarchy/lineage schema and temporal rules from migration 013 remain unchanged.

### Faction Hierarchy

- Role offices render as a true node/connector SVG tree.
- Parent office -> child office is shown spatially instead of as an indented card list.
- Each node shows tier, capacity, role name, and current office holder(s) at the selected chapter.
- Clicking a role node opens the existing inspector for edit, assignment, capacity, term ending, and deletion.
- Vacant offices use a dashed node boundary.

### Lineages

- The card gallery is replaced by a tree-first view.
- A lineage is selected from the toolbar.
- Tree semantics are: `Lineage -> Branch -> Members`.
- Member title and joined chapter appear on member nodes.
- This tree does **not** invent kinship. Parent/spouse/sibling family relations remain canonical temporal Relationship records and continue to be visualized in Relationships -> Family Tree.

### Deliberate non-change

The Factions directory itself remains a card directory because the current domain model has no canonical parent/subfaction relation. A fake faction tree is not generated. A future vassal/subfaction model may provide a real faction-to-faction tree.

## Architecture

`FactionScreen` remains Gateway-only. No direct `invoke()` was introduced. No DB migration or Rust domain change is required.
