import "./styles/globals.css";
import "./styles/shell.css";
import "./styles/dashboard.css";
import "./styles/characters.css";
import "./styles/items.css";
import "./styles/skills.css";
import "./styles/relationships.css";
import "./styles/timeline.css";
import "./styles/combat.css";
import "./styles/generators.css";
import "./styles/workspace.css";
import "./styles/manuscript.css";
import "./styles/lore.css";
import "./styles/world-systems.css";
import "./styles/atlas.css";
import { AppShell } from "./AppShell";
import { tauriCharacterGateway } from "./modules/characters/infrastructure/TauriCharacterGateway";
import { tauriEquipmentGateway } from "./modules/equipment/infrastructure/TauriEquipmentGateway";
import { tauriItemGateway } from "./modules/items/infrastructure/TauriItemGateway";
import { tauriSkillGateway } from "./modules/skills/infrastructure/TauriSkillGateway";
import { tauriRelationshipGateway } from "./modules/relationships/infrastructure/TauriRelationshipGateway";
import { tauriTimelineGateway } from "./modules/timeline/infrastructure/TauriTimelineGateway";
import { tauriCombatGateway } from "./modules/combat/infrastructure/TauriCombatGateway";
import { tauriCombatReplayGateway } from "./modules/combat_replay/infrastructure/TauriCombatReplayGateway";
import { tauriStatusEffectGateway } from "./modules/status_effects/infrastructure/TauriStatusEffectGateway";
import { tauriGeneratorGateway } from "./modules/creative_generators/infrastructure/TauriGeneratorGateway";
import { tauriWorkspaceGateway } from "./modules/workspace/infrastructure/TauriWorkspaceGateway";
import { tauriProjectGateway } from "./modules/projects/infrastructure/TauriProjectGateway";
import { tauriSearchGateway } from "./modules/global_search/infrastructure/TauriSearchGateway";
import { tauriManuscriptGateway } from "./modules/manuscript/infrastructure/TauriManuscriptGateway";
import { tauriAssetGateway } from "./modules/assets/infrastructure/TauriAssetGateway";
import { tauriLoreGateway } from "./modules/lore/infrastructure/TauriLoreGateway";
import { tauriKnowledgeLinkGateway } from "./modules/knowledge_links/infrastructure/TauriKnowledgeLinkGateway";
import { tauriAuthoringGateway } from "./modules/authoring/infrastructure/TauriAuthoringGateway";
import { tauriFactionGateway } from "./modules/factions/infrastructure/TauriFactionGateway";
import { tauriInventoryGateway } from "./modules/inventory/infrastructure/TauriInventoryGateway";
import { tauriQuestGateway } from "./modules/quests/infrastructure/TauriQuestGateway";
import { tauriSecretGateway } from "./modules/secrets/infrastructure/TauriSecretGateway";
import { tauriAtlasGateway } from "./modules/atlas/infrastructure/TauriAtlasGateway";

const app=document.querySelector<HTMLElement>("#app");
if(!app)throw new Error("#app missing");

void new AppShell(
  app,
  tauriItemGateway,
  tauriCharacterGateway,
  tauriEquipmentGateway,
  tauriSkillGateway,
  tauriStatusEffectGateway,
  tauriRelationshipGateway,
  tauriTimelineGateway,
  tauriCombatGateway,
  tauriCombatReplayGateway,
  tauriGeneratorGateway,
  tauriWorkspaceGateway,
  tauriProjectGateway,
  tauriSearchGateway,
  tauriManuscriptGateway,
  tauriAssetGateway,
  tauriLoreGateway,
  tauriKnowledgeLinkGateway,
  tauriAuthoringGateway,
  tauriFactionGateway,
  tauriInventoryGateway,
  tauriQuestGateway,
  tauriSecretGateway,
  tauriAtlasGateway,
).render();
