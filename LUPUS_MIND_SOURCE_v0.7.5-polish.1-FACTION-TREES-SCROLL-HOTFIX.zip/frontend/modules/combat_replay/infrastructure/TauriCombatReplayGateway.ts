import {invoke} from "@tauri-apps/api/core";
import type {CombatReplayGateway,ReplayFrame,ReplayVerification,TurnExecutionSummary} from "../application/CombatReplayGateway";
export const tauriCombatReplayGateway:CombatReplayGateway={
  start:(sessionId)=>invoke<ReplayFrame>("combat_replay_start",{sessionId}),
  atSequence:(sessionId,sequence)=>invoke<ReplayFrame>("combat_replay_at_sequence",{sessionId,sequence}),
  atExecution:(sessionId,executionId)=>invoke<ReplayFrame>("combat_replay_at_execution",{sessionId,executionId}),
  latest:(sessionId)=>invoke<ReplayFrame>("combat_replay_latest",{sessionId}),
  turns:(sessionId)=>invoke<TurnExecutionSummary[]>("combat_replay_turns",{sessionId}),
  verifyLatest:(sessionId)=>invoke<ReplayVerification>("combat_replay_verify_latest",{sessionId}),
};
