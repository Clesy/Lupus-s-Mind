import type { CombatAction,CombatSession,CombatantDto } from "../../combat/application/CombatGateway";
export type ReplayStatus=CombatSession["status"];
export interface CombatReplayState{sessionId:string;status:ReplayStatus;rngSeed:number;roundNumber:number;turnIndex:number;nextActionSequence:number;combatants:CombatantDto[];}
export interface TurnExecutionSummary{id:string;roundNumber:number;turnIndex:number;actorCombatantId:string;firstSequence:number;lastSequence:number;actionCount:number;createdAt:string;}
export interface ReplayFrame{state:CombatReplayState;originSequence:number;requestedSequence:number;resolvedSequence:number;turnExecution:TurnExecutionSummary|null;actions:CombatAction[];isLatest:boolean;latestSequence:number;fingerprint:string;}
export interface ReplayVerification{matchesLive:boolean;replayFingerprint:string;liveFingerprint:string;latestSequence:number;}
export interface CombatReplayGateway{
  start(sessionId:string):Promise<ReplayFrame>;
  atSequence(sessionId:string,sequence:number):Promise<ReplayFrame>;
  atExecution(sessionId:string,executionId:string):Promise<ReplayFrame>;
  latest(sessionId:string):Promise<ReplayFrame>;
  turns(sessionId:string):Promise<TurnExecutionSummary[]>;
  verifyLatest(sessionId:string):Promise<ReplayVerification>;
}
