import { invoke } from "@tauri-apps/api/core";
import type {
  ChangeRelationshipStateInput, CreateRelationshipInput, EndRelationshipInput, PerspectiveRelationshipDto,
  RelationshipDto, RelationshipGateway, RelationshipGraphSnapshotDto, RelationshipHistoryDto,
  RelationshipMatrixSnapshotDto, RelationshipStateDto, RelationshipTypeDto, ReopenRelationshipInput,
} from "../application/RelationshipGateway";

export const tauriRelationshipGateway:RelationshipGateway = {
  listTypes:()=>invoke<RelationshipTypeDto[]>("relationship_types_list"),
  create:(input:CreateRelationshipInput)=>invoke<RelationshipDto>("relationships_create",{input}),
  changeState:(input:ChangeRelationshipStateInput)=>invoke<RelationshipStateDto>("relationships_change_state",{input}),
  end:(input:EndRelationshipInput)=>invoke<void>("relationships_end",{input}),
  reopen:(input:ReopenRelationshipInput)=>invoke<RelationshipStateDto>("relationships_reopen",{input}),
  getAt:(id:string,chapter:number)=>invoke<RelationshipDto|null>("relationships_get_at",{id,chapter}),
  listForCharacterAt:(characterId:string,chapter:number)=>invoke<PerspectiveRelationshipDto[]>("relationships_for_character_at",{characterId,chapter}),
  history:(id:string)=>invoke<RelationshipHistoryDto>("relationships_history",{id}),
  graphAt:(chapter:number)=>invoke<RelationshipGraphSnapshotDto>("relationships_graph_at",{chapter}),
  matrixAt:(chapter:number)=>invoke<RelationshipMatrixSnapshotDto>("relationships_matrix_at",{chapter}),
};
