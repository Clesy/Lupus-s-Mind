export type Directionality = "directed" | "symmetric";

export interface RelationshipTypeDto {
  id:string; key:string; forwardLabel:string; inverseLabel:string;
  directionality:Directionality; category:string;
}
export interface RelationshipStateDto {
  id:string; validFromChapter:number; validToChapter:number|null;
  intensity:number; note:string; tags:string[];
}
export interface RelationshipDto {
  id:string; typeId:string; sourceCharacterId:string; targetCharacterId:string; state:RelationshipStateDto;
}
export interface PerspectiveRelationshipDto {
  id:string; typeId:string; typeKey:string; otherCharacterId:string; label:string;
  outbound:boolean; directionality:Directionality; state:RelationshipStateDto;
}
export interface TransitionDto {
  id:string; chapter:number; kind:"created"|"state_changed"|"ended"|"reopened";
  beforeStateId:string|null; afterStateId:string|null; createdAt:string;
}
export interface RelationshipHistoryDto { relationshipId:string; typeId:string; sourceCharacterId:string; targetCharacterId:string; states:RelationshipStateDto[]; transitions:TransitionDto[]; }
export interface RelationshipNodeDto { id:string; name:string; alias:string|null; level:number; classLabel:string|null; }
export interface RelationshipEdgeDto {
  relationshipId:string; typeId:string; typeKey:string; sourceCharacterId:string; targetCharacterId:string;
  forwardLabel:string; inverseLabel:string; directionality:Directionality; intensity:number; note:string;
  validFromChapter:number; validToChapter:number|null;
}
export interface RelationshipGraphSnapshotDto { chapter:number; nodes:RelationshipNodeDto[]; edges:RelationshipEdgeDto[]; }
export interface RelationshipMatrixCellDto { rowCharacterId:string; columnCharacterId:string; relationshipId:string; label:string; intensity:number; typeKey:string; }
export interface RelationshipMatrixSnapshotDto { chapter:number; nodes:RelationshipNodeDto[]; cells:RelationshipMatrixCellDto[]; }

export interface CreateRelationshipInput { typeId:string; sourceCharacterId:string; targetCharacterId:string; chapter:number; intensity:number; note?:string; tags:string[]; }
export interface ChangeRelationshipStateInput { relationshipId:string; chapter:number; intensity:number; note?:string; tags:string[]; }
export interface EndRelationshipInput { relationshipId:string; chapter:number; }
export interface ReopenRelationshipInput { relationshipId:string; chapter:number; intensity:number; note?:string; tags:string[]; }

export interface RelationshipGateway {
  listTypes():Promise<RelationshipTypeDto[]>;
  create(input:CreateRelationshipInput):Promise<RelationshipDto>;
  changeState(input:ChangeRelationshipStateInput):Promise<RelationshipStateDto>;
  end(input:EndRelationshipInput):Promise<void>;
  reopen(input:ReopenRelationshipInput):Promise<RelationshipStateDto>;
  getAt(id:string,chapter:number):Promise<RelationshipDto|null>;
  listForCharacterAt(characterId:string,chapter:number):Promise<PerspectiveRelationshipDto[]>;
  history(id:string):Promise<RelationshipHistoryDto>;
  graphAt(chapter:number):Promise<RelationshipGraphSnapshotDto>;
  matrixAt(chapter:number):Promise<RelationshipMatrixSnapshotDto>;
}
