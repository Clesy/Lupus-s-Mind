import type { RelationshipGraphSnapshotDto } from "../application/RelationshipGateway";

const esc=(v:string)=>v.replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;");

export class RelationshipGraphView {
  constructor(private readonly onEdge:(id:string)=>void, private readonly onNode:(id:string)=>void) {}
  render(host:HTMLElement,snapshot:RelationshipGraphSnapshotDto):void {
    const width=900,height=620,cx=width/2,cy=height/2,radius=Math.min(width,height)*0.34;
    const pos=new Map<string,{x:number;y:number}>();
    snapshot.nodes.forEach((node,index)=>{const angle=-Math.PI/2+(Math.PI*2*index/Math.max(snapshot.nodes.length,1));pos.set(node.id,{x:cx+Math.cos(angle)*radius,y:cy+Math.sin(angle)*radius});});
    const edges=snapshot.edges.map((edge)=>{const a=pos.get(edge.sourceCharacterId),b=pos.get(edge.targetCharacterId);if(!a||!b)return "";const marker=edge.directionality==="directed"?' marker-end="url(#arrow)"':"";return `<g class="graph-edge" data-edge="${esc(edge.relationshipId)}"><line x1="${a.x}" y1="${a.y}" x2="${b.x}" y2="${b.y}"${marker}/><text x="${(a.x+b.x)/2}" y="${(a.y+b.y)/2-8}">${esc(edge.forwardLabel)} · ${edge.intensity}</text></g>`;}).join("");
    const nodes=snapshot.nodes.map((node)=>{const p=pos.get(node.id)!;return `<g class="graph-node" data-node="${esc(node.id)}" transform="translate(${p.x},${p.y})"><circle r="42"/><text class="node-name" text-anchor="middle" y="2">${esc(node.name)}</text><text class="node-meta" text-anchor="middle" y="18">Lv ${node.level}</text></g>`;}).join("");
    host.innerHTML=`<div class="graph-stage"><svg viewBox="0 0 ${width} ${height}" role="img" aria-label="Relationship graph at chapter ${snapshot.chapter}"><defs><marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z"/></marker></defs>${edges}${nodes}</svg>${snapshot.edges.length?"":'<div class="projection-empty">No active relationships at this chapter.</div>'}</div>`;
    host.querySelectorAll<SVGGElement>("[data-edge]").forEach((el)=>el.addEventListener("click",()=>this.onEdge(el.dataset.edge!)));
    host.querySelectorAll<SVGGElement>("[data-node]").forEach((el)=>el.addEventListener("click",()=>this.onNode(el.dataset.node!)));
  }
}
