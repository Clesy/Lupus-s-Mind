import type { CharacterGateway, CharacterSummaryDto } from "../../characters/application/CharacterGateway";
import type { RelationshipGateway, RelationshipTypeDto } from "../application/RelationshipGateway";
import { RelationshipEditor } from "./RelationshipEditor";
import { RelationshipGraphView } from "./RelationshipGraphView";
import { FamilyTreeView } from "./FamilyTreeView";
import { RelationshipInspector } from "./RelationshipInspector";
import { RelationshipMatrixView } from "./RelationshipMatrixView";

type ViewMode="graph"|"matrix"|"family";
const esc=(v:string)=>v.replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;");
export class RelationshipScreen {
  private chapter=1;private mode:ViewMode="graph";private selectedRelationshipId:string|null=null;private selectedCharacterId:string|null=null;private characters:CharacterSummaryDto[]=[];private types:RelationshipTypeDto[]=[];private inspector:RelationshipInspector|null=null;
  constructor(private readonly root:HTMLElement,private readonly gateway:RelationshipGateway,private readonly characterGateway:CharacterGateway){}
  async render():Promise<void>{
    [this.characters,this.types]=await Promise.all([this.characterGateway.list(),this.gateway.listTypes()]);
    this.root.innerHTML=`<div class="relationship-screen"><aside class="relationship-sidebar"><div class="module-title"><div><span class="eyebrow">R1 · temporal graph</span><h1>Relationships</h1></div><button class="btn primary" data-new>＋ New</button></div><div class="chapter-box"><label>Chapter<input data-chapter type="number" min="1" value="${this.chapter}"></label></div><div class="section-label">Characters</div><div class="relationship-character-list">${this.characters.map(c=>`<button data-character="${esc(c.id)}"><strong>${esc(c.name)}</strong><span>${esc(c.classLabel??"Unassigned")}</span></button>`).join("")}</div></aside><main class="relationship-workspace"><header class="projection-toolbar"><div class="segmented"><button class="active" data-mode="graph">Graph</button><button data-mode="matrix">Matrix</button><button data-mode="family">Family Tree</button></div><div class="projection-meta" data-meta></div></header><div class="projection-host" data-projection></div></main><aside class="relationship-inspector-host" data-inspector></aside></div>`;
    const inspectorHost=this.root.querySelector<HTMLElement>("[data-inspector]")!;this.inspector=new RelationshipInspector(inspectorHost,this.gateway,this.characters,this.types,()=>void this.refreshAfterMutation());this.inspector.empty();
    this.root.querySelector<HTMLInputElement>("[data-chapter]")?.addEventListener("change",(e)=>{this.chapter=Math.max(1,Number((e.currentTarget as HTMLInputElement).value)||1);void this.paintProjection();if(this.selectedRelationshipId)void this.inspector?.show(this.selectedRelationshipId,this.chapter);});
    this.root.querySelector<HTMLButtonElement>("[data-new]")?.addEventListener("click",()=>this.openEditor());
    this.root.querySelectorAll<HTMLButtonElement>("[data-mode]").forEach(btn=>btn.addEventListener("click",()=>{this.mode=btn.dataset.mode as ViewMode;this.root.querySelectorAll("[data-mode]").forEach(n=>n.classList.remove("active"));btn.classList.add("active");void this.paintProjection();}));
    this.root.querySelectorAll<HTMLButtonElement>("[data-character]").forEach(btn=>btn.addEventListener("click",()=>{this.selectedCharacterId=btn.dataset.character!;this.root.querySelectorAll("[data-character]").forEach(n=>n.classList.remove("active"));btn.classList.add("active");void this.paintCharacterContext();}));
    await this.paintProjection();
  }
  private async paintProjection():Promise<void>{
    const host=this.root.querySelector<HTMLElement>("[data-projection]")!,meta=this.root.querySelector<HTMLElement>("[data-meta]")!;
    if(this.mode==="graph"){const snapshot=await this.gateway.graphAt(this.chapter);meta.textContent=`${snapshot.nodes.length} nodes · ${snapshot.edges.length} active edges · Ch. ${snapshot.chapter}`;new RelationshipGraphView((id)=>this.selectRelationship(id),(id)=>{this.selectedCharacterId=id;void this.paintCharacterContext();}).render(host,snapshot);}else if(this.mode==="family"){const snapshot=await this.gateway.graphAt(this.chapter);const familyEdges=snapshot.edges.filter(e=>["parent","adoptive_parent","spouse","betrothed","sibling"].includes(e.typeKey));meta.textContent=`${familyEdges.length} family links · Ch. ${snapshot.chapter}`;new FamilyTreeView((id)=>this.selectRelationship(id),(id)=>{this.selectedCharacterId=id;void this.paintCharacterContext();}).render(host,snapshot);}else{const snapshot=await this.gateway.matrixAt(this.chapter);meta.textContent=`${snapshot.nodes.length} × ${snapshot.nodes.length} matrix · Ch. ${snapshot.chapter}`;new RelationshipMatrixView((id)=>this.selectRelationship(id)).render(host,snapshot);}
  }
  private async paintCharacterContext():Promise<void>{if(!this.selectedCharacterId)return;const rows=await this.gateway.listForCharacterAt(this.selectedCharacterId,this.chapter);const name=this.characters.find(c=>c.id===this.selectedCharacterId)?.name??"Character";const host=this.root.querySelector<HTMLElement>("[data-inspector]")!;host.innerHTML=`<div class="character-context"><span class="eyebrow">${esc(name)} · Chapter ${this.chapter}</span><h3>Active relationships</h3>${rows.length?rows.map(r=>`<button data-rel="${r.id}"><span>${esc(r.label)}</span><strong>${r.state.intensity}</strong></button>`).join(""):'<div class="empty-note">No active relationships.</div>'}</div>`;host.querySelectorAll<HTMLButtonElement>("[data-rel]").forEach(btn=>btn.addEventListener("click",()=>this.selectRelationship(btn.dataset.rel!)));}
  private selectRelationship(id:string):void{this.selectedRelationshipId=id;void this.inspector?.show(id,this.chapter);}
  private openEditor():void{const host=this.root.querySelector<HTMLElement>("[data-inspector]")!;new RelationshipEditor(this.gateway).mount(host,this.characters,this.types,this.chapter,(id)=>{this.selectedRelationshipId=id;void this.refreshAfterMutation();},()=>this.inspector?.empty());}
  private async refreshAfterMutation():Promise<void>{await this.paintProjection();if(this.selectedRelationshipId)await this.inspector?.show(this.selectedRelationshipId,this.chapter);}
}
