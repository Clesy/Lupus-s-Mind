import type { RelationshipMatrixSnapshotDto } from "../application/RelationshipGateway";
const esc=(v:string)=>v.replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;");
export class RelationshipMatrixView {
  constructor(private readonly onCell:(id:string)=>void){}
  render(host:HTMLElement,snapshot:RelationshipMatrixSnapshotDto):void{
    const map=new Map(snapshot.cells.map((c)=>[`${c.rowCharacterId}::${c.columnCharacterId}`,c]));
    const head=snapshot.nodes.map((n)=>`<th>${esc(n.name)}</th>`).join("");
    const rows=snapshot.nodes.map((row)=>`<tr><th>${esc(row.name)}</th>${snapshot.nodes.map((col)=>{if(row.id===col.id)return '<td class="matrix-self">—</td>';const cell=map.get(`${row.id}::${col.id}`);return cell?`<td><button class="matrix-cell" data-rel="${cell.relationshipId}"><span>${esc(cell.label)}</span><strong>${cell.intensity}</strong></button></td>`:'<td class="matrix-empty">·</td>';}).join("")}</tr>`).join("");
    host.innerHTML=`<div class="matrix-wrap"><table class="relationship-matrix"><thead><tr><th></th>${head}</tr></thead><tbody>${rows}</tbody></table></div>`;
    host.querySelectorAll<HTMLButtonElement>("[data-rel]").forEach((el)=>el.addEventListener("click",()=>this.onCell(el.dataset.rel!)));
  }
}
