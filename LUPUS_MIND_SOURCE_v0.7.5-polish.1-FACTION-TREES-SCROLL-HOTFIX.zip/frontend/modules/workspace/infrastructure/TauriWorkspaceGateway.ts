import { invoke } from "@tauri-apps/api/core";
import type { AppSettings, DatabaseHealth, WorkspaceArtifact, WorkspaceGateway } from "../application/WorkspaceGateway";

export const tauriWorkspaceGateway: WorkspaceGateway = {
  health: () => invoke<DatabaseHealth>("workspace_health"),
  settings: () => invoke<AppSettings>("workspace_settings_get"),
  saveSettings: (settings) => invoke<AppSettings>("workspace_settings_save", { settings }),
  resetSettings: () => invoke<AppSettings>("workspace_settings_reset"),
  createBackup: () => invoke<WorkspaceArtifact>("workspace_backup_create"),
  exportJson: () => invoke<WorkspaceArtifact>("workspace_export_json"),
  listArtifacts: () => invoke<WorkspaceArtifact[]>("workspace_artifacts_list"),
  restoreArtifact: (path) => invoke<DatabaseHealth>("workspace_artifact_restore", { path }),
};
