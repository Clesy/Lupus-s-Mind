export interface AppSettings {
  compactNavigation: boolean;
  reduceMotion: boolean;
  confirmDestructiveActions: boolean;
  restoreLastRoute: boolean;
  defaultGeneratorCount: number;
}

export interface DatabaseHealth {
  status: "healthy" | "attention";
  quickCheck: string;
  foreignKeyViolations: number;
  schemaVersion: number;
  expectedSchemaVersion: number;
  databaseSizeBytes: number;
  databasePath: string;
  backupCount: number;
}

export interface WorkspaceArtifact {
  name: string;
  kind: "sqlite-backup" | "json-export" | "recovery-point" | string;
  path: string;
  sizeBytes: number;
  modifiedAt: string;
}

export interface WorkspaceGateway {
  health(): Promise<DatabaseHealth>;
  settings(): Promise<AppSettings>;
  saveSettings(settings: AppSettings): Promise<AppSettings>;
  resetSettings(): Promise<AppSettings>;
  createBackup(): Promise<WorkspaceArtifact>;
  exportJson(): Promise<WorkspaceArtifact>;
  listArtifacts(): Promise<WorkspaceArtifact[]>;
  restoreArtifact(path: string): Promise<DatabaseHealth>;
}
