import type { AppSettings, DatabaseHealth, WorkspaceArtifact, WorkspaceGateway } from "../application/WorkspaceGateway";

export class WorkspaceScreen {
  private settings: AppSettings | null = null;
  private health: DatabaseHealth | null = null;
  private artifacts: WorkspaceArtifact[] = [];

  constructor(
    private readonly host: HTMLElement,
    private readonly gateway: WorkspaceGateway,
    private readonly onSettingsChanged: (settings: AppSettings) => void,
  ) {}

  async render(): Promise<void> {
    const [settings, health, artifacts] = await Promise.all([
      this.gateway.settings(),
      this.gateway.health(),
      this.gateway.listArtifacts(),
    ]);
    this.settings = settings;
    this.health = health;
    this.artifacts = artifacts;
    this.draw();
  }

  private draw(): void {
    if (!this.settings || !this.health) return;
    const h = this.health;
    this.host.innerHTML = `
      <section class="workspace-screen">
        <header class="module-title">
          <div><span class="eyebrow">Desktop hardening</span><h1>Workspace & Settings</h1><p>Health, durable backups, portable exports and local application preferences.</p></div>
          <div class="workspace-health-badge ${h.status}"><span></span>${h.status === "healthy" ? "Database healthy" : "Needs attention"}</div>
        </header>
        <div class="workspace-grid">
          <section class="workspace-card health-card">
            <div class="card-heading"><div><span class="eyebrow">Database</span><h2>Workspace health</h2></div><button class="btn ghost" data-action="refresh-health">Recheck</button></div>
            <div class="health-metrics">
              ${this.metric("Quick check", h.quickCheck)}
              ${this.metric("Foreign-key issues", String(h.foreignKeyViolations))}
              ${this.metric("Schema", `${h.schemaVersion} / ${h.expectedSchemaVersion}`)}
              ${this.metric("Database size", this.bytes(h.databaseSizeBytes))}
              ${this.metric("Recovery / backups", String(h.backupCount))}
            </div>
            <div class="workspace-path"><span>Local database</span><code data-role="database-path"></code></div>
          </section>
          <section class="workspace-card">
            <div class="card-heading"><div><span class="eyebrow">Safety</span><h2>Backup & export</h2></div></div>
            <p class="workspace-help">SQLite backup is a consistent database snapshot. JSON export is portable and human-inspectable. Neither operation mutates canon.</p>
            <div class="workspace-actions"><button class="btn primary" data-action="backup">Create SQLite backup</button><button class="btn ghost" data-action="export">Export workspace JSON</button></div>
            <div class="workspace-operation" data-role="operation-status" aria-live="polite"></div>
          </section>
          <section class="workspace-card settings-card">
            <div class="card-heading"><div><span class="eyebrow">Preferences</span><h2>Studio settings</h2></div></div>
            ${this.toggle("compact-navigation", "Compact navigation", "Reduce sidebar density for larger workspaces.", this.settings.compactNavigation)}
            ${this.toggle("reduce-motion", "Reduce motion", "Disable route spinners and non-essential interface animation.", this.settings.reduceMotion)}
            ${this.toggle("confirm-destructive", "Confirm destructive actions", "Keep an explicit confirmation boundary for delete operations.", this.settings.confirmDestructiveActions)}
            ${this.toggle("restore-route", "Restore last module", "Open the last visited module when the app starts.", this.settings.restoreLastRoute)}
            <label class="setting-number"><span><strong>Generator default count</strong><small>Default number of creative candidates.</small></span><input type="number" min="1" max="50" data-setting="generator-count" value="${this.settings.defaultGeneratorCount}"></label>
            <div class="settings-footer"><span data-role="settings-status"></span><button class="btn ghost" data-action="reset-settings">Reset defaults</button><button class="btn primary" data-action="save-settings">Save settings</button></div>
          </section>
          <section class="workspace-card artifacts-card">
            <div class="card-heading"><div><span class="eyebrow">Recovery</span><h2>Workspace artifacts</h2></div><button class="btn ghost" data-action="refresh-artifacts">Refresh</button></div>
            <div class="artifact-list" data-role="artifact-list"></div>
          </section>
        </div>
      </section>`;
    const path = this.host.querySelector<HTMLElement>('[data-role="database-path"]');
    if (path) path.textContent = h.databasePath;
    this.renderArtifacts();
    this.bind();
  }

  private bind(): void {
    this.host.querySelector('[data-action="refresh-health"]')?.addEventListener("click", () => void this.refreshHealth());
    this.host.querySelector('[data-action="refresh-artifacts"]')?.addEventListener("click", () => void this.refreshArtifacts());
    this.host.querySelector('[data-action="backup"]')?.addEventListener("click", () => void this.createArtifact("backup"));
    this.host.querySelector('[data-action="export"]')?.addEventListener("click", () => void this.createArtifact("export"));
    this.host.querySelector('[data-action="save-settings"]')?.addEventListener("click", () => void this.saveSettings());
    this.host.querySelector('[data-action="reset-settings"]')?.addEventListener("click", () => void this.resetSettings());
  }

  private async refreshHealth(): Promise<void> { this.health = await this.gateway.health(); this.draw(); }
  private async refreshArtifacts(): Promise<void> { this.artifacts = await this.gateway.listArtifacts(); this.renderArtifacts(); }

  private async createArtifact(kind: "backup" | "export"): Promise<void> {
    const status = this.host.querySelector<HTMLElement>('[data-role="operation-status"]');
    if (status) status.textContent = kind === "backup" ? "Creating consistent SQLite snapshot…" : "Exporting workspace…";
    try {
      const artifact = kind === "backup" ? await this.gateway.createBackup() : await this.gateway.exportJson();
      if (status) status.textContent = `${artifact.name} · ${this.bytes(artifact.sizeBytes)}`;
      await this.refreshArtifacts();
      this.health = await this.gateway.health();
    } catch (error) {
      if (status) status.textContent = `Operation failed: ${String(error)}`;
    }
  }

  private async resetSettings(): Promise<void> {
    const status = this.host.querySelector<HTMLElement>('[data-role="settings-status"]');
    if (status) status.textContent = "Resetting…";
    try {
      this.settings = await this.gateway.resetSettings();
      this.onSettingsChanged(this.settings);
      this.draw();
      const nextStatus = this.host.querySelector<HTMLElement>('[data-role="settings-status"]');
      if (nextStatus) nextStatus.textContent = "Defaults restored";
    } catch (error) {
      if (status) status.textContent = `Could not reset: ${String(error)}`;
    }
  }

  private async saveSettings(): Promise<void> {
    if (!this.settings) return;
    const checkbox = (key: string) => this.host.querySelector<HTMLInputElement>(`[data-setting="${key}"]`)?.checked ?? false;
    const count = Number(this.host.querySelector<HTMLInputElement>('[data-setting="generator-count"]')?.value ?? 8);
    const next: AppSettings = {
      compactNavigation: checkbox("compact-navigation"),
      reduceMotion: checkbox("reduce-motion"),
      confirmDestructiveActions: checkbox("confirm-destructive"),
      restoreLastRoute: checkbox("restore-route"),
      defaultGeneratorCount: Math.max(1, Math.min(50, count)),
    };
    const status = this.host.querySelector<HTMLElement>('[data-role="settings-status"]');
    try {
      this.settings = await this.gateway.saveSettings(next);
      this.onSettingsChanged(this.settings);
      if (status) status.textContent = "Saved";
    } catch (error) {
      if (status) status.textContent = `Could not save: ${String(error)}`;
    }
  }

  private renderArtifacts(): void {
    const list = this.host.querySelector<HTMLElement>('[data-role="artifact-list"]');
    if (!list) return;
    if (this.artifacts.length === 0) {
      list.innerHTML = `<div class="artifact-empty"><strong>No recovery artifacts yet</strong><span>A pre-migration recovery point is created automatically before a schema upgrade. Manual backups appear here too.</span></div>`;
      return;
    }
    list.innerHTML = this.artifacts.slice(0, 12).map((artifact) => `
      <article class="artifact-row"><span class="artifact-kind">${this.artifactLabel(artifact.kind)}</span><div><strong></strong><small>${this.bytes(artifact.sizeBytes)} · ${new Date(artifact.modifiedAt).toLocaleString()}</small></div><code></code>${artifact.kind === "json-export" ? "" : '<button class="btn ghost small" data-restore-artifact>Restore</button>'}</article>`).join("");
    this.artifacts.slice(0, 12).forEach((artifact, index) => {
      const row = list.children.item(index) as HTMLElement | null;
      const strong = row?.querySelector("strong"); const code = row?.querySelector("code");
      if (strong) strong.textContent = artifact.name;
      if (code) code.textContent = artifact.path;
      row?.querySelector<HTMLButtonElement>("[data-restore-artifact]")?.addEventListener("click", () => void this.restoreArtifact(artifact));
    });
  }

  private async restoreArtifact(artifact: WorkspaceArtifact): Promise<void> {
    if (!confirm(`Restore workspace from “${artifact.name}”?\n\nA fresh safety snapshot will be created automatically before replacement.`)) return;
    const status = this.host.querySelector<HTMLElement>('[data-role="operation-status"]');
    if (status) status.textContent = `Restoring ${artifact.name}…`;
    try {
      this.health = await this.gateway.restoreArtifact(artifact.path);
      this.settings = await this.gateway.settings();
      this.onSettingsChanged(this.settings);
      this.artifacts = await this.gateway.listArtifacts();
      this.draw();
      const nextStatus = this.host.querySelector<HTMLElement>('[data-role="operation-status"]');
      if (nextStatus) nextStatus.textContent = `Restored ${artifact.name}. Safety snapshot preserved.`;
    } catch (error) {
      if (status) status.textContent = `Restore failed: ${String(error)}`;
    }
  }

  private metric(label: string, value: string): string { return `<div class="health-metric"><span>${label}</span><strong>${value}</strong></div>`; }
  private toggle(key: string, title: string, help: string, checked: boolean): string { return `<label class="setting-toggle"><span><strong>${title}</strong><small>${help}</small></span><input type="checkbox" data-setting="${key}" ${checked ? "checked" : ""}><i aria-hidden="true"></i></label>`; }
  private bytes(value: number): string { if (value < 1024) return `${value} B`; if (value < 1024 * 1024) return `${(value / 1024).toFixed(1)} KB`; return `${(value / (1024 * 1024)).toFixed(1)} MB`; }
  private artifactLabel(kind: string): string { return kind === "recovery-point" ? "Recovery" : kind === "sqlite-backup" ? "Backup" : kind === "json-export" ? "JSON" : kind; }
}
