import { invoke } from "@tauri-apps/api/core";
import type { TimelineBoundsDto,TimelineEventDto,TimelineEntryDto,TimelineGateway,TimelineProjectionDto,UpsertTimelineEventInput } from "../application/TimelineGateway";
export const tauriTimelineGateway:TimelineGateway={
 create:(input)=>invoke<TimelineEventDto>("timeline_create",{input}),
 update:(id,input)=>invoke<TimelineEventDto>("timeline_update",{id,input}),
 get:(id)=>invoke<TimelineEventDto>("timeline_get",{id}),
 remove:(id)=>invoke<void>("timeline_delete",{id}),
 at:(chapter)=>invoke<TimelineEventDto[]>("timeline_at",{chapter}),
 between:(start,end)=>invoke<TimelineEventDto[]>("timeline_between",{start,end}),
 forCharacter:(characterId,start,end)=>invoke<TimelineEventDto[]>("timeline_for_character",{characterId,start,end}),
 projectionBetween:(start,end)=>invoke<TimelineProjectionDto>("timeline_projection_between",{start,end}),
 characterThread:(characterId)=>invoke<TimelineEntryDto[]>("timeline_character_thread",{characterId}),
 bounds:()=>invoke<TimelineBoundsDto|null>("timeline_bounds"),
};
