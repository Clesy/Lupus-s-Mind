export type TimelineEventKind = "personal"|"conflict"|"political"|"discovery"|"death"|"birth"|"journey"|"alliance"|"betrayal"|"battle"|"catastrophe"|"revelation";
export type EventImportance = "minor"|"standard"|"major"|"critical";
export type TemporalKind = "point"|"span";
export type ParticipantRole = "actor"|"target"|"witness"|"victim"|"beneficiary"|"commander"|"participant";
export type TimelineSourceKind = "relationship_transition"|"manual";
export interface TimelineParticipantInput { characterId:string; role:ParticipantRole }
export interface TimelineSourceInput { sourceKind:TimelineSourceKind; sourceId:string }
export interface UpsertTimelineEventInput { title:string;description?:string;kind:TimelineEventKind;importance:EventImportance;temporalKind:TemporalKind;startChapter:number;endChapter?:number;worldTimeStart?:string;worldTimeEnd?:string;locationLabel?:string;tags:string[];participants:TimelineParticipantInput[];sources:TimelineSourceInput[] }
export interface TimelineEventDto { id:string;title:string;description:string;kind:TimelineEventKind;importance:EventImportance;temporalKind:TemporalKind;startChapter:number;endChapter:number|null;worldTimeStart:string|null;worldTimeEnd:string|null;locationLabel:string|null;tags:string[];participants:TimelineParticipantInput[];sources:TimelineSourceInput[];createdAt:string;updatedAt:string }
export interface TimelineParticipantProjectionDto { characterId:string;characterName:string;role:string }
export interface TimelineEntryDto { eventId:string;title:string;kind:TimelineEventKind;importance:EventImportance;temporalKind:TemporalKind;startChapter:number;endChapter:number|null;locationLabel:string|null;participants:TimelineParticipantProjectionDto[];sourceCount:number }
export interface TimelineProjectionDto { startChapter:number;endChapter:number;entries:TimelineEntryDto[] }
export interface TimelineBoundsDto { startChapter:number;endChapter:number }
export interface TimelineGateway {
 create(input:UpsertTimelineEventInput):Promise<TimelineEventDto>;
 update(id:string,input:UpsertTimelineEventInput):Promise<TimelineEventDto>;
 get(id:string):Promise<TimelineEventDto>;
 remove(id:string):Promise<void>;
 at(chapter:number):Promise<TimelineEventDto[]>;
 between(start:number,end:number):Promise<TimelineEventDto[]>;
 forCharacter(characterId:string,start?:number,end?:number):Promise<TimelineEventDto[]>;
 projectionBetween(start:number,end:number):Promise<TimelineProjectionDto>;
 characterThread(characterId:string):Promise<TimelineEntryDto[]>;
 bounds():Promise<TimelineBoundsDto|null>;
}
