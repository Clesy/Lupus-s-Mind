import { shouldConfirmDestructive } from "../../../shared/preferences";
import type { CharacterGateway,CharacterSummaryDto } from "../../characters/application/CharacterGateway";
import type { TimelineEventDto,TimelineGateway,TimelineProjectionDto } from "../application/TimelineGateway";
import { TimelineTrack } from "./TimelineTrack";
import { TimelineInspector } from "./TimelineInspector";
import { TimelineEditor } from "./TimelineEditor";
const esc=(value:string):string=>value.replace(/[&<>"']/g,(char)=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[char]!);

export class TimelineScreen {
 private characters:CharacterSummaryDto[]=[];
 private projection:TimelineProjectionDto|null=null;
 private selected:TimelineEventDto|null=null;
 private start=1;
 private end=250;
 private characterFilter:string|null=null;
 private kindFilter:string|null=null;
 constructor(private readonly host:HTMLElement,private readonly gateway:TimelineGateway,private readonly characterGateway:CharacterGateway){}
 async render():Promise<void>{
  const [characters,bounds]=await Promise.all([this.characterGateway.list(),this.gateway.bounds()]);this.characters=characters;
  if(bounds){this.start=bounds.startChapter;this.end=Math.max(bounds.endChapter,bounds.startChapter+1);}
  this.host.innerHTML=`<div class="timeline-screen"><aside class="timeline-sidebar"><div class="module-title"><div><span class="eyebrow">Temporal Narrative</span><h1>Timeline</h1></div><button class="btn primary small" data-action="new">+ Event</button></div><div class="timeline-range"><label>From<input type="number" min="1" value="${this.start}" data-range="start"></label><label>To (exclusive)<input type="number" min="2" value="${this.end}" data-range="end"></label><div class="timeline-range-actions"><button class="btn ghost small" data-action="apply-range">Apply</button><button class="btn ghost small" data-action="fit-range">Fit all</button></div></div><label class="timeline-filter">Character<select data-filter="character"><option value="">All characters</option>${this.characters.map((character)=>`<option value="${esc(character.id)}">${esc(character.name)}</option>`).join("")}</select></label><label class="timeline-filter">Event type<select data-filter="kind"><option value="">All event types</option>${["personal","conflict","political","discovery","death","birth","journey","alliance","betrayal","battle","catastrophe","revelation"].map((kind)=>`<option value="${kind}">${kind}</option>`).join("")}</select></label><div class="timeline-philosophy"><strong>Canonical truth</strong><p>TimelineEvent is narrative fact. Transitions are provenance; projections are derived views.</p></div></aside><section class="timeline-workspace"><header class="timeline-toolbar"><div><strong>Chronicle</strong><span data-role="rangeLabel"></span><span class="timeline-event-count" data-role="eventCount"></span></div><div class="semantic-pill">[start, end)</div></header><div class="timeline-track-host" data-role="track"></div></section><aside class="timeline-inspector-host" data-role="inspector"></aside></div>`;
  this.host.querySelector<HTMLButtonElement>('[data-action="new"]')?.addEventListener("click",()=>this.openEditor(null));
  this.host.querySelector<HTMLButtonElement>('[data-action="apply-range"]')?.addEventListener("click",()=>void this.applyRange());
  this.host.querySelector<HTMLButtonElement>('[data-action="fit-range"]')?.addEventListener("click",()=>void this.fitRange());
  this.host.querySelector<HTMLSelectElement>('[data-filter="character"]')?.addEventListener("change",event=>{this.characterFilter=(event.currentTarget as HTMLSelectElement).value||null;this.renderTrack();});
  this.host.querySelector<HTMLSelectElement>('[data-filter="kind"]')?.addEventListener("change",event=>{this.kindFilter=(event.currentTarget as HTMLSelectElement).value||null;this.renderTrack();});
  await this.refresh();
 }
 public async openById(id:string):Promise<void>{
  const event=await this.gateway.get(id);const eventEnd=event.temporalKind==="span"?(event.endChapter??event.startChapter+1):event.startChapter+1;const width=Math.max(12,eventEnd-event.startChapter);const padding=Math.max(5,Math.ceil(width*.35));this.start=Math.max(1,event.startChapter-padding);this.end=Math.max(this.start+2,eventEnd+padding);this.syncRangeInputs();await this.refresh(id);
 }
 private syncRangeInputs():void{const start=this.host.querySelector<HTMLInputElement>('[data-range="start"]');const end=this.host.querySelector<HTMLInputElement>('[data-range="end"]');if(start)start.value=String(this.start);if(end)end.value=String(this.end);}
 private async fitRange():Promise<void>{const bounds=await this.gateway.bounds();if(bounds){this.start=bounds.startChapter;this.end=Math.max(bounds.endChapter,this.start+1);}else{this.start=1;this.end=250;}this.syncRangeInputs();await this.refresh();}
 private async applyRange():Promise<void>{const start=Number(this.host.querySelector<HTMLInputElement>('[data-range="start"]')?.value??1);const end=Number(this.host.querySelector<HTMLInputElement>('[data-range="end"]')?.value??250);if(start>0&&end>start){this.start=start;this.end=end;await this.refresh();}}
 private async refresh(selectId?:string):Promise<void>{this.projection=await this.gateway.projectionBetween(this.start,this.end);const rangeLabel=this.host.querySelector<HTMLElement>('[data-role="rangeLabel"]');if(rangeLabel)rangeLabel.textContent=`Ch. ${this.start}–${this.end-1}`;const count=this.host.querySelector<HTMLElement>('[data-role="eventCount"]');if(count)count.textContent=`${this.projection.entries.length} event${this.projection.entries.length===1?"":"s"}`;this.renderTrack();if(selectId){this.selected=await this.gateway.get(selectId);}this.renderInspector();}
 private renderTrack():void{const track=this.host.querySelector<HTMLElement>('[data-role="track"]');if(!track||!this.projection)return;new TimelineTrack(track,(id)=>void this.select(id)).render(this.projection,this.characterFilter,this.kindFilter);}
 private async select(id:string):Promise<void>{this.selected=await this.gateway.get(id);this.renderInspector();}
 private renderInspector():void{const host=this.host.querySelector<HTMLElement>('[data-role="inspector"]');if(!host)return;new TimelineInspector(host,(event)=>this.openEditor(event),(id)=>void this.remove(id)).render(this.selected,this.characters);}
 private openEditor(event:TimelineEventDto|null):void{const host=this.host.querySelector<HTMLElement>('[data-role="inspector"]');if(!host)return;new TimelineEditor(host,this.gateway,this.characters,(saved)=>{this.selected=saved;void this.refresh(saved.id);},()=>this.renderInspector()).render(event);}
 private async remove(id:string):Promise<void>{if(shouldConfirmDestructive()&&!window.confirm("Delete this canonical timeline event?"))return;await this.gateway.remove(id);this.selected=null;await this.refresh();}
}
