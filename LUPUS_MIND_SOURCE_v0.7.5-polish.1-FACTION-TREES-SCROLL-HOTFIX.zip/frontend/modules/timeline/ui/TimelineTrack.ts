import type { TimelineEntryDto,TimelineProjectionDto } from "../application/TimelineGateway";

type PositionedEntry={entry:TimelineEntryDto;lane:number};

export class TimelineTrack {
 constructor(private readonly host:HTMLElement,private readonly onSelect:(id:string)=>void){}
 render(projection:TimelineProjectionDto,characterId:string|null=null,kind:string|null=null):void{
  const entries=projection.entries
   .filter((entry)=>!characterId||entry.participants.some((participant)=>participant.characterId===characterId))
   .filter((entry)=>!kind||entry.kind===kind)
   .sort((a,b)=>a.startChapter-b.startChapter||(a.endChapter??a.startChapter)-(b.endChapter??b.startChapter)||a.title.localeCompare(b.title));
  const span=Math.max(1,projection.endChapter-projection.startChapter);
  this.host.replaceChildren();
  const ruler=document.createElement("div");ruler.className="timeline-ruler";
  const start=document.createElement("span");start.textContent=`Ch. ${projection.startChapter}`;
  const end=document.createElement("span");end.textContent=`Ch. ${Math.max(projection.startChapter,projection.endChapter-1)}`;
  ruler.append(start,end);
  const lanes=document.createElement("div");lanes.className="timeline-lanes";lanes.dataset.role="lanes";
  this.host.append(ruler,lanes);
  if(entries.length===0){const empty=document.createElement("div");empty.className="timeline-empty";empty.textContent="No narrative events in this view.";lanes.append(empty);return;}
  const positioned=this.pack(entries,span);const laneCount=Math.max(...positioned.map(value=>value.lane))+1;
  lanes.style.setProperty("--timeline-lane-count",String(laneCount));
  positioned.forEach(({entry,lane})=>lanes.append(this.entry(entry,projection.startChapter,span,lane)));
 }
 private pack(entries:TimelineEntryDto[],span:number):PositionedEntry[]{
  const laneEnds:number[]=[];const visualPointWidth=Math.max(1,Math.ceil(span*.075));
  return entries.map(entry=>{
   const visualEnd=entry.temporalKind==="span"&&entry.endChapter!==null?entry.endChapter:entry.startChapter+visualPointWidth;
   let lane=laneEnds.findIndex(end=>end<=entry.startChapter);if(lane<0){lane=laneEnds.length;laneEnds.push(visualEnd);}else laneEnds[lane]=visualEnd;
   return{entry,lane};
  });
 }
 private entry(entry:TimelineEntryDto,start:number,span:number,lane:number):HTMLElement{
  const button=document.createElement("button");button.type="button";button.className=`timeline-entry importance-${entry.importance}`;button.dataset.eventId=entry.eventId;
  const left=Math.max(0,Math.min(100,((entry.startChapter-start)/span)*100));
  const end=entry.temporalKind==="span"&&entry.endChapter!==null?entry.endChapter:entry.startChapter+Math.max(1,Math.ceil(span*.025));
  const width=Math.max(2.8,Math.min(100-left,((end-entry.startChapter)/span)*100));
  button.style.setProperty("--timeline-left",`${left}%`);button.style.setProperty("--timeline-width",`${width}%`);button.style.setProperty("--timeline-lane",String(lane));
  const title=document.createElement("strong");title.textContent=entry.title;
  const meta=document.createElement("span");meta.textContent=entry.temporalKind==="point"?`Ch. ${entry.startChapter} · ${entry.kind}`:`Ch. ${entry.startChapter}–${(entry.endChapter??entry.startChapter)-1} · ${entry.kind}`;
  button.append(title,meta);button.title=`${entry.title} — ${meta.textContent}`;button.addEventListener("click",()=>this.onSelect(entry.eventId));return button;
 }
}
