import type { TimelineEventDto } from "../application/TimelineGateway";
import type { CharacterSummaryDto } from "../../characters/application/CharacterGateway";
const esc=(value:string):string=>value.replace(/[&<>"']/g,(char)=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[char]!);
export class TimelineInspector {
 constructor(private readonly host:HTMLElement,private readonly onEdit:(event:TimelineEventDto)=>void,private readonly onDelete:(id:string)=>void){}
 render(event:TimelineEventDto|null,characters:CharacterSummaryDto[]):void{
  if(!event){this.host.innerHTML='<div class="timeline-inspector-empty"><h3>Narrative Inspector</h3><p>Select an event to inspect canonical narrative data and provenance.</p></div>';return;}
  const names=new Map(characters.map((c)=>[c.id,c.name]));
  const when=event.temporalKind==='point'?`Chapter ${event.startChapter}`:`Ch. ${event.startChapter}–${(event.endChapter??event.startChapter)-1}`;
  this.host.innerHTML=`<div class="timeline-inspector"><div class="timeline-inspector-head"><div><span class="eyebrow">${esc(event.kind)} · ${esc(event.importance)}</span><h2>${esc(event.title)}</h2><p>${esc(when)}${event.locationLabel?` · ${esc(event.locationLabel)}`:''}</p></div><div class="timeline-action-row"><button class="btn ghost small" data-action="edit">Edit</button><button class="btn ghost small danger-text" data-action="delete">Delete</button></div></div><section><h4>Narrative</h4><p>${esc(event.description||'No narrative description recorded.')}</p></section><section><h4>Participants</h4><div class="timeline-chip-list">${event.participants.length?event.participants.map((p)=>`<span>${esc(names.get(p.characterId)??p.characterId)}<small>${esc(p.role)}</small></span>`).join(''):'<em>None</em>'}</div></section><section><h4>Provenance</h4><div class="provenance-list">${event.sources.length?event.sources.map((s)=>`<div><strong>${esc(s.sourceKind.replaceAll('_',' '))}</strong><code>${esc(s.sourceId)}</code></div>`).join(''):'<em>Manual canonical event with no linked domain transition.</em>'}</div><p class="semantic-note">A source link explains provenance. It does not make source-domain characters participants.</p></section></div>`;
  this.host.querySelector<HTMLButtonElement>('[data-action="edit"]')?.addEventListener('click',()=>this.onEdit(event));
  this.host.querySelector<HTMLButtonElement>('[data-action="delete"]')?.addEventListener('click',()=>this.onDelete(event.id));
 }
}
