import { invoke } from "@tauri-apps/api/core";
import type { ItemDto, ItemGateway, UpsertItemInput } from "../application/ItemGateway";
export const tauriItemGateway:ItemGateway={
 list:()=>invoke<ItemDto[]>("items_list"), get:(id)=>invoke<ItemDto>("items_get",{id}),
 create:(input)=>invoke<ItemDto>("items_create",{input}), update:(id,input)=>invoke<ItemDto>("items_update",{id,input}), remove:(id)=>invoke<void>("items_delete",{id})
};
