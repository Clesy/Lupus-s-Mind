export type ItemType = "weapon"|"armor"|"accessory"|"material"|"consumable";
export type ItemRarity = "standard"|"rare"|"epic"|"legendary"|"ancient";
export type StatKey = "strength"|"agility"|"vitality"|"intelligence"|"mind"|"weapon_damage"|"armor"|"armor_penetration"|"magic_penetration"|"critical_chance"|"damage_reduction";
export interface StatModifierDto { stat:StatKey; value:number; }
export interface ItemDto { id:string; name:string; description:string; itemType:ItemType; rarity:ItemRarity; modifiers:StatModifierDto[]; tags:string[]; createdAt:string; updatedAt:string; }
export interface UpsertItemInput { name:string; description?:string; itemType:ItemType; rarity:ItemRarity; modifiers:StatModifierDto[]; tags:string[]; }
export interface ItemGateway { list():Promise<ItemDto[]>; get(id:string):Promise<ItemDto>; create(input:UpsertItemInput):Promise<ItemDto>; update(id:string,input:UpsertItemInput):Promise<ItemDto>; remove(id:string):Promise<void>; }
