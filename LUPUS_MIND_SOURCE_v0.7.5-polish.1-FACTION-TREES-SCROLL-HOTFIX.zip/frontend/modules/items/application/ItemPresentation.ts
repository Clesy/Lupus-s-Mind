import type { ItemRarity, ItemType, StatKey } from "./ItemGateway";

export const ITEM_TYPE_LABELS: Record<ItemType, string> = {
  weapon: "Weapon",
  armor: "Armor",
  accessory: "Accessory",
  material: "Material",
  consumable: "Consumable",
};

export const ITEM_RARITY_LABELS: Record<ItemRarity, string> = {
  standard: "Standard",
  rare: "Rare",
  epic: "Epic",
  legendary: "Legendary",
  ancient: "Ancient",
};

export const STAT_LABELS: Record<StatKey, string> = {
  strength: "Strength",
  agility: "Agility",
  vitality: "Vitality",
  intelligence: "Intelligence",
  mind: "Mind",
  weapon_damage: "Weapon Damage",
  armor: "Armor",
  armor_penetration: "Armor Penetration",
  magic_penetration: "Magic Penetration",
  critical_chance: "Critical Chance",
  damage_reduction: "Damage Reduction",
};
