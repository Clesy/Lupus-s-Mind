import type {
  ItemDto,
  ItemGateway,
  ItemRarity,
  ItemType,
  StatKey,
  StatModifierDto,
  UpsertItemInput,
} from "../application/ItemGateway";
import {
  ITEM_RARITY_LABELS,
  ITEM_TYPE_LABELS,
  STAT_LABELS,
} from "../application/ItemPresentation";

const itemTypes = Object.keys(ITEM_TYPE_LABELS) as ItemType[];
const rarities = Object.keys(ITEM_RARITY_LABELS) as ItemRarity[];
const statKeys = Object.keys(STAT_LABELS) as StatKey[];

export type ItemEditorResult = { kind: "created" | "updated"; item: ItemDto };

export class ItemEditor {
  private editing: ItemDto | null = null;
  private modifiers: StatModifierDto[] = [];
  private onComplete: ((result: ItemEditorResult) => void) | null = null;

  constructor(
    private readonly host: HTMLElement,
    private readonly gateway: ItemGateway,
  ) {}

  openCreate(onComplete: (result: ItemEditorResult) => void): void {
    this.editing = null;
    this.modifiers = [];
    this.onComplete = onComplete;
    this.render();
  }

  openEdit(item: ItemDto, onComplete: (result: ItemEditorResult) => void): void {
    this.editing = item;
    this.modifiers = item.modifiers.map((modifier) => ({ ...modifier }));
    this.onComplete = onComplete;
    this.render();
  }

  close(): void {
    this.host.innerHTML = "";
    this.onComplete = null;
  }

  private render(): void {
    const item = this.editing;
    this.host.innerHTML = `
      <div class="overlay" data-role="overlay">
        <section class="inspector item-editor" role="dialog" aria-modal="true" aria-labelledby="item-editor-title">
          <header class="inspector-header">
            <div>
              <div class="eyebrow">${item ? "Edit item" : "New item"}</div>
              <h2 id="item-editor-title">${item ? "Update world object" : "Create world object"}</h2>
            </div>
            <button class="icon-btn" type="button" data-action="close" aria-label="Close">×</button>
          </header>

          <form class="inspector-body form-stack" data-role="form">
            <label class="field">
              <span>Name</span>
              <input data-field="name" autocomplete="off" required maxlength="120" />
            </label>

            <div class="form-grid two">
              <label class="field">
                <span>Type</span>
                <select data-field="itemType">
                  ${itemTypes.map((value) => `<option value="${value}">${ITEM_TYPE_LABELS[value]}</option>`).join("")}
                </select>
              </label>
              <label class="field">
                <span>Rarity</span>
                <select data-field="rarity">
                  ${rarities.map((value) => `<option value="${value}">${ITEM_RARITY_LABELS[value]}</option>`).join("")}
                </select>
              </label>
            </div>

            <label class="field">
              <span>Description</span>
              <textarea data-field="description" rows="5" maxlength="2000"></textarea>
            </label>

            <label class="field">
              <span>Tags</span>
              <input data-field="tags" autocomplete="off" placeholder="artifact, dragon, cursed" />
              <small>Comma separated. Stored as canonical string tags.</small>
            </label>

            <section class="modifier-editor">
              <div class="section-heading">
                <div>
                  <div class="eyebrow">Modifiers</div>
                  <h3>Effective stat contributions</h3>
                </div>
                <button class="btn" type="button" data-action="add-modifier">+ Modifier</button>
              </div>
              <div data-role="modifier-list"></div>
            </section>

            <div class="form-error" data-role="error" hidden></div>

            <footer class="inspector-footer">
              <button class="btn" type="button" data-action="cancel">Cancel</button>
              <button class="btn primary" type="submit">${item ? "Save changes" : "Create item"}</button>
            </footer>
          </form>
        </section>
      </div>`;

    const name = this.query<HTMLInputElement>('[data-field="name"]');
    const description = this.query<HTMLTextAreaElement>('[data-field="description"]');
    const type = this.query<HTMLSelectElement>('[data-field="itemType"]');
    const rarity = this.query<HTMLSelectElement>('[data-field="rarity"]');
    const tags = this.query<HTMLInputElement>('[data-field="tags"]');

    name.value = item?.name ?? "";
    description.value = item?.description ?? "";
    type.value = item?.itemType ?? "weapon";
    rarity.value = item?.rarity ?? "standard";
    tags.value = item?.tags.join(", ") ?? "";

    this.renderModifiers();

    this.query<HTMLElement>('[data-action="close"]').addEventListener("click", () => this.close());
    this.query<HTMLElement>('[data-action="cancel"]').addEventListener("click", () => this.close());
    this.query<HTMLElement>('[data-action="add-modifier"]').addEventListener("click", () => {
      this.modifiers.push({ stat: "strength", value: 0 });
      this.renderModifiers();
    });
    this.query<HTMLFormElement>('[data-role="form"]').addEventListener("submit", (event) => {
      event.preventDefault();
      void this.submit();
    });
    name.focus();
  }

  private renderModifiers(): void {
    const list = this.query<HTMLElement>('[data-role="modifier-list"]');
    list.innerHTML = this.modifiers.length
      ? this.modifiers
          .map(
            (modifier, index) => `
              <div class="modifier-editor-row" data-modifier-index="${index}">
                <select data-role="modifier-stat" aria-label="Modifier stat">
                  ${statKeys.map((key) => `<option value="${key}" ${key === modifier.stat ? "selected" : ""}>${STAT_LABELS[key]}</option>`).join("")}
                </select>
                <input data-role="modifier-value" type="number" step="0.1" value="${modifier.value}" aria-label="Modifier value" />
                <button class="icon-btn danger-text" type="button" data-action="remove-modifier" aria-label="Remove modifier">×</button>
              </div>`,
          )
          .join("")
      : `<div class="subtle-empty">No modifiers. Canonical item data remains valid without stat effects.</div>`;

    list.querySelectorAll<HTMLElement>("[data-modifier-index]").forEach((row) => {
      const index = Number(row.dataset.modifierIndex);
      const stat = row.querySelector<HTMLSelectElement>('[data-role="modifier-stat"]');
      const value = row.querySelector<HTMLInputElement>('[data-role="modifier-value"]');
      const remove = row.querySelector<HTMLButtonElement>('[data-action="remove-modifier"]');
      if (!stat || !value || !remove || !Number.isInteger(index)) return;
      stat.addEventListener("change", () => {
        const modifier = this.modifiers[index];
        if (modifier) modifier.stat = stat.value as StatKey;
      });
      value.addEventListener("input", () => {
        const modifier = this.modifiers[index];
        if (modifier) modifier.value = Number(value.value) || 0;
      });
      remove.addEventListener("click", () => {
        this.modifiers.splice(index, 1);
        this.renderModifiers();
      });
    });
  }

  private async submit(): Promise<void> {
    const error = this.query<HTMLElement>('[data-role="error"]');
    error.hidden = true;
    const input: UpsertItemInput = {
      name: this.query<HTMLInputElement>('[data-field="name"]').value.trim(),
      description: this.query<HTMLTextAreaElement>('[data-field="description"]').value.trim(),
      itemType: this.query<HTMLSelectElement>('[data-field="itemType"]').value as ItemType,
      rarity: this.query<HTMLSelectElement>('[data-field="rarity"]').value as ItemRarity,
      modifiers: this.modifiers.map((modifier) => ({ ...modifier })),
      tags: this.query<HTMLInputElement>('[data-field="tags"]')
        .value.split(",")
        .map((tag) => tag.trim())
        .filter(Boolean),
    };

    if (!input.name) {
      this.showError("Name is required.");
      return;
    }

    try {
      const saved = this.editing
        ? await this.gateway.update(this.editing.id, input)
        : await this.gateway.create(input);
      const result: ItemEditorResult = {
        kind: this.editing ? "updated" : "created",
        item: saved,
      };
      const callback = this.onComplete;
      this.close();
      callback?.(result);
    } catch (cause) {
      this.showError(this.errorMessage(cause));
    }
  }

  private showError(message: string): void {
    const error = this.query<HTMLElement>('[data-role="error"]');
    error.textContent = message;
    error.hidden = false;
  }

  private errorMessage(cause: unknown): string {
    if (cause instanceof Error) return cause.message;
    if (typeof cause === "object" && cause && "message" in cause) return String(cause.message);
    return String(cause);
  }

  private query<T extends Element>(selector: string): T {
    const element = this.host.querySelector<T>(selector);
    if (!element) throw new Error(`ItemEditor missing element: ${selector}`);
    return element;
  }
}
