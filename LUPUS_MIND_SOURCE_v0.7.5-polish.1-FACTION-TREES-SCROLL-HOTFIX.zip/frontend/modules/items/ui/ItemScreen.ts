import type { ItemDto, ItemGateway, ItemType, StatModifierDto, UpsertItemInput } from "../application/ItemGateway";
import type { AssetGateway } from "../../assets/application/AssetGateway";
import { assetBlobUrl, prepareImageAsset } from "../../assets/application/imageAssets";
import { shouldConfirmDestructive } from "../../../shared/preferences";
import { ITEM_RARITY_LABELS, ITEM_TYPE_LABELS, STAT_LABELS } from "../application/ItemPresentation";
import { ItemEditor } from "./ItemEditor";
import type { InventoryGateway } from "../../inventory/application/InventoryGateway";

const esc=(value:string):string=>value.replace(/[&<>"']/g,(char)=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[char]!);
type ViewMode="cards"|"table";
const TYPE_GLYPHS:Record<ItemType,string>={weapon:"⚔",armor:"⬢",accessory:"◇",material:"◆",consumable:"✦"};

export class ItemScreen {
  private selectedId:string|null=null;
  private items:ItemDto[]=[];
  private search="";
  private editor:ItemEditor|null=null;
  private viewMode:ViewMode="cards";
  private artworkUrls=new Map<string,string|null>();

  constructor(private readonly root:HTMLElement,private readonly gateway:ItemGateway,private readonly assets:AssetGateway,private readonly inventory:InventoryGateway){}

  async render():Promise<void>{
    try{const stored=window.localStorage.getItem("lupus_mind_item_view");if(stored==="cards"||stored==="table")this.viewMode=stored;}catch{}
    this.root.innerHTML=`
      <div class="item-gallery-shell">
        <section class="item-gallery-pane">
          <header class="item-gallery-head studio-page-head">
            <div class="page-heading-copy"><div class="eyebrow">World objects & relics</div><h1>Items</h1><p>Canonical objects, artwork, rarity and effective-stat impact at a glance.</p></div>
            <div class="action-row"><div class="segmented item-view-toggle"><button data-view="cards">Cards</button><button data-view="table">Table</button></div><button class="btn primary" data-action="new">+ New Item</button></div>
          </header>
          <div class="item-filterbar"><label class="search-field"><span>⌕</span><input data-role="search" placeholder="Search name, type, rarity, tag or lore" autocomplete="off" /></label><span class="item-count" data-role="count"></span></div>
          <div class="item-gallery" data-role="list"></div>
        </section>
        <aside class="item-inspector" data-role="detail"><div class="empty-state large"><strong>Select an item</strong><span>Artwork, rarity, lore and stat effects appear here.</span></div></aside>
      </div>
      <div data-role="editor-host"></div><div data-role="dialog-host"></div>`;
    this.editor=new ItemEditor(this.query('[data-role="editor-host"]'),this.gateway);
    this.query<HTMLButtonElement>('[data-action="new"]').addEventListener("click",()=>this.openCreate());
    this.query<HTMLInputElement>('[data-role="search"]').addEventListener("input",event=>{this.search=(event.currentTarget as HTMLInputElement).value.trim().toLowerCase();this.renderList();});
    this.root.querySelectorAll<HTMLButtonElement>("[data-view]").forEach(button=>button.addEventListener("click",()=>this.setView(button.dataset.view as ViewMode)));
    this.paintViewToggle();await this.refresh();
  }

  public openCreate():void{this.editor?.openCreate(({item})=>void this.afterSave(item));}
  public async openById(id:string):Promise<void>{this.selectedId=id;await this.refresh();}

  private setView(mode:ViewMode):void{this.viewMode=mode;try{window.localStorage.setItem("lupus_mind_item_view",mode);}catch{}this.paintViewToggle();this.renderList();}
  private paintViewToggle():void{this.root.querySelectorAll<HTMLButtonElement>("[data-view]").forEach(button=>button.classList.toggle("active",button.dataset.view===this.viewMode));}

  private async refresh():Promise<void>{
    this.items=(await this.gateway.list()).sort((a,b)=>a.name.localeCompare(b.name));this.renderList();
    if(this.selectedId){const selected=this.items.find(item=>item.id===this.selectedId);if(selected)await this.renderDetail(selected);else this.renderEmptyDetail();}
  }

  private renderList():void{
    const filtered=this.items.filter(item=>!this.search||[item.name,item.description,item.itemType,item.rarity,...item.tags,...item.modifiers.map(modifier=>STAT_LABELS[modifier.stat])].join(" ").toLowerCase().includes(this.search));
    this.query<HTMLElement>('[data-role="count"]').textContent=`${filtered.length} shown · ${this.items.length} total`;
    const list=this.query<HTMLElement>('[data-role="list"]');list.classList.toggle("table-mode",this.viewMode==="table");
    if(!filtered.length){list.innerHTML=`<div class="empty-state item-gallery-empty"><strong>No items found</strong><span>Try another filter or create a new item.</span></div>`;return;}
    list.innerHTML=filtered.map(item=>this.viewMode==="cards"?this.card(item):this.tableRow(item)).join("");
    list.querySelectorAll<HTMLButtonElement>("[data-id]").forEach(button=>button.addEventListener("click",()=>void this.select(button.dataset.id!)));
    if(this.viewMode==="cards")void this.hydrateArtwork(filtered.map(item=>item.id),list);
  }

  private card(item:ItemDto):string{
    const modifiers=item.modifiers.slice(0,5).map(modifier=>this.modifierChip(modifier)).join("");
    const tags=item.tags.slice(0,3).map((tag,index)=>`<span class="tag-tone-${index%5}">${esc(tag)}</span>`).join("");
    return `<article class="item-card rarity-${item.rarity} ${item.id===this.selectedId?"active":""}">
      <button class="item-card-select" data-id="${esc(item.id)}" aria-label="Open ${esc(item.name)}">
        <div class="item-card-visual" data-item-art-id="${esc(item.id)}"><span class="item-glyph" data-artwork-fallback>${TYPE_GLYPHS[item.itemType]}</span><img data-artwork-image alt="" hidden /><div class="item-art-shade"></div><span class="item-rarity-line"></span><span class="item-rarity-badge">${esc(ITEM_RARITY_LABELS[item.rarity])}</span><span class="item-artwork-ready">Add artwork</span></div>
        <div class="item-card-body"><div class="item-card-kicker"><span>${esc(ITEM_TYPE_LABELS[item.itemType])}</span><span>${item.modifiers.length} effects</span></div><div class="item-card-title"><strong class="item-card-name">${esc(item.name)}</strong><small>${esc(item.description||"Canonical item")}</small></div><div class="item-modifier-chips">${modifiers||'<span class="modifier-empty">No stat effects</span>'}${item.modifiers.length>5?`<span class="modifier-more">+${item.modifiers.length-5}</span>`:""}</div><div class="item-card-tags">${tags||'<span class="muted">No tags</span>'}${item.tags.length>3?`<span>+${item.tags.length-3}</span>`:""}</div></div>
      </button>
    </article>`;
  }

  private tableRow(item:ItemDto):string{
    const first=item.modifiers[0];
    return `<button class="item-table-row rarity-${item.rarity} ${item.id===this.selectedId?"active":""}" data-id="${esc(item.id)}"><span class="item-table-glyph">${TYPE_GLYPHS[item.itemType]}</span><span><strong>${esc(item.name)}</strong><small>${esc(ITEM_TYPE_LABELS[item.itemType])}</small></span><span class="rarity-text">${esc(ITEM_RARITY_LABELS[item.rarity])}</span>${first?`<span class="item-table-effect stat-tone stat-${esc(first.stat)}"><small>${esc(STAT_LABELS[first.stat])}</small><b>${this.signed(first.value)}</b></span>`:'<span class="item-table-effect empty">No effects</span>'}<span>${item.tags.length} tags</span></button>`;
  }

  private modifierChip(modifier:StatModifierDto):string{return `<span class="modifier-chip stat-tone stat-${esc(modifier.stat)} ${modifier.value<0?"negative":"positive"}"><small>${esc(STAT_LABELS[modifier.stat])}</small><b>${this.signed(modifier.value)}</b></span>`;}
  private signed(value:number):string{return `${value>=0?"+":""}${value}`;}

  private async select(id:string):Promise<void>{this.selectedId=id;const item=await this.gateway.get(id);await this.renderDetail(item);this.renderList();}

  private async renderDetail(item:ItemDto):Promise<void>{
    const detail=this.query<HTMLElement>('[data-role="detail"]');
    detail.innerHTML=`
      <div class="item-inspector-scroll">
        <header class="item-profile-head rarity-${item.rarity}"><div class="item-profile-artwork" data-item-art-id="${esc(item.id)}"><span data-artwork-fallback>${TYPE_GLYPHS[item.itemType]}</span><img data-artwork-image alt="Artwork of ${esc(item.name)}" hidden /></div><div class="item-profile-copy"><span class="eyebrow">${esc(ITEM_TYPE_LABELS[item.itemType])}</span><h2>${esc(item.name)}</h2><span class="item-rarity-pill">${esc(ITEM_RARITY_LABELS[item.rarity])}</span></div></header>
        <div class="item-profile-actions"><button class="btn ghost" data-action="artwork">Artwork</button><button class="btn ghost" data-action="remove-artwork">Remove art</button><input type="file" accept="image/png,image/jpeg,image/webp" data-role="artwork-file" hidden /><button class="btn ghost" data-action="duplicate">Duplicate</button><button class="btn ghost" data-action="edit">Edit</button><button class="btn danger ghost" data-action="delete">Delete</button></div>
        <div class="tag-row item-profile-tags">${item.tags.map((tag,index)=>`<span class="tag tag-tone-${index%5}">${esc(tag)}</span>`).join("")||'<span class="tag muted">No tags</span>'}</div>
        <section class="item-inspector-section"><div class="item-section-title"><span>Stat Effects</span><small>${item.modifiers.length} modifiers</small></div><div class="item-effect-stack">${item.modifiers.length?item.modifiers.map(modifier=>`<div class="item-effect-row stat-tone stat-${esc(modifier.stat)} ${modifier.value<0?"negative":"positive"}"><span class="effect-icon">${modifier.value<0?"−":"+"}</span><span><strong>${esc(STAT_LABELS[modifier.stat])}</strong><small>${modifier.value<0?"Penalty / debuff":"Bonus / buff"}</small></span><b>${this.signed(modifier.value)}</b></div>`).join(""):'<div class="subtle-empty">This item has no effective-stat modifiers.</div>'}</div></section>
        <section class="item-inspector-section" data-role="item-owner"><div class="loadout-loading"><span class="loading-spinner"></span><span>Reading ownership…</span></div></section>
        <section class="item-inspector-section"><div class="item-section-title"><span>Lore</span><small>Description</small></div><p class="body-copy item-lore">${esc(item.description||"No description recorded.")}</p></section>
        <footer class="record-footer"><span>Created ${esc(new Date(item.createdAt).toLocaleString())}</span><span>Updated ${esc(new Date(item.updatedAt).toLocaleString())}</span></footer>
      </div>`;
    const artworkInput=detail.querySelector<HTMLInputElement>('[data-role="artwork-file"]');
    detail.querySelector<HTMLButtonElement>('[data-action="artwork"]')?.addEventListener("click",()=>artworkInput?.click());
    artworkInput?.addEventListener("change",()=>{const file=artworkInput.files?.[0];if(file)void this.saveArtwork(item,file);artworkInput.value="";});
    detail.querySelector<HTMLButtonElement>('[data-action="remove-artwork"]')?.addEventListener("click",()=>void this.removeArtwork(item));
    detail.querySelector<HTMLButtonElement>('[data-action="duplicate"]')?.addEventListener("click",()=>void this.duplicate(item));
    detail.querySelector<HTMLButtonElement>('[data-action="edit"]')?.addEventListener("click",()=>this.editor?.openEdit(item,({item:saved})=>void this.afterSave(saved)));
    detail.querySelector<HTMLButtonElement>('[data-action="delete"]')?.addEventListener("click",()=>this.openDeleteDialog(item));
    await this.hydrateArtwork([item.id],detail);
    try{const ownership=(await this.inventory.listAt(2147483647)).find(o=>o.itemId===item.id);const owner=detail.querySelector<HTMLElement>('[data-role="item-owner"]');if(owner)owner.innerHTML=`<div class="item-section-title"><span>Ownership</span><small>Current open state</small></div>${ownership?`<div class="item-owner-card"><span><strong>${esc(ownership.ownerName)}</strong><small>${esc(ownership.ownerKind)} · since Ch.${ownership.acquiredChapter}</small></span><em>${ownership.isEquipped?"Equipped":"Owned"}</em></div>`:`<div class="subtle-empty">No current owner.</div>`}`;}catch{}
  }

  private async artworkUrl(itemId:string,force=false):Promise<string|null>{
    if(!force&&this.artworkUrls.has(itemId))return this.artworkUrls.get(itemId)??null;
    const previous=this.artworkUrls.get(itemId);if(previous)URL.revokeObjectURL(previous);
    const asset=await this.assets.getItemArtwork(itemId);const url=asset?assetBlobUrl(asset):null;this.artworkUrls.set(itemId,url);return url;
  }

  private async hydrateArtwork(itemIds:string[],scope:ParentNode):Promise<void>{
    await Promise.all(itemIds.map(async id=>{try{const url=await this.artworkUrl(id);scope.querySelectorAll<HTMLElement>(`[data-item-art-id="${CSS.escape(id)}"]`).forEach(node=>{const image=node.querySelector<HTMLImageElement>("[data-artwork-image]");const fallback=node.querySelector<HTMLElement>("[data-artwork-fallback]");const ready=node.querySelector<HTMLElement>(".item-artwork-ready");if(image){if(url){image.src=url;image.hidden=false;}else{image.removeAttribute("src");image.hidden=true;}}if(fallback)fallback.hidden=!!url;if(ready)ready.textContent=url?"Artwork":"Add artwork";node.classList.toggle("has-artwork",!!url);});}catch{}}));
  }

  private async saveArtwork(item:ItemDto,file:File):Promise<void>{
    const detail=this.query<HTMLElement>('[data-role="detail"]');const button=detail.querySelector<HTMLButtonElement>('[data-action="artwork"]');if(button){button.disabled=true;button.textContent="Saving…";}
    try{const prepared=await prepareImageAsset(file,"Item artwork");await this.assets.putItemArtwork(item.id,prepared.mimeType,prepared.bytes);await this.artworkUrl(item.id,true);this.renderList();if(this.selectedId===item.id)await this.renderDetail(item);}catch(cause){window.alert(cause instanceof Error?cause.message:String(cause));}finally{if(button?.isConnected){button.disabled=false;button.textContent="Artwork";}}
  }

  private async removeArtwork(item:ItemDto):Promise<void>{
    try{await this.assets.deleteItemArtwork(item.id);const previous=this.artworkUrls.get(item.id);if(previous)URL.revokeObjectURL(previous);this.artworkUrls.set(item.id,null);this.renderList();if(this.selectedId===item.id)await this.renderDetail(item);}catch(cause){window.alert(cause instanceof Error?cause.message:String(cause));}
  }

  private async duplicate(item:ItemDto):Promise<void>{
    const input:UpsertItemInput={name:`${item.name} Copy`,description:item.description,itemType:item.itemType,rarity:item.rarity,modifiers:item.modifiers.map(modifier=>({...modifier})),tags:[...item.tags]};
    const copy=await this.gateway.create(input);this.selectedId=copy.id;await this.refresh();
  }

  private openDeleteDialog(item:ItemDto):void{
    if(!shouldConfirmDestructive()){void this.deleteItem(item.id,this.query('[data-role="dialog-host"]'));return;}
    const host=this.query<HTMLElement>('[data-role="dialog-host"]');host.innerHTML=`<div class="overlay"><section class="confirm-dialog" role="alertdialog" aria-modal="true"><div class="eyebrow">Destructive action</div><h2>Delete ${esc(item.name)}?</h2><p>If this item is currently equipped, the database invariant will reject deletion rather than orphan equipment.</p><div class="form-error" data-role="error" hidden></div><div class="confirm-actions"><button class="btn" data-action="cancel">Cancel</button><button class="btn danger" data-action="confirm">Delete item</button></div></section></div>`;
    host.querySelector<HTMLButtonElement>('[data-action="cancel"]')?.addEventListener("click",()=>{host.innerHTML="";});host.querySelector<HTMLButtonElement>('[data-action="confirm"]')?.addEventListener("click",()=>void this.deleteItem(item.id,host));
  }
  private async deleteItem(id:string,dialogHost:HTMLElement):Promise<void>{try{await this.gateway.remove(id);dialogHost.innerHTML="";this.selectedId=null;await this.refresh();this.renderEmptyDetail();}catch(cause){const error=dialogHost.querySelector<HTMLElement>('[data-role="error"]');if(!error)return;error.textContent=cause instanceof Error?cause.message:String(cause);error.hidden=false;}}
  private async afterSave(item:ItemDto):Promise<void>{this.selectedId=item.id;await this.refresh();await this.renderDetail(item);}
  private renderEmptyDetail():void{this.query<HTMLElement>('[data-role="detail"]').innerHTML=`<div class="empty-state large"><strong>Select an item</strong><span>Artwork, rarity, lore and stat effects appear here.</span></div>`;}
  private query<T extends Element=HTMLElement>(selector:string):T{const element=this.root.querySelector<T>(selector);if(!element)throw new Error(`ItemScreen missing element: ${selector}`);return element;}
}
