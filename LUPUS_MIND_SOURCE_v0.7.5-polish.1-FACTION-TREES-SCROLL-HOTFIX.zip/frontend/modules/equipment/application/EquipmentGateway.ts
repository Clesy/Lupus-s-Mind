import type { CharacterSheetDto, EquippedItemDto } from "../../character-sheet/application/CharacterSheet";
import type { ItemDto } from "../../items/application/ItemGateway";

export type EquipmentSlot =
  | "main_hand"
  | "off_hand"
  | "head"
  | "chest"
  | "hands"
  | "legs"
  | "feet"
  | "accessory_1"
  | "accessory_2";

export interface CompatibleItemDto {
  item: ItemDto;
  available: boolean;
  equippedByCharacterId: string | null;
  equippedSlot: EquipmentSlot | null;
  equippedHere: boolean;
}

export interface EquipmentGateway {
  list(characterId: string): Promise<EquippedItemDto[]>;
  compatibleItems(characterId: string, slot: EquipmentSlot): Promise<CompatibleItemDto[]>;
  equip(input: { characterId: string; itemId: string; slot: EquipmentSlot }): Promise<CharacterSheetDto>;
  unequip(characterId: string, slot: EquipmentSlot): Promise<CharacterSheetDto>;
  sheet(characterId: string): Promise<CharacterSheetDto>;
}
