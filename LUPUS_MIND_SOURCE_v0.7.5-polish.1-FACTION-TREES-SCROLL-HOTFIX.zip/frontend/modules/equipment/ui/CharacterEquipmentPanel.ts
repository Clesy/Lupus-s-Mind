import type { CharacterSheetDto, EquippedItemDto } from "../../character-sheet/application/CharacterSheet";
import { ITEM_RARITY_LABELS, ITEM_TYPE_LABELS } from "../../items/application/ItemPresentation";
import type { CompatibleItemDto, EquipmentGateway, EquipmentSlot } from "../application/EquipmentGateway";

const slots: EquipmentSlot[] = [
  "main_hand",
  "off_hand",
  "head",
  "chest",
  "hands",
  "legs",
  "feet",
  "accessory_1",
  "accessory_2",
];

const slotLabels: Record<EquipmentSlot, string> = {
  main_hand: "Main hand",
  off_hand: "Off hand",
  head: "Head",
  chest: "Chest",
  hands: "Hands",
  legs: "Legs",
  feet: "Feet",
  accessory_1: "Accessory I",
  accessory_2: "Accessory II",
};

const esc = (value: string): string =>
  value.replace(/[&<>"']/g, (char) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;",
  })[char]!);

export class CharacterEquipmentPanel {
  private sheet: CharacterSheetDto | null = null;
  private activeSlot: EquipmentSlot | null = null;

  constructor(
    private readonly root: HTMLElement,
    private readonly gateway: EquipmentGateway,
    private readonly characterId: string,
  ) {}

  async render(): Promise<void> {
    this.root.innerHTML = `
      <div class="equipment-workspace">
        <section data-role="sheet"></section>
        <aside class="equipment-inspector" data-role="inspector">
          <div class="empty-state large">
            <strong>Select a slot</strong>
            <span>Compatible candidates will appear here.</span>
          </div>
        </aside>
      </div>`;
    this.sheet = await this.gateway.sheet(this.characterId);
    this.renderSheet();
  }

  private renderSheet(): void {
    if (!this.sheet) return;
    const bySlot = new Map<EquipmentSlot, EquippedItemDto>(
      this.sheet.equipment.map((equipment) => [equipment.slot, equipment]),
    );
    const sheet = this.query<HTMLElement>('[data-role="sheet"]');
    sheet.innerHTML = `
      <header class="equipment-header">
        <div>
          <div class="eyebrow">Character sheet</div>
          <h2>${esc(this.sheet.name)}</h2>
        </div>
        <div class="effective-strip">
          <span><b>${this.sheet.effectiveStats.strength}</b> STR</span>
          <span><b>${this.sheet.effectiveStats.agility}</b> AGI</span>
          <span><b>${this.sheet.effectiveStats.vitality}</b> VIT</span>
          <span><b>${this.sheet.effectiveStats.weaponDamage}</b> WPN</span>
          <span><b>${this.sheet.effectiveStats.armor}</b> ARM</span>
        </div>
      </header>
      <div class="equipment-grid">
        ${slots.map((slot) => this.slotTemplate(slot, bySlot.get(slot))).join("")}
      </div>`;

    sheet.querySelectorAll<HTMLButtonElement>("[data-slot]").forEach((button) => {
      button.addEventListener("click", () => {
        this.activeSlot = button.dataset.slot as EquipmentSlot;
        this.renderSheet();
        void this.openInspector(this.activeSlot);
      });
    });
  }

  private slotTemplate(slot: EquipmentSlot, equipped?: EquippedItemDto): string {
    const active = slot === this.activeSlot ? "active" : "";
    return `
      <button class="equipment-slot ${active}" data-slot="${slot}">
        <div class="equipment-slot-label">${slotLabels[slot]}</div>
        <div class="equipment-slot-item">${equipped ? esc(equipped.item.name) : "Empty"}</div>
        <div class="equipment-slot-meta">${equipped ? `${ITEM_TYPE_LABELS[equipped.item.itemType]} · ${ITEM_RARITY_LABELS[equipped.item.rarity]}` : "Choose compatible item"}</div>
      </button>`;
  }

  private async openInspector(slot: EquipmentSlot): Promise<void> {
    const inspector = this.query<HTMLElement>('[data-role="inspector"]');
    inspector.innerHTML = `<div class="loading-state">Loading compatible items…</div>`;
    try {
      const candidates = await this.gateway.compatibleItems(this.characterId, slot);
      const current = this.sheet?.equipment.find((equipment) => equipment.slot === slot);
      inspector.innerHTML = `
        <header class="inspector-inline-header">
          <div>
            <div class="eyebrow">Equipment inspector</div>
            <h3>${slotLabels[slot]}</h3>
          </div>
          ${current ? '<button class="btn danger" data-action="unequip">Unequip</button>' : ""}
        </header>
        <div class="candidate-list">
          ${candidates.length
            ? candidates.map((candidate) => this.candidateTemplate(candidate)).join("")
            : '<div class="subtle-empty">No item type is compatible with this slot yet.</div>'}
        </div>
        <div class="form-error" data-role="error" hidden></div>`;

      inspector.querySelector<HTMLButtonElement>('[data-action="unequip"]')?.addEventListener("click", () => {
        void this.unequip(slot);
      });
      inspector.querySelectorAll<HTMLButtonElement>("[data-item-id]").forEach((button) => {
        button.addEventListener("click", () => {
          if (button.disabled) return;
          void this.equip(slot, button.dataset.itemId!);
        });
      });
    } catch (cause) {
      inspector.innerHTML = `<div class="form-error">${esc(this.errorMessage(cause))}</div>`;
    }
  }

  private candidateTemplate(candidate: CompatibleItemDto): string {
    const disabled = !candidate.available && !candidate.equippedHere;
    const state = candidate.equippedHere
      ? "Equipped here"
      : candidate.available
        ? "Available"
        : "Equipped elsewhere";
    return `
      <button class="candidate-row ${candidate.equippedHere ? "active" : ""}" data-item-id="${esc(candidate.item.id)}" ${disabled ? "disabled" : ""}>
        <div>
          <strong>${esc(candidate.item.name)}</strong>
          <span>${ITEM_TYPE_LABELS[candidate.item.itemType]} · ${ITEM_RARITY_LABELS[candidate.item.rarity]}</span>
        </div>
        <em>${state}</em>
      </button>`;
  }

  private async equip(slot: EquipmentSlot, itemId: string): Promise<void> {
    try {
      this.sheet = await this.gateway.equip({ characterId: this.characterId, itemId, slot });
      this.renderSheet();
      await this.openInspector(slot);
    } catch (cause) {
      this.showInspectorError(cause);
    }
  }

  private async unequip(slot: EquipmentSlot): Promise<void> {
    try {
      this.sheet = await this.gateway.unequip(this.characterId, slot);
      this.renderSheet();
      await this.openInspector(slot);
    } catch (cause) {
      this.showInspectorError(cause);
    }
  }

  private showInspectorError(cause: unknown): void {
    const error = this.root.querySelector<HTMLElement>('[data-role="inspector"] [data-role="error"]');
    if (!error) return;
    error.textContent = this.errorMessage(cause);
    error.hidden = false;
  }

  private errorMessage(cause: unknown): string {
    if (cause instanceof Error) return cause.message;
    if (typeof cause === "object" && cause && "message" in cause) return String(cause.message);
    return String(cause);
  }

  private query<T extends Element = HTMLElement>(selector: string): T {
    const element = this.root.querySelector<T>(selector);
    if (!element) throw new Error(`CharacterEquipmentPanel missing element: ${selector}`);
    return element;
  }
}
