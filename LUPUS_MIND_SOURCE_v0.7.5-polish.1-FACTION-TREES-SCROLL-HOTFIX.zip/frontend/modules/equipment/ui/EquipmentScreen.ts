import type { CharacterGateway, CharacterSummaryDto } from "../../characters/application/CharacterGateway";
import type { EquipmentGateway } from "../application/EquipmentGateway";
import { CharacterEquipmentPanel } from "./CharacterEquipmentPanel";

const esc = (value: string): string =>
  value.replace(/[&<>"']/g, (char) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;",
  })[char]!);

export class EquipmentScreen {
  private characters: CharacterSummaryDto[] = [];
  private selectedCharacterId: string | null = null;

  constructor(
    private readonly root: HTMLElement,
    private readonly charactersGateway: CharacterGateway,
    private readonly equipmentGateway: EquipmentGateway,
  ) {}

  async render(): Promise<void> {
    this.root.innerHTML = `
      <section class="module-shell">
        <header class="module-header">
          <div>
            <div class="eyebrow">Cross-module read model</div>
            <h1>Equipment</h1>
          </div>
          <label class="character-picker">
            <span>Character</span>
            <select data-role="character"></select>
          </label>
        </header>
        <div data-role="content"></div>
      </section>`;

    this.characters = await this.charactersGateway.list();
    const picker = this.query<HTMLSelectElement>('[data-role="character"]');
    if (!this.characters.length) {
      picker.disabled = true;
      picker.innerHTML = '<option>No characters</option>';
      this.query<HTMLElement>('[data-role="content"]').innerHTML = `
        <div class="editor-pane single-empty">
          <div class="empty-state large"><strong>No characters found</strong><span>Create a character through the Characters slice before assigning equipment.</span></div>
        </div>`;
      return;
    }

    picker.innerHTML = this.characters
      .map((character) => `<option value="${esc(character.id)}">${esc(character.name)}</option>`)
      .join("");
    this.selectedCharacterId = this.characters[0]?.id ?? null;
    picker.value = this.selectedCharacterId ?? "";
    picker.addEventListener("change", () => {
      this.selectedCharacterId = picker.value;
      void this.renderCharacter();
    });
    await this.renderCharacter();
  }

  private async renderCharacter(): Promise<void> {
    if (!this.selectedCharacterId) return;
    const content = this.query<HTMLElement>('[data-role="content"]');
    content.innerHTML = '<div class="loading-state">Loading character sheet…</div>';
    await new CharacterEquipmentPanel(content, this.equipmentGateway, this.selectedCharacterId).render();
  }

  private query<T extends Element = HTMLElement>(selector: string): T {
    const element = this.root.querySelector<T>(selector);
    if (!element) throw new Error(`EquipmentScreen missing element: ${selector}`);
    return element;
  }
}
