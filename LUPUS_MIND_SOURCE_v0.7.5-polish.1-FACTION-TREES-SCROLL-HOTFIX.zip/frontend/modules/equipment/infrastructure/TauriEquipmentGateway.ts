import { invoke } from "@tauri-apps/api/core";
import type { CharacterSheetDto, EquippedItemDto } from "../../character-sheet/application/CharacterSheet";
import type { CompatibleItemDto, EquipmentGateway, EquipmentSlot } from "../application/EquipmentGateway";

export const tauriEquipmentGateway: EquipmentGateway = {
  list: (characterId) => invoke<EquippedItemDto[]>("equipment_list", { characterId }),
  compatibleItems: (characterId, slot) =>
    invoke<CompatibleItemDto[]>("equipment_compatible_items", { characterId, slot }),
  equip: (input) => invoke<CharacterSheetDto>("equipment_equip", { input }),
  unequip: (characterId, slot: EquipmentSlot) =>
    invoke<CharacterSheetDto>("equipment_unequip", { characterId, slot }),
  sheet: (characterId) => invoke<CharacterSheetDto>("character_sheet_get", { characterId }),
};
