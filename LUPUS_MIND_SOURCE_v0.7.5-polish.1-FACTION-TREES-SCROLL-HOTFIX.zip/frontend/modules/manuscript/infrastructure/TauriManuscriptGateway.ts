import { invoke } from "@tauri-apps/api/core";
import type { Chapter, ChapterSummary, ManuscriptGateway, QuickNote, UpsertChapterInput, UpsertQuickNoteInput } from "../application/ManuscriptGateway";
export const tauriManuscriptGateway:ManuscriptGateway = {
  list:()=>invoke<ChapterSummary[]>("manuscript_chapters_list"),
  get:(id)=>invoke<Chapter>("manuscript_chapter_get",{id}),
  create:(input)=>invoke<Chapter>("manuscript_chapter_create",{input}),
  update:(id,input)=>invoke<Chapter>("manuscript_chapter_update",{id,input}),
  remove:(id)=>invoke<void>("manuscript_chapter_delete",{id}),
  listNotes:()=>invoke<QuickNote[]>("manuscript_notes_list"),
  createNote:(input)=>invoke<QuickNote>("manuscript_note_create",{input}),
  updateNote:(id,input)=>invoke<QuickNote>("manuscript_note_update",{id,input}),
  removeNote:(id)=>invoke<void>("manuscript_note_delete",{id}),
};
