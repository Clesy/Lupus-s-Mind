export type ChapterStatus = "draft"|"revised"|"final";
export interface ChapterSummary { id:string; chapterNumber:number; title:string; status:ChapterStatus; wordCount:number; tags:string[]; updatedAt:string; }
export interface Chapter extends ChapterSummary { content:string; notes:string; createdAt:string; }
export interface UpsertChapterInput { chapterNumber:number; title:string; status:ChapterStatus; content:string; notes:string; tags:string[]; }
export interface QuickNote { id:string; body:string; pinned:boolean; linkKind:string|null; linkId:string|null; linkLabel:string|null; createdAt:string; updatedAt:string; }
export interface UpsertQuickNoteInput { body:string; pinned:boolean; linkKind:string|null; linkId:string|null; linkLabel:string|null; }
export interface ManuscriptGateway {
  list():Promise<ChapterSummary[]>;
  get(id:string):Promise<Chapter>;
  create(input:UpsertChapterInput):Promise<Chapter>;
  update(id:string,input:UpsertChapterInput):Promise<Chapter>;
  remove(id:string):Promise<void>;
  listNotes():Promise<QuickNote[]>;
  createNote(input:UpsertQuickNoteInput):Promise<QuickNote>;
  updateNote(id:string,input:UpsertQuickNoteInput):Promise<QuickNote>;
  removeNote(id:string):Promise<void>;
}
