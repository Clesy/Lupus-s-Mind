export interface SearchHit { id:string; kind:string; title:string; subtitle:string; route:string; score:number; }
export interface SearchGateway { search(query:string, limit?:number):Promise<SearchHit[]>; }
