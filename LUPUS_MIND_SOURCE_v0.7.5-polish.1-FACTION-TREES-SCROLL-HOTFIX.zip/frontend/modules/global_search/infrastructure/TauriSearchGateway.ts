import { invoke } from "@tauri-apps/api/core";
import type { SearchGateway, SearchHit } from "../application/SearchGateway";
export const tauriSearchGateway:SearchGateway = { search:(query,limit=20)=>invoke<SearchHit[]>("global_search",{query,limit}) };
