import { invoke } from "@tauri-apps/api/core";
import type { CombatGateway,CombatImpactPreviewDto,CombatImpactPreviewInput,CombatSessionDto,StartCombatInput,UseSkillCommand } from "../application/CombatGateway";
export const tauriCombatGateway:CombatGateway={
  start:(input:StartCombatInput)=>invoke<CombatSessionDto>("combat_start",{input}),
  get:(id:string)=>invoke<CombatSessionDto>("combat_get",{id}),
  listRunning:()=>invoke<CombatSessionDto[]>("combat_list_running"),
  listAll:()=>invoke<CombatSessionDto[]>("combat_list_all"),
  delete:(id:string)=>invoke<void>("combat_delete",{id}),
  useSkill:(command:UseSkillCommand)=>invoke<CombatSessionDto>("combat_use_skill",{command}),
  previewImpact:(input:CombatImpactPreviewInput)=>invoke<CombatImpactPreviewDto>("combat_preview_impact",{input}),
};
