export type CombatStatus = "running" | "completed" | "abandoned";
export type CombatSkillKind = "physical" | "magical" | "healing" | "utility";
export type CombatResourceKind = "none" | "mana" | "stamina" | "health";
export type ScalingStat = "strength" | "agility" | "vitality" | "intelligence" | "mind" | "weapon_damage" | "armor";
export type CombatStatusEffectKind = "damage_over_time" | "heal_over_time" | "stun" | "stat_modifier";
export type CombatStackingPolicy = "refresh";
export type RuntimeModifierKind = "armor_multiplier" | "damage_multiplier";
export type CombatActionKind = "use_skill" | "effect_tick" | "effect_applied" | "effect_refreshed" | "effect_expired" | "turn_skipped";

export interface ScalingTerm { stat: ScalingStat; coefficient: number; }
export interface CombatStats { strength:number;agility:number;vitality:number;intelligence:number;mind:number;weaponDamage:number;armor:number;armorPenetration:number;magicPenetration:number;criticalChance:number;damageReduction:number; }
export interface RuntimeModifier { kind:RuntimeModifierKind;multiplier:number; }
export interface CombatStatusEffectSpec { definitionId:string;name:string;kind:CombatStatusEffectKind;stackingPolicy:CombatStackingPolicy;durationTurns:number;power:number;modifier:RuntimeModifier|null; }
export interface CombatSkillSnapshot { skillId:string;name:string;kind:CombatSkillKind;resourceKind:CombatResourceKind;basePower:number;resourceCost:number;cooldownTurns:number;scaling:ScalingTerm[];effects:CombatStatusEffectSpec[]; }
export interface CombatantSnapshot { sourceCharacterId:string;displayName:string;effectiveStats:CombatStats;maxHp:number;maxMana:number;skills:CombatSkillSnapshot[]; }
export interface CooldownState { skillId:string;remainingTurns:number; }
export interface ActiveStatusEffect { instanceId:string;definitionId:string;name:string;sourceCombatantId:string;kind:CombatStatusEffectKind;stackingPolicy:CombatStackingPolicy;power:number;durationRemaining:number;modifier:RuntimeModifier|null;appliedSequence:number; }
export interface CombatantRuntimeState { currentHp:number;currentMana:number;isDefeated:boolean;cooldowns:CooldownState[];activeEffects:ActiveStatusEffect[]; }
export interface CombatantDto { id:string;position:number;snapshot:CombatantSnapshot;runtimeState:CombatantRuntimeState; }
export interface CombatSession { id:string;status:CombatStatus;rngSeed:number;roundNumber:number;turnIndex:number;nextActionSequence:number;combatants:CombatantDto[];createdAt:string;updatedAt:string;completedAt:string|null; }
export interface UseSkillCommand { sessionId:string;actorCombatantId:string;targetCombatantId:string;skillId:string; }
export interface CombatResolution { rawPower:number;resolvedPower:number;hpDelta:number;manaDelta:number;wasCritical:boolean;wasDodged:boolean;rollCritical:number;rollDodge:number; }
export interface StatusTick { effectInstanceId:string;definitionId:string;effectName:string;hpDelta:number;preventsAction:boolean; }
export type CombatActionInput =
  | {type:"use_skill";data:UseSkillCommand}
  | {type:"status_effect";data:{effect_instance_id:string;definition_id:string}}
  | {type:"system";data:{reason:string}};
export type CombatActionResolution =
  | {type:"skill";data:CombatResolution}
  | {type:"status_tick";data:StatusTick}
  | {type:"effect_lifecycle";data:{definition_id:string;effect_name:string;duration_remaining:number}}
  | {type:"turn_skipped";data:{reason:string}};
export interface CombatAction { id:string;sessionId:string;turnExecutionId:string;sequenceNumber:number;roundNumber:number;turnIndex:number;actorCombatantId:string;targetCombatantId:string|null;actionKind:CombatActionKind;input:CombatActionInput;resolution:CombatActionResolution;createdAt:string; }
export interface CombatSessionDto { session:CombatSession;actions:CombatAction[]; }
export interface StartCombatInput { characterIds:string[];rngSeed:number; }

export interface CombatImpactPreviewInput { attackerCharacterId:string;targetCharacterId:string;skillId:string;rngSeed:number;forceCritical:boolean; }
export interface CombatImpactPreviewDto {
  attackerCharacterId:string;attackerName:string;attackerMaxHp:number;attackerMaxMana:number;
  targetCharacterId:string;targetName:string;targetMaxHp:number;targetMaxMana:number;skillId:string;skillName:string;
  kind:CombatSkillKind;resourceKind:CombatResourceKind;resourceCost:number;cooldownTurns:number;learnedByAttacker:boolean;
  targetArmor:number;targetDamageReduction:number;attackerCriticalChance:number;targetDodgeChance:number;resolution:CombatResolution;
}

export interface CombatGateway {
  start(input:StartCombatInput):Promise<CombatSessionDto>;
  get(id:string):Promise<CombatSessionDto>;
  listRunning():Promise<CombatSessionDto[]>;
  listAll():Promise<CombatSessionDto[]>;
  delete(id:string):Promise<void>;
  useSkill(command:UseSkillCommand):Promise<CombatSessionDto>;
  previewImpact(input:CombatImpactPreviewInput):Promise<CombatImpactPreviewDto>;
}
