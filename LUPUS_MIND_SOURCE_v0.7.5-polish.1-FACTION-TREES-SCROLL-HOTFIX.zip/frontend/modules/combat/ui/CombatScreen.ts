import type { CharacterGateway, CharacterSummaryDto } from "../../characters/application/CharacterGateway";
import type { SkillDto, SkillGateway } from "../../skills/application/SkillGateway";
import type { CombatGateway, CombatImpactPreviewDto } from "../application/CombatGateway";
import type { CombatReplayGateway } from "../../combat_replay/application/CombatReplayGateway";

const BASIC_ATTACK_SKILL_ID = "runtime:basic_attack";
const esc = (value: string): string => value.replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char]!);
const clamp = (value: number, min: number, max: number): number => Math.max(min, Math.min(max, value));

interface ArenaVitals {
  hp: number;
  maxHp: number;
  mana: number;
  maxMana: number;
}

interface ArenaLogEntry {
  id: number;
  attacker: string;
  target: string;
  skill: string;
  damage: number;
  critical: boolean;
  dodged: boolean;
}

export class CombatScreen {
  private characters: CharacterSummaryDto[] = [];
  private learnedSkills: SkillDto[] = [];
  private vitals = new Map<string, ArenaVitals>();
  private logs: ArenaLogEntry[] = [];
  private actionSequence = 0;
  private legacySessionCount = 0;

  constructor(
    private readonly host: HTMLElement,
    private readonly gateway: CombatGateway,
    private readonly characterGateway: CharacterGateway,
    private readonly _replayGateway: CombatReplayGateway,
    private readonly skillGateway: SkillGateway,
    private readonly _navigateToSkills?: () => void,
  ) {}

  async render(): Promise<void> {
    this.characters = await this.characterGateway.list();
    this.legacySessionCount = (await this.gateway.listAll()).length;
    if (this.characters.length < 2) {
      this.host.innerHTML = `<div class="manual-arena-empty"><span>Savaş Arenası</span><h2>En az iki karakter gerekli</h2><p>Manuel hasar testi için önce iki karakter oluştur.</p></div>`;
      return;
    }

    this.host.innerHTML = `<div class="manual-arena-screen">
      <section class="manual-arena-main">
        <header class="manual-arena-title">
          <div><span class="eyebrow">MANUEL COMBAT SANDBOX</span><h1>Savaş Arenası & Yazar Kontrol Merkezi</h1></div>
          <div class="manual-arena-tools">
            <button class="btn ghost" data-action="refill">Can & Mana Doldur</button>
            ${this.legacySessionCount ? `<button class="btn danger small" data-action="purge-legacy">Eski savaş kayıtlarını sil (${this.legacySessionCount})</button>` : ""}
          </div>
        </header>

        <section class="manual-action-panel">
          <h2>Hamle Parametreleri</h2>
          <div class="manual-fighter-row">
            <label><span>Saldıran (aktif taraf)</span><select data-role="attacker">${this.characterOptions(0)}</select></label>
            <button class="swap-fighters" data-action="swap" title="Tarafları değiştir" aria-label="Tarafları değiştir">⇄</button>
            <label><span>Hedef (savunan)</span><select data-role="target">${this.characterOptions(1)}</select></label>
          </div>
          <label class="manual-action-select"><span>Eylem / Yetenek Seçimi</span><select data-role="skill"></select></label>
          <label class="manual-critical-toggle"><input type="checkbox" data-role="force-critical"><span>💥 Bu hamle kritik vuruş olsun (x2 hasar)</span></label>
          <button class="manual-execute" data-action="execute">Seçilen Hamleyi Gerçekleştir</button>
          <div class="manual-action-error" data-role="error"></div>
        </section>

        <section class="manual-status-section">
          <div class="manual-section-head"><h2>Savaşan Tarafların Durumu</h2><span>Bu ekran kapanınca sandbox state sıfırlanır.</span></div>
          <div class="manual-status-list" data-role="status"></div>
        </section>
      </section>

      <aside class="manual-combat-log">
        <header><div><span class="eyebrow">COMBAT LOG</span><h2>Savaş Kayıtları</h2></div><button class="btn ghost small" data-action="clear-log">Logları Temizle</button></header>
        <div class="manual-log-list" data-role="log"></div>
      </aside>
    </div>`;

    this.bindEvents();
    await this.refreshSelectionContext();
    this.renderLog();
  }

  private characterOptions(preferred: number): string {
    return this.characters.map((c, index) => `<option value="${esc(c.id)}" ${index === preferred ? "selected" : ""}>${esc(c.name)}</option>`).join("");
  }

  private bindEvents(): void {
    this.host.querySelector<HTMLSelectElement>('[data-role="attacker"]')?.addEventListener("change", () => void this.onFighterChanged("attacker"));
    this.host.querySelector<HTMLSelectElement>('[data-role="target"]')?.addEventListener("change", () => void this.onFighterChanged("target"));
    this.host.querySelector<HTMLButtonElement>('[data-action="swap"]')?.addEventListener("click", () => void this.swapFighters());
    this.host.querySelector<HTMLButtonElement>('[data-action="execute"]')?.addEventListener("click", () => void this.execute());
    this.host.querySelector<HTMLButtonElement>('[data-action="refill"]')?.addEventListener("click", () => this.refill());
    this.host.querySelector<HTMLButtonElement>('[data-action="clear-log"]')?.addEventListener("click", () => { this.logs = []; this.renderLog(); });
    this.host.querySelector<HTMLButtonElement>('[data-action="purge-legacy"]')?.addEventListener("click", () => void this.purgeLegacySessions());
  }

  private ids(): { attackerId: string; targetId: string } {
    return {
      attackerId: this.host.querySelector<HTMLSelectElement>('[data-role="attacker"]')?.value ?? "",
      targetId: this.host.querySelector<HTMLSelectElement>('[data-role="target"]')?.value ?? "",
    };
  }

  private async onFighterChanged(changed: "attacker" | "target"): Promise<void> {
    const attacker = this.host.querySelector<HTMLSelectElement>('[data-role="attacker"]');
    const target = this.host.querySelector<HTMLSelectElement>('[data-role="target"]');
    if (!attacker || !target) return;
    if (attacker.value === target.value) {
      const replacement = this.characters.find((c) => c.id !== (changed === "attacker" ? attacker.value : target.value));
      if (replacement) {
        if (changed === "attacker") target.value = replacement.id;
        else attacker.value = replacement.id;
      }
    }
    await this.refreshSelectionContext();
  }

  private async swapFighters(): Promise<void> {
    const attacker = this.host.querySelector<HTMLSelectElement>('[data-role="attacker"]');
    const target = this.host.querySelector<HTMLSelectElement>('[data-role="target"]');
    if (!attacker || !target) return;
    const previous = attacker.value;
    attacker.value = target.value;
    target.value = previous;
    await this.refreshSelectionContext();
  }

  private async refreshSelectionContext(): Promise<void> {
    const { attackerId, targetId } = this.ids();
    if (!attackerId || !targetId || attackerId === targetId) return;
    this.setError("");
    try {
      this.learnedSkills = (await this.skillGateway.listForCharacter(attackerId)).filter((skill) =>
        (skill.kind === "physical" || skill.kind === "magical") && (skill.resourceKind === "none" || skill.resourceKind === "mana")
      );
      this.renderSkillOptions();
      const probe = await this.gateway.previewImpact({
        attackerCharacterId: attackerId,
        targetCharacterId: targetId,
        skillId: BASIC_ATTACK_SKILL_ID,
        rngSeed: 42,
        forceCritical: false,
      });
      this.ensureVitals(probe);
      this.renderStatus();
    } catch (error) {
      this.setError(error instanceof Error ? error.message : String(error));
    }
  }

  private renderSkillOptions(): void {
    const select = this.host.querySelector<HTMLSelectElement>('[data-role="skill"]');
    if (!select) return;
    const previous = select.value;
    const options = [
      `<option value="${BASIC_ATTACK_SKILL_ID}">Normal Saldırı</option>`,
      ...this.learnedSkills.map((skill) => `<option value="${esc(skill.id)}">${esc(skill.name)}${skill.resourceCost ? ` · ${skill.resourceCost} mana` : ""}</option>`),
    ];
    select.innerHTML = options.join("");
    if (Array.from(select.options).some((option) => option.value === previous)) select.value = previous;
  }

  private ensureVitals(preview: CombatImpactPreviewDto): void {
    if (!this.vitals.has(preview.attackerCharacterId)) {
      this.vitals.set(preview.attackerCharacterId, { hp: preview.attackerMaxHp, maxHp: preview.attackerMaxHp, mana: preview.attackerMaxMana, maxMana: preview.attackerMaxMana });
    }
    if (!this.vitals.has(preview.targetCharacterId)) {
      this.vitals.set(preview.targetCharacterId, { hp: preview.targetMaxHp, maxHp: preview.targetMaxHp, mana: preview.targetMaxMana, maxMana: preview.targetMaxMana });
    }
  }

  private async execute(): Promise<void> {
    const { attackerId, targetId } = this.ids();
    const skillId = this.host.querySelector<HTMLSelectElement>('[data-role="skill"]')?.value ?? BASIC_ATTACK_SKILL_ID;
    const forceCritical = this.host.querySelector<HTMLInputElement>('[data-role="force-critical"]')?.checked ?? false;
    if (!attackerId || !targetId || attackerId === targetId) { this.setError("Farklı iki karakter seç."); return; }

    const attackerVitals = this.vitals.get(attackerId);
    const targetVitals = this.vitals.get(targetId);
    if (!attackerVitals || !targetVitals) { await this.refreshSelectionContext(); return; }
    if (attackerVitals.hp <= 0) { this.setError("Saldıran karakterin HP'si 0. Can & Mana Doldur ile resetleyebilirsin."); return; }
    if (targetVitals.hp <= 0) { this.setError("Hedef zaten düşmüş durumda. Tarafları değiştir veya Can & Mana Doldur."); return; }

    const selectedSkill = this.learnedSkills.find((skill) => skill.id === skillId);
    if (selectedSkill?.resourceKind === "mana" && attackerVitals.mana < selectedSkill.resourceCost) {
      this.setError(`Mana yetersiz: ${attackerVitals.mana}/${selectedSkill.resourceCost}`);
      return;
    }

    try {
      const preview = await this.gateway.previewImpact({
        attackerCharacterId: attackerId,
        targetCharacterId: targetId,
        skillId,
        rngSeed: 42 + this.actionSequence,
        forceCritical,
      });
      this.ensureVitals(preview);
      const actor = this.vitals.get(attackerId)!;
      const target = this.vitals.get(targetId)!;
      actor.mana = clamp(actor.mana + preview.resolution.manaDelta, 0, actor.maxMana);
      target.hp = clamp(target.hp + preview.resolution.hpDelta, 0, target.maxHp);
      const damage = preview.resolution.hpDelta < 0 ? -preview.resolution.hpDelta : 0;
      this.logs.push({
        id: ++this.actionSequence,
        attacker: preview.attackerName,
        target: preview.targetName,
        skill: preview.skillName === "Basic Attack" ? "Normal Saldırı" : preview.skillName,
        damage,
        critical: preview.resolution.wasCritical,
        dodged: preview.resolution.wasDodged,
      });
      this.setError("");
      this.renderStatus();
      this.renderLog();
    } catch (error) {
      this.setError(error instanceof Error ? error.message : String(error));
    }
  }

  private refill(): void {
    for (const state of this.vitals.values()) {
      state.hp = state.maxHp;
      state.mana = state.maxMana;
    }
    this.setError("");
    this.renderStatus();
  }

  private async purgeLegacySessions(): Promise<void> {
    const sessions = await this.gateway.listAll();
    if (!sessions.length) return;
    if (!window.confirm(`${sessions.length} eski durable savaş kaydı kalıcı olarak silinsin mi?`)) return;
    try {
      for (const session of sessions) await this.gateway.delete(session.session.id);
      this.legacySessionCount = 0;
      this.host.querySelector<HTMLButtonElement>('[data-action="purge-legacy"]')?.remove();
    } catch (error) {
      this.setError(error instanceof Error ? error.message : String(error));
    }
  }

  private renderStatus(): void {
    const host = this.host.querySelector<HTMLElement>('[data-role="status"]');
    if (!host) return;
    const { attackerId, targetId } = this.ids();
    host.innerHTML = [this.statusCard(attackerId, "⚔", "attacker"), this.statusCard(targetId, "🛡", "target")].join("");
    host.querySelectorAll<HTMLElement>('[data-meter]').forEach((node) => node.style.setProperty("--meter", `${Number(node.dataset.meter ?? 0)}%`));
  }

  private statusCard(characterId: string, icon: string, role: "attacker" | "target"): string {
    const character = this.characters.find((c) => c.id === characterId);
    const state = this.vitals.get(characterId);
    if (!character || !state) return "";
    const hpPct = state.maxHp ? clamp(state.hp / state.maxHp * 100, 0, 100) : 0;
    const manaPct = state.maxMana ? clamp(state.mana / state.maxMana * 100, 0, 100) : 0;
    return `<article class="manual-status-card ${role}">
      <div><strong>${icon} ${esc(character.name)}</strong><span>HP: ${state.hp}/${state.maxHp} | Mana: ${state.mana}/${state.maxMana}</span></div>
      <div class="manual-meter hp"><i data-meter="${hpPct}"></i><b>${Math.round(hpPct)}% HP</b></div>
      <div class="manual-meter mana"><i data-meter="${manaPct}"></i><b>${Math.round(manaPct)}% Mana</b></div>
    </article>`;
  }

  private renderLog(): void {
    const host = this.host.querySelector<HTMLElement>('[data-role="log"]');
    if (!host) return;
    if (!this.logs.length) {
      host.innerHTML = `<div class="manual-log-empty">Henüz hamle yapılmadı.</div>`;
      return;
    }
    host.innerHTML = [...this.logs].reverse().map((entry) => {
      const result = entry.dodged ? "SALDIRIDAN KAÇINDI" : `${entry.damage} HASAR`;
      return `<article class="manual-log-entry ${entry.critical ? "critical" : ""}"><span>#${entry.id}</span><strong>${entry.critical ? "💥 KRİTİK · " : ""}${esc(entry.attacker)} → ${esc(entry.target)}</strong><p>${esc(entry.skill)} · ${result}</p></article>`;
    }).join("");
  }

  private setError(message: string): void {
    const host = this.host.querySelector<HTMLElement>('[data-role="error"]');
    if (host) host.textContent = message;
  }
}
