export type StatusEffectKind = "damage_over_time" | "heal_over_time" | "stun" | "stat_modifier";
export type StackingPolicy = "refresh";
export type StatusModifierKind = "armor_multiplier" | "damage_multiplier";
export interface StatusModifierSpec { kind: StatusModifierKind; multiplier: number; }
export interface StatusEffectDefinitionDto {
  id:string;
  effectKey:string;
  name:string;
  kind:StatusEffectKind;
  stackingPolicy:StackingPolicy;
  durationTurns:number;
  power:number;
  modifier:StatusModifierSpec|null;
}
export interface StatusEffectGateway {
  list():Promise<StatusEffectDefinitionDto[]>;
  forSkill(skillId:string):Promise<StatusEffectDefinitionDto[]>;
  setForSkill(skillId:string,effectIds:string[]):Promise<void>;
}
