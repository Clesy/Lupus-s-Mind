import { invoke } from "@tauri-apps/api/core";
import type { StatusEffectDefinitionDto,StatusEffectGateway } from "../application/StatusEffectGateway";
export const tauriStatusEffectGateway:StatusEffectGateway={
  list:()=>invoke<StatusEffectDefinitionDto[]>("status_effects_list"),
  forSkill:(skillId)=>invoke<StatusEffectDefinitionDto[]>("status_effects_for_skill",{skillId}),
  setForSkill:(skillId,effectIds)=>invoke<void>("status_effects_set_for_skill",{skillId,effectIds}),
};
