import type { StatusEffectDefinitionDto,StatusEffectGateway } from "../application/StatusEffectGateway";

export class SkillEffectBindingPanel {
  constructor(private readonly gateway:StatusEffectGateway){}
  async mount(host:HTMLElement,skillId:string):Promise<void>{
    const [all,bound]=await Promise.all([this.gateway.list(),this.gateway.forSkill(skillId)]);
    const selected=new Set(bound.map((e)=>e.id));
    host.innerHTML=`<section class="effect-binding"><div class="section-label">Frozen combat effects</div><p class="effect-help">Definitions are canonical; running battles receive immutable snapshots. C2.2 supports Refresh stacking only.</p><div class="effect-binding-grid">${all.map((e)=>this.row(e,selected.has(e.id))).join("")}</div><div class="effect-binding-actions"><span data-effect-save-state></span><button class="btn" data-save-effects>Save effect bindings</button></div></section>`;
    host.querySelector<HTMLButtonElement>("[data-save-effects]")?.addEventListener("click",()=>void this.save(host,skillId));
  }
  private row(e:StatusEffectDefinitionDto,checked:boolean):string{
    const payload=e.kind==="stat_modifier"?`${e.modifier?.kind.replaceAll("_"," ")} × ${e.modifier?.multiplier}`:`${e.power} power`;
    return `<label class="effect-option"><input type="checkbox" value="${e.id}" data-effect-id ${checked?"checked":""}><span><strong>${this.escape(e.name)}</strong><small>${e.kind.replaceAll("_"," ")} · ${payload} · ${e.durationTurns}t</small></span><em>${e.stackingPolicy}</em></label>`;
  }
  private async save(host:HTMLElement,skillId:string):Promise<void>{
    const ids:Array<string>=[];
    host.querySelectorAll<HTMLInputElement>("[data-effect-id]:checked").forEach((el)=>ids.push(el.value));
    const state=host.querySelector<HTMLElement>("[data-effect-save-state]");
    try{await this.gateway.setForSkill(skillId,ids);if(state)state.textContent="Saved";}catch(error){if(state)state.textContent=String(error);}
  }
  private escape(value:string):string{return value.replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;");}
}
