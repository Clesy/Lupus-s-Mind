import type { CharacterGateway, CharacterSummaryDto } from "../../characters/application/CharacterGateway";
import type { FactionDto, FactionGateway } from "../../factions/application/FactionGateway";
import type { ItemDto, ItemGateway, ItemType, StatModifierDto } from "../../items/application/ItemGateway";
import { ITEM_RARITY_LABELS, ITEM_TYPE_LABELS, STAT_LABELS } from "../../items/application/ItemPresentation";
import type { AssetGateway } from "../../assets/application/AssetGateway";
import { assetBlobUrl } from "../../assets/application/imageAssets";
import type { InventoryGateway, OwnershipDto } from "../application/InventoryGateway";

const esc=(value:string):string=>value.replace(/[&<>"']/g,(char)=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[char]!);
const TYPE_GLYPHS:Record<ItemType,string>={weapon:"⚔",armor:"⬢",accessory:"◇",material:"◆",consumable:"✦"};
type OwnershipState="all"|"equipped"|"owned"|"unowned";

export class InventoryScreen {
  private items:ItemDto[]=[];
  private chars:CharacterSummaryDto[]=[];
  private factions:FactionDto[]=[];
  private ownerships:OwnershipDto[]=[];
  private chapter=1;
  private ownerFilter="all";
  private stateFilter:OwnershipState="all";
  private search="";
  private artworkUrls=new Map<string,string|null>();

  constructor(
    private readonly root:HTMLElement,
    private readonly inventory:InventoryGateway,
    private readonly itemGateway:ItemGateway,
    private readonly charGateway:CharacterGateway,
    private readonly factionGateway:FactionGateway,
    private readonly assets:AssetGateway,
  ){}

  async render():Promise<void>{
    this.root.innerHTML=`
      <div class="world-system-shell inventory-page-shell">
        <header class="studio-page-head inventory-page-head">
          <div class="page-heading-copy"><div class="eyebrow">Ownership ≠ equipment</div><h1>Inventory & Ownership</h1><p>See who owns every physical item at a chapter without changing equipment state.</p></div>
        </header>
        <section class="inventory-control-panel" aria-label="Inventory filters">
          <div class="inventory-toolbar">
            <label><span>Chapter</span><input data-role="chapter" type="number" min="1" value="1"></label>
            <label><span>Owner</span><select data-role="owner"><option value="all">All owners</option></select></label>
            <label class="inventory-search-field"><span>Find item</span><input data-role="search" type="search" placeholder="Name, type, rarity, tag or effect"></label>
          </div>
          <div class="inventory-statebar">
            <div class="inventory-filter-pills" data-role="state-filter">
              <button class="inventory-filter-pill active" data-state="all">All <b data-count="all">0</b></button>
              <button class="inventory-filter-pill equipped" data-state="equipped">Equipped <b data-count="equipped">0</b></button>
              <button class="inventory-filter-pill owned" data-state="owned">Owned <b data-count="owned">0</b></button>
              <button class="inventory-filter-pill unowned" data-state="unowned">Unowned <b data-count="unowned">0</b></button>
            </div>
            <div class="inventory-owner-summary" data-role="summary"></div>
          </div>
        </section>
        <section class="inventory-content" data-role="content">
          <div class="inventory-grid" data-role="grid"></div>
        </section>
      </div>`;

    this.root.querySelector<HTMLInputElement>('[data-role="chapter"]')?.addEventListener("change",event=>{
      this.chapter=Math.max(1,Number((event.currentTarget as HTMLInputElement).value)||1);
      void this.refreshOwnerships();
    });
    this.root.querySelector<HTMLSelectElement>('[data-role="owner"]')?.addEventListener("change",event=>{
      this.ownerFilter=(event.currentTarget as HTMLSelectElement).value;
      this.paint();
    });
    this.root.querySelector<HTMLInputElement>('[data-role="search"]')?.addEventListener("input",event=>{
      this.search=(event.currentTarget as HTMLInputElement).value.trim().toLowerCase();
      this.paint();
    });
    this.root.querySelectorAll<HTMLButtonElement>('[data-state]').forEach(button=>button.addEventListener("click",()=>{
      this.stateFilter=button.dataset.state as OwnershipState;
      this.root.querySelectorAll<HTMLButtonElement>('[data-state]').forEach(node=>node.classList.toggle("active",node===button));
      this.paint();
    }));
    await this.refreshAll();
  }

  private async refreshAll():Promise<void>{
    [this.items,this.chars,this.factions]=await Promise.all([this.itemGateway.list(),this.charGateway.list(),this.factionGateway.list()]);
    const select=this.root.querySelector<HTMLSelectElement>('[data-role="owner"]');
    if(select)select.innerHTML=`<option value="all">All owners</option><optgroup label="Characters">${this.chars.map(character=>`<option value="character:${esc(character.id)}">${esc(character.name)}</option>`).join("")}</optgroup><optgroup label="Factions">${this.factions.map(faction=>`<option value="faction:${esc(faction.id)}">${esc(faction.name)}</option>`).join("")}</optgroup>`;
    await this.refreshOwnerships();
  }

  private async refreshOwnerships():Promise<void>{
    this.ownerships=await this.inventory.listAt(this.chapter);
    this.paint();
  }

  private ownershipState(ownership:OwnershipDto|undefined):Exclude<OwnershipState,"all">{
    return ownership?.isEquipped?"equipped":ownership?"owned":"unowned";
  }

  private paint():void{
    const host=this.root.querySelector<HTMLElement>('[data-role="grid"]');
    if(!host)return;
    const ownerByItem=new Map(this.ownerships.map(ownership=>[ownership.itemId,ownership]));
    const ownerScoped=this.items.filter(item=>{
      if(this.ownerFilter==="all")return true;
      const ownership=ownerByItem.get(item.id);
      return ownership?`${ownership.ownerKind}:${ownership.ownerId}`===this.ownerFilter:false;
    });
    const counts={
      all:ownerScoped.length,
      equipped:ownerScoped.filter(item=>this.ownershipState(ownerByItem.get(item.id))==="equipped").length,
      owned:ownerScoped.filter(item=>this.ownershipState(ownerByItem.get(item.id))==="owned").length,
      unowned:ownerScoped.filter(item=>this.ownershipState(ownerByItem.get(item.id))==="unowned").length,
    };
    (Object.keys(counts) as Array<keyof typeof counts>).forEach(key=>{const node=this.root.querySelector<HTMLElement>(`[data-count="${key}"]`);if(node)node.textContent=String(counts[key]);});

    const rows=ownerScoped.filter(item=>{
      const state=this.ownershipState(ownerByItem.get(item.id));
      if(this.stateFilter!=="all"&&state!==this.stateFilter)return false;
      if(!this.search)return true;
      const haystack=[item.name,item.description,item.itemType,item.rarity,...item.tags,...item.modifiers.map(modifier=>STAT_LABELS[modifier.stat])].join(" ").toLowerCase();
      return haystack.includes(this.search);
    });
    this.paintSummary(counts);

    host.innerHTML=rows.length?rows.map(item=>this.card(item,ownerByItem.get(item.id))).join(""):`<div class="empty-state inventory-empty"><strong>No inventory cards match</strong><span>Change the owner, state or search filter.</span></div>`;
    host.querySelectorAll<HTMLButtonElement>('[data-transfer]').forEach(button=>button.addEventListener("click",()=>void this.openTransfer(button.dataset.transfer!)));
    host.querySelectorAll<HTMLButtonElement>('[data-release]').forEach(button=>button.addEventListener("click",()=>void this.release(button.dataset.release!)));
    void this.hydrateArtwork(rows.map(item=>item.id),host);
  }

  private paintSummary(counts:{all:number;equipped:number;owned:number;unowned:number}):void{
    const summary=this.root.querySelector<HTMLElement>('[data-role="summary"]');
    if(!summary)return;
    const selected=this.ownerFilter==="all"?"All inventory":this.ownerFilter.startsWith("character:")?this.chars.find(character=>`character:${character.id}`===this.ownerFilter)?.name:this.factions.find(faction=>`faction:${faction.id}`===this.ownerFilter)?.name;
    summary.innerHTML=`<span><strong>${esc(selected||"Selected owner")}</strong><small>Chapter ${this.chapter}</small></span><span class="inventory-summary-metric"><b>${counts.equipped}</b><small>equipped</small></span><span class="inventory-summary-metric"><b>${counts.owned}</b><small>owned</small></span>`;
  }

  private card(item:ItemDto,ownership:OwnershipDto|undefined):string{
    const state=this.ownershipState(ownership);
    const modifiers=item.modifiers.slice(0,5).map(modifier=>this.modifierChip(modifier)).join("");
    const tags=item.tags.slice(0,3).map((tag,index)=>`<span class="tag tag-tone-${index%5}">${esc(tag)}</span>`).join("");
    return `<article class="inventory-card inventory-card-rich rarity-${esc(item.rarity)} state-${state}">
      <div class="inventory-card-visual" data-item-art-id="${esc(item.id)}">
        <span class="inventory-card-glyph" data-artwork-fallback>${TYPE_GLYPHS[item.itemType]}</span>
        <img data-artwork-image alt="" hidden />
        <div class="inventory-art-shade"></div>
        <span class="inventory-rarity-badge">${esc(ITEM_RARITY_LABELS[item.rarity])}</span>
        <span class="ownership-badge ${state}">${state==="equipped"?"EQUIPPED":state==="owned"?"OWNED":"UNOWNED"}</span>
      </div>
      <div class="inventory-card-body">
        <div class="inventory-card-kicker"><span>${esc(ITEM_TYPE_LABELS[item.itemType])}</span><span>${item.modifiers.length} effects</span></div>
        <div class="inventory-card-title"><strong>${esc(item.name)}</strong><small>${ownership?`${esc(ownership.ownerName)} · since Ch.${ownership.acquiredChapter}`:"No owner at this chapter"}</small></div>
        <div class="inventory-modifier-chips">${modifiers||'<span class="modifier-empty">No stat effects</span>'}${item.modifiers.length>5?`<span class="modifier-more">+${item.modifiers.length-5}</span>`:""}</div>
        <div class="inventory-card-tags">${tags||'<span class="tag muted">No tags</span>'}${item.tags.length>3?`<span class="tag muted">+${item.tags.length-3}</span>`:""}</div>
        ${ownership?.note?`<p class="inventory-note">${esc(ownership.note)}</p>`:""}
        <div class="inventory-card-actions"><button class="btn ghost small" data-transfer="${esc(item.id)}">${ownership?"Transfer":"Assign"}</button>${ownership?`<button class="btn ghost small" data-release="${esc(item.id)}">Release</button>`:""}</div>
      </div>
    </article>`;
  }

  private modifierChip(modifier:StatModifierDto):string{
    return `<span class="modifier-chip stat-tone stat-${esc(modifier.stat)} ${modifier.value<0?"negative":"positive"}"><small>${esc(STAT_LABELS[modifier.stat])}</small><b>${modifier.value>=0?"+":""}${modifier.value}</b></span>`;
  }

  private async artworkUrl(itemId:string):Promise<string|null>{
    if(this.artworkUrls.has(itemId))return this.artworkUrls.get(itemId)??null;
    const asset=await this.assets.getItemArtwork(itemId);const url=asset?assetBlobUrl(asset):null;this.artworkUrls.set(itemId,url);return url;
  }

  private async hydrateArtwork(itemIds:string[],scope:ParentNode):Promise<void>{
    await Promise.all(itemIds.map(async itemId=>{try{const url=await this.artworkUrl(itemId);scope.querySelectorAll<HTMLElement>(`[data-item-art-id="${CSS.escape(itemId)}"]`).forEach(node=>{const image=node.querySelector<HTMLImageElement>('[data-artwork-image]');const fallback=node.querySelector<HTMLElement>('[data-artwork-fallback]');if(image){if(url){image.src=url;image.hidden=false;}else{image.removeAttribute("src");image.hidden=true;}}if(fallback)fallback.hidden=!!url;node.classList.toggle("has-artwork",!!url);});}catch{}}));
  }

  private async openTransfer(itemId:string):Promise<void>{
    const item=this.items.find(candidate=>candidate.id===itemId);
    const modal=document.createElement("div");modal.className="inline-modal-host";
    modal.innerHTML=`<div class="inline-modal-backdrop"><form class="inline-modal"><header><div><span class="eyebrow">Ownership transfer</span><h2>${esc(item?.name??"Item")}</h2></div><button type="button" class="btn ghost" data-close>Close</button></header><label><span>Owner type</span><select name="kind"><option value="character">Character</option><option value="faction">Faction</option></select></label><label><span>Owner</span><select name="owner"></select></label><label><span>Chapter</span><input name="chapter" type="number" min="1" value="${this.chapter}"></label><label><span>Note</span><input name="note" placeholder="Gift, loot, inheritance…"></label><button class="btn primary" type="submit">Save ownership</button><div class="form-error" data-error hidden></div></form></div>`;
    this.root.appendChild(modal);
    const kind=modal.querySelector<HTMLSelectElement>('[name="kind"]')!,owner=modal.querySelector<HTMLSelectElement>('[name="owner"]')!;
    const paintOwners=()=>{owner.innerHTML=(kind.value==="character"?this.chars:this.factions).map(value=>`<option value="${esc(value.id)}">${esc(value.name)}</option>`).join("");};
    paintOwners();kind.addEventListener("change",paintOwners);modal.querySelector('[data-close]')?.addEventListener("click",()=>modal.remove());
    modal.querySelector<HTMLFormElement>("form")?.addEventListener("submit",event=>{event.preventDefault();void(async()=>{const data=new FormData(event.currentTarget as HTMLFormElement);try{await this.inventory.transfer({itemId,ownerKind:String(data.get("kind")) as "character"|"faction",ownerId:String(data.get("owner")),chapter:Math.max(1,Number(data.get("chapter")||1)),note:String(data.get("note")||"")});modal.remove();await this.refreshOwnerships();}catch(error){const node=modal.querySelector<HTMLElement>('[data-error]');if(node){node.hidden=false;node.textContent=error instanceof Error?error.message:String(error);}}})();});
  }

  private async release(itemId:string):Promise<void>{
    const raw=prompt("Release ownership at chapter:",String(this.chapter));if(!raw)return;
    await this.inventory.release(itemId,Math.max(1,Number(raw)));
    await this.refreshOwnerships();
  }
}
