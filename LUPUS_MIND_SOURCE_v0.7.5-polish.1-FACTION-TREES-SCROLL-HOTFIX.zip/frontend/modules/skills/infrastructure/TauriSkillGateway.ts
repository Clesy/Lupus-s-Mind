import { invoke } from "@tauri-apps/api/core";
import type { SkillDto, SkillGateway, SkillPreviewDto, SkillSummaryDto, UpsertSkillInput } from "../application/SkillGateway";

export const tauriSkillGateway: SkillGateway = {
  list: () => invoke<SkillSummaryDto[]>("skills_list"),
  get: (id) => invoke<SkillDto>("skills_get", { id }),
  create: (input) => invoke<SkillDto>("skills_create", { input }),
  update: (id, input) => invoke<SkillDto>("skills_update", { id, input }),
  remove: (id) => invoke<void>("skills_delete", { id }),
  teach: (characterId, skillId) => invoke<void>("skills_teach", { characterId, skillId }),
  forget: (characterId, skillId) => invoke<void>("skills_forget", { characterId, skillId }),
  listForCharacter: (characterId) => invoke<SkillDto[]>("skills_list_for_character", { characterId }),
  preview: (characterId, skillId) => invoke<SkillPreviewDto>("skills_preview", { characterId, skillId }),
};
