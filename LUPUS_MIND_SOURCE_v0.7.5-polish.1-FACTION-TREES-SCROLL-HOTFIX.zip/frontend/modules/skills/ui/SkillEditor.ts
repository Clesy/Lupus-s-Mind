import type { ResourceKind, SkillDto, SkillGateway, SkillKind, UpsertSkillInput } from "../application/SkillGateway";
import { ScalingEditor } from "./ScalingEditor";

export class SkillEditor {
  constructor(private readonly gateway: SkillGateway) {}

  mount(host: HTMLElement, existing: SkillDto | null, onSaved: (skill: SkillDto) => void, onCancel: () => void): void {
    host.innerHTML = `
      <form class="skill-editor" data-skill-form>
        <div class="editor-title"><div><span class="eyebrow">${existing ? "Edit definition" : "New definition"}</span><h2>${existing ? existing.name : "Create skill"}</h2></div><button type="button" class="icon-btn" data-cancel>×</button></div>
        <div class="field-grid two"><label>Name<input name="name" required value="${this.escape(existing?.name ?? "")}"></label><label>Kind<select name="kind">${this.options(["physical","magical","healing","utility"], existing?.kind ?? "physical")}</select></label></div>
        <label>Description<textarea name="description" rows="4">${this.escape(existing?.description ?? "")}</textarea></label>
        <div class="field-grid three"><label>Base power<input name="basePower" type="number" min="0" step="0.1" value="${existing?.basePower ?? 0}"></label><label>Resource<select name="resourceKind">${this.options(["none","mana","stamina","health"], existing?.resourceKind ?? "mana")}</select></label><label>Cost<input name="resourceCost" type="number" min="0" step="1" value="${existing?.resourceCost ?? 0}"></label></div>
        <div class="field-grid two"><label>Cooldown turns<input name="cooldownTurns" type="number" min="0" step="1" value="${existing?.cooldownTurns ?? 0}"></label><label>Tags<input name="tags" value="${this.escape(existing?.tags.join(", ") ?? "")}" placeholder="burst, dragon, melee"></label></div>
        <div class="scaling-editor-host" data-scaling-editor></div>
        <div class="editor-error" data-editor-error></div>
        <div class="editor-actions"><button type="button" class="btn" data-cancel>Cancel</button><button class="btn primary" type="submit">${existing ? "Save changes" : "Create skill"}</button></div>
      </form>`;

    const scalingHost = host.querySelector<HTMLElement>("[data-scaling-editor]");
    const form = host.querySelector<HTMLFormElement>("[data-skill-form]");
    if (!scalingHost || !form) throw new Error("SkillEditor mount failed");
    const scaling = new ScalingEditor(scalingHost, existing?.scaling ?? []);
    scaling.render();
    host.querySelectorAll<HTMLButtonElement>("[data-cancel]").forEach((button) => button.addEventListener("click", onCancel));
    form.addEventListener("submit", async (event) => {
      event.preventDefault();
      const error = host.querySelector<HTMLElement>("[data-editor-error]");
      if (error) error.textContent = "";
      try {
        const data = new FormData(form);
        const resourceKind = String(data.get("resourceKind")) as ResourceKind;
        const input: UpsertSkillInput = {
          name: String(data.get("name") ?? "").trim(),
          description: String(data.get("description") ?? ""),
          kind: String(data.get("kind")) as SkillKind,
          resourceKind,
          basePower: Number(data.get("basePower")),
          resourceCost: resourceKind === "none" ? 0 : Number(data.get("resourceCost")),
          cooldownTurns: Number(data.get("cooldownTurns")),
          scaling: scaling.value(),
          tags: String(data.get("tags") ?? "").split(",").map((tag) => tag.trim()).filter(Boolean),
        };
        const saved = existing ? await this.gateway.update(existing.id, input) : await this.gateway.create(input);
        onSaved(saved);
      } catch (cause) {
        if (error) error.textContent = cause instanceof Error ? cause.message : String(cause);
      }
    });
  }

  private options(values: readonly string[], selected: string): string {
    return values.map((value) => `<option value="${value}" ${value === selected ? "selected" : ""}>${value[0]?.toUpperCase()}${value.slice(1)}</option>`).join("");
  }

  private escape(value: string): string {
    return value.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;");
  }
}
