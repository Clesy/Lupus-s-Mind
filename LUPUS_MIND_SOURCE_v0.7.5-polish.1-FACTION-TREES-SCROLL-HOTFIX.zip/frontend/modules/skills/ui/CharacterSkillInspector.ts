import type { CharacterGateway } from "../../characters/application/CharacterGateway";
import type { SkillDto, SkillGateway, SkillPreviewDto } from "../application/SkillGateway";

export class CharacterSkillInspector {
  private characterId: string | null = null;
  private skillId: string | null = null;

  constructor(
    private readonly host: HTMLElement,
    private readonly characters: CharacterGateway,
    private readonly skills: SkillGateway,
  ) {}

  async init(): Promise<void> {
    const characters = await this.characters.list();
    this.characterId = characters[0]?.id ?? null;
    this.host.innerHTML = `
      <section class="inspector-panel">
        <div class="inspector-head"><div><span class="eyebrow">Character runtime preview</span><h3>Skill Inspector</h3></div></div>
        <label class="inspector-character">Character<select data-character>${characters.map((character) => `<option value="${character.id}">${this.escape(character.name)}</option>`).join("")}</select></label>
        <div data-inspector-content></div>
      </section>`;
    this.host.querySelector<HTMLSelectElement>("[data-character]")?.addEventListener("change", (event) => {
      this.characterId = (event.currentTarget as HTMLSelectElement).value;
      void this.refresh();
    });
    await this.refresh();
  }

  async selectSkill(skillId: string | null): Promise<void> {
    this.skillId = skillId;
    await this.refresh();
  }

  private async refresh(): Promise<void> {
    const content = this.host.querySelector<HTMLElement>("[data-inspector-content]");
    if (!content) return;
    if (!this.characterId) {
      content.innerHTML = `<div class="empty-note">Create a character before assigning skills.</div>`;
      return;
    }

    const learned = await this.skills.listForCharacter(this.characterId);
    const selectedLearned = this.skillId ? learned.some((skill) => skill.id === this.skillId) : false;
    let selected: SkillDto | null = null;
    let preview: SkillPreviewDto | null = null;
    if (this.skillId) {
      selected = await this.skills.get(this.skillId);
      preview = await this.skills.preview(this.characterId, this.skillId);
    }

    content.innerHTML = `
      ${selected ? `
        <div class="inspector-selected">
          <div><span class="eyebrow">Selected skill</span><strong>${this.escape(selected.name)}</strong></div>
          <button class="btn ${selectedLearned ? "danger" : "primary"}" data-assignment>${selectedLearned ? "Forget" : "Teach"}</button>
        </div>` : `<div class="empty-note">Select a skill to preview it against the character's effective stats.</div>`}
      ${preview ? this.previewMarkup(preview) : ""}
      <div class="learned-block"><div class="section-label">Learned skills · ${learned.length}</div>${learned.length ? learned.map((skill) => `<div class="learned-row"><span>${this.escape(skill.name)}</span><small>${skill.kind}</small></div>`).join("") : `<div class="empty-note">No learned skills.</div>`}</div>`;

    content.querySelector<HTMLButtonElement>("[data-assignment]")?.addEventListener("click", async () => {
      if (!this.characterId || !this.skillId) return;
      if (selectedLearned) await this.skills.forget(this.characterId, this.skillId);
      else await this.skills.teach(this.characterId, this.skillId);
      await this.refresh();
    });
  }

  private previewMarkup(preview: SkillPreviewDto): string {
    return `
      <div class="preview-card">
        <div class="preview-power"><span>Theoretical power</span><strong>${preview.theoreticalPower.toFixed(2)}</strong></div>
        <div class="preview-meta"><span>${preview.resourceCost} ${preview.resourceKind}</span><span>${preview.cooldownTurns} turn cooldown</span></div>
        <div class="contribution-list">${preview.contributions.length ? preview.contributions.map((entry) => `<div><span>${this.label(entry.stat)} · ${entry.sourceValue.toFixed(2)} × ${entry.coefficient.toFixed(2)}</span><strong>+${entry.contribution.toFixed(2)}</strong></div>`).join("") : `<div class="empty-note">No scaling contribution. Base power only.</div>`}</div>
        <p class="preview-disclaimer">Deterministic preview only. No target, mitigation, crit, dodge, resource mutation or cooldown runtime is evaluated here.</p>
      </div>`;
  }

  private label(value: string): string { return value.replaceAll("_", " ").replace(/\b\w/g, (letter) => letter.toUpperCase()); }
  private escape(value: string): string { return value.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;"); }
}
