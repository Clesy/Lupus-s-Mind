import type { ScalingStat, ScalingTerm } from "../application/SkillGateway";

const stats: readonly ScalingStat[] = ["strength", "agility", "vitality", "intelligence", "mind", "weapon_damage", "armor"];
const label = (value: string) => value.replaceAll("_", " ").replace(/\b\w/g, (letter) => letter.toUpperCase());

export class ScalingEditor {
  constructor(private readonly host: HTMLElement, private terms: ScalingTerm[]) {}

  render(): void {
    this.host.innerHTML = `
      <div class="scaling-head"><span>Scaling terms</span><button type="button" class="btn" data-scale-add>+ Add</button></div>
      <div class="scaling-list" data-scale-list></div>`;
    this.paintRows();
    this.host.querySelector<HTMLButtonElement>("[data-scale-add]")?.addEventListener("click", () => {
      const used = new Set(this.readRows().map((term) => term.stat));
      const next = stats.find((stat) => !used.has(stat));
      if (!next) return;
      this.terms = [...this.readRows(), { stat: next, coefficient: 1 }];
      this.paintRows();
    });
  }

  value(): ScalingTerm[] { return this.readRows(); }

  private paintRows(): void {
    const list = this.host.querySelector<HTMLElement>("[data-scale-list]");
    if (!list) return;
    if (this.terms.length === 0) {
      list.innerHTML = `<div class="empty-note">No scaling terms. Base power is deterministic on its own.</div>`;
      return;
    }
    list.innerHTML = this.terms.map((term, index) => `
      <div class="scaling-row" data-scale-row="${index}">
        <select data-scale-stat>${stats.map((stat) => `<option value="${stat}" ${stat === term.stat ? "selected" : ""}>${label(stat)}</option>`).join("")}</select>
        <div class="coefficient-field"><span>×</span><input data-scale-coefficient type="number" min="0" step="0.05" value="${term.coefficient}"></div>
        <button type="button" class="icon-btn" data-scale-remove="${index}" aria-label="Remove scaling term">×</button>
      </div>`).join("");
    list.querySelectorAll<HTMLButtonElement>("[data-scale-remove]").forEach((button) => {
      button.addEventListener("click", () => {
        const index = Number(button.dataset.scaleRemove);
        const current = this.readRows();
        current.splice(index, 1);
        this.terms = current;
        this.paintRows();
      });
    });
  }

  private readRows(): ScalingTerm[] {
    const rows = Array.from(this.host.querySelectorAll<HTMLElement>("[data-scale-row]"));
    if (rows.length === 0) return this.terms.length === 0 ? [] : this.terms;
    return rows.map((row) => {
      const stat = row.querySelector<HTMLSelectElement>("[data-scale-stat]")?.value as ScalingStat | undefined;
      const coefficient = Number(row.querySelector<HTMLInputElement>("[data-scale-coefficient]")?.value ?? "0");
      if (!stat || !Number.isFinite(coefficient)) throw new Error("Invalid scaling row");
      return { stat, coefficient };
    });
  }
}
