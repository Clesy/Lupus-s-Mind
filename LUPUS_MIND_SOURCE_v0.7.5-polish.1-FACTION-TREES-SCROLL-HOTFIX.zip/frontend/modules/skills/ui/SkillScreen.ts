import { shouldConfirmDestructive } from "../../../shared/preferences";
import type { CharacterGateway } from "../../characters/application/CharacterGateway";
import type { SkillDto, SkillGateway, SkillSummaryDto } from "../application/SkillGateway";
import { CharacterSkillInspector } from "./CharacterSkillInspector";
import { SkillEditor } from "./SkillEditor";
import type { StatusEffectGateway } from "../../status_effects/application/StatusEffectGateway";
import { SkillEffectBindingPanel } from "../../status_effects/ui/SkillEffectBindingPanel";

export class SkillScreen {
  private selectedId: string | null = null;
  private inspector: CharacterSkillInspector | null = null;

  constructor(
    private readonly root: HTMLElement,
    private readonly gateway: SkillGateway,
    private readonly characters: CharacterGateway,
    private readonly statusEffects: StatusEffectGateway,
  ) {}

  async render(): Promise<void> {
    this.root.innerHTML = `
      <div class="skill-screen">
        <section class="skill-library">
          <div class="module-title"><div><span class="eyebrow">Canonical definitions</span><h1>Skills</h1></div><button class="btn primary" data-new-skill>+ New</button></div>
          <input class="library-search" data-skill-search placeholder="Search skills…">
          <div class="skill-list" data-skill-list></div>
        </section>
        <section class="skill-workspace" data-skill-workspace></section>
        <aside class="skill-inspector" data-skill-inspector></aside>
      </div>`;

    this.root.querySelector<HTMLButtonElement>("[data-new-skill]")?.addEventListener("click", () => void this.openEditor(null));
    this.root.querySelector<HTMLInputElement>("[data-skill-search]")?.addEventListener("input", () => void this.paintList());
    const inspectorHost = this.root.querySelector<HTMLElement>("[data-skill-inspector]");
    if (!inspectorHost) throw new Error("Skill inspector host missing");
    this.inspector = new CharacterSkillInspector(inspectorHost, this.characters, this.gateway);
    await this.inspector.init();
    await this.paintList();
    await this.paintWorkspace();
  }

  public createNew(): void { void this.openEditor(null); }

  public async openById(id: string): Promise<void> {
    this.selectedId = id;
    await this.paintList();
    await this.paintWorkspace();
    await this.inspector?.selectSkill(id);
  }

  private async paintList(): Promise<void> {
    const list = this.root.querySelector<HTMLElement>("[data-skill-list]");
    if (!list) return;
    const query = this.root.querySelector<HTMLInputElement>("[data-skill-search]")?.value.trim().toLowerCase() ?? "";
    const skills = (await this.gateway.list()).filter((skill) => !query || `${skill.name} ${skill.kind}`.toLowerCase().includes(query));
    list.innerHTML = skills.length ? skills.map((skill) => this.listRow(skill)).join("") : `<div class="empty-note">No skills found.</div>`;
    list.querySelectorAll<HTMLButtonElement>("[data-skill-id]").forEach((button) => button.addEventListener("click", async () => {
      this.selectedId = button.dataset.skillId ?? null;
      await this.paintList();
      await this.paintWorkspace();
      await this.inspector?.selectSkill(this.selectedId);
    }));
  }

  private listRow(skill: SkillSummaryDto): string {
    const active = skill.id === this.selectedId ? " active" : "";
    return `<button class="skill-row${active}" data-skill-id="${skill.id}"><span><strong>${this.escape(skill.name)}</strong><small>${this.label(skill.kind)} · ${skill.basePower} base</small></span><span class="cooldown-chip">${skill.cooldownTurns}t</span></button>`;
  }

  private async paintWorkspace(): Promise<void> {
    const workspace = this.root.querySelector<HTMLElement>("[data-skill-workspace]");
    if (!workspace) return;
    if (!this.selectedId) {
      workspace.innerHTML = `<div class="workspace-empty"><span class="workspace-glyph">⌁</span><h2>Skill definitions</h2><p>Select a canonical skill or create a new one. Combat state does not live here.</p></div>`;
      return;
    }
    const skill = await this.gateway.get(this.selectedId);
    workspace.innerHTML = this.detailMarkup(skill);
    const effectHost=workspace.querySelector<HTMLElement>("[data-skill-effects]");
    if(effectHost) await new SkillEffectBindingPanel(this.statusEffects).mount(effectHost,skill.id);
    workspace.querySelector<HTMLButtonElement>("[data-edit]")?.addEventListener("click", () => void this.openEditor(skill));
    workspace.querySelector<HTMLButtonElement>("[data-delete]")?.addEventListener("click", async () => {
      if (shouldConfirmDestructive() && !confirm(`Delete ${skill.name}? Character assignments will be removed by FK cascade.`)) return;
      await this.gateway.remove(skill.id);
      this.selectedId = null;
      await this.paintList();
      await this.paintWorkspace();
      await this.inspector?.selectSkill(null);
    });
  }

  private detailMarkup(skill: SkillDto): string {
    return `
      <div class="skill-detail">
        <header class="detail-head"><div><span class="eyebrow">${this.label(skill.kind)} · ${this.label(skill.resourceKind)}</span><h2>${this.escape(skill.name)}</h2><p>${this.escape(skill.description || "No description recorded.")}</p></div><div class="detail-actions"><button class="btn" data-edit>Edit</button><button class="btn danger" data-delete>Delete</button></div></header>
        <div class="skill-kpis"><div><span>Base power</span><strong>${skill.basePower}</strong></div><div><span>Resource cost</span><strong>${skill.resourceCost}</strong></div><div><span>Cooldown</span><strong>${skill.cooldownTurns} turns</strong></div></div>
        <section class="detail-section"><div class="section-label">Scaling contract</div>${skill.scaling.length ? `<div class="scaling-readonly">${skill.scaling.map((term) => `<div><span>${this.label(term.stat)}</span><strong>× ${term.coefficient.toFixed(2)}</strong></div>`).join("")}</div>` : `<div class="empty-note">Base power only.</div>`}</section>
        <section class="detail-section"><div class="section-label">Tags</div><div class="tag-line">${skill.tags.length ? skill.tags.map((tag) => `<span>${this.escape(tag)}</span>`).join("") : `<small>No tags</small>`}</div></section>
        <div data-skill-effects></div>
        <section class="architecture-note"><strong>Skill ≠ Combat Action</strong><p>This record is canonical knowledge. Current resource, remaining cooldown, target, crit, dodge and damage application belong to the future combat runtime.</p></section>
      </div>`;
  }

  private async openEditor(existing: SkillDto | null): Promise<void> {
    const workspace = this.root.querySelector<HTMLElement>("[data-skill-workspace]");
    if (!workspace) return;
    new SkillEditor(this.gateway).mount(workspace, existing, (saved) => {
      this.selectedId = saved.id;
      void (async () => { await this.paintList(); await this.paintWorkspace(); await this.inspector?.selectSkill(saved.id); })();
    }, () => void this.paintWorkspace());
  }

  private label(value: string): string { return value.replaceAll("_", " ").replace(/\b\w/g, (letter) => letter.toUpperCase()); }
  private escape(value: string): string { return value.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;"); }
}
