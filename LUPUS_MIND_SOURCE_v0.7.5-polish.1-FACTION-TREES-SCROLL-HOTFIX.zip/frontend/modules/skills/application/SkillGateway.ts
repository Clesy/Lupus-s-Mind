export type SkillKind = "physical" | "magical" | "healing" | "utility";
export type ResourceKind = "none" | "mana" | "stamina" | "health";
export type ScalingStat = "strength" | "agility" | "vitality" | "intelligence" | "mind" | "weapon_damage" | "armor";

export interface ScalingTerm { stat: ScalingStat; coefficient: number; }
export interface ScalingContribution { stat: ScalingStat; sourceValue: number; coefficient: number; contribution: number; }

export interface SkillSummaryDto {
  id: string;
  name: string;
  kind: SkillKind;
  resourceKind: ResourceKind;
  basePower: number;
  resourceCost: number;
  cooldownTurns: number;
}

export interface SkillDto extends SkillSummaryDto {
  description: string;
  scaling: ScalingTerm[];
  tags: string[];
  createdAt: string;
  updatedAt: string;
}

export interface UpsertSkillInput {
  name: string;
  description?: string;
  kind: SkillKind;
  resourceKind: ResourceKind;
  basePower: number;
  resourceCost: number;
  cooldownTurns: number;
  scaling: ScalingTerm[];
  tags: string[];
}

export interface SkillPreviewDto {
  characterId: string;
  skillId: string;
  skillName: string;
  kind: SkillKind;
  resourceKind: ResourceKind;
  theoreticalPower: number;
  resourceCost: number;
  cooldownTurns: number;
  contributions: ScalingContribution[];
}

export interface SkillGateway {
  list(): Promise<SkillSummaryDto[]>;
  get(id: string): Promise<SkillDto>;
  create(input: UpsertSkillInput): Promise<SkillDto>;
  update(id: string, input: UpsertSkillInput): Promise<SkillDto>;
  remove(id: string): Promise<void>;
  teach(characterId: string, skillId: string): Promise<void>;
  forget(characterId: string, skillId: string): Promise<void>;
  listForCharacter(characterId: string): Promise<SkillDto[]>;
  preview(characterId: string, skillId: string): Promise<SkillPreviewDto>;
}
