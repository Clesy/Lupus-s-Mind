import type { PortraitAssetDto } from "./AssetGateway";

export const assetBlobUrl=(asset:PortraitAssetDto):string=>URL.createObjectURL(new Blob([new Uint8Array(asset.bytes)],{type:asset.mimeType}));

export async function prepareImageAsset(file:File,label="Artwork"):Promise<{mimeType:string;bytes:number[]}>{
  if(!file.type.startsWith("image/"))throw new Error("Choose an image file.");
  const source=URL.createObjectURL(file);
  try{
    const image=await new Promise<HTMLImageElement>((resolve,reject)=>{const node=new Image();node.onload=()=>resolve(node);node.onerror=()=>reject(new Error("The selected image could not be decoded."));node.src=source;});
    const maxSide=900;const scale=Math.min(1,maxSide/Math.max(image.naturalWidth,image.naturalHeight));
    const canvas=document.createElement("canvas");canvas.width=Math.max(1,Math.round(image.naturalWidth*scale));canvas.height=Math.max(1,Math.round(image.naturalHeight*scale));
    const context=canvas.getContext("2d");if(!context)throw new Error("Image processing is unavailable.");
    context.drawImage(image,0,0,canvas.width,canvas.height);
    const blob=await new Promise<Blob>((resolve,reject)=>canvas.toBlob(value=>value?resolve(value):reject(new Error(`${label} encoding failed.`)),"image/webp",.86));
    const bytes=new Uint8Array(await blob.arrayBuffer());
    if(bytes.byteLength>2*1024*1024)throw new Error(`${label} is still larger than 2 MB after optimization.`);
    return{mimeType:"image/webp",bytes:Array.from(bytes)};
  }finally{URL.revokeObjectURL(source);}
}
