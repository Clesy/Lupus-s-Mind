export interface PortraitAssetDto { mimeType:string; bytes:number[] }
export interface AssetGateway {
  getCharacterPortrait(characterId:string):Promise<PortraitAssetDto|null>;
  putCharacterPortrait(characterId:string,mimeType:string,bytes:number[]):Promise<PortraitAssetDto>;
  deleteCharacterPortrait(characterId:string):Promise<void>;
  getItemArtwork(itemId:string):Promise<PortraitAssetDto|null>;
  putItemArtwork(itemId:string,mimeType:string,bytes:number[]):Promise<PortraitAssetDto>;
  deleteItemArtwork(itemId:string):Promise<void>;
}
