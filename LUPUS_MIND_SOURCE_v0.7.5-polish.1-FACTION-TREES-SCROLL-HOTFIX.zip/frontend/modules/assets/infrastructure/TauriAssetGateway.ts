import { invoke } from "@tauri-apps/api/core";
import type { AssetGateway,PortraitAssetDto } from "../application/AssetGateway";
export const tauriAssetGateway:AssetGateway={
  getCharacterPortrait:(characterId)=>invoke<PortraitAssetDto|null>("character_portrait_get",{characterId}),
  putCharacterPortrait:(characterId,mimeType,bytes)=>invoke<PortraitAssetDto>("character_portrait_put",{characterId,mimeType,bytes}),
  deleteCharacterPortrait:(characterId)=>invoke<void>("character_portrait_delete",{characterId}),
  getItemArtwork:(itemId)=>invoke<PortraitAssetDto|null>("item_artwork_get",{itemId}),
  putItemArtwork:(itemId,mimeType,bytes)=>invoke<PortraitAssetDto>("item_artwork_put",{itemId,mimeType,bytes}),
  deleteItemArtwork:(itemId)=>invoke<void>("item_artwork_delete",{itemId}),
};
