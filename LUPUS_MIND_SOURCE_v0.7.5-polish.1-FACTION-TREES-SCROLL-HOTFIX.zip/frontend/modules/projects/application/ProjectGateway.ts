export interface ProjectSummary { id:string; name:string; createdAt:string; lastOpenedAt:string; isCurrent:boolean; }
export interface CreateProjectInput { name:string; }
export interface ProjectGateway {
  list():Promise<ProjectSummary[]>;
  current():Promise<ProjectSummary>;
  create(input:CreateProjectInput):Promise<ProjectSummary>;
  switchProject(id:string):Promise<ProjectSummary>;
}
