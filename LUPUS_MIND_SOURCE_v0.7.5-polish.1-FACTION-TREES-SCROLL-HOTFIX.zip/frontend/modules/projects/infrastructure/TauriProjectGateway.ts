import { invoke } from "@tauri-apps/api/core";
import type { CreateProjectInput, ProjectGateway, ProjectSummary } from "../application/ProjectGateway";
export const tauriProjectGateway:ProjectGateway = {
  list:()=>invoke<ProjectSummary[]>("projects_list"),
  current:()=>invoke<ProjectSummary>("projects_current"),
  create:(input)=>invoke<ProjectSummary>("projects_create",{input}),
  switchProject:(id)=>invoke<ProjectSummary>("projects_switch",{id}),
};
