export type FactionKind="faction"|"clan"|"guild"|"kingdom"|"order"|"house";
export type FactionRelation="allied"|"friendly"|"neutral"|"tense"|"hostile"|"war"|"vassal";
export type LineageKind="family"|"dynasty"|"bloodline"|"house";

export interface FactionDto{id:string;name:string;kind:FactionKind;description:string;motto:string;color:string;tags:string[];memberCount:number;createdAt:string;updatedAt:string}
export interface UpsertFactionInput{name:string;kind:FactionKind;description?:string;motto?:string;color?:string;tags:string[]}
export interface FactionMembershipDto{id:string;factionId:string;factionName:string;characterId:string;characterName:string;role:string;rank:string;joinedChapter:number;leftChapter:number|null}
export interface FactionRelationDto{id:string;factionAId:string;factionAName:string;factionBId:string;factionBName:string;relationType:FactionRelation;validFromChapter:number;validToChapter:number|null;notes:string}

export interface HierarchyRoleDto{id:string;factionId:string;name:string;parentRoleId:string|null;tier:number;capacity:number|null;color:string;sortOrder:number}
export interface UpsertHierarchyRoleInput{factionId:string;name:string;parentRoleId?:string|null;tier:number;capacity?:number|null;color?:string;sortOrder:number}
export interface RoleAssignmentDto{id:string;factionId:string;roleId:string;roleName:string;characterId:string;characterName:string;validFromChapter:number;validToChapter:number|null;titleOverride:string;notes:string}
export interface AssignRoleInput{roleId:string;characterId:string;validFromChapter:number;titleOverride?:string;notes?:string}

export interface LineageDto{id:string;name:string;kind:LineageKind;description:string;color:string;tags:string[];affiliatedFactionId:string|null;affiliatedFactionName:string|null;memberCount:number}
export interface UpsertLineageInput{name:string;kind:LineageKind;description?:string;color?:string;tags:string[];affiliatedFactionId?:string|null}
export interface LineageMembershipDto{id:string;lineageId:string;lineageName:string;characterId:string;characterName:string;branchLabel:string;title:string;joinedChapter:number;leftChapter:number|null}
export interface AddLineageMembershipInput{lineageId:string;characterId:string;branchLabel?:string;title?:string;joinedChapter:number}

export interface FactionGateway{
  list():Promise<FactionDto[]>;get(id:string):Promise<FactionDto>;create(input:UpsertFactionInput):Promise<FactionDto>;update(id:string,input:UpsertFactionInput):Promise<FactionDto>;remove(id:string):Promise<void>;
  memberships(filter?:{factionId?:string;characterId?:string;chapter?:number}):Promise<FactionMembershipDto[]>;addMembership(input:{factionId:string;characterId:string;role:string;rank:string;joinedChapter:number}):Promise<FactionMembershipDto>;endMembership(id:string,leftChapter:number):Promise<void>;
  relationsAt(chapter:number):Promise<FactionRelationDto[]>;setRelation(input:{factionAId:string;factionBId:string;relationType:FactionRelation;chapter:number;notes?:string}):Promise<FactionRelationDto>;
  hierarchyRoles(factionId:string):Promise<HierarchyRoleDto[]>;createHierarchyRole(input:UpsertHierarchyRoleInput):Promise<HierarchyRoleDto>;updateHierarchyRole(id:string,input:UpsertHierarchyRoleInput):Promise<HierarchyRoleDto>;deleteHierarchyRole(id:string):Promise<void>;seedHierarchyDefaults(factionId:string):Promise<HierarchyRoleDto[]>;
  roleAssignmentsAt(factionId:string,chapter:number):Promise<RoleAssignmentDto[]>;assignRole(input:AssignRoleInput):Promise<RoleAssignmentDto>;endRoleAssignment(id:string,chapter:number):Promise<void>;
  lineages(factionId?:string):Promise<LineageDto[]>;createLineage(input:UpsertLineageInput):Promise<LineageDto>;updateLineage(id:string,input:UpsertLineageInput):Promise<LineageDto>;deleteLineage(id:string):Promise<void>;
  lineageMembershipsAt(lineageId:string,chapter:number):Promise<LineageMembershipDto[]>;addLineageMembership(input:AddLineageMembershipInput):Promise<LineageMembershipDto>;endLineageMembership(id:string,chapter:number):Promise<void>;
}
