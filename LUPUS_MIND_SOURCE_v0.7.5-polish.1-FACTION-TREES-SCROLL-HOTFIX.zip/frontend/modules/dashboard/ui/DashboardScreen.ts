import type { CharacterGateway } from "../../characters/application/CharacterGateway";
import type { ItemGateway } from "../../items/application/ItemGateway";
import type { ManuscriptGateway, QuickNote } from "../../manuscript/application/ManuscriptGateway";
import type { SkillGateway } from "../../skills/application/SkillGateway";

export type DashboardRoute = "characters" | "items" | "skills" | "manuscript" | "relationships" | "timeline" | "combat" | "generators";

type Metric = { label: string; value: string; note: string; route: DashboardRoute };

export class DashboardScreen {
  constructor(
    private readonly host: HTMLElement,
    private readonly characters: CharacterGateway,
    private readonly items: ItemGateway,
    private readonly skills: SkillGateway,
    private readonly manuscript: ManuscriptGateway,
    private readonly navigate: (route: DashboardRoute) => void,
  ) {}

  async render(): Promise<void> {
    this.host.innerHTML = `<div class="dashboard-loading"><span class="loading-spinner" aria-hidden="true"></span><strong>Reading local workspace…</strong></div>`;
    const [characters, items, skills, notes] = await Promise.allSettled([
      this.characters.list(),
      this.items.list(),
      this.skills.list(),
      this.manuscript.listNotes(),
    ]);

    const metric = (label: string, result: PromiseSettledResult<unknown[]>, route: DashboardRoute, note: string): Metric => ({
      label,
      value: result.status === "fulfilled" ? String(result.value.length) : "—",
      note: result.status === "fulfilled" ? note : "Unavailable",
      route,
    });
    const metrics: Metric[] = [
      metric("Characters", characters, "characters", "Canonical identities"),
      metric("Items", items, "items", "World inventory definitions"),
      metric("Skills", skills, "skills", "Deterministic definitions"),
      metric("Quick notes", notes, "manuscript", "Ideas & continuity reminders"),
    ];
    const quickNotes = notes.status === "fulfilled" ? notes.value as QuickNote[] : [];

    this.host.innerHTML = `
      <section class="dashboard-screen">
        <header class="dashboard-hero">
          <div><div class="eyebrow">Temporal Knowledge Runtime</div><h1>Studio overview</h1><p>Canon, writing and creative tools remain isolated — one local desktop workspace.</p></div>
          <button class="btn primary" data-route-jump="generators">Open generators</button>
        </header>
        <div class="dashboard-metrics">
          ${metrics.map((entry) => `<button class="dashboard-metric" data-route-jump="${entry.route}"><span>${entry.label}</span><strong>${entry.value}</strong><em>${entry.note}</em></button>`).join("")}
        </div>
        <div class="dashboard-grid">
          <section class="dashboard-panel">
            <header class="dashboard-panel-header"><div><div class="eyebrow">Writing desk</div><h2>Quick Notes</h2></div><button class="btn" data-route-jump="manuscript">Open Manuscript</button></header>
            <div class="dashboard-note-list">
              ${quickNotes.length ? quickNotes.slice(0, 6).map((entry) => this.noteCard(entry)).join("") : `<div class="dashboard-empty"><strong>No quick notes yet</strong><span>Capture an idea or continuity reminder from Manuscript.</span><button class="btn ghost" data-route-jump="manuscript">Create a note</button></div>`}
            </div>
          </section>
          <section class="dashboard-panel">
            <header class="dashboard-panel-header"><div><div class="eyebrow">Architecture</div><h2>Knowledge runtime</h2></div></header>
            <div class="runtime-layers">
              <button data-route-jump="characters"><strong>Canon</strong><span>Characters · Items · Skills</span></button>
              <button data-route-jump="relationships"><strong>Temporal graph</strong><span>Relationships by chapter</span></button>
              <button data-route-jump="timeline"><strong>Narrative</strong><span>Canonical timeline events</span></button>
              <button data-route-jump="combat"><strong>Simulation</strong><span>Manual combat sandbox</span></button>
              <button data-route-jump="generators"><strong>Creative tools</strong><span>Non-canonical generation</span></button>
            </div>
          </section>
        </div>
      </section>`;

    this.host.querySelectorAll<HTMLButtonElement>("[data-route-jump]").forEach((button) => {
      button.addEventListener("click", () => this.navigate(button.dataset.routeJump as DashboardRoute));
    });
  }

  private noteCard(note: QuickNote): string {
    const linked = note.linkLabel ?? (note.linkKind ? note.linkKind : "");
    const meta = [note.pinned ? "Pinned" : "", linked].filter(Boolean).join(" · ");
    return `<button class="dashboard-note" data-route-jump="manuscript"><span>${this.escape(meta || "Quick note")}</span><strong>${this.escape(note.body)}</strong><em>${this.relativeTime(note.updatedAt)}</em></button>`;
  }

  private relativeTime(value: string): string {
    const time = new Date(value).getTime();
    if (!Number.isFinite(time)) return "Updated recently";
    const delta = Math.max(0, Date.now() - time);
    const minutes = Math.floor(delta / 60_000);
    if (minutes < 1) return "Updated just now";
    if (minutes < 60) return `Updated ${minutes}m ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `Updated ${hours}h ago`;
    const days = Math.floor(hours / 24);
    if (days < 30) return `Updated ${days}d ago`;
    return `Updated ${new Date(value).toLocaleDateString()}`;
  }

  private escape(value: string): string {
    return value.replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char]!);
  }
}
