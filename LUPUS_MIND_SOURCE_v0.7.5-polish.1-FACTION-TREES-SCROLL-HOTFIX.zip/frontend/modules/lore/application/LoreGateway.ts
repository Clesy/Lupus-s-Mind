export interface LoreSummary { id:string; title:string; category:string; summary:string; tags:string[]; updatedAt:string; }
export interface LorePage extends LoreSummary { content:string; wordCount:number; createdAt:string; }
export interface UpsertLoreInput { title:string; category:string; summary:string; content:string; tags:string[]; }
export interface LoreGateway { list():Promise<LoreSummary[]>; get(id:string):Promise<LorePage>; create(input:UpsertLoreInput):Promise<LorePage>; update(id:string,input:UpsertLoreInput):Promise<LorePage>; remove(id:string):Promise<void>; }
