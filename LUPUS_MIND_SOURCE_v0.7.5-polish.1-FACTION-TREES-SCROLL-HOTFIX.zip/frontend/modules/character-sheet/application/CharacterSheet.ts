import type { CharacterStats } from "../../characters/application/CharacterGateway";
import type { ItemDto } from "../../items/application/ItemGateway";
import type { EquipmentSlot } from "../../equipment/application/EquipmentGateway";
export interface EffectiveStats { strength:number; agility:number; vitality:number; intelligence:number; mind:number; weaponDamage:number; armor:number; armorPenetration:number; magicPenetration:number; criticalChance:number; damageReduction:number; }
export interface EquippedItemDto { slot:EquipmentSlot; item:ItemDto; }
export interface CharacterSheetDto { characterId:string; name:string; baseStats:CharacterStats; effectiveStats:EffectiveStats; equipment:EquippedItemDto[]; }
