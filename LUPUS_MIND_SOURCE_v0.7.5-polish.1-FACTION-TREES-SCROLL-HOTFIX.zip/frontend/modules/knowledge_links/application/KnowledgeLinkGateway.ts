export type LinkSourceKind="chapter"|"lore";export type LinkTargetKind="character"|"item"|"skill"|"lore";
export interface EntityMention{sourceKind:LinkSourceKind;sourceId:string;sourceTitle:string;targetKind:LinkTargetKind;targetId:string;targetTitle:string;route:string;displayText:string;startOffset:number;endOffset:number;}
export interface EntityBacklink{sourceKind:LinkSourceKind;sourceId:string;sourceTitle:string;route:string;displayText:string;occurrences:number;}
export interface KnowledgeLinkGateway{mentionsForSource(sourceKind:LinkSourceKind,sourceId:string):Promise<EntityMention[]>;backlinksForTarget(targetKind:LinkTargetKind,targetId:string):Promise<EntityBacklink[]>;}
