import type {
  AtlasGateway,
  AtlasMapDto,
  ConnectionKind,
  GeneratedMapDraft,
  LocationDto,
  LocationKind,
  MapConnectionDto,
  MapPinDto,
  MapPoint,
} from "../application/AtlasGateway";
import { shouldConfirmDestructive } from "../../../shared/preferences";

const esc = (v: string) => v.replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]!);
const kinds: LocationKind[] = ["world", "continent", "country", "region", "province", "city", "town", "village", "district", "building", "landmark", "dungeon", "biome", "location"];
const connectionKinds: ConnectionKind[] = ["road", "sea_route", "portal", "border", "path"];
const iconFor = (kind: string) => ({ world: "◎", continent: "◒", country: "◆", region: "◇", province: "◇", city: "▣", town: "▦", village: "▫", district: "▤", building: "▥", landmark: "✦", dungeon: "⌁", biome: "≈", location: "•" } as Record<string, string>)[kind] ?? "•";

const curvePath = (points: MapPoint[], w: number, h: number, closed: boolean) => {
  if (points.length < 2) return "";
  const pts = points.map(p => ({ x: p.x * w, y: p.y * h }));
  const n = pts.length;
  let d = `M${pts[0]!.x.toFixed(2)} ${pts[0]!.y.toFixed(2)}`;
  const end = closed ? n : n - 1;
  for (let i = 0; i < end; i++) {
    const p0 = pts[closed ? (i - 1 + n) % n : Math.max(0, i - 1)]!;
    const p1 = pts[i % n]!;
    const p2 = pts[(i + 1) % n]!;
    const p3 = pts[closed ? (i + 2) % n : Math.min(n - 1, i + 2)]!;
    const c1x = p1.x + (p2.x - p0.x) / 6;
    const c1y = p1.y + (p2.y - p0.y) / 6;
    const c2x = p2.x - (p3.x - p1.x) / 6;
    const c2y = p2.y - (p3.y - p1.y) / 6;
    d += ` C${c1x.toFixed(2)} ${c1y.toFixed(2)} ${c2x.toFixed(2)} ${c2y.toFixed(2)} ${p2.x.toFixed(2)} ${p2.y.toFixed(2)}`;
  }
  return closed ? `${d} Z` : d;
};

export class AtlasScreen {
  private view: "atlas" | "locations" | "generator" = "atlas";
  private locations: LocationDto[] = [];
  private maps: AtlasMapDto[] = [];
  private pins: MapPinDto[] = [];
  private connections: MapConnectionDto[] = [];
  private selectedMapId: string | null = null;
  private selectedLocationId: string | null = null;
  private placementLocationId: string | null = null;
  private draft: GeneratedMapDraft | null = null;
  private generatorBusy = false;
  private mapZoom = 1;
  private mapPanX = 0;
  private mapPanY = 0;
  private drawLandMode = false;
  private drawingPoints: MapPoint[] = [];

  constructor(private readonly root: HTMLElement, private readonly gateway: AtlasGateway) {}

  async render() { await this.reload(); this.paint(); }

  async openById(id: string) {
    if (this.maps.some(x => x.id === id)) {
      this.view = "atlas";
      this.selectedMapId = id;
      this.drawLandMode = false;
      this.resetMapCamera();
      await this.loadMapState();
      this.paint();
      return;
    }
    if (this.locations.some(x => x.id === id)) {
      this.view = "locations";
      this.selectedLocationId = id;
      this.paint();
    }
  }

  openCreate() { this.view = "locations"; this.selectedLocationId = "__new__"; this.paint(); }

  private async reload() {
    [this.locations, this.maps] = await Promise.all([this.gateway.locations(), this.gateway.maps()]);
    if (this.selectedMapId && !this.maps.some(m => m.id === this.selectedMapId)) this.selectedMapId = null;
    if (!this.selectedMapId && this.maps.length) this.selectedMapId = this.maps[0]?.id ?? null;
    await this.loadMapState();
  }

  private async loadMapState() {
    if (!this.selectedMapId) { this.pins = []; this.connections = []; return; }
    [this.pins, this.connections] = await Promise.all([this.gateway.pins(this.selectedMapId), this.gateway.connections(this.selectedMapId)]);
  }

  private paint() {
    this.root.innerHTML = `<section class="atlas-shell"><header class="atlas-head"><div><span class="eyebrow">WORLD CARTOGRAPHY</span><h1>Atlas</h1><p>Build canonical places, draw maps by hand, or generate deterministic world drafts.</p></div><div class="atlas-tabs"><button class="${this.view === "atlas" ? "active" : ""}" data-view="atlas">Atlas</button><button class="${this.view === "locations" ? "active" : ""}" data-view="locations">Locations</button><button class="${this.view === "generator" ? "active" : ""}" data-view="generator">Generator</button></div></header><div data-role="atlas-body"></div></section>`;
    this.root.querySelectorAll<HTMLButtonElement>("[data-view]").forEach(button => button.addEventListener("click", () => {
      this.view = button.dataset.view as typeof this.view;
      this.drawLandMode = false;
      this.paint();
    }));
    const body = this.root.querySelector<HTMLElement>("[data-role=atlas-body]")!;
    if (this.view === "atlas") this.paintAtlas(body);
    else if (this.view === "locations") this.paintLocations(body);
    else this.paintGenerator(body);
  }

  private paintAtlas(host: HTMLElement) {
    const map = this.maps.find(m => m.id === this.selectedMapId) ?? null;
    if (!map && this.maps.length === 0) {
      host.innerHTML = this.firstMapMarkup();
      host.querySelector<HTMLButtonElement>("[data-first-manual]")?.addEventListener("click", () => void this.createBlankMap(true));
      host.querySelector<HTMLButtonElement>("[data-first-generate]")?.addEventListener("click", () => { this.view = "generator"; this.paint(); });
      host.querySelector<HTMLButtonElement>("[data-first-locations]")?.addEventListener("click", () => { this.view = "locations"; this.selectedLocationId = "__new__"; this.paint(); });
      return;
    }

    host.innerHTML = `<div class="atlas-workspace"><aside class="atlas-rail"><div class="rail-title"><span>MAPS</span><button class="mini-add" data-new-map>+</button></div>${this.maps.map(m => `<button class="map-row ${m.id === this.selectedMapId ? "active" : ""}" data-map="${esc(m.id)}"><span class="map-thumb">${m.generatorSeed !== null ? "✦" : "⌖"}</span><span><strong>${esc(m.name)}</strong><small>${esc(m.scopeLocationName ?? (m.generatorSeed !== null ? `Generated · seed ${m.generatorSeed}` : "Manual map"))}</small></span><em>${m.pinCount}</em></button>`).join("")}<button class="btn ghost full" data-open-generator>✦ Generate map</button></aside><main class="atlas-canvas-panel">${map ? this.mapCanvasMarkup(map) : `<div class="atlas-empty"><strong>Select a map</strong><span>Choose a map from the left rail.</span></div>`}</main><aside class="atlas-inspector" data-role="atlas-inspector">${map ? this.mapInspectorMarkup(map) : this.locationSummaryMarkup()}</aside></div>`;
    host.querySelectorAll<HTMLButtonElement>("[data-map]").forEach(button => button.addEventListener("click", async () => {
      this.selectedMapId = button.dataset.map!;
      this.drawLandMode = false;
      this.resetMapCamera();
      await this.loadMapState();
      this.paint();
    }));
    host.querySelectorAll<HTMLButtonElement>("[data-new-map]").forEach(button => button.addEventListener("click", () => void this.createBlankMap(false)));
    host.querySelectorAll<HTMLButtonElement>("[data-open-generator]").forEach(button => button.addEventListener("click", () => { this.view = "generator"; this.paint(); }));
    if (!map) return;
    this.bindCanvas(host, map);
    this.bindMapInspector(host, map);
  }

  private firstMapMarkup() {
    const locationCopy = this.locations.length ? `${this.locations.length} existing location${this.locations.length === 1 ? " is" : "s are"} ready to place.` : "You can create locations now or add them later.";
    return `<div class="atlas-first-run"><div class="atlas-first-hero"><span class="eyebrow">START YOUR WORLD MAP</span><h2>Create the first Atlas map</h2><p>Choose the workflow that matches how you build worlds. Manual drawing writes only when you finish a coastline; generated drafts remain non-canonical until accepted.</p><small>${esc(locationCopy)}</small></div><div class="atlas-first-options"><button data-first-manual><span class="first-map-icon">✎</span><strong>Draw manually</strong><small>Create a blank ocean canvas and sketch landmasses with the Draw Land tool.</small><em>Best for authored geography →</em></button><button data-first-generate><span class="first-map-icon">✦</span><strong>Generate from seed</strong><small>Build a deterministic draft with continents, ranges, rivers and settlements.</small><em>Best for exploration →</em></button><button data-first-locations><span class="first-map-icon">⌖</span><strong>Create locations first</strong><small>Define canonical places and hierarchy before deciding where they sit on a map.</small><em>Best for lore-first worlds →</em></button></div><div class="atlas-first-boundary"><strong>Canonical boundary</strong><span>Drawing a coastline changes only the selected map. Generator previews do not change world records until “Accept into World”.</span></div></div>`;
  }

  private mapCanvasMarkup(map: AtlasMapDto) {
    const w = map.width, h = map.height;
    const terrain = map.terrain;
    const pinByLocation = new Map(this.pins.map(p => [p.locationId, p]));
    const lines = this.connections.map(c => {
      const a = pinByLocation.get(c.fromLocationId), b = pinByLocation.get(c.toLocationId);
      if (!a || !b) return "";
      return `<line class="map-connection conn-${esc(c.kind)}" x1="${a.x * w}" y1="${a.y * h}" x2="${b.x * w}" y2="${b.y * h}" stroke="${esc(c.color)}" vector-effect="non-scaling-stroke"><title>${esc(c.label || c.kind)}</title></line>`;
    }).join("");
    const pins = this.pins.map((p, index) => {
      const offset = this.pinLabelOffset(index, p);
      return `<g class="map-pin pin-${esc(p.locationKind)}" data-pin="${esc(p.id)}" data-location="${esc(p.locationId)}" data-kind="${esc(p.locationKind)}" transform="translate(${p.x * w} ${p.y * h})"><g data-pin-visual><circle class="pin-hit" r="18"/>${this.pinGlyphMarkup(p.locationKind, p.color)}<text data-pin-label x="${offset.x}" y="${offset.y}">${esc(p.label || p.locationName)}</text></g><title>${esc(p.locationName)} · ${esc(p.locationKind)}</title></g>`;
    }).join("");
    const manual = map.generatorSeed === null;
    const hasManualLand = manual && Boolean(terrain?.landmasses.length);
    const hint = this.drawLandMode ? "Drag on the canvas to sketch a coastline" : this.placementLocationId ? "Click map to place selected location" : "Drag pins · drag empty map to pan · wheel to zoom";
    return `<div class="map-stage"><div class="map-stage-top"><span class="map-stage-title"><strong>${esc(map.name)}</strong>${map.scopeLocationName ? ` · ${esc(map.scopeLocationName)}` : ""}</span><div class="map-stage-actions"><span class="map-stage-hint">${hint}</span>${manual ? `<div class="map-draw-controls" aria-label="Manual terrain tools"><button type="button" class="${this.drawLandMode ? "active" : ""}" data-draw-land>✎ Draw land</button><button type="button" data-undo-land ${hasManualLand ? "" : "disabled"}>Undo</button><button type="button" data-clear-terrain ${hasManualLand ? "" : "disabled"}>Clear</button></div>` : ""}<div class="map-zoom-controls" aria-label="Map zoom controls"><button type="button" data-zoom-out aria-label="Zoom out">−</button><output data-zoom-label>${Math.round(this.mapZoom * 100)}%</output><button type="button" data-zoom-in aria-label="Zoom in">+</button><button type="button" data-zoom-fit>Fit</button></div></div></div><div class="map-scroll"><svg class="atlas-map ${this.placementLocationId ? "placing" : ""} ${this.drawLandMode ? "drawing-land" : ""}" data-map-canvas viewBox="0 0 ${w} ${h}" preserveAspectRatio="xMidYMin meet" role="img" aria-label="${esc(map.name)}"><rect width="${w}" height="${h}" class="ocean"/>${terrain ? this.terrainMarkup(terrain, w, h) : `<g class="blank-grid"><path d="M0 ${h / 2}H${w} M${w / 2} 0V${h}"/></g>`}<path class="manual-draw-preview" data-draw-preview d=""/>${lines}${pins}</svg></div></div>`;
  }

  private terrainMarkup(t: GeneratedMapDraft, w: number, h: number) {
    const poly = t.landmasses.map(l => `<path class="landmass" d="${curvePath(l.points, w, h, true)}"><title>${esc(l.name)}</title></path>`).join("");
    const rivers = t.rivers.map(r => `<path class="river" d="${curvePath(r.points, w, h, false)}" vector-effect="non-scaling-stroke"/>`).join("");
    const mountains = t.mountains.map(m => `<g class="mountain-range" transform="translate(${m.x * w} ${m.y * h})"><path class="mountain" d="M-8 7 L0 -9 L8 7 Z"/><path class="mountain mountain-secondary" d="M2 7 L8 -4 L14 7 Z"/><title>${esc(m.name)}</title></g>`).join("");
    return `<g>${poly}${rivers}${mountains}</g>`;
  }

  private pinGlyphMarkup(kind: string, color: string) {
    const c = esc(color);
    if (kind === "city") return `<circle class="pin-symbol pin-city-ring" r="12" fill="${c}"/><rect class="pin-core" x="-4" y="-4" width="8" height="8" rx="1"/>`;
    if (kind === "town") return `<circle class="pin-symbol" r="9" fill="${c}"/><circle r="3.5" class="pin-core"/>`;
    if (kind === "village") return `<circle class="pin-symbol" r="6" fill="${c}"/><circle r="2.2" class="pin-core"/>`;
    return `<circle class="pin-symbol" r="10" fill="${c}"/><circle r="4" class="pin-core"/>`;
  }

  private generatedSettlementMarkup(s: GeneratedMapDraft["settlements"][number], w: number, h: number) {
    const x = s.x * w, y = s.y * h;
    if (s.kind === "city") return `<g transform="translate(${x} ${y})" class="generated-settlement city"><circle r="9"/><rect x="-3.5" y="-3.5" width="7" height="7" rx="1"/><text y="-14">${esc(s.name)}</text></g>`;
    if (s.kind === "town") return `<g transform="translate(${x} ${y})" class="generated-settlement town"><circle r="6.5"/><circle class="settlement-core" r="2.5"/><text y="-11">${esc(s.name)}</text></g>`;
    return `<g transform="translate(${x} ${y})" class="generated-settlement village"><circle r="4"/><text y="-9">${esc(s.name)}</text><title>${esc(s.name)} · village</title></g>`;
  }

  private mapInspectorMarkup(map: AtlasMapDto) {
    const unpinned = this.locations.filter(l => !this.pins.some(p => p.locationId === l.id));
    return `<div class="inspector-title"><div><span class="eyebrow">MAP INSPECTOR</span><h2>${esc(map.name)}</h2></div><button class="btn danger ghost small" data-delete-map>Delete</button></div><form class="world-form compact" data-map-form><label><span>Name</span><input name="name" value="${esc(map.name)}"></label><label><span>Scope location</span><select name="scope"><option value="">Whole world</option>${this.locations.map(l => `<option value="${esc(l.id)}" ${l.id === map.scopeLocationId ? "selected" : ""}>${esc(l.name)} · ${esc(l.kind)}</option>`).join("")}</select></label><label><span>Parent map</span><select name="parentMap"><option value="">Top-level map</option>${this.maps.filter(m => m.id !== map.id && !this.mapDescendants(map.id).has(m.id)).map(m => `<option value="${esc(m.id)}" ${m.id === map.parentMapId ? "selected" : ""}>${esc(m.name)}</option>`).join("")}</select></label><div class="form-grid two"><label><span>Width</span><input name="width" type="number" min="320" max="8192" value="${map.width}"></label><label><span>Height</span><input name="height" type="number" min="240" max="8192" value="${map.height}"></label></div><button class="btn" type="submit">Save map</button></form><section class="inspector-section"><div class="section-title"><div><span class="eyebrow">PINS · ${this.pins.length}</span><h3>Place location</h3></div></div><select data-placement><option value="">Choose location…</option>${unpinned.map(l => `<option value="${esc(l.id)}" ${l.id === this.placementLocationId ? "selected" : ""}>${esc(l.name)} · ${esc(l.kind)}</option>`).join("")}</select><div class="pin-list">${this.pins.map(p => `<button class="pin-list-row" data-focus-pin="${esc(p.id)}"><span class="pin-dot"></span><strong>${esc(p.locationName)}</strong><small>${esc(p.locationKind)}</small><em data-remove-pin="${esc(p.id)}">×</em></button>`).join("") || '<div class="empty-note">No locations pinned yet.</div>'}</div></section><section class="inspector-section"><div class="section-title"><div><span class="eyebrow">ROUTES · ${this.connections.length}</span><h3>Connections</h3></div></div>${this.pins.length >= 2 ? `<form class="connection-form" data-connection-form><select name="from">${this.pins.map(p => `<option value="${esc(p.locationId)}">${esc(p.locationName)}</option>`).join("")}</select><select name="to">${this.pins.map((p, i) => `<option value="${esc(p.locationId)}" ${i === 1 ? "selected" : ""}>${esc(p.locationName)}</option>`).join("")}</select><select name="kind">${connectionKinds.map(k => `<option>${k}</option>`).join("")}</select><button class="btn small" type="submit">Connect</button></form>` : '<div class="empty-note">Pin two locations to connect them.</div>'}${this.connections.map(c => `<div class="connection-row"><span>${esc(c.fromLocationName)} → ${esc(c.toLocationName)}</span><small>${esc(c.kind)}</small><button data-remove-connection="${esc(c.id)}">×</button></div>`).join("")}</section>`;
  }

  private bindCanvas(host: HTMLElement, map: AtlasMapDto) {
    const svg = host.querySelector<SVGSVGElement>("[data-map-canvas]");
    if (!svg) return;
    this.applyMapCamera(svg, map);

    const worldPoint = (clientX: number, clientY: number) => {
      const ctm = svg.getScreenCTM();
      if (!ctm) return { x: 0, y: 0 };
      const pt = svg.createSVGPoint();
      pt.x = clientX; pt.y = clientY;
      const out = pt.matrixTransform(ctm.inverse());
      return { x: out.x, y: out.y };
    };
    const normalized = (clientX: number, clientY: number): MapPoint => {
      const p = worldPoint(clientX, clientY);
      return { x: Math.min(1, Math.max(0, p.x / map.width)), y: Math.min(1, Math.max(0, p.y / map.height)) };
    };

    let panning = false, moved = false, drawing = false;
    let startClientX = 0, startClientY = 0, startPanX = 0, startPanY = 0;

    svg.addEventListener("wheel", event => {
      event.preventDefault();
      this.zoomMap(svg, map, event.deltaY < 0 ? this.mapZoom * 1.18 : this.mapZoom / 1.18, event.clientX, event.clientY);
    }, { passive: false });

    svg.addEventListener("pointerdown", event => {
      if ((event.target as Element).closest("[data-pin]") || this.placementLocationId) return;
      if (this.drawLandMode && map.generatorSeed === null) {
        drawing = true;
        moved = true;
        this.drawingPoints = [normalized(event.clientX, event.clientY)];
        svg.setPointerCapture(event.pointerId);
        svg.classList.add("is-drawing-land");
        this.updateDrawPreview(svg, map);
        event.preventDefault();
        return;
      }
      panning = true; moved = false;
      startClientX = event.clientX; startClientY = event.clientY;
      startPanX = this.mapPanX; startPanY = this.mapPanY;
      svg.setPointerCapture(event.pointerId);
      svg.classList.add("is-panning");
    });

    svg.addEventListener("pointermove", event => {
      if (drawing) {
        const p = normalized(event.clientX, event.clientY);
        const previous = this.drawingPoints[this.drawingPoints.length - 1];
        if (!previous || Math.hypot(previous.x - p.x, previous.y - p.y) > 0.004 / Math.max(1, this.mapZoom * .75)) {
          this.drawingPoints.push(p);
          this.updateDrawPreview(svg, map);
        }
        return;
      }
      if (!panning) return;
      const rect = svg.getBoundingClientRect(), viewW = map.width / this.mapZoom, viewH = map.height / this.mapZoom;
      const dx = (event.clientX - startClientX) * (viewW / Math.max(1, rect.width));
      const dy = (event.clientY - startClientY) * (viewH / Math.max(1, rect.height));
      if (Math.abs(event.clientX - startClientX) > 3 || Math.abs(event.clientY - startClientY) > 3) moved = true;
      this.mapPanX = startPanX - dx; this.mapPanY = startPanY - dy;
      this.clampMapCamera(map); this.applyMapCamera(svg, map);
    });

    const endPointer = (event: PointerEvent) => {
      if (drawing) {
        drawing = false;
        svg.classList.remove("is-drawing-land");
        if (svg.hasPointerCapture(event.pointerId)) svg.releasePointerCapture(event.pointerId);
        const points = this.simplifyDrawnPoints(this.drawingPoints);
        this.drawingPoints = [];
        this.updateDrawPreview(svg, map);
        if (points.length >= 5) void this.commitManualLandmass(map, points);
        return;
      }
      if (!panning) return;
      panning = false;
      svg.classList.remove("is-panning");
      if (svg.hasPointerCapture(event.pointerId)) svg.releasePointerCapture(event.pointerId);
    };
    svg.addEventListener("pointerup", endPointer);
    svg.addEventListener("pointercancel", event => {
      if (drawing) { drawing = false; this.drawingPoints = []; this.updateDrawPreview(svg, map); svg.classList.remove("is-drawing-land"); }
      endPointer(event);
    });

    svg.addEventListener("click", event => {
      if (moved) { moved = false; return; }
      if ((event.target as Element).closest("[data-pin]")) return;
      if (!this.placementLocationId || this.drawLandMode) return;
      const p = normalized(event.clientX, event.clientY);
      void this.gateway.upsertPin({ mapId: map.id, locationId: this.placementLocationId, x: p.x, y: p.y }).then(async () => {
        this.placementLocationId = null;
        await this.loadMapState();
        this.paint();
      });
    });

    host.querySelector("[data-zoom-in]")?.addEventListener("click", () => this.zoomMap(svg, map, this.mapZoom * 1.25));
    host.querySelector("[data-zoom-out]")?.addEventListener("click", () => this.zoomMap(svg, map, this.mapZoom / 1.25));
    host.querySelector("[data-zoom-fit]")?.addEventListener("click", () => { this.resetMapCamera(); this.applyMapCamera(svg, map); });
    host.querySelector<HTMLButtonElement>("[data-draw-land]")?.addEventListener("click", () => { this.drawLandMode = !this.drawLandMode; this.placementLocationId = null; this.paint(); });
    host.querySelector<HTMLButtonElement>("[data-undo-land]")?.addEventListener("click", () => void this.undoManualLand(map));
    host.querySelector<HTMLButtonElement>("[data-clear-terrain]")?.addEventListener("click", () => void this.clearManualTerrain(map));

    host.querySelectorAll<SVGGElement>("[data-pin]").forEach(node => {
      let dragging = false;
      node.addEventListener("pointerdown", event => {
        if (this.drawLandMode) return;
        dragging = true;
        node.setPointerCapture(event.pointerId);
        event.stopPropagation();
        event.preventDefault();
      });
      node.addEventListener("pointermove", event => {
        if (!dragging) return;
        const p = normalized(event.clientX, event.clientY);
        node.setAttribute("transform", `translate(${p.x * map.width} ${p.y * map.height})`);
      });
      node.addEventListener("pointerup", event => {
        if (!dragging) return;
        dragging = false;
        const p = normalized(event.clientX, event.clientY), pin = this.pins.find(x => x.id === node.dataset.pin);
        if (pin) void this.gateway.upsertPin({ mapId: map.id, locationId: pin.locationId, label: pin.label, x: p.x, y: p.y, icon: pin.icon, color: pin.color }).then(async () => { await this.loadMapState(); this.paint(); });
      });
    });
  }

  private bindMapInspector(host: HTMLElement, map: AtlasMapDto) {
    host.querySelector<HTMLFormElement>("[data-map-form]")?.addEventListener("submit", event => {
      event.preventDefault();
      const form = event.currentTarget as HTMLFormElement, data = new FormData(form);
      void this.gateway.updateMap(map.id, {
        name: String(data.get("name") || map.name),
        scopeLocationId: String(data.get("scope") || "") || null,
        parentMapId: String(data.get("parentMap") || "") || null,
        width: Number(data.get("width") || map.width),
        height: Number(data.get("height") || map.height),
        background: map.background,
        terrain: map.terrain,
      }).then(async () => { await this.reload(); this.paint(); });
    });
    host.querySelector<HTMLSelectElement>("[data-placement]")?.addEventListener("change", event => {
      this.placementLocationId = (event.currentTarget as HTMLSelectElement).value || null;
      if (this.placementLocationId) this.drawLandMode = false;
      this.paint();
    });
    host.querySelector("[data-delete-map]")?.addEventListener("click", () => {
      if (shouldConfirmDestructive() && !confirm(`Delete map “${map.name}”?`)) return;
      void this.gateway.deleteMap(map.id).then(async () => { this.selectedMapId = null; this.drawLandMode = false; await this.reload(); this.paint(); });
    });
    host.querySelectorAll<HTMLButtonElement>("[data-focus-pin]").forEach(button => button.addEventListener("click", event => {
      if ((event.target as Element).closest("[data-remove-pin]")) return;
      const pin = this.pins.find(p => p.id === button.dataset.focusPin);
      if (!pin) return;
      this.selectedLocationId = pin.locationId;
      this.view = "locations";
      this.paint();
    }));
    host.querySelectorAll<HTMLElement>("[data-remove-pin]").forEach(button => button.addEventListener("click", event => {
      event.stopPropagation();
      void this.gateway.deletePin(button.dataset.removePin!).then(async () => { await this.loadMapState(); this.paint(); });
    }));
    host.querySelector<HTMLFormElement>("[data-connection-form]")?.addEventListener("submit", event => {
      event.preventDefault();
      const data = new FormData(event.currentTarget as HTMLFormElement), from = String(data.get("from")), to = String(data.get("to"));
      if (from === to) return;
      void this.gateway.upsertConnection({ mapId: map.id, fromLocationId: from, toLocationId: to, kind: String(data.get("kind")) as ConnectionKind }).then(async () => { await this.loadMapState(); this.paint(); });
    });
    host.querySelectorAll<HTMLButtonElement>("[data-remove-connection]").forEach(button => button.addEventListener("click", () => void this.gateway.deleteConnection(button.dataset.removeConnection!).then(async () => { await this.loadMapState(); this.paint(); })));
  }

  private resetMapCamera() { this.mapZoom = 1; this.mapPanX = 0; this.mapPanY = 0; }

  private clampMapCamera(map: AtlasMapDto) {
    this.mapZoom = Math.min(6, Math.max(1, this.mapZoom));
    const viewW = map.width / this.mapZoom, viewH = map.height / this.mapZoom;
    this.mapPanX = Math.min(Math.max(0, map.width - viewW), Math.max(0, this.mapPanX));
    this.mapPanY = Math.min(Math.max(0, map.height - viewH), Math.max(0, this.mapPanY));
  }

  private applyMapCamera(svg: SVGSVGElement, map: AtlasMapDto) {
    this.clampMapCamera(map);
    const viewW = map.width / this.mapZoom, viewH = map.height / this.mapZoom;
    svg.setAttribute("viewBox", `${this.mapPanX} ${this.mapPanY} ${viewW} ${viewH}`);
    const label = this.root.querySelector<HTMLOutputElement>("[data-zoom-label]");
    if (label) label.value = `${Math.round(this.mapZoom * 100)}%`;
    const out = this.root.querySelector<HTMLButtonElement>("[data-zoom-out]"), inc = this.root.querySelector<HTMLButtonElement>("[data-zoom-in]");
    if (out) out.disabled = this.mapZoom <= 1.001;
    if (inc) inc.disabled = this.mapZoom >= 5.999;
    this.applyZoomAwarePins(svg);
  }

  private applyZoomAwarePins(svg: SVGSVGElement) {
    const inverse = 1 / this.mapZoom;
    svg.querySelectorAll<SVGGElement>("[data-pin]").forEach(node => {
      node.querySelector<SVGGElement>("[data-pin-visual]")?.setAttribute("transform", `scale(${inverse.toFixed(4)})`);
      const kind = node.dataset.kind ?? "location";
      const threshold = ({ world: 1, continent: 1, country: 1, city: 1, region: 1.15, province: 1.2, town: 1.3, landmark: 1.35, dungeon: 1.45, district: 1.55, building: 1.6, biome: 1.6, village: 1.8, location: 1.5 } as Record<string, number>)[kind] ?? 1.5;
      node.querySelector<SVGTextElement>("[data-pin-label]")?.classList.toggle("zoom-hidden", this.mapZoom + 1e-6 < threshold);
    });
  }

  private zoomMap(svg: SVGSVGElement, map: AtlasMapDto, nextZoom: number, clientX?: number, clientY?: number) {
    const oldZoom = this.mapZoom, oldW = map.width / oldZoom, oldH = map.height / oldZoom;
    const rect = svg.getBoundingClientRect();
    const fx = clientX === undefined ? .5 : Math.min(1, Math.max(0, (clientX - rect.left) / Math.max(1, rect.width)));
    const fy = clientY === undefined ? .5 : Math.min(1, Math.max(0, (clientY - rect.top) / Math.max(1, rect.height)));
    const anchorX = this.mapPanX + fx * oldW, anchorY = this.mapPanY + fy * oldH;
    this.mapZoom = Math.min(6, Math.max(1, nextZoom));
    const newW = map.width / this.mapZoom, newH = map.height / this.mapZoom;
    this.mapPanX = anchorX - fx * newW; this.mapPanY = anchorY - fy * newH;
    this.applyMapCamera(svg, map);
  }

  private pinLabelOffset(index: number, pin: MapPinDto) {
    const slots = [{ x: 0, y: -20 }, { x: 28, y: -6 }, { x: -28, y: -6 }, { x: 0, y: 34 }, { x: 32, y: 24 }, { x: -32, y: 24 }];
    let near = 0;
    for (let i = 0; i < index; i++) { const other = this.pins[i]; if (other && Math.hypot(other.x - pin.x, other.y - pin.y) < .105) near++; }
    return slots[near % slots.length]!;
  }

  private updateDrawPreview(svg: SVGSVGElement, map: AtlasMapDto) {
    const path = svg.querySelector<SVGPathElement>("[data-draw-preview]");
    if (path) path.setAttribute("d", curvePath(this.drawingPoints, map.width, map.height, false));
  }

  private simplifyDrawnPoints(points: MapPoint[]) {
    if (points.length < 5) return [];
    const filtered: MapPoint[] = [];
    for (const point of points) {
      const previous = filtered[filtered.length - 1];
      if (!previous || Math.hypot(previous.x - point.x, previous.y - point.y) >= .0035) filtered.push(point);
    }
    if (filtered.length > 96) {
      const step = Math.ceil(filtered.length / 96);
      return filtered.filter((_, index) => index % step === 0);
    }
    return filtered;
  }

  private cloneTerrain(terrain: GeneratedMapDraft | null): GeneratedMapDraft | null {
    return terrain ? JSON.parse(JSON.stringify(terrain)) as GeneratedMapDraft : null;
  }

  private async commitManualLandmass(map: AtlasMapDto, points: MapPoint[]) {
    const terrain = this.cloneTerrain(map.terrain) ?? { seed: 0, name: map.name, width: map.width, height: map.height, oceanRatio: .7, landmasses: [], mountains: [], rivers: [], settlements: [] };
    terrain.name = map.name; terrain.width = map.width; terrain.height = map.height;
    terrain.landmasses.push({ id: `manual-land-${Date.now()}`, name: `Landmass ${terrain.landmasses.length + 1}`, points });
    await this.saveManualTerrain(map, terrain);
  }

  private async undoManualLand(map: AtlasMapDto) {
    if (map.generatorSeed !== null || !map.terrain?.landmasses.length) return;
    const terrain = this.cloneTerrain(map.terrain)!;
    terrain.landmasses.pop();
    await this.saveManualTerrain(map, terrain.landmasses.length || terrain.mountains.length || terrain.rivers.length || terrain.settlements.length ? terrain : null);
  }

  private async clearManualTerrain(map: AtlasMapDto) {
    if (map.generatorSeed !== null || !map.terrain) return;
    if (shouldConfirmDestructive() && !confirm(`Clear all drawn terrain from “${map.name}”? Locations and pins will be kept.`)) return;
    await this.saveManualTerrain(map, null);
  }

  private async saveManualTerrain(map: AtlasMapDto, terrain: GeneratedMapDraft | null) {
    await this.gateway.updateMap(map.id, { name: map.name, scopeLocationId: map.scopeLocationId, parentMapId: map.parentMapId, width: map.width, height: map.height, background: map.background, terrain });
    await this.reload();
    this.paint();
  }

  private async createBlankMap(startDrawing = false) {
    const map = await this.gateway.createMap({ name: this.maps.length ? `Map ${this.maps.length + 1}` : "World Map", scopeLocationId: null, parentMapId: null, width: 1200, height: 760, background: "ocean", terrain: null });
    this.selectedMapId = map.id;
    this.drawLandMode = startDrawing;
    this.resetMapCamera();
    await this.reload();
    this.paint();
  }

  private locationSummaryMarkup() { return `<div class="atlas-empty-small"><strong>${this.locations.length} canonical locations</strong><span>Create a map to place them spatially.</span></div>`; }

  private paintLocations(host: HTMLElement) {
    const selected = this.selectedLocationId === "__new__" ? null : this.locations.find(l => l.id === this.selectedLocationId) ?? null;
    host.innerHTML = `<div class="location-workspace"><section class="location-tree-panel"><div class="location-toolbar"><div><span class="eyebrow">LOCATION TREE</span><strong>${this.locations.length} places</strong></div><button class="btn primary small" data-new-location>+ Location</button></div><div class="location-tree">${this.locationTreeMarkup(null, 0) || '<div class="atlas-empty-small">No locations yet.</div>'}</div></section><aside class="location-inspector">${this.selectedLocationId ? this.locationFormMarkup(selected) : `<div class="atlas-empty-small"><strong>Select a place</strong><span>Edit its hierarchy, category and world notes.</span></div>`}</aside></div>`;
    host.querySelector("[data-new-location]")?.addEventListener("click", () => { this.selectedLocationId = "__new__"; this.paint(); });
    host.querySelectorAll<HTMLButtonElement>("[data-location]").forEach(button => button.addEventListener("click", () => { this.selectedLocationId = button.dataset.location!; this.paint(); }));
    const form = host.querySelector<HTMLFormElement>("[data-location-form]");
    form?.addEventListener("submit", event => { event.preventDefault(); void this.saveLocation(event.currentTarget as HTMLFormElement, selected?.id); });
    host.querySelector("[data-delete-location]")?.addEventListener("click", () => { if (selected) void this.deleteLocation(selected); });
  }

  private locationTreeMarkup(parent: string | null, depth: number): string {
    const children = this.locations.filter(l => l.parentLocationId === parent).sort((a, b) => a.name.localeCompare(b.name));
    return children.map(l => `<div class="location-tree-node depth-${Math.min(depth, 8)}"><button class="${l.id === this.selectedLocationId ? "active" : ""}" data-location="${esc(l.id)}"><span class="location-kind-icon">${iconFor(l.kind)}</span><span><strong>${esc(l.name)}</strong><small>${esc(l.kind)}${l.childCount ? ` · ${l.childCount} child` : ""}</small></span></button>${this.locationTreeMarkup(l.id, depth + 1)}</div>`).join("");
  }

  private locationFormMarkup(selected: LocationDto | null) {
    const model = selected ?? { id: "", name: "", kind: "location" as LocationKind, parentLocationId: null, parentLocationName: null, description: "", color: "#70b7c4", tags: [], childCount: 0, createdAt: "", updatedAt: "" };
    return `<form class="world-form" data-location-form><div class="inspector-title"><div><span class="eyebrow">${selected ? "LOCATION" : "NEW PLACE"}</span><h2>${esc(model.name || "Untitled")}</h2></div>${selected ? '<button class="btn danger ghost small" type="button" data-delete-location>Delete</button>' : ""}</div><label><span>Name</span><input name="name" value="${esc(model.name)}" required></label><div class="form-grid two"><label><span>Kind</span><select name="kind">${kinds.map(k => `<option ${k === model.kind ? "selected" : ""}>${k}</option>`).join("")}</select></label><label><span>Color</span><input type="color" name="color" value="${esc(model.color)}"></label></div><label><span>Parent</span><select name="parent"><option value="">Top level</option>${this.locations.filter(l => l.id !== model.id && (!model.id || !this.locationDescendants(model.id).has(l.id))).map(l => `<option value="${esc(l.id)}" ${l.id === model.parentLocationId ? "selected" : ""}>${esc(l.name)} · ${esc(l.kind)}</option>`).join("")}</select></label><label><span>Description</span><textarea name="description" rows="7">${esc(model.description)}</textarea></label><label><span>Tags</span><input name="tags" value="${esc(model.tags.join(", "))}"></label><div class="world-form-status" data-role="location-status" aria-live="polite"></div><button class="btn primary" type="submit">${selected ? "Save location" : "Create location"}</button></form>`;
  }

  private locationDescendants(id: string) {
    const out = new Set<string>(), queue = [id];
    while (queue.length) { const parent = queue.shift()!; for (const loc of this.locations) if (loc.parentLocationId === parent && !out.has(loc.id)) { out.add(loc.id); queue.push(loc.id); } }
    return out;
  }

  private mapDescendants(id: string) {
    const out = new Set<string>(), queue = [id];
    while (queue.length) { const parent = queue.shift()!; for (const map of this.maps) if (map.parentMapId === parent && !out.has(map.id)) { out.add(map.id); queue.push(map.id); } }
    return out;
  }

  private async saveLocation(form: HTMLFormElement, id?: string) {
    const data = new FormData(form);
    const input = { name: String(data.get("name") || "").trim(), kind: String(data.get("kind")) as LocationKind, parentLocationId: String(data.get("parent") || "") || null, description: String(data.get("description") || ""), color: String(data.get("color") || "#70b7c4"), tags: String(data.get("tags") || "").split(",").map(x => x.trim()).filter(Boolean) };
    const status = form.querySelector<HTMLElement>("[data-role=location-status]");
    try {
      const saved = id ? await this.gateway.updateLocation(id, input) : await this.gateway.createLocation(input);
      this.selectedLocationId = saved.id;
      await this.reload();
      this.paint();
    } catch (error) {
      if (status) status.textContent = `Could not save location: ${String(error)}`;
    }
  }

  private async deleteLocation(selected: LocationDto) {
    if (shouldConfirmDestructive() && !confirm(`Delete location “${selected.name}”? Child locations will become top-level; map pins and routes for this location will be removed.`)) return;
    const status = this.root.querySelector<HTMLElement>("[data-role=location-status]");
    if (status) status.textContent = "Deleting…";
    try {
      await this.gateway.deleteLocation(selected.id);
      this.selectedLocationId = null;
      await this.reload();
      this.paint();
    } catch (error) {
      if (status) status.textContent = `Could not delete location: ${String(error)}`;
    }
  }

  private paintGenerator(host: HTMLElement) {
    const d = this.draft;
    host.innerHTML = `<div class="generator-map-layout"><form class="map-generator-controls" data-generator-form><div><span class="eyebrow">PROCEDURAL MAP BUILDER</span><h2>Generate a world draft</h2><p>Drafts are non-canonical until accepted. v0.7.5 uses higher-resolution coastlines and more varied continental silhouettes.</p></div><label><span>Seed</span><div class="seed-row"><input name="seed" type="number" min="1" max="4294967295" value="${d?.seed ?? 482193}"><button class="btn" type="button" data-random-seed>Random</button></div></label><label><span>Map name</span><input name="name" value="${esc(d?.name ?? "Generated World")}"></label><div class="form-grid two"><label><span>Continents</span><input name="continents" type="number" min="1" max="8" value="${d?.landmasses.length ?? 3}"></label><label><span>Ocean %</span><input name="ocean" type="number" min="20" max="90" value="${Math.round((d?.oceanRatio ?? .55) * 100)}"></label><label><span>Mountains</span><input name="mountains" type="range" min="0" max="100" value="55"></label><label><span>Rivers</span><input name="rivers" type="number" min="0" max="30" value="${d?.rivers.length ?? 5}"></label><label><span>Settlements</span><input name="settlements" type="number" min="0" max="80" value="${d?.settlements.length ?? 12}"></label></div><button class="btn primary" type="submit" ${this.generatorBusy ? "disabled" : ""}>${this.generatorBusy ? "Generating…" : "Generate / Regenerate"}</button>${d ? `<label class="check-row"><input type="checkbox" name="locations" checked><span>Create continent & settlement locations on accept</span></label><button class="btn accept-map" type="button" data-accept-map>Accept into World</button>` : ""}</form><section class="generated-preview">${d ? `<div class="preview-head"><span><strong>${esc(d.name)}</strong> · Seed ${d.seed}</span><span>${d.landmasses.length} continents · ${d.settlements.length} settlements</span></div><svg viewBox="0 0 ${d.width} ${d.height}" class="atlas-map generator-preview"><rect width="${d.width}" height="${d.height}" class="ocean"/>${this.terrainMarkup(d, d.width, d.height)}${d.settlements.map(s => this.generatedSettlementMarkup(s, d.width, d.height)).join("")}</svg>` : `<div class="atlas-empty"><strong>Seeded generation</strong><span>Choose parameters and generate a non-canonical preview.</span></div>`}</section></div>`;
    const form = host.querySelector<HTMLFormElement>("[data-generator-form]")!;
    form.addEventListener("submit", event => { event.preventDefault(); void this.generate(form); });
    host.querySelector("[data-random-seed]")?.addEventListener("click", () => { const input = form.elements.namedItem("seed") as HTMLInputElement; input.value = String(Math.floor(Math.random() * 4_000_000_000) + 1); });
    host.querySelector("[data-accept-map]")?.addEventListener("click", () => d && void this.acceptDraft(form, d));
  }

  private async generate(form: HTMLFormElement) {
    const data = new FormData(form);
    this.generatorBusy = true; this.paint();
    try {
      this.draft = await this.gateway.generate({ seed: Number(data.get("seed") || 1) >>> 0, name: String(data.get("name") || "Generated World"), width: 1200, height: 760, continents: Number(data.get("continents") || 3), oceanRatio: Number(data.get("ocean") || 55) / 100, mountainDensity: Number(data.get("mountains") || 55) / 100, riverCount: Number(data.get("rivers") || 5), settlementCount: Number(data.get("settlements") || 12) });
    } finally { this.generatorBusy = false; this.paint(); }
  }

  private async acceptDraft(form: HTMLFormElement, draft: GeneratedMapDraft) {
    const data = new FormData(form);
    const result = await this.gateway.acceptGenerated({ draft, mapName: String(data.get("name") || draft.name), createLocations: Boolean(data.get("locations")) });
    this.selectedMapId = result.map.id;
    this.resetMapCamera();
    this.draft = null;
    this.view = "atlas";
    await this.reload();
    this.paint();
  }
}
