import{invoke}from"@tauri-apps/api/core";
import type{AtlasGateway,AtlasMapDto,LocationDto,MapConnectionDto,MapPinDto,GeneratedMapDraft,AcceptGeneratedMapResult,UpsertLocationInput,UpsertMapInput,UpsertPinInput,UpsertConnectionInput,GenerateMapRequest}from"../application/AtlasGateway";
export const tauriAtlasGateway:AtlasGateway={
  locations:()=>invoke<LocationDto[]>("atlas_locations_list"),location:id=>invoke("atlas_location_get",{id}),createLocation:input=>invoke("atlas_location_create",{input}),updateLocation:(id,input)=>invoke("atlas_location_update",{id,input}),deleteLocation:id=>invoke("atlas_location_delete",{id}),
  maps:()=>invoke<AtlasMapDto[]>("atlas_maps_list"),map:id=>invoke("atlas_map_get",{id}),createMap:input=>invoke("atlas_map_create",{input}),updateMap:(id,input)=>invoke("atlas_map_update",{id,input}),deleteMap:id=>invoke("atlas_map_delete",{id}),
  pins:mapId=>invoke<MapPinDto[]>("atlas_map_pins",{mapId}),upsertPin:input=>invoke<MapPinDto>("atlas_map_pin_upsert",{input}),deletePin:id=>invoke("atlas_map_pin_delete",{id}),
  connections:mapId=>invoke<MapConnectionDto[]>("atlas_map_connections",{mapId}),upsertConnection:input=>invoke<MapConnectionDto>("atlas_map_connection_upsert",{input}),deleteConnection:id=>invoke("atlas_map_connection_delete",{id}),
  generate:input=>invoke<GeneratedMapDraft>("atlas_generate_map",{input}),acceptGenerated:input=>invoke<AcceptGeneratedMapResult>("atlas_accept_generated_map",{input}),
};
