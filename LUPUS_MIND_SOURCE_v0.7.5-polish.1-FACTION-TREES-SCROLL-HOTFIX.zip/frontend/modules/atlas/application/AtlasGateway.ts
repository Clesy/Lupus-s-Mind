export type LocationKind="world"|"continent"|"country"|"region"|"province"|"city"|"town"|"village"|"district"|"building"|"landmark"|"dungeon"|"biome"|"location";
export interface LocationDto{id:string;name:string;kind:LocationKind;parentLocationId:string|null;parentLocationName:string|null;description:string;color:string;tags:string[];childCount:number;createdAt:string;updatedAt:string}
export interface UpsertLocationInput{name:string;kind:LocationKind;parentLocationId?:string|null;description?:string;color?:string;tags:string[]}
export interface MapPoint{x:number;y:number}
export interface GeneratedLandmass{id:string;name:string;points:MapPoint[]}
export interface GeneratedMarker{id:string;name:string;kind:string;x:number;y:number}
export interface GeneratedRiver{id:string;points:MapPoint[]}
export interface GeneratedMapDraft{seed:number;name:string;width:number;height:number;oceanRatio:number;landmasses:GeneratedLandmass[];mountains:GeneratedMarker[];rivers:GeneratedRiver[];settlements:GeneratedMarker[]}
export interface AtlasMapDto{id:string;name:string;scopeLocationId:string|null;scopeLocationName:string|null;parentMapId:string|null;width:number;height:number;background:string;terrain:GeneratedMapDraft|null;generatorSeed:number|null;pinCount:number;createdAt:string;updatedAt:string}
export interface UpsertMapInput{name:string;scopeLocationId?:string|null;parentMapId?:string|null;width:number;height:number;background?:string;terrain?:GeneratedMapDraft|null}
export interface MapPinDto{id:string;mapId:string;locationId:string;locationName:string;locationKind:string;label:string;x:number;y:number;icon:string;color:string}
export interface UpsertPinInput{mapId:string;locationId:string;label?:string;x:number;y:number;icon?:string;color?:string}
export type ConnectionKind="road"|"sea_route"|"portal"|"border"|"path";
export interface MapConnectionDto{id:string;mapId:string;fromLocationId:string;fromLocationName:string;toLocationId:string;toLocationName:string;kind:ConnectionKind;label:string;color:string}
export interface UpsertConnectionInput{mapId:string;fromLocationId:string;toLocationId:string;kind:ConnectionKind;label?:string;color?:string}
export interface GenerateMapRequest{seed:number;name?:string;width:number;height:number;continents:number;oceanRatio:number;mountainDensity:number;riverCount:number;settlementCount:number}
export interface AcceptGeneratedMapResult{map:AtlasMapDto;createdLocationIds:string[]}
export interface AtlasGateway{
  locations():Promise<LocationDto[]>;location(id:string):Promise<LocationDto>;createLocation(input:UpsertLocationInput):Promise<LocationDto>;updateLocation(id:string,input:UpsertLocationInput):Promise<LocationDto>;deleteLocation(id:string):Promise<void>;
  maps():Promise<AtlasMapDto[]>;map(id:string):Promise<AtlasMapDto>;createMap(input:UpsertMapInput):Promise<AtlasMapDto>;updateMap(id:string,input:UpsertMapInput):Promise<AtlasMapDto>;deleteMap(id:string):Promise<void>;
  pins(mapId:string):Promise<MapPinDto[]>;upsertPin(input:UpsertPinInput):Promise<MapPinDto>;deletePin(id:string):Promise<void>;
  connections(mapId:string):Promise<MapConnectionDto[]>;upsertConnection(input:UpsertConnectionInput):Promise<MapConnectionDto>;deleteConnection(id:string):Promise<void>;
  generate(input:GenerateMapRequest):Promise<GeneratedMapDraft>;acceptGenerated(input:{draft:GeneratedMapDraft;mapName:string;createLocations:boolean}):Promise<AcceptGeneratedMapResult>;
}
