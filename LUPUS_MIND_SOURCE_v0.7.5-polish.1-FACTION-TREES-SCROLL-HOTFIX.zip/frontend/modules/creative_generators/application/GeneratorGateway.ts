export type GeneratorKind="character_name"|"location_name"|"item_name";
export type GeneratorTone="noble"|"dark"|"ancient"|"harsh"|"elegant"|"mystic";
export interface GenerationRequest{kind:GeneratorKind;tone:GeneratorTone;subtype:string;count:number;seed:number;}
export interface GeneratedCandidate{id:string;value:string;note:string;}
export interface GeneratorGateway{generate(input:GenerationRequest):Promise<GeneratedCandidate[]>;}
