import {invoke} from "@tauri-apps/api/core";
import type {GeneratedCandidate,GenerationRequest,GeneratorGateway} from "../application/GeneratorGateway";
export const tauriGeneratorGateway:GeneratorGateway={generate:(input)=>invoke<GeneratedCandidate[]>("creative_generate",{input})};
