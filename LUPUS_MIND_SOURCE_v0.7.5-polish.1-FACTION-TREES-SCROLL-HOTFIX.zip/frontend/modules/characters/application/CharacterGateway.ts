export interface CharacterStats { str:number; agi:number; vit:number; int:number; mnd:number; }
export interface CharacterSummaryDto { id:string; name:string; alias:string|null; level:number; classLabel:string|null; }
export interface CharacterDto extends CharacterSummaryDto { baseStats:CharacterStats; biography:string; tags:string[]; createdAt:string; updatedAt:string; }
export interface UpsertCharacterInput { name:string; alias?:string; classLabel?:string; level:number; baseStats:CharacterStats; biography?:string; tags:string[]; }
export interface CharacterGateway {
  list():Promise<CharacterSummaryDto[]>;
  get(id:string):Promise<CharacterDto>;
  create(input:UpsertCharacterInput):Promise<CharacterDto>;
  update(id:string,input:UpsertCharacterInput):Promise<CharacterDto>;
  remove(id:string):Promise<void>;
}
