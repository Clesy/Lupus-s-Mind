import type { CharacterDto, CharacterGateway, UpsertCharacterInput } from "../application/CharacterGateway";
import type { EquipmentGateway } from "../../equipment/application/EquipmentGateway";
import type { SkillDto, SkillGateway } from "../../skills/application/SkillGateway";
import type { CharacterSheetDto, EffectiveStats } from "../../character-sheet/application/CharacterSheet";
import type { AssetGateway } from "../../assets/application/AssetGateway";
import { assetBlobUrl, prepareImageAsset } from "../../assets/application/imageAssets";
import { shouldConfirmDestructive } from "../../../shared/preferences";
import { CharacterEditor } from "./CharacterEditor";
import type { AuthoringGateway, CharacterArcPoint } from "../../authoring/application/AuthoringGateway";
import type { EntityBacklink, KnowledgeLinkGateway } from "../../knowledge_links/application/KnowledgeLinkGateway";
import type { FactionGateway, FactionMembershipDto } from "../../factions/application/FactionGateway";
import type { InventoryGateway, OwnershipDto } from "../../inventory/application/InventoryGateway";

const esc=(value:string):string=>value.replace(/[&<>"']/g,(char)=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[char]!);
const label=(value:string):string=>value.replaceAll("_"," ").replace(/\b\w/g,(letter)=>letter.toUpperCase());
const FAVORITES_KEY="lupus_mind_character_favorites";

type ViewMode="cards"|"table";
type BaseStatKey="str"|"agi"|"vit"|"int"|"mnd";

const BASE_STAT_META:Record<BaseStatKey,{label:string,tone:string}>={
  str:{label:"STR",tone:"strength"},
  agi:{label:"AGI",tone:"agility"},
  vit:{label:"VIT",tone:"vitality"},
  int:{label:"INT",tone:"intelligence"},
  mnd:{label:"MND",tone:"mind"},
};
const EFFECTIVE_META:Array<[keyof EffectiveStats,string,string]>=[
  ["strength","STR","strength"],["agility","AGI","agility"],["vitality","VIT","vitality"],
  ["intelligence","INT","intelligence"],["mind","MND","mind"],["weaponDamage","DMG","weapon"],
  ["armor","ARM","armor"],["armorPenetration","ARM PEN","penetration"],["magicPenetration","MAG PEN","penetration"],
  ["criticalChance","CRIT","critical"],["damageReduction","RED","reduction"],
];

export class CharacterScreen {
  private records:CharacterDto[]=[];
  private selectedId:string|null=null;
  private search="";
  private editor:CharacterEditor|null=null;
  private detailEpoch=0;
  private viewMode:ViewMode="cards";
  private favorites=new Set<string>();
  private favoritesOnly=false;
  private portraitUrls=new Map<string,string|null>();

  constructor(private readonly host:HTMLElement,private readonly gateway:CharacterGateway,private readonly equipment:EquipmentGateway,private readonly skills:SkillGateway,private readonly assets:AssetGateway,private readonly authoring:AuthoringGateway,private readonly links:KnowledgeLinkGateway,private readonly factions:FactionGateway,private readonly inventory:InventoryGateway,private readonly navigate?:(route:string,id?:string)=>void){}

  async render():Promise<void>{
    this.restorePreferences();
    this.host.innerHTML=`
      <div class="character-gallery-shell">
        <section class="character-gallery-pane">
          <header class="character-gallery-head studio-page-head">
            <div class="page-heading-copy">
              <div class="eyebrow">Cast & identities</div>
              <h1>Characters</h1>
              <p>Canonical cast, build identity and loadout at a glance.</p>
            </div>
            <div class="action-row">
              <button class="filter-chip" data-action="favorites" aria-pressed="false">★ Favorites</button>
              <div class="segmented"><button data-view="cards">Cards</button><button data-view="table">Table</button></div>
              <button class="btn primary" data-action="new">+ New Character</button>
            </div>
          </header>
          <div class="character-filterbar">
            <label class="search-field"><span>⌕</span><input data-role="search" placeholder="Search name, class, tag or biography" /></label>
            <span class="character-count" data-role="count"></span>
          </div>
          <div class="character-gallery" data-role="list"></div>
        </section>
        <aside class="character-inspector" data-role="detail"><div class="empty-state large"><strong>Select a character</strong><span>Stats, equipment, skills and canonical lore appear here.</span></div></aside>
      </div>
      <div data-role="editor-host"></div><div data-role="dialog-host"></div>`;
    this.editor=new CharacterEditor(this.query('[data-role="editor-host"]'),this.gateway);
    this.query<HTMLButtonElement>('[data-action="new"]').addEventListener("click",()=>this.openCreate());
    this.query<HTMLButtonElement>('[data-action="favorites"]').addEventListener("click",()=>{this.favoritesOnly=!this.favoritesOnly;this.paintFavoritesFilter();this.renderList();});
    this.query<HTMLInputElement>('[data-role="search"]').addEventListener("input",(event)=>{this.search=(event.currentTarget as HTMLInputElement).value.trim().toLowerCase();this.renderList();});
    this.host.querySelectorAll<HTMLButtonElement>("[data-view]").forEach(button=>button.addEventListener("click",()=>this.setView(button.dataset.view as ViewMode)));
    this.paintViewToggle();this.paintFavoritesFilter();
    await this.refresh();
  }

  public openCreate():void{this.editor?.openCreate(character=>void this.afterSave(character));}
  public async openById(id:string):Promise<void>{await this.select(id);}

  private restorePreferences():void{
    try{
      const stored=window.localStorage.getItem("lupus_mind_character_view");if(stored==="table"||stored==="cards")this.viewMode=stored;
      const favorites=JSON.parse(window.localStorage.getItem(FAVORITES_KEY)??"[]");if(Array.isArray(favorites))this.favorites=new Set(favorites.filter((value):value is string=>typeof value==="string"));
    }catch{}
  }
  private persistFavorites():void{try{window.localStorage.setItem(FAVORITES_KEY,JSON.stringify([...this.favorites]));}catch{}}
  private setView(mode:ViewMode):void{this.viewMode=mode;try{window.localStorage.setItem("lupus_mind_character_view",mode);}catch{}this.paintViewToggle();this.renderList();}
  private paintViewToggle():void{this.host.querySelectorAll<HTMLButtonElement>("[data-view]").forEach(button=>button.classList.toggle("active",button.dataset.view===this.viewMode));}
  private paintFavoritesFilter():void{const button=this.host.querySelector<HTMLButtonElement>('[data-action="favorites"]');if(!button)return;button.classList.toggle("active",this.favoritesOnly);button.setAttribute("aria-pressed",String(this.favoritesOnly));}

  private async refresh():Promise<void>{
    const summaries=await this.gateway.list();
    this.records=await Promise.all(summaries.map(summary=>this.gateway.get(summary.id)));
    this.records.sort((a,b)=>Number(this.favorites.has(b.id))-Number(this.favorites.has(a.id))||a.name.localeCompare(b.name));
    this.renderList();
    if(this.selectedId){const selected=this.records.find(record=>record.id===this.selectedId);if(selected)await this.renderDetail(selected);else this.renderEmpty();}
  }

  private renderList():void{
    const filtered=this.records.filter(character=>(!this.favoritesOnly||this.favorites.has(character.id))&&(!this.search||[character.name,character.alias??"",character.classLabel??"",character.biography,...character.tags].join(" ").toLowerCase().includes(this.search)));
    this.query<HTMLElement>('[data-role="count"]').textContent=`${filtered.length} shown · ${this.records.length} total`;
    const list=this.query<HTMLElement>('[data-role="list"]');list.classList.toggle("table-mode",this.viewMode==="table");
    if(!filtered.length){list.innerHTML=`<div class="empty-state gallery-empty"><strong>${this.favoritesOnly?"No favorite characters yet":"No characters found"}</strong><span>${this.favoritesOnly?"Open a character and star it for quick access.":"Try another filter or create a new character."}</span></div>`;return;}
    list.innerHTML=filtered.map(character=>this.viewMode==="cards"?this.card(character):this.tableRow(character)).join("");
    list.querySelectorAll<HTMLButtonElement>("[data-select-id]").forEach(button=>button.addEventListener("click",()=>void this.select(button.dataset.selectId!)));
    list.querySelectorAll<HTMLButtonElement>("[data-favorite-id]").forEach(button=>button.addEventListener("click",event=>{event.stopPropagation();this.toggleFavorite(button.dataset.favoriteId!);}));
    void this.hydratePortraits(filtered.map(character=>character.id),list);
  }

  private card(character:CharacterDto):string{
    const initial=esc(character.name.trim().slice(0,1).toUpperCase()||"?");
    const tags=character.tags.slice(0,3);
    const stats=(Object.keys(BASE_STAT_META) as BaseStatKey[]).map(key=>this.baseStatChip(key,character.baseStats[key])).join("");
    const isFavorite=this.favorites.has(character.id);
    return `<article class="character-card ${character.id===this.selectedId?"active":""}">
      <button class="character-card-select" data-select-id="${esc(character.id)}" aria-label="Open ${esc(character.name)}">
        <div class="character-art" data-portrait-id="${esc(character.id)}"><span data-portrait-fallback>${initial}</span><img data-portrait-image alt="" hidden /><div class="character-art-shade"></div><em>Lv ${character.level}</em><div class="portrait-ready">Add portrait</div></div>
        <div class="character-card-body">
          <div class="character-card-kicker"><span>${esc(character.classLabel??"Unassigned")}</span><span>${character.tags.length} tags</span></div>
          <div class="character-card-title"><strong>${esc(character.name)}</strong><small>${character.alias?esc(character.alias):"Canonical character"}</small></div>
          <div class="character-mini-stats">${stats}</div>
          <div class="character-card-tags">${tags.length?tags.map((tag,index)=>`<span class="tag-tone-${index%5}">${esc(tag)}</span>`).join(""):`<span class="muted">No tags</span>`}${character.tags.length>3?`<span>+${character.tags.length-3}</span>`:""}</div>
        </div>
      </button>
      <button class="card-favorite ${isFavorite?"active":""}" data-favorite-id="${esc(character.id)}" aria-label="${isFavorite?"Remove from favorites":"Add to favorites"}" title="${isFavorite?"Favorite":"Add to favorites"}">★</button>
    </article>`;
  }

  private tableRow(character:CharacterDto):string{
    const isFavorite=this.favorites.has(character.id);
    return `<div class="character-table-row ${character.id===this.selectedId?"active":""}">
      <button class="table-favorite ${isFavorite?"active":""}" data-favorite-id="${esc(character.id)}" aria-label="Toggle favorite">★</button>
      <button class="character-table-select" data-select-id="${esc(character.id)}"><span class="table-avatar">${esc(character.name.slice(0,1).toUpperCase())}</span><span><strong>${esc(character.name)}</strong><small>${esc(character.classLabel??"Unassigned")}</small></span><span>Lv ${character.level}</span>${this.tableStat("STR","strength",character.baseStats.str)}${this.tableStat("AGI","agility",character.baseStats.agi)}${this.tableStat("VIT","vitality",character.baseStats.vit)}</button>
    </div>`;
  }

  private baseStatChip(key:BaseStatKey,value:number):string{const meta=BASE_STAT_META[key];return `<span class="stat-tone stat-${meta.tone}"><small>${meta.label}</small><b>${value}</b></span>`;}
  private tableStat(name:string,tone:string,value:number):string{return `<span class="table-stat stat-tone stat-${tone}"><small>${name}</small><b>${value}</b></span>`;}
  private toggleFavorite(id:string):void{if(this.favorites.has(id))this.favorites.delete(id);else this.favorites.add(id);this.persistFavorites();this.records.sort((a,b)=>Number(this.favorites.has(b.id))-Number(this.favorites.has(a.id))||a.name.localeCompare(b.name));this.renderList();if(this.selectedId===id){const selected=this.records.find(record=>record.id===id);if(selected)void this.renderDetail(selected);}}

  private async select(id:string):Promise<void>{this.selectedId=id;const character=this.records.find(record=>record.id===id)??await this.gateway.get(id);if(!this.records.some(record=>record.id===id))this.records.push(character);this.renderList();await this.renderDetail(character);}

  private async renderDetail(character:CharacterDto):Promise<void>{
    const epoch=++this.detailEpoch;const detail=this.query<HTMLElement>('[data-role="detail"]');const favorite=this.favorites.has(character.id);
    detail.innerHTML=`
      <div class="character-inspector-scroll">
        <header class="character-profile-head">
          <div class="character-profile-avatar" data-portrait-id="${esc(character.id)}"><span data-portrait-fallback>${esc(character.name.slice(0,1).toUpperCase())}</span><img data-portrait-image alt="Portrait of ${esc(character.name)}" hidden /></div>
          <div class="character-profile-copy"><span class="eyebrow">${esc(character.classLabel??"Unassigned class")} · Level ${character.level}</span><h2>${esc(character.name)}</h2>${character.alias?`<p>${esc(character.alias)}</p>`:""}</div>
          <div class="profile-menu"><button class="btn ghost ${favorite?"favorite-active":""}" data-action="favorite">★</button><button class="btn ghost" data-action="portrait">Portrait</button><button class="btn ghost" data-action="remove-portrait">Remove art</button><input type="file" accept="image/png,image/jpeg,image/webp" data-role="portrait-file" hidden /><button class="btn ghost" data-action="compare">Compare</button><button class="btn ghost" data-action="duplicate">Duplicate</button><button class="btn ghost" data-action="edit">Edit</button><button class="btn danger ghost" data-action="delete">Delete</button></div>
        </header>
        <div class="tag-row character-profile-tags">${character.tags.map((tag,index)=>`<span class="tag tag-tone-${index%5}">${esc(tag)}</span>`).join("")||'<span class="tag muted">No tags</span>'}</div>
        <section class="inspector-section"><div class="inspector-section-title"><span>Base Stats</span><small>Canonical</small></div><div class="character-stat-grid compact">${(Object.keys(BASE_STAT_META) as BaseStatKey[]).map(key=>{const meta=BASE_STAT_META[key];return `<div class="character-stat-card stat-tone stat-${meta.tone}"><span>${meta.label}</span><strong>${character.baseStats[key]}</strong><i></i></div>`;}).join("")}</div></section>
        <section class="character-loadout" data-role="loadout"><div class="loadout-loading"><span class="loading-spinner"></span><span>Reading loadout…</span></div></section>
        <section class="inspector-section"><div class="inspector-section-title"><span>Biography</span></div><p class="body-copy character-bio-copy">${esc(character.biography||"No biography recorded.")}</p></section>
        <section class="inspector-section character-world-context" data-role="character-world-context"><div class="loadout-loading"><span class="loading-spinner"></span><span>Reading factions & inventory…</span></div></section>
        <section class="inspector-section character-authoring" data-role="character-authoring"><div class="loadout-loading"><span class="loading-spinner"></span><span>Reading arc & backlinks…</span></div></section>
      </div>`;
    detail.querySelector<HTMLButtonElement>('[data-action="favorite"]')?.addEventListener("click",()=>this.toggleFavorite(character.id));
    const portraitInput=detail.querySelector<HTMLInputElement>('[data-role="portrait-file"]');
    detail.querySelector<HTMLButtonElement>('[data-action="portrait"]')?.addEventListener("click",()=>portraitInput?.click());
    portraitInput?.addEventListener("change",()=>{const file=portraitInput.files?.[0];if(file)void this.savePortrait(character,file);portraitInput.value="";});
    detail.querySelector<HTMLButtonElement>('[data-action="remove-portrait"]')?.addEventListener("click",()=>void this.removePortrait(character));
    detail.querySelector<HTMLButtonElement>('[data-action="compare"]')?.addEventListener("click",()=>this.openCompare(character));
    detail.querySelector<HTMLButtonElement>('[data-action="duplicate"]')?.addEventListener("click",()=>void this.duplicate(character));
    detail.querySelector<HTMLButtonElement>('[data-action="edit"]')?.addEventListener("click",()=>this.editor?.openEdit(character,saved=>void this.afterSave(saved)));
    detail.querySelector<HTMLButtonElement>('[data-action="delete"]')?.addEventListener("click",()=>this.openDelete(character));
    void this.hydratePortraits([character.id],detail);
    try{const [sheet,learned,arc,backlinks,memberships,inventory]=await Promise.all([this.equipment.sheet(character.id),this.skills.listForCharacter(character.id),this.authoring.arcForCharacter(character.id),this.links.backlinksForTarget("character",character.id),this.factions.memberships({characterId:character.id}),this.inventory.listAt(2147483647,"character",character.id)]);if(epoch!==this.detailEpoch||this.selectedId!==character.id)return;this.renderLoadout(sheet,learned);this.renderWorldContext(memberships.filter(m=>m.leftChapter===null),inventory);this.renderCharacterAuthoring(character,arc,backlinks);}catch(cause){if(epoch!==this.detailEpoch)return;const node=detail.querySelector<HTMLElement>('[data-role="loadout"]');if(node)node.innerHTML=`<div class="loadout-error"><strong>Character detail unavailable</strong><span>${esc(cause instanceof Error?cause.message:String(cause))}</span></div>`;}
  }

  private renderLoadout(sheet:CharacterSheetDto,learned:SkillDto[]):void{
    const loadout=this.query<HTMLElement>('[data-role="loadout"]');
    loadout.innerHTML=`
      <section class="inspector-section"><div class="inspector-section-title"><span>Effective Stats</span><small>Base + equipment</small></div><div class="character-effective-strip">${EFFECTIVE_META.map(([key,name,tone])=>`<div class="stat-tone stat-${tone}"><span>${name}</span><strong>${sheet.effectiveStats[key]}</strong></div>`).join("")}</div></section>
      <section class="inspector-section"><div class="inspector-section-title"><span>Equipment · ${sheet.equipment.length}</span><button class="text-btn" data-manage="equipment">Manage</button></div><div class="inspector-list equipment-inspector-list">${sheet.equipment.length?sheet.equipment.map(({slot,item})=>`<div><span><strong>${esc(item.name)}</strong><small>${esc(label(slot))}</small></span><em class="rarity-text rarity-${esc(item.rarity)}">${esc(label(item.rarity))}</em></div>`).join(""):`<div class="empty-note">No items equipped.</div>`}</div></section>
      <section class="inspector-section"><div class="inspector-section-title"><span>Skills · ${learned.length}</span><button class="text-btn" data-manage="skills">Manage</button></div><div class="inspector-list skill-inspector-list">${learned.length?learned.map(skill=>`<div><span><strong>${esc(skill.name)}</strong><small>${esc(label(skill.kind))}</small></span><em class="skill-tone skill-${esc(skill.kind)}">${skill.basePower} power</em></div>`).join(""):`<div class="empty-note">No learned skills.</div>`}</div></section>`;
    loadout.querySelector<HTMLButtonElement>('[data-manage="equipment"]')?.addEventListener("click",()=>this.navigate?.("equipment"));loadout.querySelector<HTMLButtonElement>('[data-manage="skills"]')?.addEventListener("click",()=>this.navigate?.("skills"));
  }


  private renderWorldContext(memberships:FactionMembershipDto[],inventory:OwnershipDto[]):void{
    const host=this.query<HTMLElement>('[data-role="character-world-context"]');
    const membershipsMarkup=memberships.length?memberships.map(m=>`<button class="world-context-row" data-faction-id="${esc(m.factionId)}"><span><strong>${esc(m.factionName)}</strong><small>${esc(m.role)}${m.rank?` · ${esc(m.rank)}`:""} · since Ch.${m.joinedChapter}</small></span><em>Faction</em></button>`).join(""):`<div class="empty-note">No current faction memberships.</div>`;
    const inventoryMarkup=inventory.length?inventory.slice(0,8).map(o=>`<button class="world-context-row" data-item-id="${esc(o.itemId)}"><span><strong>${esc(o.itemName)}</strong><small>Owned since Ch.${o.acquiredChapter}</small></span><em>${o.isEquipped?"Equipped":"Owned"}</em></button>`).join(""):`<div class="empty-note">No currently owned items.</div>`;
    host.innerHTML=`<div class="inspector-section-title"><span>World Context</span><small>Current open state</small></div><div class="world-context-group"><b>Factions</b>${membershipsMarkup}</div><div class="world-context-group"><b>Inventory</b>${inventoryMarkup}</div>`;
    host.querySelectorAll<HTMLButtonElement>('[data-faction-id]').forEach(b=>b.addEventListener('click',()=>this.navigate?.('factions',b.dataset.factionId!)));
    host.querySelectorAll<HTMLButtonElement>('[data-item-id]').forEach(b=>b.addEventListener('click',()=>this.navigate?.('items',b.dataset.itemId!)));
  }

  private renderCharacterAuthoring(character:CharacterDto,arc:CharacterArcPoint[],backlinks:EntityBacklink[]):void{
    const host=this.query<HTMLElement>('[data-role="character-authoring"]');
    const arcMarkup=arc.length?`<div class="arc-track">${arc.map(point=>`<article class="arc-point"><span class="arc-dot"></span><div><small>Ch. ${point.chapterNumber}${point.phase?` · ${esc(point.phase)}`:""}</small><strong>${esc(point.title)}</strong>${point.description?`<p>${esc(point.description)}</p>`:""}</div><button class="text-btn danger-text" data-delete-arc="${esc(point.id)}">×</button></article>`).join("")}</div>`:`<div class="empty-note">No character arc points yet.</div>`;
    const backlinkMarkup=backlinks.length?backlinks.slice(0,8).map(link=>`<button class="knowledge-link compact-link" data-backlink-route="${esc(link.route)}" data-backlink-id="${esc(link.sourceId)}"><span class="link-kind">${esc(link.sourceKind)}</span><strong>${esc(link.sourceTitle)}</strong><small>${link.occurrences} mention${link.occurrences===1?"":"s"}</small></button>`).join(""):`<div class="empty-note">No manuscript or lore backlinks yet.</div>`;
    host.innerHTML=`<div class="inspector-section-title"><span>Character Arc</span><button class="text-btn" data-action="add-arc">+ Point</button></div>${arcMarkup}<div class="inspector-section-title authoring-subhead"><span>Backlinks</span><small>${backlinks.length}</small></div><div class="character-backlinks">${backlinkMarkup}</div>`;
    host.querySelector<HTMLButtonElement>('[data-action="add-arc"]')?.addEventListener("click",()=>this.openArcEditor(character));
    host.querySelectorAll<HTMLButtonElement>('[data-delete-arc]').forEach(button=>button.addEventListener("click",()=>void this.authoring.removeArc(button.dataset.deleteArc!).then(()=>this.renderDetail(character))));
    host.querySelectorAll<HTMLButtonElement>('[data-backlink-route]').forEach(button=>button.addEventListener("click",()=>this.navigate?.(button.dataset.backlinkRoute!,button.dataset.backlinkId!)));
  }

  private openArcEditor(character:CharacterDto):void{
    const host=this.query<HTMLElement>('[data-role="dialog-host"]');
    host.innerHTML=`<div class="overlay"><section class="arc-dialog" role="dialog" aria-modal="true"><header><div><span class="eyebrow">Narrative development</span><h2>Add arc point · ${esc(character.name)}</h2></div><button class="icon-btn" data-action="close">×</button></header><form data-role="arc-form"><div class="arc-form-grid"><label><span>Chapter</span><input name="chapter" type="number" min="1" value="1" required /></label><label><span>Phase</span><input name="phase" placeholder="Exile, Recovery…" /></label></div><label><span>Turning point</span><input name="title" required placeholder="Betrayal changes his goal" /></label><label><span>Notes</span><textarea name="description" rows="4" placeholder="Narrative meaning, motivation, internal change…"></textarea></label><div class="confirm-actions"><button class="btn" type="button" data-action="close">Cancel</button><button class="btn primary" type="submit">Add point</button></div></form></section></div>`;
    host.querySelectorAll<HTMLButtonElement>('[data-action="close"]').forEach(button=>button.addEventListener("click",()=>{host.innerHTML="";}));
    host.querySelector<HTMLFormElement>('[data-role="arc-form"]')?.addEventListener("submit",event=>{event.preventDefault();const form=event.currentTarget as HTMLFormElement;const data=new FormData(form);void this.authoring.createArc({characterId:character.id,chapterNumber:Math.max(1,Math.floor(Number(data.get("chapter")||1))),title:String(data.get("title")||"").trim(),phase:String(data.get("phase")||"").trim(),description:String(data.get("description")||"")}).then(()=>{host.innerHTML="";return this.renderDetail(character);});});
  }

  private async portraitUrl(characterId:string,force=false):Promise<string|null>{
    if(!force&&this.portraitUrls.has(characterId))return this.portraitUrls.get(characterId)??null;
    const previous=this.portraitUrls.get(characterId);if(previous)URL.revokeObjectURL(previous);
    const asset=await this.assets.getCharacterPortrait(characterId);const url=asset?assetBlobUrl(asset):null;this.portraitUrls.set(characterId,url);return url;
  }

  private async hydratePortraits(characterIds:string[],scope:ParentNode):Promise<void>{
    await Promise.all(characterIds.map(async id=>{try{const url=await this.portraitUrl(id);scope.querySelectorAll<HTMLElement>(`[data-portrait-id="${CSS.escape(id)}"]`).forEach(node=>{const image=node.querySelector<HTMLImageElement>("[data-portrait-image]");const fallback=node.querySelector<HTMLElement>("[data-portrait-fallback]");const ready=node.querySelector<HTMLElement>(".portrait-ready");if(image){if(url){image.src=url;image.hidden=false;}else{image.removeAttribute("src");image.hidden=true;}}if(fallback)fallback.hidden=!!url;if(ready)ready.textContent=url?"Portrait":"Add portrait";node.classList.toggle("has-portrait",!!url);});}catch{}}));
  }

  private async savePortrait(character:CharacterDto,file:File):Promise<void>{
    const detail=this.query<HTMLElement>('[data-role="detail"]');const button=detail.querySelector<HTMLButtonElement>('[data-action="portrait"]');if(button){button.disabled=true;button.textContent="Saving…";}
    try{const prepared=await prepareImageAsset(file,"Portrait");await this.assets.putCharacterPortrait(character.id,prepared.mimeType,prepared.bytes);await this.portraitUrl(character.id,true);this.renderList();if(this.selectedId===character.id)await this.renderDetail(character);}catch(cause){window.alert(cause instanceof Error?cause.message:String(cause));}finally{if(button?.isConnected){button.disabled=false;button.textContent="Portrait";}}
  }

  private async removePortrait(character:CharacterDto):Promise<void>{
    try{await this.assets.deleteCharacterPortrait(character.id);const previous=this.portraitUrls.get(character.id);if(previous)URL.revokeObjectURL(previous);this.portraitUrls.set(character.id,null);this.renderList();if(this.selectedId===character.id)await this.renderDetail(character);}catch(cause){window.alert(cause instanceof Error?cause.message:String(cause));}
  }

  private async duplicate(character:CharacterDto):Promise<void>{
    const input:UpsertCharacterInput={name:`${character.name} Copy`,alias:character.alias??undefined,classLabel:character.classLabel??undefined,level:character.level,baseStats:{...character.baseStats},biography:character.biography,tags:[...character.tags]};
    const copy=await this.gateway.create(input);this.selectedId=copy.id;await this.refresh();
  }

  private openCompare(character:CharacterDto):void{
    const others=this.records.filter(record=>record.id!==character.id);const host=this.query<HTMLElement>('[data-role="dialog-host"]');
    host.innerHTML=`<div class="overlay compare-overlay"><section class="compare-dialog" role="dialog" aria-modal="true"><header><div><span class="eyebrow">Compare mode</span><h2>${esc(character.name)} vs.</h2></div><button class="icon-btn" data-action="close" aria-label="Close">×</button></header><label class="compare-picker"><span>Second character</span><select data-role="compare-select"><option value="">Choose character…</option>${others.map(other=>`<option value="${esc(other.id)}">${esc(other.name)}</option>`).join("")}</select></label><div class="compare-body" data-role="compare-body"><div class="empty-state large"><strong>Choose another character</strong><span>Base and effective stats will be compared side by side.</span></div></div></section></div>`;
    host.querySelector<HTMLButtonElement>('[data-action="close"]')?.addEventListener("click",()=>{host.innerHTML="";});
    host.querySelector<HTMLSelectElement>('[data-role="compare-select"]')?.addEventListener("change",event=>{const id=(event.currentTarget as HTMLSelectElement).value;if(id)void this.renderCompare(character,id);});
  }

  private async renderCompare(left:CharacterDto,rightId:string):Promise<void>{
    const host=this.query<HTMLElement>('[data-role="dialog-host"]');const body=host.querySelector<HTMLElement>('[data-role="compare-body"]');if(!body)return;body.innerHTML=`<div class="loadout-loading"><span class="loading-spinner"></span><span>Comparing builds…</span></div>`;
    try{
      const right=this.records.find(record=>record.id===rightId)??await this.gateway.get(rightId);const [leftSheet,rightSheet]=await Promise.all([this.equipment.sheet(left.id),this.equipment.sheet(right.id)]);if(!body.isConnected)return;
      body.innerHTML=`<div class="compare-head"><div><strong>${esc(left.name)}</strong><small>Lv ${left.level} · ${esc(left.classLabel??"Unassigned")}</small></div><span>VS</span><div><strong>${esc(right.name)}</strong><small>Lv ${right.level} · ${esc(right.classLabel??"Unassigned")}</small></div></div><div class="compare-stat-list">${EFFECTIVE_META.map(([key,name,tone])=>this.compareRow(name,tone,leftSheet.effectiveStats[key],rightSheet.effectiveStats[key])).join("")}</div>`;
    }catch(cause){body.innerHTML=`<div class="loadout-error"><strong>Compare unavailable</strong><span>${esc(cause instanceof Error?cause.message:String(cause))}</span></div>`;}
  }
  private compareRow(name:string,tone:string,left:number,right:number):string{const leftLead=left>right?"winner":"";const rightLead=right>left?"winner":"";return `<div class="compare-stat-row stat-tone stat-${tone}"><strong class="${leftLead}">${left}</strong><span>${name}</span><strong class="${rightLead}">${right}</strong></div>`;}

  private openDelete(character:CharacterDto):void{
    if(!shouldConfirmDestructive()){void this.delete(character.id,this.query('[data-role="dialog-host"]'));return;}
    const host=this.query<HTMLElement>('[data-role="dialog-host"]');host.innerHTML=`<div class="overlay"><section class="confirm-dialog" role="alertdialog" aria-modal="true"><div class="eyebrow">Destructive action</div><h2>Delete ${esc(character.name)}?</h2><p>Cross-domain constraints may reject deletion when durable records still depend on this character.</p><div class="form-error" data-role="error" hidden></div><div class="confirm-actions"><button class="btn" data-action="cancel">Cancel</button><button class="btn danger" data-action="confirm">Delete character</button></div></section></div>`;host.querySelector<HTMLButtonElement>('[data-action="cancel"]')?.addEventListener("click",()=>{host.innerHTML="";});host.querySelector<HTMLButtonElement>('[data-action="confirm"]')?.addEventListener("click",()=>void this.delete(character.id,host));
  }
  private async delete(id:string,dialogHost:HTMLElement):Promise<void>{try{await this.gateway.remove(id);this.favorites.delete(id);this.persistFavorites();dialogHost.innerHTML="";this.selectedId=null;this.detailEpoch++;await this.refresh();this.renderEmpty();}catch(cause){const error=dialogHost.querySelector<HTMLElement>('[data-role="error"]');if(error){error.textContent=cause instanceof Error?cause.message:String(cause);error.hidden=false;}}}
  private async afterSave(character:CharacterDto):Promise<void>{this.selectedId=character.id;await this.refresh();}
  private renderEmpty():void{this.detailEpoch++;this.query<HTMLElement>('[data-role="detail"]').innerHTML=`<div class="empty-state large"><strong>Select a character</strong><span>Stats, equipment, skills and lore appear here.</span></div>`;}
  private query<T extends Element=HTMLElement>(selector:string):T{const element=this.host.querySelector<T>(selector);if(!element)throw new Error(`CharacterScreen missing element: ${selector}`);return element;}
}
