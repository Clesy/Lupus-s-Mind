import type {
  CharacterDto,
  CharacterGateway,
  CharacterStats,
  UpsertCharacterInput,
} from "../application/CharacterGateway";

const esc = (value: string): string =>
  value.replace(/[&<>"']/g, (char) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;",
  })[char]!);

const DEFAULT_STATS: CharacterStats = { str: 10, agi: 10, vit: 10, int: 10, mnd: 10 };

type SaveHandler = (character: CharacterDto) => void;

export class CharacterEditor {
  constructor(
    private readonly host: HTMLElement,
    private readonly gateway: CharacterGateway,
  ) {}

  openCreate(onSaved: SaveHandler): void {
    this.render(null, onSaved);
  }

  openEdit(character: CharacterDto, onSaved: SaveHandler): void {
    this.render(character, onSaved);
  }

  private render(character: CharacterDto | null, onSaved: SaveHandler): void {
    const stats = character?.baseStats ?? DEFAULT_STATS;
    this.host.innerHTML = `
      <div class="overlay" data-role="character-overlay">
        <section class="inspector character-editor" role="dialog" aria-modal="true" aria-label="${character ? "Edit character" : "Create character"}">
          <header class="inspector-header">
            <div>
              <div class="eyebrow">Canonical character</div>
              <h2>${character ? `Edit ${esc(character.name)}` : "New character"}</h2>
            </div>
            <button class="icon-btn" type="button" data-action="close" aria-label="Close">×</button>
          </header>
          <form class="inspector-body form-stack" data-role="form">
            <div class="form-grid two">
              <label class="field"><span>Name</span><input name="name" required maxlength="120" value="${esc(character?.name ?? "")}" /></label>
              <label class="field"><span>Alias</span><input name="alias" maxlength="120" value="${esc(character?.alias ?? "")}" /></label>
            </div>
            <div class="form-grid two">
              <label class="field"><span>Class label</span><input name="classLabel" maxlength="120" value="${esc(character?.classLabel ?? "")}" /></label>
              <label class="field"><span>Level</span><input name="level" type="number" min="1" max="9999" value="${character?.level ?? 1}" /></label>
            </div>

            <section class="character-editor-section">
              <div class="section-heading compact"><div><div class="eyebrow">Base values</div><h3>Stats</h3></div></div>
              <div class="character-stat-editor">
                ${(["str", "agi", "vit", "int", "mnd"] as const).map((key) => `
                  <label class="field character-stat-field">
                    <span>${key.toUpperCase()}</span>
                    <input name="${key}" type="number" min="0" max="1000000" value="${stats[key]}" />
                  </label>`).join("")}
              </div>
            </section>

            <label class="field"><span>Biography</span><textarea name="biography" rows="8">${esc(character?.biography ?? "")}</textarea></label>
            <label class="field"><span>Tags</span><input name="tags" value="${esc(character?.tags.join(", ") ?? "")}" placeholder="protagonist, northern, cursed" /><small>Comma-separated. Tags stay canonical; UI filters are derived.</small></label>
            <div class="form-error" data-role="error" hidden></div>
            <footer class="inspector-footer">
              <button class="btn" type="button" data-action="cancel">Cancel</button>
              <button class="btn primary" type="submit">${character ? "Save changes" : "Create character"}</button>
            </footer>
          </form>
        </section>
      </div>`;

    const close = (): void => { this.host.innerHTML = ""; };
    this.host.querySelectorAll<HTMLButtonElement>('[data-action="close"],[data-action="cancel"]').forEach((button) => {
      button.addEventListener("click", close);
    });
    this.host.querySelector<HTMLElement>('[data-role="character-overlay"]')?.addEventListener("mousedown", (event) => {
      if (event.target === event.currentTarget) close();
    });
    this.host.querySelector<HTMLFormElement>('[data-role="form"]')?.addEventListener("submit", (event) => {
      event.preventDefault();
      void this.save(character, onSaved);
    });
  }

  private async save(character: CharacterDto | null, onSaved: SaveHandler): Promise<void> {
    const form = this.host.querySelector<HTMLFormElement>('[data-role="form"]');
    const error = this.host.querySelector<HTMLElement>('[data-role="error"]');
    if (!form || !error) return;
    error.hidden = true;

    const data = new FormData(form);
    const number = (name: string, fallback = 0): number => {
      const parsed = Number(data.get(name));
      return Number.isFinite(parsed) ? parsed : fallback;
    };
    const input: UpsertCharacterInput = {
      name: String(data.get("name") ?? "").trim(),
      alias: String(data.get("alias") ?? "").trim() || undefined,
      classLabel: String(data.get("classLabel") ?? "").trim() || undefined,
      level: Math.max(1, Math.floor(number("level", 1))),
      baseStats: {
        str: Math.max(0, Math.floor(number("str"))),
        agi: Math.max(0, Math.floor(number("agi"))),
        vit: Math.max(0, Math.floor(number("vit"))),
        int: Math.max(0, Math.floor(number("int"))),
        mnd: Math.max(0, Math.floor(number("mnd"))),
      },
      biography: String(data.get("biography") ?? "").trim() || undefined,
      tags: String(data.get("tags") ?? "").split(",").map((tag) => tag.trim()).filter(Boolean),
    };

    if (!input.name) {
      error.textContent = "Name is required.";
      error.hidden = false;
      return;
    }

    try {
      const saved = character
        ? await this.gateway.update(character.id, input)
        : await this.gateway.create(input);
      this.host.innerHTML = "";
      onSaved(saved);
    } catch (cause) {
      error.textContent = cause instanceof Error ? cause.message : String(cause);
      error.hidden = false;
    }
  }
}
