import { invoke } from "@tauri-apps/api/core";
import type { CharacterDto, CharacterGateway, CharacterSummaryDto, UpsertCharacterInput } from "../application/CharacterGateway";
export const tauriCharacterGateway:CharacterGateway = {
  list:()=>invoke<CharacterSummaryDto[]>("characters_list"),
  get:(id)=>invoke<CharacterDto>("characters_get",{id}),
  create:(input)=>invoke<CharacterDto>("characters_create",{input}),
  update:(id,input)=>invoke<CharacterDto>("characters_update",{id,input}),
  remove:(id)=>invoke<void>("characters_delete",{id}),
};
