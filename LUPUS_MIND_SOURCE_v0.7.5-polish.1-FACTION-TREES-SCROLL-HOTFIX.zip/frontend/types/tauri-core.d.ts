export declare function invoke<T>(command: string, args?: Record<string, unknown>): Promise<T>;
