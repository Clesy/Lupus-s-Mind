import type { CharacterGateway } from "../modules/characters/application/CharacterGateway";
import type { ItemGateway, ItemDto } from "../modules/items/application/ItemGateway";
import type { EquipmentGateway } from "../modules/equipment/application/EquipmentGateway";
const fakeItems:ItemGateway={list:async()=>[],get:async()=>{throw new Error()},create:async i=>({id:"1",name:i.name,description:i.description??"",itemType:i.itemType,rarity:i.rarity,modifiers:i.modifiers,tags:i.tags,createdAt:"",updatedAt:""}),update:async()=>{throw new Error()},remove:async()=>{}};
const _contracts:[ItemGateway,CharacterGateway|undefined,EquipmentGateway|undefined]=[fakeItems,undefined,undefined];
const sample:ItemDto={id:"x",name:"Dragon Claw",description:"",itemType:"weapon",rarity:"legendary",modifiers:[{stat:"strength",value:10}],tags:[],createdAt:"",updatedAt:""};
if(sample.modifiers[0]?.stat!=="strength") throw new Error("contract mismatch");
void _contracts;
