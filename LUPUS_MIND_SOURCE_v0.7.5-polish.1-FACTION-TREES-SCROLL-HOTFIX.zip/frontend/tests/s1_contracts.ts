import type { SkillDto, SkillGateway, SkillPreviewDto, SkillSummaryDto, UpsertSkillInput } from "../modules/skills/application/SkillGateway";

class FakeSkillGateway implements SkillGateway {
  list(): Promise<SkillSummaryDto[]> { return Promise.resolve([]); }
  get(_id: string): Promise<SkillDto> { return Promise.reject(new Error("fake")); }
  create(_input: UpsertSkillInput): Promise<SkillDto> { return Promise.reject(new Error("fake")); }
  update(_id: string, _input: UpsertSkillInput): Promise<SkillDto> { return Promise.reject(new Error("fake")); }
  remove(_id: string): Promise<void> { return Promise.resolve(); }
  teach(_characterId: string, _skillId: string): Promise<void> { return Promise.resolve(); }
  forget(_characterId: string, _skillId: string): Promise<void> { return Promise.resolve(); }
  listForCharacter(_characterId: string): Promise<SkillDto[]> { return Promise.resolve([]); }
  preview(_characterId: string, _skillId: string): Promise<SkillPreviewDto> { return Promise.reject(new Error("fake")); }
}

const contract: SkillGateway = new FakeSkillGateway();
void contract;
