import type { CombatGateway,CombatImpactPreviewDto,CombatImpactPreviewInput,CombatSessionDto,StartCombatInput,UseSkillCommand } from "../modules/combat/application/CombatGateway";
class FakeCombatGateway implements CombatGateway {
  start(_input:StartCombatInput):Promise<CombatSessionDto>{throw new Error("fake");}
  get(_id:string):Promise<CombatSessionDto>{throw new Error("fake");}
  listRunning():Promise<CombatSessionDto[]>{return Promise.resolve([]);}
  listAll():Promise<CombatSessionDto[]>{return Promise.resolve([]);}
  delete(_id:string):Promise<void>{return Promise.resolve();}
  useSkill(_command:UseSkillCommand):Promise<CombatSessionDto>{throw new Error("fake");}
  previewImpact(_input:CombatImpactPreviewInput):Promise<CombatImpactPreviewDto>{throw new Error("fake");}
}
export const fakeCombatGateway:CombatGateway=new FakeCombatGateway();
