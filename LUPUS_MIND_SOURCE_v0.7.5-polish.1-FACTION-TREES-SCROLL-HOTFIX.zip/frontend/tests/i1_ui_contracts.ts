import type { CharacterGateway, CharacterSummaryDto } from "../modules/characters/application/CharacterGateway";
import type { CharacterSheetDto, EquippedItemDto } from "../modules/character-sheet/application/CharacterSheet";
import type { CompatibleItemDto, EquipmentGateway, EquipmentSlot } from "../modules/equipment/application/EquipmentGateway";
import type { ItemDto, ItemGateway, UpsertItemInput } from "../modules/items/application/ItemGateway";

const sampleItem: ItemDto = {
  id: "item-1",
  name: "Dragon Claw",
  description: "Reference fixture",
  itemType: "weapon",
  rarity: "legendary",
  modifiers: [{ stat: "strength", value: 10 }],
  tags: ["artifact"],
  createdAt: "2026-08-27T00:00:00Z",
  updatedAt: "2026-08-27T00:00:00Z",
};

class FakeItemGateway implements ItemGateway {
  private items = new Map<string, ItemDto>([[sampleItem.id, sampleItem]]);
  async list(): Promise<ItemDto[]> { return [...this.items.values()]; }
  async get(id: string): Promise<ItemDto> { const item = this.items.get(id); if (!item) throw new Error("missing item"); return item; }
  async create(input: UpsertItemInput): Promise<ItemDto> { const item = { ...sampleItem, ...input, id: "created" }; this.items.set(item.id, item); return item; }
  async update(id: string, input: UpsertItemInput): Promise<ItemDto> { const current = await this.get(id); const item = { ...current, ...input }; this.items.set(id, item); return item; }
  async remove(id: string): Promise<void> { this.items.delete(id); }
}

const sampleSheet: CharacterSheetDto = {
  characterId: "character-1",
  name: "Talion",
  baseStats: { str: 10, agi: 10, vit: 10, int: 10, mnd: 10 },
  effectiveStats: {
    strength: 20,
    agility: 10,
    vitality: 10,
    intelligence: 10,
    mind: 10,
    weaponDamage: 120,
    armor: 0,
    armorPenetration: 0,
    magicPenetration: 0,
    criticalChance: 0,
    damageReduction: 0,
  },
  equipment: [{ slot: "main_hand", item: sampleItem }],
};

class FakeEquipmentGateway implements EquipmentGateway {
  async list(_characterId: string): Promise<EquippedItemDto[]> { return sampleSheet.equipment; }
  async compatibleItems(_characterId: string, slot: EquipmentSlot): Promise<CompatibleItemDto[]> {
    return slot === "main_hand" ? [{ item: sampleItem, available: true, equippedByCharacterId: null, equippedSlot: null, equippedHere: false }] : [];
  }
  async equip(_input: { characterId: string; itemId: string; slot: EquipmentSlot }): Promise<CharacterSheetDto> { return sampleSheet; }
  async unequip(_characterId: string, _slot: EquipmentSlot): Promise<CharacterSheetDto> { return { ...sampleSheet, equipment: [] }; }
  async sheet(_characterId: string): Promise<CharacterSheetDto> { return sampleSheet; }
}

class FakeCharacterGateway implements CharacterGateway {
  async list(): Promise<CharacterSummaryDto[]> { return [{ id: "character-1", name: "Talion", alias: null, level: 1, classLabel: null }]; }
  async get(): ReturnType<CharacterGateway["get"]> { throw new Error("not needed in I1 UI fixture"); }
  async create(): ReturnType<CharacterGateway["create"]> { throw new Error("not needed in I1 UI fixture"); }
  async update(): ReturnType<CharacterGateway["update"]> { throw new Error("not needed in I1 UI fixture"); }
  async remove(): Promise<void> { throw new Error("not needed in I1 UI fixture"); }
}

export const i1FakeGateways = {
  items: new FakeItemGateway(),
  equipment: new FakeEquipmentGateway(),
  characters: new FakeCharacterGateway(),
};
