import type { TimelineBoundsDto,TimelineEventDto,TimelineEntryDto,TimelineGateway,TimelineProjectionDto,UpsertTimelineEventInput } from "../modules/timeline/application/TimelineGateway";
export class FakeTimelineGateway implements TimelineGateway {
 private events:TimelineEventDto[]=[];
 async create(input:UpsertTimelineEventInput):Promise<TimelineEventDto>{const now=new Date(0).toISOString();const event:TimelineEventDto={id:`event-${this.events.length+1}`,title:input.title,description:input.description??"",kind:input.kind,importance:input.importance,temporalKind:input.temporalKind,startChapter:input.startChapter,endChapter:input.endChapter??null,worldTimeStart:input.worldTimeStart??null,worldTimeEnd:input.worldTimeEnd??null,locationLabel:input.locationLabel??null,tags:input.tags,participants:input.participants,sources:input.sources,createdAt:now,updatedAt:now};this.events.push(event);return event;}
 async update(id:string,input:UpsertTimelineEventInput):Promise<TimelineEventDto>{this.events=this.events.filter((e)=>e.id!==id);const created=await this.create(input);const event={...created,id};this.events=this.events.map((e)=>e.id===created.id?event:e);return event;}
 async get(id:string):Promise<TimelineEventDto>{const event=this.events.find((e)=>e.id===id);if(!event)throw new Error('not found');return event;}
 async remove(id:string):Promise<void>{this.events=this.events.filter((e)=>e.id!==id);}
 async at(chapter:number):Promise<TimelineEventDto[]>{return this.events.filter((e)=>e.temporalKind==='point'?e.startChapter===chapter:e.startChapter<=chapter&&chapter<(e.endChapter??e.startChapter));}
 async between(start:number,end:number):Promise<TimelineEventDto[]>{return this.events.filter((e)=>e.temporalKind==='point'?(start<=e.startChapter&&e.startChapter<end):(e.startChapter<end&&(e.endChapter??e.startChapter)>start));}
 async forCharacter(characterId:string):Promise<TimelineEventDto[]>{return this.events.filter((e)=>e.participants.some((p)=>p.characterId===characterId));}
 async projectionBetween(start:number,end:number):Promise<TimelineProjectionDto>{return{startChapter:start,endChapter:end,entries:[]};}
 async characterThread(_characterId:string):Promise<TimelineEntryDto[]>{return[];}
 async bounds():Promise<TimelineBoundsDto|null>{if(!this.events.length)return null;return{startChapter:Math.min(...this.events.map(e=>e.startChapter)),endChapter:Math.max(...this.events.map(e=>e.temporalKind==='span'?(e.endChapter??e.startChapter+1):e.startChapter+1))};}
}
