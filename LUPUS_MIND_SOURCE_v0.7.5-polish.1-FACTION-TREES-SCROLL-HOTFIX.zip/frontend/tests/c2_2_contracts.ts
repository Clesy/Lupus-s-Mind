import type { StatusEffectDefinitionDto,StatusEffectGateway } from "../modules/status_effects/application/StatusEffectGateway";
import type { CombatAction,CombatantRuntimeState } from "../modules/combat/application/CombatGateway";
class FakeStatusEffectGateway implements StatusEffectGateway{
  list():Promise<StatusEffectDefinitionDto[]>{return Promise.resolve([]);}
  forSkill(_skillId:string):Promise<StatusEffectDefinitionDto[]>{return Promise.resolve([]);}
  setForSkill(_skillId:string,_effectIds:string[]):Promise<void>{return Promise.resolve();}
}
export const fakeStatusEffectGateway:StatusEffectGateway=new FakeStatusEffectGateway();
const runtime:CombatantRuntimeState={currentHp:100,currentMana:50,isDefeated:false,cooldowns:[],activeEffects:[]};
const actions:CombatAction[]=[];
void runtime;void actions;
