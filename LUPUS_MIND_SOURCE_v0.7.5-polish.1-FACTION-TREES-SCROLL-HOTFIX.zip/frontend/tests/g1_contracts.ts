import type {GeneratedCandidate,GenerationRequest,GeneratorGateway} from "../modules/creative_generators/application/GeneratorGateway";
class FakeGeneratorGateway implements GeneratorGateway{generate(_input:GenerationRequest):Promise<GeneratedCandidate[]>{return Promise.resolve([]);}}
export const fakeGeneratorGateway:GeneratorGateway=new FakeGeneratorGateway();
