import type {CombatReplayGateway,ReplayFrame,ReplayVerification,TurnExecutionSummary} from "../modules/combat_replay/application/CombatReplayGateway";
class FakeCombatReplayGateway implements CombatReplayGateway{
  start(_sessionId:string):Promise<ReplayFrame>{return Promise.reject(new Error("fixture"));}
  atSequence(_sessionId:string,_sequence:number):Promise<ReplayFrame>{return Promise.reject(new Error("fixture"));}
  atExecution(_sessionId:string,_executionId:string):Promise<ReplayFrame>{return Promise.reject(new Error("fixture"));}
  latest(_sessionId:string):Promise<ReplayFrame>{return Promise.reject(new Error("fixture"));}
  turns(_sessionId:string):Promise<TurnExecutionSummary[]>{return Promise.resolve([]);}
  verifyLatest(_sessionId:string):Promise<ReplayVerification>{return Promise.resolve({matchesLive:true,replayFingerprint:"x",liveFingerprint:"x",latestSequence:0});}
}
export const fakeCombatReplayGateway:CombatReplayGateway=new FakeCombatReplayGateway();
