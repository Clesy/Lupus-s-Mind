import type { AppSettings } from "../modules/workspace/application/WorkspaceGateway";

const defaults: AppSettings = {
  compactNavigation: false,
  reduceMotion: false,
  confirmDestructiveActions: true,
  restoreLastRoute: true,
  defaultGeneratorCount: 8,
};

let current: AppSettings = { ...defaults };

export const setStudioPreferences = (settings: AppSettings): void => { current = { ...settings }; };
export const getStudioPreferences = (): AppSettings => ({ ...current });
export const shouldConfirmDestructive = (): boolean => current.confirmDestructiveActions;
