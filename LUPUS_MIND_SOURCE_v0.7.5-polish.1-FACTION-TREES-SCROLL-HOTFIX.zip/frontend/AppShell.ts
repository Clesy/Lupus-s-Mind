import type { CharacterGateway } from "./modules/characters/application/CharacterGateway";
import { CharacterScreen } from "./modules/characters/ui/CharacterScreen";
import { DashboardScreen, type DashboardRoute } from "./modules/dashboard/ui/DashboardScreen";
import type { EquipmentGateway } from "./modules/equipment/application/EquipmentGateway";
import { EquipmentScreen } from "./modules/equipment/ui/EquipmentScreen";
import type { ItemGateway } from "./modules/items/application/ItemGateway";
import { ItemScreen } from "./modules/items/ui/ItemScreen";
import type { SkillGateway } from "./modules/skills/application/SkillGateway";
import { SkillScreen } from "./modules/skills/ui/SkillScreen";
import type { RelationshipGateway } from "./modules/relationships/application/RelationshipGateway";
import { RelationshipScreen } from "./modules/relationships/ui/RelationshipScreen";
import type { TimelineGateway } from "./modules/timeline/application/TimelineGateway";
import { TimelineScreen } from "./modules/timeline/ui/TimelineScreen";
import type { CombatGateway } from "./modules/combat/application/CombatGateway";
import type { CombatReplayGateway } from "./modules/combat_replay/application/CombatReplayGateway";
import { CombatScreen } from "./modules/combat/ui/CombatScreen";
import type { StatusEffectGateway } from "./modules/status_effects/application/StatusEffectGateway";
import type { GeneratorGateway } from "./modules/creative_generators/application/GeneratorGateway";
import { GeneratorScreen } from "./modules/creative_generators/ui/GeneratorScreen";
import type { AppSettings, WorkspaceGateway } from "./modules/workspace/application/WorkspaceGateway";
import { WorkspaceScreen } from "./modules/workspace/ui/WorkspaceScreen";
import type { ProjectGateway, ProjectSummary } from "./modules/projects/application/ProjectGateway";
import type { SearchGateway, SearchHit } from "./modules/global_search/application/SearchGateway";
import type { ManuscriptGateway } from "./modules/manuscript/application/ManuscriptGateway";
import type { AssetGateway } from "./modules/assets/application/AssetGateway";
import { ManuscriptScreen } from "./modules/manuscript/ui/ManuscriptScreen";
import type { LoreGateway } from "./modules/lore/application/LoreGateway";
import { LoreScreen } from "./modules/lore/ui/LoreScreen";
import type { KnowledgeLinkGateway } from "./modules/knowledge_links/application/KnowledgeLinkGateway";
import type { AuthoringGateway } from "./modules/authoring/application/AuthoringGateway";
import type { FactionGateway } from "./modules/factions/application/FactionGateway";
import { FactionScreen } from "./modules/factions/ui/FactionScreen";
import type { InventoryGateway } from "./modules/inventory/application/InventoryGateway";
import { InventoryScreen } from "./modules/inventory/ui/InventoryScreen";
import type { QuestGateway } from "./modules/quests/application/QuestGateway";
import { QuestScreen } from "./modules/quests/ui/QuestScreen";
import type { SecretGateway } from "./modules/secrets/application/SecretGateway";
import { SecretScreen } from "./modules/secrets/ui/SecretScreen";
import type { AtlasGateway } from "./modules/atlas/application/AtlasGateway";
import { AtlasScreen } from "./modules/atlas/ui/AtlasScreen";
import { setStudioPreferences } from "./shared/preferences";

type Route = "dashboard" | "manuscript" | "lore" | "atlas" | "characters" | "items" | "equipment" | "inventory" | "factions" | "quests" | "secrets" | "skills" | "relationships" | "timeline" | "combat" | "generators" | "workspace";
type RouteGroup = "Studio" | "Writing" | "World" | "Systems" | "Simulation" | "Creative";
type RouteMeta = { label:string; eyebrow:string; icon:string; group:RouteGroup };
type PendingIntent = { kind:"create"; route:Route } | { kind:"select"; route:Route; id:string };
type Overlay = "shortcuts" | "search" | "projects" | "quick-create" | null;

const ROUTES:Record<Route,RouteMeta>={
  dashboard:{label:"Overview",eyebrow:"Studio",icon:"◫",group:"Studio"},
  workspace:{label:"Workspace",eyebrow:"Desktop health",icon:"⚙",group:"Studio"},
  manuscript:{label:"Manuscript",eyebrow:"Chapters & notes",icon:"✎",group:"Writing"},
  lore:{label:"Lore Bible",eyebrow:"Wiki & backlinks",icon:"◈",group:"World"},
  atlas:{label:"Atlas",eyebrow:"Maps & locations",icon:"⌖",group:"World"},
  characters:{label:"Characters",eyebrow:"Canonical world",icon:"◇",group:"World"},
  items:{label:"Items",eyebrow:"Canonical world",icon:"◆",group:"World"},
  equipment:{label:"Equipment",eyebrow:"Cross-domain state",icon:"▦",group:"World"},
  inventory:{label:"Inventory",eyebrow:"Ownership through time",icon:"▤",group:"World"},
  factions:{label:"Factions",eyebrow:"Clans & diplomacy",icon:"⬡",group:"World"},
  quests:{label:"Quests",eyebrow:"Narrative objectives",icon:"☷",group:"World"},
  secrets:{label:"Secrets",eyebrow:"Knowledge flow",icon:"◈",group:"World"},
  skills:{label:"Skills",eyebrow:"Canonical systems",icon:"⌁",group:"Systems"},
  relationships:{label:"Relationships",eyebrow:"Temporal graph",icon:"⌘",group:"Systems"},
  timeline:{label:"Timeline",eyebrow:"Narrative chronology",icon:"◴",group:"Systems"},
  combat:{label:"Combat",eyebrow:"Manual damage sandbox",icon:"⚔",group:"Simulation"},
  generators:{label:"Generators",eyebrow:"Non-canonical tools",icon:"✦",group:"Creative"},
};
const GROUPS:RouteGroup[]=["Studio","Writing","World","Systems","Simulation","Creative"];
const LAST_ROUTE_KEY="lupus_mind_last_route";
const DEFAULT_SETTINGS:AppSettings={compactNavigation:false,reduceMotion:false,confirmDestructiveActions:true,restoreLastRoute:true,defaultGeneratorCount:8};
const esc=(value:string):string=>value.replace(/[&<>"']/g,(char)=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[char]!);

export class AppShell {
  private route:Route="dashboard";
  private renderEpoch=0;
  private settings:AppSettings={...DEFAULT_SETTINGS};
  private overlay:Overlay=null;
  private currentProject:ProjectSummary|null=null;
  private projectList:ProjectSummary[]=[];
  private pendingIntent:PendingIntent|null=null;
  private searchEpoch=0;
  private activeManuscriptScreen:ManuscriptScreen|null=null;
  private activeLoreScreen:LoreScreen|null=null;

  constructor(
    private readonly root:HTMLElement,
    private readonly items:ItemGateway,
    private readonly characters:CharacterGateway,
    private readonly equipment:EquipmentGateway,
    private readonly skills:SkillGateway,
    private readonly statusEffects:StatusEffectGateway,
    private readonly relationships:RelationshipGateway,
    private readonly timeline:TimelineGateway,
    private readonly combat:CombatGateway,
    private readonly combatReplay:CombatReplayGateway,
    private readonly generators:GeneratorGateway,
    private readonly workspace:WorkspaceGateway,
    private readonly projects:ProjectGateway,
    private readonly search:SearchGateway,
    private readonly manuscript:ManuscriptGateway,
    private readonly assets:AssetGateway,
    private readonly lore:LoreGateway,
    private readonly links:KnowledgeLinkGateway,
    private readonly authoring:AuthoringGateway,
    private readonly factions:FactionGateway,
    private readonly inventory:InventoryGateway,
    private readonly quests:QuestGateway,
    private readonly secrets:SecretGateway,
    private readonly atlas:AtlasGateway,
  ){}

  async render():Promise<void>{
    await Promise.all([this.loadPreferences(),this.loadProjects()]);
    this.root.innerHTML=`
      <div class="app-shell">
        <aside class="app-sidebar">
          <button class="brand-block" data-route="dashboard" aria-label="Open overview"><span class="brand-mark">LM</span><span class="brand-copy"><strong>LUPUS'S MIND</strong><small>World Authoring Studio</small></span></button>
          <nav class="app-nav" aria-label="Primary navigation">${GROUPS.map(group=>`<section class="nav-group"><div class="nav-group-label">${group}</div>${Object.entries(ROUTES).filter(([,meta])=>meta.group===group).map(([route,meta])=>`<button class="nav-item" data-route="${route}"><span aria-hidden="true">${meta.icon}</span><strong>${meta.label}</strong></button>`).join("")}</section>`).join("")}</nav>
          <div class="sidebar-foot"><span class="runtime-dot"></span><span>Local project database</span><button class="keyboard-help" data-action="shortcuts">?</button></div>
        </aside>
        <section class="app-stage">
          <header class="app-topbar">
            <div class="topbar-breadcrumb"><span data-role="route-group"></span><b>›</b><strong data-role="route-title"></strong></div>
            <button class="project-switcher" data-action="projects" aria-label="Switch project"><span class="project-dot"></span><strong data-role="project-name">Project</strong></button>
            <div class="topbar-actions">
              <button class="topbar-search" data-action="search"><span>⌕</span><span>Search everything…</span><kbd>Ctrl K</kbd></button>
              <button class="topbar-create" data-action="quick-create" title="Quick create">+</button>
              <button class="topbar-settings" data-route="workspace" title="Workspace settings">⚙</button>
            </div>
          </header>
          <main class="app-content" data-role="content"></main>
        </section>
        <div data-role="overlay-host"></div>
      </div>`;
    this.root.querySelectorAll<HTMLButtonElement>("[data-route]").forEach(button=>button.addEventListener("click",()=>this.navigate(button.dataset.route as Route)));
    this.root.querySelector<HTMLButtonElement>('[data-action="shortcuts"]')?.addEventListener("click",()=>this.openShortcuts());
    this.root.querySelector<HTMLButtonElement>('[data-action="projects"]')?.addEventListener("click",()=>this.openProjects());
    this.root.querySelector<HTMLButtonElement>('[data-action="search"]')?.addEventListener("click",()=>this.openSearch());
    this.root.querySelector<HTMLButtonElement>('[data-action="quick-create"]')?.addEventListener("click",()=>this.openQuickCreate());
    window.addEventListener("keydown",this.onKeyDown);
    this.applySettings();this.updateShellState();await this.renderRoute();
  }

  private async loadPreferences():Promise<void>{try{this.settings=await this.workspace.settings();}catch{this.settings={...DEFAULT_SETTINGS};}setStudioPreferences(this.settings);this.route=this.settings.restoreLastRoute?this.restoreRoute():"dashboard";}
  private async loadProjects():Promise<void>{try{this.projectList=await this.projects.list();this.currentProject=this.projectList.find(project=>project.isCurrent)??await this.projects.current();}catch{this.projectList=[];this.currentProject=null;}}

  private readonly onKeyDown=(event:KeyboardEvent):void=>{
    const target=event.target as HTMLElement|null;const editing=!!target&&["INPUT","TEXTAREA","SELECT"].includes(target.tagName);
    if(event.key==="Escape"&&this.overlay){event.preventDefault();this.closeOverlay();return;}
    if((event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==="k"){event.preventDefault();this.openSearch();return;}
    if((event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==="n"){event.preventDefault();this.openQuickCreate();return;}
    if(!editing&&event.key==="?"){event.preventDefault();this.openShortcuts();return;}
    if((event.ctrlKey||event.metaKey)&&event.key===","){event.preventDefault();this.navigate("workspace");return;}
    if(!event.altKey||event.ctrlKey||event.metaKey)return;
    const shortcuts:Record<string,Route>={"1":"dashboard","2":"manuscript","3":"characters","4":"items","5":"equipment","6":"skills","7":"relationships","8":"timeline","9":"combat","0":"generators"};
    const route=shortcuts[event.key];if(!route)return;event.preventDefault();this.navigate(route);
  };

  private navigate(route:Route|DashboardRoute,intent?:PendingIntent):void{
    if(!(route in ROUTES))return;this.route=route as Route;this.pendingIntent=intent??null;
    if(this.settings.restoreLastRoute){try{window.localStorage.setItem(LAST_ROUTE_KEY,this.route);}catch{}}
    this.closeOverlay();this.updateShellState();void this.renderRoute();
  }

  private updateShellState():void{
    const meta=ROUTES[this.route];this.root.querySelectorAll<HTMLElement>("[data-route]").forEach(node=>node.classList.toggle("active",node.dataset.route===this.route));
    const title=this.root.querySelector<HTMLElement>('[data-role="route-title"]');const group=this.root.querySelector<HTMLElement>('[data-role="route-group"]');const project=this.root.querySelector<HTMLElement>('[data-role="project-name"]');
    if(title)title.textContent=meta.label;if(group)group.textContent=meta.group;if(project)project.textContent=this.currentProject?.name??"My World";
  }
  private applySettings():void{setStudioPreferences(this.settings);this.root.querySelector<HTMLElement>(".app-shell")?.classList.toggle("compact-nav",this.settings.compactNavigation);document.documentElement.classList.toggle("reduce-motion",this.settings.reduceMotion);}

  private async renderRoute():Promise<void>{
    const content=this.root.querySelector<HTMLElement>('[data-role="content"]');if(!content)throw new Error("AppShell content missing");const epoch=++this.renderEpoch;
    content.innerHTML=`<div class="route-state"><span class="loading-spinner"></span><strong>Opening ${ROUTES[this.route].label}…</strong><span>Reading ${esc(this.currentProject?.name??"the active project")}.</span></div>`;
    const host=document.createElement("div");host.className="route-host";
    try{await this.renderInto(host,this.route);if(epoch!==this.renderEpoch)return;content.replaceChildren(host);}catch(cause){if(epoch!==this.renderEpoch)return;const message=cause instanceof Error?cause.message:String(cause);content.innerHTML=`<div class="route-error"><div class="eyebrow">Module unavailable</div><h2>${ROUTES[this.route].label} could not open</h2><p data-role="route-error-message"></p><div class="action-row"><button class="btn primary" data-action="retry-route">Retry</button><button class="btn" data-route="workspace">Workspace health</button></div></div>`;const messageNode=content.querySelector<HTMLElement>('[data-role="route-error-message"]');if(messageNode)messageNode.textContent=message;content.querySelector<HTMLButtonElement>('[data-action="retry-route"]')?.addEventListener("click",()=>void this.renderRoute());content.querySelector<HTMLButtonElement>('[data-route="workspace"]')?.addEventListener("click",()=>this.navigate("workspace"));}
  }

  private async renderInto(host:HTMLElement,route:Route):Promise<void>{
    const intent=this.pendingIntent?.route===route?this.pendingIntent:null;this.pendingIntent=null;
    switch(route){
      case "dashboard":await new DashboardScreen(host,this.characters,this.items,this.skills,this.manuscript,next=>this.navigate(next)).render();return;
      case "manuscript":{const screen=new ManuscriptScreen(host,this.manuscript,this.links,this.authoring,this.characters,(next,id)=>this.navigateEntity(next,id));this.activeManuscriptScreen=screen;await screen.render();if(intent?.kind==="create")await screen.createNewChapter();else if(intent?.kind==="select")await screen.openById(intent.id);return;}
      case "lore":{const screen=new LoreScreen(host,this.lore,this.links,(next,id)=>this.navigateEntity(next,id));this.activeLoreScreen=screen;await screen.render();if(intent?.kind==="create")await screen.createNew();else if(intent?.kind==="select")await screen.openById(intent.id);return;}
      case "atlas":{const screen=new AtlasScreen(host,this.atlas);await screen.render();if(intent?.kind==="create")screen.openCreate();else if(intent?.kind==="select")await screen.openById(intent.id);return;}
      case "characters":{const screen=new CharacterScreen(host,this.characters,this.equipment,this.skills,this.assets,this.authoring,this.links,this.factions,this.inventory,(next,id)=>this.navigateEntity(next,id));await screen.render();if(intent?.kind==="create")screen.openCreate();else if(intent?.kind==="select")await screen.openById(intent.id);return;}
      case "items":{const screen=new ItemScreen(host,this.items,this.assets,this.inventory);await screen.render();if(intent?.kind==="create")screen.openCreate();else if(intent?.kind==="select")await screen.openById(intent.id);return;}
      case "equipment":await new EquipmentScreen(host,this.characters,this.equipment).render();return;
      case "inventory":await new InventoryScreen(host,this.inventory,this.items,this.characters,this.factions,this.assets).render();return;
      case "factions":{const screen=new FactionScreen(host,this.factions,this.characters);await screen.render();if(intent?.kind==="create")screen.openCreate();else if(intent?.kind==="select")await screen.openById(intent.id);return;}
      case "quests":{const screen=new QuestScreen(host,this.quests,this.characters,this.factions);await screen.render();if(intent?.kind==="create")screen.openCreate();else if(intent?.kind==="select")await screen.openById(intent.id);return;}
      case "secrets":{const screen=new SecretScreen(host,this.secrets,this.characters);await screen.render();if(intent?.kind==="create")screen.openCreate();else if(intent?.kind==="select")await screen.openById(intent.id);return;}
      case "skills":{const screen=new SkillScreen(host,this.skills,this.characters,this.statusEffects);await screen.render();if(intent?.kind==="create")screen.createNew();else if(intent?.kind==="select")await screen.openById(intent.id);return;}
      case "relationships":await new RelationshipScreen(host,this.relationships,this.characters).render();return;
      case "timeline":{const screen=new TimelineScreen(host,this.timeline,this.characters);await screen.render();if(intent?.kind==="select")await screen.openById(intent.id);return;}
      case "combat":await new CombatScreen(host,this.combat,this.characters,this.combatReplay,this.skills,()=>this.navigate("skills")).render();return;
      case "generators":await new GeneratorScreen(host,this.generators,this.settings.defaultGeneratorCount).render();return;
      case "workspace":await new WorkspaceScreen(host,this.workspace,settings=>{this.settings=settings;this.applySettings();}).render();return;
    }
  }

  private navigateEntity(route:string,id?:string):void{
    if(!(route in ROUTES))return;const typed=route as Route;if(id)this.navigate(typed,{kind:"select",route:typed,id});else this.navigate(typed);
  }

  private openSearch():void{
    this.overlay="search";const host=this.overlayHost();host.innerHTML=`<div class="command-overlay" data-action="overlay-backdrop"><section class="command-palette" role="dialog" aria-modal="true"><div class="command-search"><span>⌕</span><input data-role="global-query" placeholder="Search characters, locations, maps, items, factions, quests, secrets, chapters, lore…" autocomplete="off" /><kbd>Esc</kbd></div><div class="command-results" data-role="search-results"></div><footer><span>Enter or click to open</span><span>Current project: ${esc(this.currentProject?.name??"My World")}</span></footer></section></div>`;
    host.querySelector<HTMLElement>('[data-action="overlay-backdrop"]')?.addEventListener("mousedown",event=>{if(event.target===event.currentTarget)this.closeOverlay();});
    const input=host.querySelector<HTMLInputElement>('[data-role="global-query"]');input?.addEventListener("input",()=>void this.paintSearch(input.value));requestAnimationFrame(()=>input?.focus());void this.paintSearch("");
  }

  private async paintSearch(query:string):Promise<void>{
    const results=this.overlayHost().querySelector<HTMLElement>('[data-role="search-results"]');
    if(!results)return;
    const epoch=++this.searchEpoch;
    const trimmed=query.trim();
    const nav=Object.entries(ROUTES)
      .filter(([route])=>route!=="workspace")
      .filter(([,meta])=>!trimmed||`${meta.label} ${meta.group}`.toLowerCase().includes(trimmed.toLowerCase()))
      .slice(0,trimmed?4:7);
    const navMarkup=nav.length
      ? `<div class="command-section-label">Navigate</div>${nav.map(([route,meta])=>`<button class="command-result" data-command-route="${route}"><span class="command-icon">${meta.icon}</span><span><strong>${meta.label}</strong><small>${meta.group} · ${meta.eyebrow}</small></span><em>Open</em></button>`).join("")}`
      : "";
    const dataMarkup=trimmed
      ? `<div class="command-section-label">Search results</div><div class="search-loading"><span class="loading-spinner"></span> Searching current project…</div>`
      : `<div class="command-hint">Type to search the entire active project. Ctrl+N opens Quick Create.</div>`;
    results.innerHTML=navMarkup+dataMarkup;
    results.querySelectorAll<HTMLButtonElement>("[data-command-route]").forEach(button=>button.addEventListener("click",()=>this.navigate(button.dataset.commandRoute as Route)));
    if(!trimmed)return;
    try{
      const hits=await this.search.search(trimmed,24);
      if(epoch!==this.searchEpoch||this.overlay!=="search")return;
      results.querySelector<HTMLElement>(".search-loading")?.remove();
      if(!hits.length){results.insertAdjacentHTML("beforeend",`<div class="command-hint">No project data matched &quot;${esc(trimmed)}&quot;.</div>`);return;}
      results.insertAdjacentHTML("beforeend",hits.map(hit=>this.searchHitMarkup(hit)).join(""));
      results.querySelectorAll<HTMLButtonElement>("[data-search-route]").forEach(button=>button.addEventListener("click",()=>{
        const route=button.dataset.searchRoute as Route;
        if(!(route in ROUTES))return;
        const id=button.dataset.searchId!;
        this.navigate(route,{kind:"select",route,id});
      }));
    }catch(cause){
      if(epoch!==this.searchEpoch)return;
      const loading=results.querySelector<HTMLElement>(".search-loading");
      if(loading)loading.outerHTML=`<div class="command-hint error">${esc(cause instanceof Error?cause.message:String(cause))}</div>`;
    }
  }

  private searchHitMarkup(hit:SearchHit):string{
    return `<button class="command-result" data-search-route="${esc(hit.route)}" data-search-id="${esc(hit.id)}"><span class="command-kind">${esc(hit.kind.slice(0,2).toUpperCase())}</span><span><strong>${esc(hit.title)}</strong><small>${esc(hit.subtitle||hit.kind)}</small></span><em>${esc(hit.kind)}</em></button>`;
  }

  private openQuickCreate():void{
    this.overlay="quick-create";
    const host=this.overlayHost();
    const options:Array<[Route,string,string]>=[["characters","Character","◇"],["atlas","Location","⌖"],["items","Item","◆"],["factions","Faction","⬡"],["quests","Quest","☷"],["secrets","Secret","◈"],["skills","Skill","⌁"],["manuscript","Chapter","✎"],["lore","Lore Page","◈"]];
    const optionMarkup=options.map(([route,label,icon])=>`<button data-create-route="${route}"><span>${icon}</span><strong>${label}</strong><small>Create inside this project</small></button>`).join("");
    host.innerHTML=`<div class="command-overlay" data-action="overlay-backdrop"><section class="quick-create-sheet" role="dialog" aria-modal="true"><header><div><span class="eyebrow">Current project</span><h2>Quick Create</h2><p>${esc(this.currentProject?.name??"My World")}</p></div><kbd>Ctrl N</kbd></header><div class="quick-create-grid">${optionMarkup}</div></section></div>`;
    host.querySelector<HTMLElement>('[data-action="overlay-backdrop"]')?.addEventListener("mousedown",event=>{if(event.target===event.currentTarget)this.closeOverlay();});
    host.querySelectorAll<HTMLButtonElement>("[data-create-route]").forEach(button=>button.addEventListener("click",()=>{const route=button.dataset.createRoute as Route;this.navigate(route,{kind:"create",route});}));
  }

  private openProjects():void{
    this.overlay="projects";
    const host=this.overlayHost();
    const rows=this.projectList.map(project=>{
      const lastOpened=project.isCurrent?"Current project":`Last opened ${esc(new Date(project.lastOpenedAt).toLocaleDateString())}`;
      const action=project.isCurrent?"Current":"Switch";
      return `<button class="project-row ${project.isCurrent?"active":""}" data-project-id="${esc(project.id)}"><span class="project-avatar">${esc(project.name.slice(0,1).toUpperCase())}</span><span><strong>${esc(project.name)}</strong><small>${lastOpened}</small></span><em>${action}</em></button>`;
    }).join("");
    host.innerHTML=`<div class="command-overlay" data-action="overlay-backdrop"><section class="project-sheet" role="dialog" aria-modal="true"><header><div><span class="eyebrow">Workspace isolation</span><h2>Projects</h2><p>Each project owns a separate SQLite database.</p></div><button class="btn ghost" data-action="close">Close</button></header><div class="project-list">${rows}</div><form class="new-project-form" data-role="new-project"><label><span>New project</span><input name="name" maxlength="80" placeholder="Ashen Crown" required /></label><button class="btn primary" type="submit">Create & switch</button><div class="form-error" data-role="project-error" hidden></div></form></section></div>`;
    host.querySelector<HTMLElement>('[data-action="overlay-backdrop"]')?.addEventListener("mousedown",event=>{if(event.target===event.currentTarget)this.closeOverlay();});
    host.querySelector<HTMLButtonElement>('[data-action="close"]')?.addEventListener("click",()=>this.closeOverlay());
    host.querySelectorAll<HTMLButtonElement>("[data-project-id]").forEach(button=>button.addEventListener("click",()=>void this.switchProject(button.dataset.projectId!)));
    host.querySelector<HTMLFormElement>('[data-role="new-project"]')?.addEventListener("submit",event=>{event.preventDefault();void this.createProject(event.currentTarget as HTMLFormElement);});
  }

  private async switchProject(id:string):Promise<void>{
    if(this.currentProject?.id===id){this.closeOverlay();return;}
    const host=this.overlayHost();host.classList.add("busy");
    try{
      const manuscript=this.activeManuscriptScreen;const lore=this.activeLoreScreen;
      if(manuscript)await manuscript.flushPendingSave();if(lore)await lore.flushPendingSave();
      this.currentProject=await this.projects.switchProject(id);
      manuscript?.dispose();lore?.dispose();this.activeManuscriptScreen=null;this.activeLoreScreen=null;
      await this.loadProjects();
      await this.loadPreferences();
      this.route="dashboard";this.pendingIntent=null;this.applySettings();this.closeOverlay();this.updateShellState();await this.renderRoute();
    }catch(cause){
      host.classList.remove("busy");
      const error=host.querySelector<HTMLElement>('[data-role="project-error"]');
      if(error){error.textContent=cause instanceof Error?cause.message:String(cause);error.hidden=false;}
    }
  }

  private async createProject(form:HTMLFormElement):Promise<void>{
    const data=new FormData(form);const name=String(data.get("name")??"").trim();if(!name)return;
    const error=form.querySelector<HTMLElement>('[data-role="project-error"]');if(error)error.hidden=true;
    try{const created=await this.projects.create({name});await this.loadProjects();await this.switchProject(created.id);}catch(cause){if(error){error.textContent=cause instanceof Error?cause.message:String(cause);error.hidden=false;}}
  }

  private openShortcuts():void{
    this.overlay="shortcuts";
    const rows:Array<[string,string]>=[["Global search","Ctrl K"],["Quick create","Ctrl N"],["Overview","Alt 1"],["Manuscript","Alt 2"],["Characters","Alt 3"],["Items","Alt 4"],["Equipment","Alt 5"],["Skills","Alt 6"],["Relationships","Alt 7"],["Timeline","Alt 8"],["Combat","Alt 9"],["Generators","Alt 0"],["Workspace","Ctrl ,"],["Close overlay","Esc"]];
    const host=this.overlayHost();
    const rowMarkup=rows.map(([label,key])=>`<div class="shortcut-row"><span>${label}</span><kbd>${key}</kbd></div>`).join("");
    host.innerHTML=`<div class="shortcut-overlay" data-action="overlay-backdrop"><section class="shortcut-sheet" role="dialog" aria-modal="true"><header><div><span class="eyebrow">Keyboard</span><h2>Studio shortcuts</h2></div><button class="btn ghost" data-action="close">Close</button></header><div class="shortcut-grid">${rowMarkup}</div></section></div>`;
    host.querySelector<HTMLElement>('[data-action="overlay-backdrop"]')?.addEventListener("mousedown",event=>{if(event.target===event.currentTarget)this.closeOverlay();});
    host.querySelector<HTMLButtonElement>('[data-action="close"]')?.addEventListener("click",()=>this.closeOverlay());
  }

  private overlayHost():HTMLElement{const host=this.root.querySelector<HTMLElement>('[data-role="overlay-host"]');if(!host)throw new Error("overlay host missing");return host;}
  private closeOverlay():void{this.overlay=null;const host=this.root.querySelector<HTMLElement>('[data-role="overlay-host"]');if(host){host.innerHTML="";host.classList.remove("busy");}}
  private restoreRoute():Route{try{const value=window.localStorage.getItem(LAST_ROUTE_KEY);if(value&&value in ROUTES)return value as Route;}catch{}return "dashboard";}
}
