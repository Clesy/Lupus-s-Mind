# Apply v0.7.4 Generator Quality Hotfix

This patch is intended for an existing **v0.7.4-alpha.2** source folder.

1. Close the running app / dev server.
2. Extract this ZIP.
3. Copy its contents over the root of the existing v0.7.4-alpha.2 source folder, preserving directories and replacing files when asked.
4. Run:

```powershell
npm.cmd run verify
npm.cmd run build
cargo test --manifest-path .\src-tauri\Cargo.toml
npm.cmd run tauri:dev
```

No database migration is added by this hotfix.
