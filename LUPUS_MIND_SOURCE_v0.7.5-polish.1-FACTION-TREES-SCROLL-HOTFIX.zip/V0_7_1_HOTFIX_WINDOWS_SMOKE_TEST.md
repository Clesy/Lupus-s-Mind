# Windows Smoke Test — v0.7.1 Portrait + Timeline Hotfix

Apply the hotfix over the existing `v0.7.1-alpha.1` project folder. No new npm or Cargo dependency was added.

Run:

```powershell
npm.cmd run verify
npm.cmd run build
cargo test --manifest-path .\src-tauri\Cargo.toml
npm.cmd run tauri:dev
```

## Portrait

1. Open Characters.
2. Select a character.
3. Click `Portrait`.
4. Choose a JPEG/PNG/WebP image.
5. Confirm the card and inspector show the image.
6. Close and reopen the app; confirm the portrait persists.
7. Create/switch to another project; confirm the first project's portrait does not leak into it.
8. Switch back; confirm the portrait returns.
9. Click `Remove art`; confirm the portrait disappears.

## Timeline

1. Open Timeline with events at different chapter ranges.
2. Confirm it opens fitted to actual event bounds instead of being locked to Ch. 1–250.
3. Create at least 7 events near the same chapter; confirm cards are assigned to separate lanes and do not pile onto row 1.
4. Change From/To and Apply; confirm the projection updates.
5. Click `Fit all`; confirm the whole timeline is framed again.
6. Search for a timeline event with Ctrl+K and open it; confirm Timeline frames/selects that event.
7. Create/edit an event containing characters such as `<`, `>`, `&`, `'`, `"` in its title/description; confirm the Timeline UI remains intact.

## Native-specific tests added

`cargo test` now includes:

```text
portrait_files_are_isolated_by_active_project_database
timeline_bounds_cover_point_and_half_open_span_events
```
