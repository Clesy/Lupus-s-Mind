# v0.7.3 Windows Smoke Test

Run from a fresh extracted source directory:

```powershell
npm.cmd install
npm.cmd run verify
npm.cmd run build
cargo test --manifest-path .\src-tauri\Cargo.toml
npm.cmd run tauri:dev
```

## 1. Faction / Membership

1. Create Characters `Aren` and `Elysia`.
2. Create Factions `Elysium` and `Empire`.
3. Open Elysium and add Aren as `Captain`, joined Chapter 10.
4. Confirm Aren's Character Inspector shows Elysium under World Context.

## 2. Faction Matrix / Time Travel

1. Open Factions -> Matrix.
2. At Chapter 10 set Elysium / Empire to `allied`.
3. At Chapter 50 set them to `war`.
4. Inspect Chapter 30: matrix must show ALLIED.
5. Inspect Chapter 50 or later: matrix must show WAR.

## 3. Inventory / Ownership != Equipment

1. Create Item `Voidfang`.
2. Inventory: assign Voidfang to Aren at Chapter 20.
3. Equipment: equip Voidfang to Aren.
4. Character Inspector should show Voidfang in both loadout context and current inventory.
5. Transfer ownership to Elysium at Chapter 100.
6. The ownership transfer must not silently mutate Equipment; Item Inspector should show Elysium as current owner.

## 4. Quest

1. Create `The Broken Crown` as Active.
2. Set Elysia as quest giver and Elysium as faction.
3. Add objective `Recover the Crown`.
4. Mark it complete and optionally record Chapter 184.
5. Restart the app; quest and objective must persist.

## 5. Secret Knowledge Matrix

1. Create Secret `The Emperor is Aren's father` as Critical.
2. Set Elysia -> Knows at Chapter 430.
3. Set Aren -> Knows at Chapter 810.
4. Inspect Chapter 500: only Elysia should be Knows.
5. Inspect Chapter 900: Aren and Elysia should both be Knows.

## 6. Search / Project Isolation

1. Ctrl+K and search Elysium / Broken Crown / Emperor.
2. Results must deep-link to Factions / Quests / Secrets.
3. Switch to another project. The new project's four World Systems must not show records from the previous project.
4. Switch back and confirm all records return.

Report any visual glitch, unexpected cross-project data, or mismatch in chapter-based state.
