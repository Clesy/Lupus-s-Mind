# LUPUS'S MIND — v0.7.5-polish.1 Full Polish Candidate

> **Current candidate:** backlog #001–#010 is implemented in source. This is not yet a Windows-sealed release; run `V0_7_5_WINDOWS_SMOKE_TEST.md` before promotion.

## Current checkpoint — v0.7.5-polish.1

This pass is deliberately a product-polish checkpoint rather than a new feature-module expansion. It fixes Workspace health/recovery/settings, reshapes Overview around Quick Notes, makes Manuscript/Lore read-first, and completes the Atlas authoring/empty-state/generator/zoom polish backlog. See `V0_7_5_POLISH.md`.

Current source version: **0.7.5-polish.1**.

LUPUS'S MIND is an offline-first Tauri desktop studio for long-form fiction: manuscript authoring, structured world data, temporal canon, relationships, world systems and deterministic simulation tools.

## Current checkpoint

```text
v0.6   Native desktop foundation               SEALED on Windows
v0.7.0 Authoring + Navigation Foundation       ALPHA
v0.7.1 Character / Item Visual UX              ALPHA
v0.7.2 Lore + Connected Authoring              ALPHA
v0.7.3 Factions / Inventory / Quests / Secrets + Hierarchies ALPHA
v0.7.4 Atlas / Locations / Maps / Procedural Generator ALPHA
v0.7.5 Product polish #001–#010             CURRENT CANDIDATE
```

v0.7.4 adds canonical Location hierarchies, Atlas Maps, draggable map pins, map connections, nested maps and a deterministic seeded procedural world-map generator whose drafts remain non-canonical until explicit acceptance.

## Non-negotiable boundaries

```text
ItemOwnership     != Equipment
FactionMembership != Character Relationship
Quest             != TimelineEvent
Secret            != CharacterKnowledge
GeneratedMapDraft != Canonical Atlas/Location
Authored prose    != Canonical state
```

The default Combat Arena remains manual-only.

## Architecture

```text
Domain
  -> Application Use Case
    -> Repository / Read Port
      -> SQLite Adapter
        -> Tauri IPC
          -> Frontend Gateway
            -> Obsidian UI
```

UI modules do not call Tauri `invoke()` directly. SQLite remains behind infrastructure adapters. Each project owns a separate SQLite database and project-local asset storage.

## Windows gate

```powershell
npm.cmd install
npm.cmd run verify
npm.cmd run build
cargo test --manifest-path .\src-tauri\Cargo.toml
npm.cmd run tauri:dev
```

See:

- `V0_7_4_ATLAS_MAPS.md`
- `V0_7_4_WINDOWS_SMOKE_TEST.md`
- `VERIFICATION.md`
- `PROJECT_HANDOFF_LUPUS_MIND.md`

Historical architecture/freeze notes for I1/S1/R1/T1/C2/P1/P2/P3 and earlier v0.7 checkpoints remain in this source archive.

## v0.7.3-alpha.2 Inventory UI Hotfix
- Inventory layout compacted: controls and cards now flow from the top with no giant empty panel.
- Inventory cards reuse Item artwork, rarity and semantic stat/effect colors.
- Added ownership state filters/counts and current owner/chapter summary.
- No migration/domain behavior change; ItemOwnership remains separate from Equipment.


## v0.7.3-alpha.3 Hierarchies & Lineages
- Faction `Hierarchy` lens with editable role trees, capacity and chapter-aware office terms.
- Recommended Clan / Kingdom / Guild / Order / House structures.
- `Lineages` lens for family, dynasty, bloodline and house membership.
- Relationships `Family Tree` projection using canonical temporal kinship edges.
- Migration `013_hierarchies_and_lineages.sql`.
- See `V0_7_3_1_HIERARCHIES_LINEAGES.md`.


## v0.7.3-alpha.4 Tree UX

Faction Hierarchy and Lineages now render as true node/connector trees. Hierarchy nodes remain editable through the existing inspector. Lineage trees render Lineage → Branch → Members without fabricating kinship relationships.


## v0.7.4-alpha.2 Atlas & Map Systems

- Canonical Location hierarchy and Atlas Map records.
- SVG Atlas canvas with canonical pins, drag persistence and map connections.
- Nested maps with UI + SQLite cycle protection.
- Deterministic seeded procedural generator for landmasses, mountains, rivers and settlements.
- Generator preview is non-canonical; `Accept into World` is transactional and optionally creates Locations + pins.
- Global Search includes Locations and Maps.
- Migration `014_atlas.sql`.
- See `V0_7_4_ATLAS_MAPS.md` and `V0_7_4_WINDOWS_SMOKE_TEST.md`.
