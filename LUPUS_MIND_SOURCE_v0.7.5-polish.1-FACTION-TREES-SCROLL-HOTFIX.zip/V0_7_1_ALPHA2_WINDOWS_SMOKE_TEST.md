# v0.7.1-alpha.2 Windows smoke test

Run from the extracted source root:

```powershell
npm.cmd install
npm.cmd run verify
npm.cmd run build
cargo test --manifest-path .\src-tauri\Cargo.toml
npm.cmd run tauri:dev
```

Manual checks:

1. Open **Items**. Cards should visually match the Character Gallery hierarchy.
2. Select an item -> **Artwork** -> choose PNG/JPEG/WebP. Card and inspector should both update.
3. Restart the app. Item artwork should persist.
4. Switch projects. Item artwork from Project A must not appear in Project B.
5. Open **Characters** with an existing portrait. Inspector avatar must show only the image, never the fallback initial over/above it.
6. Check the centered Project Switcher. It should show only the project dot + project name; no arrow glyph.
