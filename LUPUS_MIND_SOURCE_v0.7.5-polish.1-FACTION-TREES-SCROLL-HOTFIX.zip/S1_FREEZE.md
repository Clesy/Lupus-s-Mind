# S1 — Skills Foundation Freeze Candidate

## Status

**Architecture/UI/invariant freeze: PASS** in the available execution environment.

**Full Rust compile freeze: BLOCKED BY ENVIRONMENT** because `cargo` / `rustc` are not installed here.

**Vite production build: BLOCKED BY ENVIRONMENT** because Vite is not locally installed/cached; `npx vite build` timed out while attempting package resolution.

## Frozen architectural decisions

1. **Skill ≠ Combat Action.** `Skill` is canonical knowledge. Current resource, remaining cooldown, target, crit, dodge, mitigation, status ticking and cast history do not exist in the S1 domain.
2. **Pure deterministic evaluation.** `DeterministicSkillEvaluator` accepts only `Skill + EvaluationStats` and returns a theoretical evaluation with an explainable scaling breakdown.
3. **EvaluationStats boundary.** The evaluator does not depend on CharacterSheet DTOs. The Preview application service maps CharacterSheet effective stats into the evaluator-owned value object.
4. **Character ↔ Skill is a relation.** No `owner_id` exists on `Skill`; `character_skills` stores learning assignments.
5. **Duplicate learning invariant is double-guarded.** The application service returns an explicit already-learned error and SQLite enforces `PRIMARY KEY(character_id, skill_id)`.
6. **Frontend does not calculate skill power.** The Obsidian inspector requests `skills_preview` through `SkillGateway`; Rust owns the deterministic formula.
7. **IPC remains an infrastructure concern.** UI/application TypeScript files contain no direct `invoke()` calls.
8. **Application remains persistence-agnostic.** Rust application modules contain no `rusqlite`, `Sqlite*`, or `AppState` dependency.

## S1 vertical slice

```text
Skill Editor
  -> SkillGateway
    -> Tauri IPC
      -> Skills application use case
        -> SkillRepository trait
          -> SQLite adapter

CharacterSkillInspector
  -> teach / forget relation
  -> Rust-backed preview
      CharacterSheet effective stats
        -> EvaluationStats
          -> DeterministicSkillEvaluator
```

## Implemented capabilities

- Typed `SkillKind`
- Typed `ResourceKind`
- Typed `ScalingStat`
- Multi-term `ScalingTerm`
- Skill CRUD
- Teach / Forget
- Duplicate learning prevention
- Character skill listing
- SQLite migration `003_skills.sql`
- Restart persistence invariants
- Pure `DeterministicSkillEvaluator`
- Explainable scaling contribution breakdown
- Rust-backed character skill preview
- Obsidian Skill Library
- Skill Editor
- Scaling Editor
- Character Skill Inspector
- Type-level FakeSkillGateway contract
- Rust evaluator unit test
- Rust end-to-end skill flow integration test source

## Explicitly excluded from S1

- current mana/stamina/health mutation
- remaining cooldown state
- target selection
- crit / dodge randomness
- armor / magic mitigation
- damage application
- status effect ticking
- turn sequencing
- cast history

These belong to the future Combat Runtime, not Skill canonical knowledge.

## Local freeze commands

```bash
npm install
npm run verify
npm run build

cd src-tauri
cargo test
```

When all four commands are green on the development machine, S1 can be promoted from **Freeze Candidate** to **S1 FREEZE 🔒** without changing architectural boundaries.
