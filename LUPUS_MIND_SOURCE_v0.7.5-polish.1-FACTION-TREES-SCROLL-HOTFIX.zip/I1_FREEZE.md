# Sprint I1 — Items & Equipment UI Freeze

Status: **REFERENCE IMPLEMENTATION READY FOR LOCAL RUST BUILD VALIDATION**

## Frozen boundaries

- UI components do not call Tauri IPC directly.
- Tauri `invoke()` exists only inside infrastructure adapters.
- Rust application services depend on repository traits, not SQLite implementations.
- Item canonical data is independent from equipment state.
- Equipment is a character↔item relation with a typed `EquipmentSlot` domain enum.
- Compatibility is decided by the Rust domain rule and surfaced through an application query.
- Unique physical-item occupancy is enforced by both repository behavior and the database unique index.
- Slot replacement is atomic; failures roll back without losing the previously equipped item.
- `CharacterSheet` is a read model: item modifiers affect effective stats, never persisted character base stats.

## UI flow frozen in I1

### Item Editor

- Create item
- Edit item
- Delete item with confirmation
- Edit type and rarity
- Edit description and tags
- Add/remove typed stat modifiers
- Search item list
- Gateway-backed errors remain visible instead of being swallowed

### Equipment Inspector

- Character selector
- Typed equipment slots
- Live CharacterSheet effective-stat summary
- Slot selection
- Rust-backed compatibility candidates
- Availability state for unique equipment
- Equip
- Unequip
- Slot replacement via transaction-safe repository operation

## Verification executed in this environment

```text
TypeScript strict typecheck                         PASS
Architecture invariant suite                       PASS
SQLite unique-equipment invariant                  PASS
SQLite rollback-preserves-old-equipment invariant  PASS
SQLite restart persistence                         PASS
SQLite slot constraint                             PASS
I1 UI structural invariant suite                   PASS
Production Rust source unwrap scan                 PASS (zero matches)
```

## Environment-blocked checks

The container does not provide `cargo`/`rustc`, so Rust compilation and Rust integration tests could not be executed here. The tests are included under `src-tauri/tests/` and should be run locally with:

```bash
cd src-tauri
cargo test
```

Vite is declared in `package.json` but is not installed/cached in this offline container. `vite build` therefore cannot be truthfully marked as passed here. After installing dependencies locally:

```bash
npm install
npm run build
```

## Freeze gate

I1 becomes fully sealed after these two local commands are green:

```bash
npm run verify
npm run build
cd src-tauri && cargo test
```

No Skills/Relationships/Timeline/Combat work should alter these domain and adapter boundaries without an explicit ADR.
