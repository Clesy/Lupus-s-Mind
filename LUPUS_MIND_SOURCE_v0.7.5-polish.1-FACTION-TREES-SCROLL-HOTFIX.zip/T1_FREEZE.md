# T1 — Narrative Timeline Freeze Contract

## Status

**Architecture / invariant freeze: PASS**  
**Full Rust + production bundle compile freeze: pending local toolchain**

T1 adds a canonical narrative timeline without turning technical domain transitions into narrative events.

## Frozen semantic boundary

```text
RelationshipTransition != StateTransition != TimelineEvent != TimelineProjection
```

- `TimelineEvent` is editable canonical narrative truth.
- `TimelineSourceLink` is provenance only.
- Provenance does **not** imply participation.
- `TimelineProjectionDto` and character threads are derived read models and are never stored as canonical tables.
- No automatic transition -> TimelineEvent write exists in T1.

## Temporal semantics

`TemporalKind::Point`

```text
start_chapter = N
end_chapter   = NULL
active only at N
```

`TemporalKind::Span`

```text
[start_chapter, end_chapter)
```

The database CHECK constraint makes point/span ambiguity impossible.

### Golden test

```text
Ch.10     Arrival                 point
Ch.50-80  Siege                   span [50,80)
Ch.80     Fall of the Citadel     point

at(9)   -> []
at(10)  -> Arrival
at(49)  -> []
at(50)  -> Siege
at(79)  -> Siege
at(80)  -> Fall of the Citadel (NOT Siege)
at(999) -> []
```

This test passes in `tests/t1_invariants.py`. An equivalent Rust integration test is present in `src-tauri/tests/timeline_flow.rs` for the local Cargo gate.

## Canonical schema

`005_timeline.sql` introduces:

- `timeline_events`
- `timeline_event_characters`
- `timeline_event_sources`
- temporal, character, and provenance indexes

No `timeline_projections`, `character_timelines`, or persisted Chronicle view exists.

## Clean Architecture boundary

```text
Obsidian UI
  -> TimelineGateway
    -> Tauri adapter
      -> Tauri command
        -> Timeline application use cases
          -> TimelineRepository / TimelineSourceReferenceRepository
            -> SqliteTimelineRepository
```

Application code contains no `rusqlite`, concrete `Sqlite*`, or `AppState` dependency.

## Authoring transaction boundary

Create/update operations treat canonical event data, participant links, and source links as one atomic unit. A failed participant/source write rolls the transaction back so no half-created narrative event remains.

## Provenance rule

T1 supports:

- `manual`
- `relationship_transition`

A relationship transition source is validated behind `TimelineSourceReferenceRepository`; the frontend does not guess whether a source exists.

## Read models

T1 ships derived:

- Chronicle range projection
- Character narrative thread
- Timeline entry projection with participant names and source counts

## Obsidian UI

Reference UI includes:

- Timeline screen
- `[start,end)` range selector
- Character filter
- Event-kind filter
- Timeline track
- Canonical event editor
- Participant role editor
- Provenance source editor
- Narrative inspector

The reference UI intentionally keeps the first editor small (one participant/source row visible) while the Gateway/domain DTOs already support multiple participants and sources.

## Executed verification

```text
npm run verify                              PASS
TypeScript strict                          PASS
Architecture invariants                    PASS
C1 / I1 regression                         PASS
S1 regression                              PASS
R1 regression                              PASS
T1 golden point/span semantics             PASS
Source != participant semantic test        PASS
Atomic event transaction rollback          PASS
Restart persistence                        PASS
Projection-is-not-canonical test           PASS
```

## Pending local compile seal

This execution environment has no Rust toolchain and no installed Vite binary/package tree. Therefore these are deliberately **not** reported as passing here:

```bash
npm install
npm run verify
npm run build

cd src-tauri
cargo test
```

When those local commands are green, T1 receives the final compile seal.
