# v0.7.1 — Portrait + Timeline Hotfix

This hotfix closes two issues reported during Windows smoke testing.

## Character portrait is now real

The previous v0.7.1 card was only portrait-ready. This hotfix adds a real project-local asset flow:

```text
HTML file input
  -> client resize / WebP optimization (max 900 px)
    -> AssetGateway
      -> Tauri IPC
        -> FileSystemAssetStore
          -> active-project asset directory
```

Rules:

- JPEG / PNG / WebP input accepted.
- The frontend optimizes the selected image before IPC.
- Backend accepts at most 2 MB.
- Portrait bytes are NOT stored in the canonical Character SQLite row.
- Portrait assets follow the active project database path, so different projects have isolated artwork.
- Character cards and the Character Inspector read the portrait through `AssetGateway`.
- `Remove art` deletes the current portrait file for that character/project.

## Timeline repaired

The Timeline view had two layout problems after the v0.7 shell redesign:

1. It used a viewport-height calculation while living inside a topbar + padded route host, which could cause clipping.
2. Event vertical positioning only had CSS rules for the first five rows, so denser timelines could overlap.

The hotfix:

- uses the route host height (`height: 100%`, `min-height: 0`);
- uses flexible sidebar/workspace/inspector columns;
- dynamically packs events into as many lanes as required;
- removes the five-event `nth-child` placement limit;
- queries actual timeline bounds and opens fitted to real event data;
- adds `Fit all`;
- lets Global Search deep-link to a timeline event and frame its chapter range;
- escapes user-authored timeline text before rendering it into editor/inspector HTML.

## Validation

Executed in the artifact environment:

```text
npm run verify -> PASS
TypeScript strict -> PASS
all C1..v0.7.1 regression suites -> PASS
portrait/timeline hotfix invariants -> PASS
```

This environment still has no Cargo/Rust and no local Vite install, so native compile and production bundle must be sealed on the Windows workstation.

New native integration test:

```text
src-tauri/tests/asset_timeline_hotfix_flow.rs
```

It verifies project-isolated portrait files and timeline point/span bounds.
