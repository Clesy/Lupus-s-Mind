# LUPUS'S MIND v0.7.0-alpha.1 — Windows Smoke Test

Run from the extracted project root.

## 1. Dependency / source gate

```powershell
npm.cmd install
npm.cmd run verify
npm.cmd run build
cargo test --manifest-path .\src-tauri\Cargo.toml
```

The Rust run must include `authoring_project_flow`.

## 2. Launch

```powershell
npm.cmd run tauri:dev
```

## 3. Existing-world migration

- Confirm your previous v0.6 data is still present.
- Open the centered Project Switcher.
- Confirm the legacy world appears as `My World` (or the registered current project).
- Check Workspace health reports schema version 10.

## 4. Project isolation

1. In Project A create a clearly named character, e.g. `PROJECT_A_ONLY`.
2. Create a chapter containing the same marker.
3. Create & switch to Project B.
4. Confirm Project A character/chapter are absent.
5. Search `PROJECT_A_ONLY` with Ctrl+K; expect no project-data hits.
6. Create `PROJECT_B_ONLY` in B.
7. Switch back to A.
8. Confirm A data returns and B-only data is absent.

## 5. Autosave safety across project switch

1. Open a chapter in Project A.
2. Type a unique final sentence.
3. Immediately open Project Switcher (do not wait for autosave indicator).
4. Switch to Project B.
5. Return to Project A and reopen the chapter.
6. Confirm the final sentence was saved in A and does not appear in B.

## 6. Manuscript

- New Chapter works.
- Title/status/content/notes/tags save.
- Word count updates live.
- Focus / Exit Focus works.
- Quick Note create, pin/unpin and delete work.
- Delete chapter honors destructive confirmation preference.

## 7. Global Search / Quick Create

- Ctrl+K opens search.
- Search character, item, skill, chapter and timeline content.
- Clicking Character / Item / Skill / Chapter opens the expected target.
- Ctrl+N opens Quick Create.
- Quick Create opens Character, Item, Skill and Chapter creation flows.

## 8. Character Gallery

- Cards is usable as primary view.
- Table toggle works.
- Search/filter narrows cards.
- Select a card and confirm inspector shows base/effective stats, equipment and learned skills.
- Manage Equipment / Manage Skills navigation works.

## 9. Regression

- Manual Combat Arena remains manual only.
- Attacker / target swap works.
- Forced Crit works.
- Existing Items / Equipment / Skills / Relationships / Timeline / Generators / Workspace still open.

Do not promote the alpha if project isolation or autosave-switch safety fails.
