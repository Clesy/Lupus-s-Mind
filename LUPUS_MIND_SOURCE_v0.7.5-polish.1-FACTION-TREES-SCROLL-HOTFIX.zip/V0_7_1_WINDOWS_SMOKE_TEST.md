# LUPUS'S MIND — v0.7.1 Windows Visual UX Smoke Test

Run from the extracted project directory:

```powershell
npm.cmd install
npm.cmd run verify
npm.cmd run build
cargo test --manifest-path .\src-tauri\Cargo.toml
npm.cmd run tauri:dev
```

Then verify manually:

## Shell

- Top bar, project switcher and search remain readable and restrained.
- Active sidebar route has a subtle accent marker; no neon/cyber regression.
- Multi-project switching still isolates data.

## Characters

- Cards are the default visual view (unless Table was previously saved).
- STR / AGI / VIT / INT / MND use distinct but muted semantic colors.
- Selecting a Character opens the right inspector.
- Base Stats and Effective Stats remain visually distinct.
- Equipment rarity and skill kind are readable without overwhelming the page.
- Favorite a Character, navigate away/back, and confirm it persists.
- Favorites filter works without changing canonical Character data.
- Duplicate creates a new Character named `... Copy`; editing the copy does not change the source.
- Compare Mode compares two CharacterSheet projections and performs no writes.

## Items

- Cards / Table toggle persists.
- Rarity is visible as an accent, not a full-card background.
- Positive modifier values are visibly distinct from negative modifiers.
- Different stat modifiers retain the same colors used on Character stats.
- Item inspector shows Lore + Stat Effects clearly.
- Duplicate Item creates a new identity.

## Regression

- Manuscript autosave and project switching still work.
- Global Search still searches only the active project.
- Manual Combat Arena remains manual-only; nobody attacks without user action.
