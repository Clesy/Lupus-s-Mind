# P3 UX Hotfix — Character Loadout + Combat Impact Preview

This hotfix addresses two issues found during the first real Windows desktop smoke test.

## Character detail

Character detail now reads the existing bounded-context gateways and displays:

- base stats,
- effective stats from CharacterSheet,
- equipped items with slot / rarity / item type,
- learned skills with kind / power / resource cost,
- direct Manage navigation to Equipment and Skills.

No item/skill state is duplicated into Character canon.

## Combat simulator

Durable Battle keeps the original invariant: only skills learned before combat start are frozen into the session snapshot. Existing running battles remain immutable.

A new read-only **Damage Preview** answers the authoring question:

`Attacker + Skill + Target + RNG Seed -> direct deterministic impact`

The preview:

- can inspect any Skill Library definition, even before it is taught,
- uses the same Rust combat resolver math as durable combat,
- shows damage/healing/dodge/critical, raw and resolved power, armor and RNG anatomy,
- performs no combat session write and no canonical write.

If a durable battle actor has zero learned skills, the UI now explains why and links to Skills. After teaching, a **new** battle must be started because existing sessions are snapshot-frozen by design.
