# v0.7.4-alpha.2 — Atlas Viewport / Zoom Hotfix

This checkpoint is a frontend/read-interaction hotfix over `0.7.4-alpha.1`. It does not change migration 014 or Atlas domain semantics.

## Fixed

- Atlas workspace now consumes the available route height instead of reserving a large empty vertical area above the map.
- The center map viewport stays inside the desktop workspace; the right Map Inspector scrolls independently.
- Canonical map canvas starts directly below its toolbar and no longer gets pushed below the visible window by the previous fixed minimum-height layout.
- Dense generated settlement labels use deterministic alternate offsets to reduce overlap at fit zoom.

## Zoom / pan

- Mouse wheel zooms around the pointer position.
- `+` and `-` controls zoom in/out.
- `Fit` returns to the full-map camera.
- Zoom is bounded from 100% (fit) to 600%.
- Dragging empty map space pans the camera while zoomed.
- Dragging a pin still moves the pin and does not pan the map.
- Pin placement still uses normalized map coordinates and remains correct at any zoom/pan state.
- Camera changes are UI-only and never mutate canonical map/location data.

## Boundaries preserved

```text
Map camera (zoom/pan) != AtlasMap persistence
Pin drag              = MapPin projection update
GeneratedMapDraft      != Canon
```

No new database migration is introduced.
