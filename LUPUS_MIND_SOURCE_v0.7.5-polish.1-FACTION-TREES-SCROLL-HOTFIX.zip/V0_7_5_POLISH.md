# LUPUS'S MIND — v0.7.5-polish.1

## Scope

This checkpoint implements the agreed **#001–#010 polish backlog** on top of the v0.7.4-alpha.3 Atlas / Generator baseline. It intentionally avoids opening another large product module.

1. **#001 Workspace — Schema 14/10 / false “Needs attention”**
   - Database health now derives its expected schema from the shared latest-migration constant (`14`).
   - A healthy schema-14 workspace reports 14/14 instead of 14/10.

2. **#002 Overview — Quick Notes instead of Arena panel**
   - Overview no longer promotes active Combat sessions as the primary lower panel.
   - It reads existing project Quick Notes through `ManuscriptGateway`.
   - Combat remains available in its dedicated route; this is an Overview information-hierarchy change only.

3. **#003 Workspace — Reset settings**
   - Added a persisted reset-to-domain-defaults use case and Tauri command.
   - The Workspace screen applies the returned defaults immediately to the live shell.

4. **#004 Workspace — Recovery Restore**
   - SQLite backup/recovery artifacts can be restored from Workspace.
   - Restore is restricted to artifacts inside the workspace artifact directory.
   - A new pre-restore safety snapshot is created before replacement.
   - The selected database is copied to a staging file, migrated, `quick_check` validated and foreign-key checked before activation.
   - Activation swaps the shared SQLite connection and includes rollback/reopen paths if replacement fails.

5. **#005 Manuscript & Lore — Read-first mode**
   - Existing Chapters and Lore Pages open in a clean read/view mode by default.
   - `Edit` explicitly enters authoring mode; `Done` flushes pending saves and returns to view mode.
   - Newly created records still open directly in edit mode.

6. **#006 Atlas — Manual world-map drawing**
   - Manual maps now expose Draw Land / Undo / Clear controls.
   - Pointer drawing is normalized into map coordinates and simplified before persistence.
   - Authored coastlines are stored in the existing `GeneratedMapDraft`-compatible terrain payload of the selected Atlas map; no new canonical entity is created by drawing.

7. **#007 Atlas — Location deletion**
   - Location deletion is explicit and transactional.
   - Children are detached to top level, map pins/routes for the deleted location are cleaned, scoped maps are detached, then the location is removed.

8. **#008 Atlas — Generator quality pass**
   - Coastline sampling increases from 160 to 256 points per landmass.
   - Continental silhouettes gain deterministic anisotropy, angular warping, broader multi-frequency shaping and additional bay/peninsula features.
   - Mountain density is reduced slightly while ranges are made longer/more coherent.
   - Independent deterministic RNG streams remain intact; same request + same seed remains stable.

9. **#009 Atlas — Pin/icon scaling + zoom-aware visibility**
   - Pin visuals use inverse scaling so markers remain legible instead of ballooning/shrinking with map zoom.
   - Semantic labels reveal progressively by location kind (town/village labels require deeper zoom).
   - Terrain/routes use non-scaling strokes where appropriate.

10. **#010 Atlas — Empty-state / Create first map UX**
    - A project with no maps now gets three explicit starting paths: Draw manually, Generate from seed, or Create locations first.
    - The screen explains the canonical boundary between map drawing, generated drafts and accepted world records.

## Architecture preserved

- UI modules still do not call Tauri `invoke()` directly; infrastructure gateways own IPC.
- SQLite remains the local source of truth.
- Generator preview remains non-canonical until explicit acceptance.
- Generated map logic remains deterministic and free of SQLite, OS RNG and wall-clock dependencies.
- Combat remains separate from canonical world state and is not removed by the Overview change.
- Restore operations create a safety snapshot and validate staged SQLite data before replacing the active workspace.

## Verification status in this packaging environment

TypeScript and the complete constituent invariant suite are green in the packaging environment; see `V0_7_5_VERIFICATION.md` for the exact record. Production Vite build and native Cargo/Tauri compilation remain Windows promotion gates because dependencies/toolchains are unavailable here. The final Windows/manual checks are documented in `V0_7_5_WINDOWS_SMOKE_TEST.md`.

The version is intentionally a prerelease-style candidate: **0.7.5-polish.1**. Promote only after Windows smoke testing succeeds.
