# P3 — Native Release Candidate Foundation

Version: **0.6.0-rc.1**

Status: **source-level release gate complete; Windows native seal pending a machine with network + Rust/Tauri prerequisites**.

## Delivered

- Version alignment across npm / Cargo / Tauri manifests.
- Explicit Tauri bundling with Windows NSIS as the first official installer target.
- Current-user install mode (no administrator requirement for the normal installer path).
- Explicit WebView2 downloaded-bootstrapper policy.
- Rust release profile with LTO, one codegen unit, abort-on-panic and stripping.
- Cross-platform `release:preflight` and `release:gate` commands.
- Windows bootstrap and release PowerShell scripts.
- Windows-native GitHub Actions release-gate workflow that runs verify → Vite build → Cargo tests → NSIS bundle and uploads the installer artifact.
- Manual native smoke-test contract.
- `.gitignore` for build/runtime artifacts.
- RC version surfaced in the desktop shell.

## Release commands on Windows

After installing the system prerequisites:

```powershell
powershell -ExecutionPolicy Bypass -File scripts/windows-bootstrap.ps1
powershell -ExecutionPolicy Bypass -File scripts/windows-release.ps1
```

The bootstrap intentionally creates `package-lock.json` and `src-tauri/Cargo.lock`. Those lockfiles must be retained for a sealed release so dependency resolution is reproducible.

The release script executes:

```text
preflight
  -> npm run verify
  -> npm run build
  -> cargo test
  -> tauri build --bundles nsis
```

Expected installer location:

```text
src-tauri/target/release/bundle/nsis/*-setup.exe
```

## Native seal still required

This packaging environment has Node/npm but no Rust/Cargo and no access to the npm registry. Therefore dependency installation, Vite production build, Cargo tests and NSIS creation cannot truthfully be sealed here.

No native-pass claim is made until the Windows release gate succeeds and `P3_WINDOWS_SMOKE_TEST.md` is completed.
