# v0.7.3-alpha.4 Windows Smoke Test

Run:

```powershell
npm.cmd install
npm.cmd run verify
npm.cmd run build
cargo test --manifest-path .\src-tauri\Cargo.toml
npm.cmd run tauri:dev
```

Then verify:

1. Open **Factions -> Hierarchy**. Create/seed a hierarchy. Confirm roles render as connected tree nodes rather than an indented card list.
2. Click a role node. Confirm the right inspector still edits `Reports to`, tier, capacity, color and sort order.
3. Assign a character to a role. Confirm the current holder appears inside that role node.
4. Change Chapter. Confirm office holders update without changing the role tree itself.
5. Open **Factions -> Lineages**. Select/create a lineage and add members with `Main`, `Branch A`, etc. Confirm the view renders `Lineage -> Branch -> Members`.
6. Confirm lineage membership does not create parent/spouse relations. Relationships -> Family Tree remains the source for actual kinship.
7. Resize the window. Large trees should scroll inside the tree panel rather than stretching the entire shell.
