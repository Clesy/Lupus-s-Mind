# LUPUS'S MIND — v0.7.2 Lore & Authoring Alpha

Version: **0.7.2-alpha.1**

This slice connects manuscript writing to structured world knowledge without turning prose into canonical state.

## Product scope

- Lore Bible / Lore Pages with list, editor, category, summary, tags and autosave.
- Natural entity mentions in Chapter and Lore text: `@Aren`, `@Voidfang`, etc.
- Rebuildable `entity_mentions` projection and two-way backlinks.
- Quick Peek / linked navigation for recognized entities.
- Global Search includes Lore and can deep-link to a Lore page.
- Manuscript Find / Next / Previous uses native textarea selection for visible match highlighting.
- Chapter Scene Planner with Scene Order, Title, Goal, Obstacle, Outcome, POV Character, Location Label and Notes.
- Character Arc points in Character Inspector.
- Quick Notes can optionally link back to a Chapter or supported entity; deleting the linked target preserves the note and clears only the stale link metadata.
- Project switching flushes pending and in-flight Manuscript + Lore autosaves before the active SQLite connection changes.

## Architectural boundaries

```text
Chapter/Lore text          = authored source
EntityMention              = rebuildable projection/read model
CharacterArcPoint          = narrative planning data
ScenePlan                  = narrative planning data
Canonical Character state  = separate
TimelineEvent              = separate canonical narrative fact
```

Writing `@Aren` creates no Character mutation. Writing "Aren died" creates no status transition. Authoring data may inform future review tools, but canon changes require an explicit canonical command.

`entity_mentions` currently resolves exact names/aliases for:

- Characters (name + alias)
- Items
- Skills
- Lore Pages

Locations and Factions will join the same link model when their canonical domains exist.

## Mention behavior

Mention extraction is backend-owned. Source text remains plain text and is never rewritten to store internal IDs. The projection stores the resolved target ID plus the original display text, so backlinks are stable and the projection can be regenerated later.

Current v0.7.2 matching is intentionally conservative: exact known `@Name` / `@Alias` matches only. Fuzzy/semantic entity resolution is future work.

## Authoring constraints

- Rich-text editing was intentionally not introduced in this slice. The existing reliable textarea authoring workflow remains.
- Find highlighting uses `setSelectionRange`, avoiding a second editor subsystem.
- Scene participant IDs are present in the schema/API, but the v0.7.2 UI emphasizes POV + location + Goal/Obstacle/Outcome rather than a large participant-management interface.
- Mention projection refresh is best-effort after a durable Chapter/Lore save; projection failure must not falsely report that the authored document itself failed to save.
- Deleting source/target records cleans stale mention rows with SQLite triggers.

## Migration

Migration `011_lore_authoring_links.sql` adds:

- `lore_pages`
- `entity_mentions`
- `character_arc_points`
- `scene_plans`
- optional Quick Note link metadata
- indexes and projection cleanup triggers

## Verification in packaging environment

- `npm run verify` — **PASS**
- `npm run typecheck` — **PASS**
- `npm run build` — **NOT SEALED HERE** (`vite: not found` in this environment)
- Rust/Cargo native compile — **NOT SEALED HERE** (Cargo unavailable in this environment)

Run `V0_7_2_WINDOWS_SMOKE_TEST.md` on the Windows development machine before promoting this alpha.
