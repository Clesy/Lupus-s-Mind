# G1 — Creative Generators Foundation

G1 is a non-canonical creative query capability added alongside C2.3.

```text
GeneratorRequest
  -> deterministic generator
  -> GeneratedCandidate

GeneratedCandidate != Character
GeneratedCandidate != Location
GeneratedCandidate != Item
```

Implemented generators:

- Character names
- Location names
- Item / artifact names

Inputs include typed generator kind, tone, subtype, count and deterministic seed.

The Rust generator module has no repository, SQLite or canonical write dependency. The Obsidian Generator screen calls it only through `GeneratorGateway` and currently offers copy-to-clipboard candidates. It deliberately does not create canonical entities automatically.

Supported tones:

- Noble
- Dark
- Ancient
- Harsh
- Elegant
- Mystic

Initial subtypes:

- Character: full / single
- Location: kingdom / city / ruin / forest / dungeon
- Item: weapon / armor / artifact

Future world-aware generation may consume read-only canonical context, but any `Use` operation must remain an explicit command owned by the target canonical domain.
