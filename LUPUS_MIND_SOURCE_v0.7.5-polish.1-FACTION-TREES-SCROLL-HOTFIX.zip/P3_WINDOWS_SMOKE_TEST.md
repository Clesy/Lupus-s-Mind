# P3 — Windows Native Smoke Test

This checklist is the final human acceptance gate after `scripts/windows-release.ps1` succeeds.

## Launch / persistence

1. Launch the built app from the NSIS-installed Start Menu shortcut.
2. Confirm the shell opens without a console window and the Overview route renders.
3. Create a character, close the app, reopen it, and confirm the character persists.

## Canonical world

4. Create an Item and equip it to the character; verify Character Sheet effective stats reflect it.
5. Create a Skill, bind a status effect, teach it to the character, and verify Preview renders.
6. Create a temporal Relationship with a later state change and inspect both chapters.
7. Create point/span Timeline events and verify `[start,end)` behavior in the UI.

## Combat / replay

8. Start a combat, execute a skill, apply/refresh a status effect, close/reopen, and resume the same session.
9. Open Replay, scrub backward/forward, then return LIVE; LIVE state must remain unchanged.
10. Run replay verification; latest reconstructed state must equal persisted LIVE state.

## Creative / desktop safety

11. Generate Character, Location, and Item names with a fixed seed; repeat and confirm identical candidates.
12. Open Workspace health; quick check and foreign-key check must be healthy.
13. Create a manual SQLite backup and JSON export; confirm both artifacts appear in the artifact list.
14. Toggle compact navigation / reduce motion, restart the app, and confirm settings persist.

## Installer acceptance

15. Uninstall the app, reinstall using the generated `*-setup.exe`, and relaunch.
16. Confirm user workspace data is not silently deleted by ordinary app upgrade/uninstall testing before any destructive cleanup policy is introduced.

A release candidate is not sealed until the automated gate and all applicable smoke items pass on Windows.
