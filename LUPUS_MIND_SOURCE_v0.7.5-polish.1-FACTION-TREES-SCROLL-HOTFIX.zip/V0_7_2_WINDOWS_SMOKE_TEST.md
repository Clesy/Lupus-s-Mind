# LUPUS'S MIND — v0.7.2 Windows Smoke Test

Run from the extracted `0.7.2-alpha.1` source root in PowerShell.

```powershell
npm.cmd install
npm.cmd run verify
npm.cmd run build
cargo test --manifest-path .\src-tauri\Cargo.toml
npm.cmd run tauri:dev
```

All five commands should complete before the alpha is promoted.

## Lore / entity-link smoke test

1. Open or create a test project.
2. Create Character `Aren` and Item `Voidfang` if they do not already exist.
3. Open Manuscript and create/select a chapter.
4. Type: `@Aren carries @Voidfang.`
5. Wait for autosave.
6. Confirm Linked Entities shows Aren and Voidfang.
7. Open Aren from the link/Quick Peek and confirm the Character Inspector Backlinks area references the chapter.
8. Create Lore Page `Ashen Prophecy` and write `The prophecy names @Aren.`
9. Confirm the Lore page shows the Aren mention and Aren now has a Lore backlink as well.
10. Search `Ashen Prophecy` with Global Search and confirm it opens the correct Lore page.

## Scene Planner smoke test

1. Select a manuscript chapter.
2. Add a scene.
3. Fill Goal, Obstacle and Outcome, choose Aren as POV, and add a location label.
4. Save/reopen the chapter and confirm the scene persists.
5. Delete a disposable test chapter and verify its scene plans disappear with it.

## Character Arc smoke test

1. Open Aren.
2. In Character Arc, add `Ch. 430 — Exile` with a phase/description.
3. Navigate away and back; confirm it persists.
4. Delete only a disposable test character when checking cascade behavior; its arc points should disappear.

## Autosave / project-isolation smoke test

1. In Project A, edit a Chapter and immediately switch to Project B before the debounce delay naturally expires.
2. Return to Project A and confirm the edit is present.
3. Confirm the Project A text did not appear in Project B.
4. Repeat the same test while editing a Lore Page.

## Regression spot checks

- Character portrait remains correct in cards + inspector.
- Item artwork remains correct and project-scoped.
- Project Switcher has no arrow glyph.
- Timeline opens/fits correctly and `Fit all` works.
- Manual Combat Arena remains manual-only and does not auto-run turns.

If a command/test fails, keep the previous working source/executable as the rollback checkpoint and capture the exact console output before changing code.
