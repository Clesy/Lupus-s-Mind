# LUPUS'S MIND — v0.7.1 Visual UX / Character & Item Studio

Version: `0.7.1-alpha.1`

## Goal

Make the v0.7 authoring/navigation shell feel like a professional desktop studio while keeping the visual language restrained and readable.

The design rule for this slice is:

```text
Color = information
not decoration
```

The Obsidian shell remains dark and neutral. Stronger colors are reserved for semantic data: stats, rarity, positive/negative effects, skill kinds and selection state.

## Semantic stat palette

The same stat keeps the same visual identity across Character and Item surfaces:

- Strength — warm coral
- Agility — muted green
- Vitality — muted gold
- Intelligence — blue
- Mind — violet
- Weapon Damage — warm damage tone
- Armor — steel
- Penetration — copper
- Critical — amber
- Damage Reduction — teal

These are centralized CSS tokens, not inline styles.

## Character Gallery

Added/refined:

- professional card-first gallery;
- persistent Cards / Table view;
- colored STR / AGI / VIT / INT / MND chips;
- portrait-ready visual region (placeholder only in this slice; no image storage contract added yet);
- deterministic tag color presentation;
- Favorites stored as local UI preference;
- Favorites-only filter;
- contextual right inspector;
- canonical Base Stats separated visually from Effective Stats;
- effective stat palette across combat/build statistics;
- rarity-colored equipment labels;
- skill-kind colors;
- Duplicate Character (new identity; never copies the UUID);
- Compare Mode using two CharacterSheet projections.

Compare Mode is a read-only UI projection and does not write canonical data.

## Item Gallery

Items now use the same professional Gallery / Inspector language as Characters:

- Cards / Table toggle;
- type glyphs;
- rarity accent and badge;
- compact lore excerpt;
- colored modifier chips;
- positive modifier = bonus/buff presentation;
- negative modifier = penalty/debuff presentation;
- right-side item inspector;
- full stat-effect stack;
- Duplicate Item (new identity).

No Item or Character domain/schema change was required for this presentation slice.

## Boundaries

The following rules remain frozen:

```text
UI -> Gateway -> Tauri -> Application -> Repository
```

- Character and Item screens contain no direct `invoke()` calls.
- No SQLite dependency exists in UI modules.
- Favorites and view modes are UI preferences only.
- Compare is read-only.
- Duplicate uses the existing explicit create command and therefore receives a new canonical identity.
- No portrait binary/base64 data is written into the canonical Character table in this slice.

## Verification

Packaging environment:

```text
npm run verify     PASS
TypeScript strict  PASS
v0.7.1 UX tests    PASS
npm run build      NOT SEALED HERE — vite binary absent in this environment
Cargo              NOT SEALED HERE — use Windows native toolchain
```

Windows seal commands:

```powershell
npm.cmd install
npm.cmd run verify
npm.cmd run build
cargo test --manifest-path .\src-tauri\Cargo.toml
npm.cmd run tauri:dev
```

## Manual smoke checks

1. Character cards are legible at normal Windows scaling.
2. Each base/effective stat keeps its semantic color.
3. Favorites survive route changes/application restart.
4. Favorites filter does not mutate Character data.
5. Duplicate Character creates a second record with a different identity.
6. Compare Mode shows effective stats for two characters and performs no write.
7. Item Cards show rarity and modifier colors consistently.
8. Negative item modifier is visually distinct from a positive modifier.
9. Duplicate Item creates a second Item with a new identity.
10. Manual Combat Arena behavior remains unchanged.
