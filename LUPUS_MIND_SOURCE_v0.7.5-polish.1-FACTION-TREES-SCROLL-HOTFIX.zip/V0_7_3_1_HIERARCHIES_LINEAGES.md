# v0.7.3.1 — Hierarchies & Lineages

Implementation package version: **0.7.3-alpha.3**.

This slice is intentionally placed before Atlas so countries, clans, houses and family structures already have a stable semantic model when map territories arrive.

## Core boundaries

```text
FactionMembership != HierarchyRoleAssignment
LineageMembership != FamilyRelationship
FamilyTree        != Canonical Family Database
HierarchyRole     != Character Title/State
```

- Faction Membership answers whether a character belongs to an organization.
- Hierarchy Role Assignment answers which office/position they hold at a chapter.
- Lineage Membership answers which family/dynasty/bloodline/house they belong to.
- Parent/Spouse/Sibling/etc. remain canonical temporal Relationships.
- Family Tree is a read model over active kinship Relationships at the selected chapter.

## Faction Hierarchy

Faction screen adds a `Hierarchy` lens.

Roles form a custom tree with:

- role / office name
- parent role
- tier
- optional capacity
- accent color
- ordering

Office holders are temporal `[valid_from, valid_to)` assignments. A one-seat office therefore supports:

```text
Ch. 1–49   Kael — Clan Leader
Ch. 50+    Aren — Clan Leader
```

Database rules prevent cross-faction parent roles, role cycles and over-capacity open assignments.

### Recommended structures

`Recommended structure` seeds editable defaults only when a faction has no roles.

Examples:

- Clan: Clan Leader → Vice Leader / Grand Elder → Elder / Elite Captain → Captain → Member
- Kingdom: Monarch → Prime Minister / Grand Marshal / Royal Council → Minister / Governor / General → Officer
- Guild: Guild Master → Vice Master → Officer → Elite Member → Member → Recruit
- Order: Grand Master → Deputy Master → Commander → Captain → Knight → Initiate
- House: House Head → Heir / Steward → Retainer / House Member

These are templates, not hardcoded canon. The user may add, rename, move, resize or delete roles.

## Lineages

Faction screen adds a `Lineages` lens for:

- Family
- Dynasty
- Bloodline
- House

A lineage may optionally be affiliated with a faction/country. Membership stores branch/title and chapter history without creating kinship relationships.

Example:

```text
House Valerius
Affiliation: Kingdom of Elysium
Aren — Heir — Main Branch — since Ch. 10
```

## Family Tree

Relationships adds a third projection:

```text
Graph | Matrix | Family Tree
```

Migration 013 adds built-in kinship relationship types:

- Parent / Child (directed inverse)
- Adoptive Parent / Adopted Child (directed inverse)
- Spouse (symmetric)
- Betrothed (symmetric)
- Sibling remains the existing symmetric type

The Family Tree reads the same chapter-filtered Relationship graph and renders only kinship edges. It never writes a parallel family table.

## Storage

Migration: `src-tauri/migrations/013_hierarchies_and_lineages.sql`

New tables:

- `faction_hierarchy_roles`
- `faction_role_assignments`
- `lineages`
- `lineage_memberships`

Native test source:

- `src-tauri/tests/hierarchy_lineage_flow.rs`

Python invariant suite:

- `tests/v0_7_3_1_hierarchy_lineage_invariants.py`
