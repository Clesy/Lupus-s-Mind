# R1 FREEZE — Temporal Relationships Foundation

## Status

**Invariant / architecture / TypeScript freeze: PASS**

**Full production compile freeze: pending local `npm install && npm run build` and `cargo test`** because this artifact environment has no Rust toolchain and no locally installed Vite binary.

## Frozen architectural boundary

```text
RelationshipType
      ↓
Relationship             canonical identity
      ↓
RelationshipState        immutable temporal interval payload
      ↓
RelationshipTransition   append-only audit

ChapterNumber
      ↓
GraphSnapshot / MatrixSnapshot   derived read models only
```

These types are intentionally separate from `TimelineEvent` and future combat/faction runtime models.

## Frozen temporal semantics

- State intervals are **half-open**: `[valid_from, valid_to)`.
- Chapter numbers must be positive.
- Intensity is constrained to **0..100**.
- At most one open state may exist per relationship.
- State intervals may not overlap.
- State payload is immutable after insertion.
- The only permitted state-row update is one-way closure: `valid_to = NULL -> chapter`.
- Canonical relationship identity (`type/source/target`) cannot be mutated in place.
- Transition rows cannot be updated in place.
- Graph/Matrix layout/projection data is never persisted as canonical truth.

## Directed / symmetric semantics

- Directed `A -> B` and `B -> A` may coexist.
- Symmetric reverse duplicates are rejected.
- Self relationships are rejected.
- Forward/inverse display labels are resolved from the relationship type registry.

## Transaction guarantees

`create`, `change_state`, `end`, and `reopen` use repository-level atomic operations. In a state change:

```text
BEGIN
close current state
insert next state
insert transition audit
COMMIT
```

Failure after the close operation rolls the transaction back and restores the previous open state.

## Golden temporal test

```text
Ch. 10  Trust = 90
Ch. 50  Trust = 35
Ch. 80  Relationship ended

snapshot(9)   -> none
snapshot(10)  -> 90
snapshot(49)  -> 90
snapshot(50)  -> 35
snapshot(79)  -> 35
snapshot(80)  -> none
snapshot(999) -> none
```

This passes in `tests/r1_invariants.py`. Equivalent Rust integration coverage is supplied in `src-tauri/tests/relationship_flow.rs` for execution on a machine with Cargo.

## Obsidian UI included

- Relationship chapter selector
- Graph projection
- Matrix projection
- Character relationship context
- Relationship inspector
- State transition history
- Create Relationship editor
- Change State
- End Relationship
- Reopen Relationship

All UI operations remain behind `RelationshipGateway`; direct Tauri IPC exists only in the infrastructure adapter.

## Deliberately outside R1

- dynamic RelationshipType CRUD
- retroactive arbitrary interval rewriting/splitting
- Timeline events
- Neo4j projection
- faction relations
- combat modifiers
- AI relationship inference
- persisted graph coordinates / physics

Those are later capabilities and must not weaken the frozen R1 temporal model.
