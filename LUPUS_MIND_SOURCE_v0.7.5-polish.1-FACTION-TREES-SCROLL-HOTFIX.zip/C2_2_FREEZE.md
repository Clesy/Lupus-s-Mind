# C2.2 — Status Effects / Turn Effects Freeze Contract

## Status

**Architecture / invariant freeze: PASS**  
**Full Rust + production bundle compile freeze: pending local toolchain**

C2.2 adds deterministic, durable turn effects without allowing combat runtime state to leak back into canonical knowledge.

## Frozen semantic boundary

```text
StatusEffectDefinition
    != CombatStatusEffectSpec
    != ActiveStatusEffect
    != StatusTick
    != CombatAction

CombatState != CanonicalState
CombatLog   != TimelineEvent
```

- `StatusEffectDefinition` is canonical vocabulary.
- `CombatStatusEffectSpec` is frozen into a combat skill snapshot at session start.
- `ActiveStatusEffect` is session-local runtime state.
- `StatusTick` is the pure resolved result of one runtime effect tick.
- `CombatAction` is durable runtime audit, not narrative history.

Once a session starts, the turn resolver does not consult live status-effect definitions, Skill rows, Items, Characters, Relationships or Timeline.

## C2.1 upgrade compatibility

C2.1 snapshots did not contain `effects` and runtime states did not contain `activeEffects`.

C2.2 explicitly marks both as serde-defaulted fields so persisted C2.1 running sessions load as:

```text
effects       = []
activeEffects = []
```

No destructive session migration is required.

## Canonical definition registry

`007_status_effects.sql` introduces:

```text
status_effect_definitions
skill_status_effects
combat_turn_executions
rebuilt combat_actions
```

The reference registry seeds:

- Burn
- Poison
- Regeneration
- Stun
- Armor Break
- Weakness

Definition timestamps are RFC3339-compatible.

Skills bind to definitions through `skill_status_effects`. The Skills UI exposes this through `StatusEffectGateway`; direct IPC remains confined to the Tauri adapter.

## Frozen stacking policy

The engine is policy-aware, but C2.2 intentionally supports only:

```text
StackingPolicy::Refresh
```

Refresh key:

```text
target combatant + effect definition id
```

Reapplying the same definition:

```text
instance identity       preserved
source combatant        replaced
power                   replaced
full duration           replaced
modifier                replaced
applied sequence        updated
active instance count   remains 1
```

No hidden `max(old,new)` or strongest-wins behavior exists.

`Independent`, `Intensity` and `StrongestWins` are deliberately deferred rather than silently approximated.

## TurnExecution atomic boundary

C2.2 replaces the C2.1 assumption that one command produces exactly one action.

```text
TurnExecution
  ├─ EffectTick
  ├─ EffectTick
  ├─ UseSkill
  ├─ EffectApplied / EffectRefreshed
  ├─ EffectExpired
  └─ TurnSkipped
```

All actions share one `turn_execution_id` and one SQLite transaction.

`CombatUnitOfWork::with_turn_transaction` owns:

```text
BEGIN
  load durable session
  resolve full turn lifecycle
  insert TurnExecution
  append every ordered CombatAction
  persist every runtime state
  persist turn/session cursor
COMMIT
```

Any failure rolls back **ticks, HP, Mana, cooldowns, effect durations, effect instances, action rows, TurnExecution and turn cursor together**.

## Frozen turn lifecycle

```text
START TURN
  ↓
Pre-Turn
  - deterministic ordered DoT / HoT / Stun ticks
  - defeat / stun gate
  ↓
Main Action
  - skipped when defeated or stunned
  - otherwise frozen SkillEvaluator + combat resolver
  - apply / refresh frozen skill effects
  ↓
Post-Turn
  - decrement effects that existed at turn start
  - expire zero-duration effects
  - newly applied/refreshed effects keep full incoming duration
  ↓
Victory check / advance turn
```

### Exact duration rule

A `duration = 2` effect that is already active when its owner turn begins:

```text
Turn N start     tick
Turn N end       2 -> 1
Turn N+1 start   tick
Turn N+1 end     1 -> 0 -> expire
```

It ticks exactly twice.

A status applied or refreshed during the current turn is **not decremented during that same post-turn phase**.

## Deterministic effect order

Pre-turn effects resolve in stable order by:

```text
(applied_sequence, definition_id)
```

Runtime UUID identity is never used to decide simulation order.

## Runtime modifiers

C2.2 intentionally freezes a narrow modifier algebra:

```text
ArmorMultiplier
DamageMultiplier
```

Derived combat values:

```text
runtime armor  = snapshot armor × active armor multipliers
raw skill power = SkillEvaluator output × active damage multipliers
```

Snapshot stats are never mutated.

## DoT / HoT / Stun semantics

- DoT applies direct runtime HP loss at start of the affected combatant's turn.
- HoT applies bounded runtime HP healing at start of turn.
- Stun produces a tick/audit entry and blocks Main Action for that turn.
- If a pre-turn effect reduces HP to zero, Main Action is skipped.
- Stat modifiers do not produce HP ticks; they participate in resolver-time derived values.

Damage-type-specific DoT mitigation is deferred; C2.2 effect `power` is direct tick power.

## Seeded RNG remains unchanged

Ambient randomness remains forbidden.

```text
roll = stable_rng(session.rng_seed, action.sequence_number, salt)
```

Because pre-turn actions consume deterministic sequence numbers, replay remains stable for the entire TurnExecution tree.

## Canonical isolation

Combat runtime tables still contain no foreign keys to canonical Character / Skill / StatusEffect / Item / Timeline / Relationship entities.

Canonical status definitions and skill bindings are read only while building a new session snapshot.

After start:

```text
use_skill()
  -> CombatSession snapshot/runtime only
```

No Apply-to-Canon path exists in C2.2.

## Golden freeze tests

### 1. Refresh

```text
existing Burn
power=20 duration=2

incoming Burn
power=30 duration=4

result
active count = 1
same runtime instance id
power = 30
duration = 4
new source retained
```

### 2. Exact tick count

```text
Burn duration=2
=> exactly two start-of-turn ticks
=> removed after second owner turn
=> no third tick
```

### 3. Atomic poison death

```text
Aren HP = 15
Poison = 20

Pre-Turn
  HP -> 0
  EffectTick logged
  Main Action skipped
```

Forced runtime-state failure after action insertion produces:

```text
Aren HP                 15
Poison duration          2
Turn index               0
Next action sequence     1
CombatAction count       0
TurnExecution count      0
```

Everything rolls back.

## Migration compatibility

Migration 007 rebuilds `combat_actions` to support typed multi-action turns and backfills C2.1 action history:

```text
legacy action
  -> synthetic legacy TurnExecution
  -> action preserved with same sequence and payload
```

The Rust action loader also accepts legacy C2.1 untagged `UseSkillCommand` / `CombatResolution` payloads while writing only the new tagged representation.

## UI boundary

Obsidian UI additions:

- active effect chips on combatants
- effect tick / apply / refresh / expire / skip log rows
- TurnExecution grouping marker in runtime audit
- canonical effect binding panel inside Skills

UI components call gateways only. `invoke()` remains isolated to infrastructure adapters.

## Deliberately deferred

- Independent stacks
- Intensity stacks
- Strongest-wins policy
- status application chance/resistance
- cleanses / dispels
- immunity
- AoE effects
- effect-triggered reactions
- damage-type-specific DoT mitigation
- loot / XP
- Apply-to-Canon
- automatic Timeline / Relationship writes

## Executed verification

```text
npm run verify                              PASS
TypeScript strict                          PASS
C1/I1/S1/R1/T1 regressions                PASS
C2.1 regression                           PASS
Canonical status registry                 PASS
Refresh golden rule                       PASS
Exact duration                            PASS
Same-turn duration preservation           PASS
Runtime canonical-FK isolation            PASS
Modifier projection semantics             PASS
Durable TurnExecution grouping            PASS
Poison-death skip                         PASS
Forced full-turn rollback                 PASS
C2.1 -> C2.2 migration compatibility      PASS
Gateway / IPC boundaries                  PASS
Rust delimiter/source sanity              PASS*
```

`*` Source sanity is explicitly not a Rust compiler substitute.

## Pending local compile seal

The packaging environment contains no Rust toolchain and no installed Vite binary/package tree.

No compile PASS is claimed for:

```bash
npm install
npm run verify
npm run build

cd src-tauri
cargo test
```

When those pass locally, C2.2 receives its final compile seal.
