# P1 — Desktop Integration Productization

Status: **integration/invariant gate passed; local Vite + Cargo compile seal pending**.

P1 deliberately adds no new canonical domain. It turns the existing C1/I1/S1/R1/T1/C2.x/G1 architecture into a coherent desktop product shell.

## Product shell changes

- `Dashboard` is now the default studio route.
- `Characters` is a first-class route; the previously backend-only C1 slice now has full Obsidian CRUD UI.
- Navigation is grouped by bounded-context intent: Studio / World / Systems / Simulation / Creative.
- Shell styling moved out of `items.css` into dedicated `shell.css`; a feature module no longer owns application-level layout.
- The top bar communicates current bounded-context meaning rather than duplicating module controls.
- Last-opened route is stored only as a UI preference; no canonical state is written to browser storage.

## Async route safety

Every route is rendered into a detached host under a monotonic `renderEpoch`.

```text
click Timeline
  ↓ epoch 10
async Timeline render

click Combat before Timeline finishes
  ↓ epoch 11
async Combat render

Timeline completes later
  ↓ epoch 10 != 11
DISCARD stale host
```

This prevents stale asynchronous modules from overwriting the currently selected screen.

All initial module failures are caught by one route-level error boundary with explicit retry.

## Dashboard semantics

Dashboard is a read-only aggregation over existing gateways:

- Character count
- Item count
- Skill count
- Running durable combat sessions
- Quick navigation to canonical, temporal, simulation and creative contexts

Dashboard has no `create`, `update` or `remove` path and therefore cannot become a hidden write-side orchestrator.

## Character product UI

C1 now has:

- searchable character list
- canonical detail view
- base-stat presentation
- biography/tags
- create/edit inspector
- guarded delete flow
- no direct Tauri IPC
- no inline style attributes

All mutation still flows through `CharacterGateway`.

## P1 invariant

```text
Product Shell ≠ Domain Orchestrator
```

The shell routes bounded contexts and handles presentation lifecycle. It does not perform domain writes or reach through gateway boundaries.

## Local seal

```bash
npm install
npm run verify
npm run build

cd src-tauri
cargo test
```
