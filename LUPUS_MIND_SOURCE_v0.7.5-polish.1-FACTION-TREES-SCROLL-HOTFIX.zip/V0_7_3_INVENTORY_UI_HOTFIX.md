# LUPUS'S MIND v0.7.3-alpha.2 — Inventory UI Hotfix

## Scope
This checkpoint changes Inventory presentation only. Domain semantics, migration 012, Item Ownership, Equipment and temporal ownership history are unchanged.

## Fixed
- Inventory no longer stretches a giant empty middle panel and pushes cards to the bottom.
- Layout is now `header -> controls -> state summary -> cards`.
- Chapter, Owner and item search controls remain visible directly above content.
- Added All / Equipped / Owned / Unowned quick filters with counts.
- Added selected-owner summary for the current chapter.
- Inventory items use the same professional card language as Item Gallery:
  - project-scoped item artwork,
  - rarity accent,
  - semantic stat/effect chips,
  - tags,
  - ownership status,
  - Transfer / Release actions.
- Existing item artwork is reused through AssetGateway; Inventory never reads files or calls Tauri directly.

## Architectural invariants
- `ItemOwnership != Equipment` remains unchanged.
- Inventory UI remains Gateway-only.
- No new SQLite migration.
- No ownership mutation occurs from merely filtering/searching cards.

## Verification
`npm run verify` passes through v0.7.3 Inventory hotfix invariants.
Native Rust build remains a Windows smoke-test step in environments without Cargo.
