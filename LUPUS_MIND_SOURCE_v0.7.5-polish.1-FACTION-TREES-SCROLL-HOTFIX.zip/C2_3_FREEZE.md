# C2.3 — Deterministic Replay & Debugger Freeze Contract

## Status

**Architecture / invariant freeze: PASS**  
**Full Rust + production bundle compile freeze: pending local toolchain**

C2.3 turns the durable combat audit into a read-only deterministic debugger without allowing replay to mutate the real session.

## Frozen boundary

```text
CombatUnitOfWork       -> WRITE / future / transaction
CombatReplayService    -> READ / history / reconstruction

CombatCommand
  != CombatResolution
  != CombatAction
  != CombatReplayMutation
  != ReplayFrame
```

`CombatUnitOfWork` has no `rebuild_state_to` API. Replay is a separate CQRS query capability.

## Atomic replay frame semantics

A SQLite turn commits as one `TurnExecution`. The debugger therefore exposes state frames at committed TurnExecution boundaries.

Actions inside a turn remain individually visible in **Resolution Anatomy**, but there is no fictional half-committed runtime state.

```text
TurnExecution #8
  #17 Poison Tick
  #18 Burn Tick
  #19 Dragon Strike
  #20 Effect Expired
        ↓
   one replay frame
```

`replay_at_sequence(#18)` resolves to the committed frame for the TurnExecution containing #18.

## Replay origin

New sessions receive:

```text
origin_sequence = 0
state = frozen combat-start state
```

C2.2 sessions created before migration 008 do not have state-complete replay events. Migration 008 therefore does **not invent history**. It stores their current committed state as a truthful legacy replay origin at their latest action sequence. Full replay continues from that point forward.

## State-complete machine stream

`008_combat_replay.sql` introduces append-only `combat_replay_events`.

Machine replay mutations are separate from human-readable `CombatAction` records:

```text
HpChanged
ManaChanged
DefeatedChanged
CooldownsChanged
ActiveEffectsChanged
TurnAdvanced
SessionStatusChanged
```

Each mutation carries `before -> after`. The reconstructor refuses to continue on a mismatch and returns a replay divergence instead of silently repairing history.

## Pure reconstructor

`CombatStateReconstructor` knows no:

```text
SQLite
Tauri
UI
clock
RNG
canonical repositories
```

It folds:

```text
ReplayOrigin + ordered CombatReplayEvent[] -> CombatReplayState
```

Replay never reruns SkillEvaluator or rolls RNG. The original committed mutations are replayed.

## Golden equality

The primary C2.3 invariant is:

```text
REPLAY(latest) == LIVE(runtime_state)
```

The equality includes:

- HP
- Mana
- cooldowns
- active effects + durations
- defeated flags
- round
- turn index
- session status
- next action sequence
- frozen combatant snapshots

## Determinism seal

The same origin + event stream is reconstructed 1000 times and produces the same state fingerprint every time.

Forward / backward / forward scrub always reconstructs from immutable history rather than mutating the live runtime.

## Append-only + rollback

Replay mutations are written inside the same SQLite transaction as:

- TurnExecution
- CombatActions
- combatant runtime state
- session cursor/status

A forced runtime write failure rolls back the replay event rows as well.

Persisted replay events reject UPDATE/DELETE mutation.

## Read-only debugger

Frontend replay state is view state only.

```text
|<<   replay origin
<     previous TurnExecution
LIVE  exit replay and return to real runtime
>     next TurnExecution
>>|   latest replay frame
```

While any replay frame is open, Main Action controls are disabled. The backend does not expose any `use_skill(... replay_sequence ...)` surface, so historical mutation cannot be requested even if the UI is bypassed.

## Resolution Anatomy

The Obsidian debugger exposes the selected execution's ordered CombatActions and skill resolution values such as:

- raw power
- resolved power
- HP/Mana delta
- crit roll
- dodge roll

CombatAction remains runtime audit and never becomes TimelineEvent.

## Explicitly out of scope

- replay branching / alternate combat forks
- undoing the live session
- checkpoint optimization
- replay-driven canonical writes
- timeline promotion
- AoE / reactions / counter systems

These require later bounded capabilities and cannot leak into C2.3.

## Local compile seal

```bash
npm install
npm run verify
npm run build

cd src-tauri
cargo test
```
