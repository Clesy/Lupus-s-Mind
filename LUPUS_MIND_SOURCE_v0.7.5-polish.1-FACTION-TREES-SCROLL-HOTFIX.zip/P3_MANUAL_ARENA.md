# P3 Manual Arena UX Contract

The primary Combat screen is an author-controlled, ephemeral damage sandbox.

- No durable combat session is created when the screen is used.
- Attacker, target and action are explicitly selected by the author.
- Nothing attacks automatically.
- `Normal Saldırı` is always available through the reserved `runtime:basic_attack` skill snapshot.
- Learned physical/magical skills are loaded for the selected attacker.
- The swap control exchanges attacker and target without executing an action.
- The critical checkbox forces a guaranteed critical hit at the combat resolver boundary; the existing x2 critical multiplier is reused.
- HP/Mana changes live only in frontend RAM and reset when the sandbox is reloaded.
- Damage math remains Rust-backed through `combat_preview_impact`; the UI contains no duplicate damage formula.
- Legacy durable sessions can be purged from the Manual Arena, and the Manual Arena creates no new session rows.

Native Rust compile/test must be re-run on the Windows development machine after applying this patch.
