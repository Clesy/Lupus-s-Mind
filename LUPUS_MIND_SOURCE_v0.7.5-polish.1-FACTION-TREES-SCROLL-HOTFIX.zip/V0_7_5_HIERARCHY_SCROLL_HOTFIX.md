# LUPUS'S MIND — v0.7.5 Hierarchy Scroll Hotfix

## Problem
The Factions → Hierarchy organization chart could extend below the visible route instead of becoming independently scrollable.

## Fix
- Hierarchy mode now opts into a bounded `hierarchy-body` layout.
- The toolbar and organization-chart header stay visible.
- Only the hierarchy tree canvas receives vertical/horizontal scrolling.
- The right role inspector keeps its own independent scroll.
- Leaving Hierarchy clears the mode-specific body class so other Factions tabs keep their existing layout.

No domain, SQLite, migration, hierarchy semantics, or canonical data behavior changed.

## Companion fix — Lineages

The same bounded viewport behavior now applies to the Lineages tree: the toolbar/header stays fixed, the lineage canvas scrolls inside its panel, and the inspector remains independently scrollable. Other Factions modes are unchanged.
