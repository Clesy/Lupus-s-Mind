# v0.7.3-alpha.3 Windows Smoke Test

Run from the extracted source root:

```powershell
npm.cmd install
npm.cmd run verify
npm.cmd run build
cargo test --manifest-path .\src-tauri\Cargo.toml
npm.cmd run tauri:dev
```

## Hierarchy smoke

1. Create or open a `clan` faction.
2. Open `Factions -> Hierarchy`.
3. Click `Recommended structure`.
4. Confirm Clan Leader / Vice Leader / Grand Elder / Elite Captain etc. appear as a tree.
5. Assign Character A as Clan Leader at Chapter 1.
6. Confirm assigning Character B to the same one-seat office is rejected while A is active.
7. End A's office at Chapter 50; assign B at Chapter 50.
8. Inspect Chapter 30: A must be shown. Inspect Chapter 50+: B must be shown.
9. Create a custom role, change its parent and capacity, save it and restart the app. It must persist.

Repeat with a `kingdom` faction and confirm the recommended structure contains Monarch / Prime Minister / Grand Marshal / Ministers / Governors / Generals.

## Lineage smoke

1. Open `Factions -> Lineages`.
2. Create `House Valerius`, kind `dynasty`, optionally affiliate it with a kingdom.
3. Add Aren as `Heir`, branch `Main`, Chapter 10.
4. Restart the app and verify membership persists.
5. End membership later and confirm the selected chapter changes visibility using `[joined,left)` semantics.

## Family Tree smoke

1. Create characters Parent, Child and Spouse.
2. In Relationships create `Parent` from Parent -> Child at Chapter 1.
3. Create `Spouse` between Parent and Spouse.
4. Open `Family Tree` and verify parent/child generation and spouse link appear.
5. Change the Relationship chapter and verify the tree reflects active temporal states.
6. Click a family edge; the normal Relationship Inspector should open its canonical history.

## Regression checks

- Faction Membership still works independently from hierarchy positions.
- Relationship Graph and Matrix remain unchanged.
- Inventory / Quests / Secrets still open.
- Manual Combat Arena remains manual-only.
- Project switching preserves complete isolation.
