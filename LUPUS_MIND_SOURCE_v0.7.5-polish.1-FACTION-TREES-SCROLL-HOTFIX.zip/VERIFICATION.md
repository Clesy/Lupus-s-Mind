# Verification — v0.7.4-alpha.2

## Sandbox verification

- `tsc -p tsconfig.json --noEmit`: **PASS**
- `npm run verify`: **PASS**
- v0.7.4 Atlas + viewport/zoom invariant suite: **PASS**
- SQLite migration/invariant suite: **PASS**
- Rust source sanity: **PASS** (not a compiler substitute)
- Deterministic generator purity/static invariants: **PASS**
- Atlas Gateway/Tauri boundary invariants: **PASS**
- Cursor-anchored wheel zoom, +/-/Fit controls, bounded zoom and drag-pan static contracts: **PASS**

Captured outputs:

- `V0_7_4_ALPHA2_VERIFY_OUTPUT.txt`
- `V0_7_4_ALPHA2_VERIFY_EXIT.txt` (`0`)

## Toolchain limitations in this sandbox

`npm run build` was attempted but cannot run because this source-only sandbox does not contain the local Vite dependency/binary (`vite: not found`, exit 127).

Native Cargo verification was attempted but `cargo` is unavailable in this sandbox (exit 127).

Windows remains the promotion gate:

```powershell
npm.cmd install
npm.cmd run verify
npm.cmd run build
cargo test --manifest-path .\src-tauri\Cargo.toml
npm.cmd run tauri:dev
```

## alpha.2 Atlas camera contract

```text
Map camera (zoom/pan) != AtlasMap persistence
Pin drag              = MapPin projection update
GeneratedMapDraft      != Canon
```

- Fit camera is 100%; zoom is bounded to 600%.
- Wheel zoom is anchored at the pointer.
- Empty-map drag pans; pin drag remains independent.
- Pin placement converts screen coordinates through the current SVG camera before normalizing to `0..1`.
- Atlas viewport fills the route workspace and inspector scrolling is independent.
- No migration/domain change from alpha.1.


## v0.7.4-alpha.3 Generator Quality

- `npm run verify`: PASS after generator-v2 changes.
- `tsc -p tsconfig.json --noEmit`: PASS.
- Atlas generator quality invariants: PASS.
- Rust source sanity: PASS (not a compiler substitute).
- Native `cargo test` must be sealed on Windows.
