# LUPUS'S MIND — v0.7.3 World Systems Alpha

Version: **0.7.3-alpha.1**

This checkpoint adds four connected world-management bounded contexts without collapsing them into existing canon concepts.

## Frozen distinctions

```text
Faction            != Character Relationship
FactionMembership  != Character identity
ItemOwnership      != Equipment
Quest              != TimelineEvent
QuestObjective     != Canonical StateTransition
Secret             != CharacterKnowledge
SecretKnowledge    != Relationship
```

## FA1 — Factions / Clans

- Faction / Clan / Guild / Kingdom / Order / House records.
- Description, motto, accent color and tags.
- Chapter-aware character memberships using `[joined_chapter, left_chapter)`.
- Only one open membership for the same Character + Faction pair.
- Chapter-aware faction diplomacy states: allied / friendly / neutral / tense / hostile / war / vassal.
- Diplomacy Matrix reads the selected chapter.
- Relation changes close the previous state and open a new state; history is preserved.

## INV1 — Inventory / Item Ownership

- Physical Item ownership is independent from Equipment.
- Owners may be Characters or Factions.
- Ownership uses `[acquired_chapter, released_chapter)` history.
- Only one open owner exists for one physical item.
- Transfer closes the old ownership and creates the new one.
- Ownership operations do not silently equip/unequip items.
- Character Inspector shows current owned items.
- Item Inspector shows the current owner.

## Q1 — Quests

- Planned / Active / Completed / Failed / Abandoned lifecycle.
- Summary, description, quest giver, faction, start/completion chapter and tags.
- Ordered objectives with completion state and optional completion chapter.
- Quest links storage supports Character / Item / Faction / Lore / Chapter references.
- Deleting a Quest cascades objectives and its link records.
- Quest completion does not automatically create a TimelineEvent.

The alpha UI exposes the primary Quest record, giver/faction connection and objective workflow. The generic related-record link editor is foundation-ready but intentionally not expanded into a large UI in this checkpoint.

## SEC1 — Secrets / Knowledge Matrix

- Secret record with Minor / Major / Critical importance.
- Per-character knowledge states: Knows / Suspects / Misinformed.
- Temporal state uses `[learned_chapter, lost_chapter)`.
- Matrix can answer who knew/suspected/misunderstood a secret at Chapter X.
- Knowledge changes do not mutate Character canonical state.

## Navigation integration

- New sidebar routes: Inventory, Factions, Quests, Secrets.
- Quick Create includes Faction / Quest / Secret.
- Global Search includes Faction / Quest / Secret.
- Character Inspector surfaces current Faction Membership + Inventory context.
- Item Inspector surfaces current ownership.

## Storage

Migration `012_world_systems.sql` adds the new tables and indexes. All data remains inside the active project's isolated SQLite database.

## Verification

`npm run verify` passes from C1 through v0.7.3, including `tests/v0_7_3_world_systems_invariants.py`.

A native Rust integration test is included at:

`src-tauri/tests/world_systems_flow.rs`

This environment does not have Cargo or local Vite installed. Windows promotion still requires `npm run build` and `cargo test`.
