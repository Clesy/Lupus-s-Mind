# LUPUS'S MIND v0.7.1-alpha.2 — Item Card & Switcher Polish

## Scope
This checkpoint is intentionally narrow:

- Items use the same card hierarchy as Characters.
- Item artwork can be selected, optimized and persisted per project.
- Item cards show artwork (or item-type glyph fallback), rarity, semantic stat/effect chips and tags.
- Item inspector shows the same persisted artwork and provides Artwork / Remove art actions.
- Project Switcher no longer renders a dropdown-arrow glyph.
- Character Inspector portrait now fully replaces the fallback initial when artwork exists.

## Asset boundary
Item artwork follows the same offline-first rule as character portraits:

```text
ItemScreen
  -> AssetGateway
    -> Tauri asset commands
      -> FileSystemAssetStore
        -> <active-project>-assets/items/<item-id>.webp
```

No base64 image payload is stored in SQLite. The active project database path determines the asset directory, so projects remain isolated.

## Verification
`npm run verify` passes through the v0.7.1 item-card invariant suite.

Native Rust compilation is still a Windows-side seal for this checkpoint because Cargo/Rust are unavailable in the packaging environment.
