from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
violations=[]
for p in (ROOT/'frontend/modules').rglob('*.ts'):
    if '/infrastructure/' not in p.as_posix() and 'invoke(' in p.read_text():
        violations.append(f'IPC leak: {p.relative_to(ROOT)}')
for p in (ROOT/'src-tauri/src').glob('*/application/**/*.rs'):
    text=p.read_text()
    if 'rusqlite' in text or 'Sqlite' in text or 'app_state' in text:
        violations.append(f'infrastructure leak: {p.relative_to(ROOT)}')
for p in (ROOT/'src-tauri/src').rglob('*.rs'):
    if 'unwrap(' in p.read_text():
        violations.append(f'production unwrap: {p.relative_to(ROOT)}')
assert not violations, '\n'.join(violations)
print('PASS UI has no direct Tauri IPC outside infrastructure adapters')
print('PASS Rust application layers have no SQLite/AppState dependency')
print('PASS production Rust source contains no unwrap()')
print('ALL ARCHITECTURE INVARIANTS PASSED')
