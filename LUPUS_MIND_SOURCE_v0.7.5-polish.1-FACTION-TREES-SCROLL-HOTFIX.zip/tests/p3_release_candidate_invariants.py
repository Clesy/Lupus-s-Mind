from pathlib import Path
import json, re, sys

ROOT=Path(__file__).resolve().parents[1]
failures=[]
def check(cond,msg):
    if cond: print('PASS',msg)
    else: print('FAIL',msg); failures.append(msg)

pkg=json.loads((ROOT/'package.json').read_text())
cfg=json.loads((ROOT/'src-tauri/tauri.conf.json').read_text())
cargo=(ROOT/'src-tauri/Cargo.toml').read_text()
cv=re.search(r'^version\s*=\s*"([^"]+)"',cargo,re.M)
check(bool(re.match(r'^0\.7\.\d+-(?:alpha|polish)\.\d+$',pkg.get('version',''))),'package version is v0.7 prerelease semver')
check(cfg.get('version')==pkg.get('version') and cv and cv.group(1)==pkg.get('version'),'package / Tauri / Cargo versions are aligned')
check(cfg.get('bundle',{}).get('active') is True,'Tauri bundling is active')
check(cfg.get('bundle',{}).get('targets')==['nsis'],'Windows release target is explicit NSIS')
check(cfg.get('bundle',{}).get('windows',{}).get('nsis',{}).get('installMode')=='currentUser','NSIS installer defaults to non-admin current-user install')
check(cfg.get('bundle',{}).get('windows',{}).get('webviewInstallMode',{}).get('type')=='downloadBootstrapper','installer has explicit WebView2 bootstrap policy')
check('release:preflight' in pkg.get('scripts',{}) and 'release:gate' in pkg.get('scripts',{}),'package exposes preflight and full release gates')
check('test:p3' in pkg.get('scripts',{}) and 'npm run test:p3' in pkg.get('scripts',{}).get('verify',''),'P3 invariants participate in global verification')
pre=(ROOT/'scripts/release-preflight.mjs').read_text()
check('cargo' in pre and 'rustc' in pre and 'node_modules/.bin/vite' in pre,'preflight checks native and frontend toolchains')
gate=(ROOT/'scripts/release-gate.mjs').read_text()
for token in ['release:preflight','run\", \"verify','run\", \"build','cargo','tauri:build']:
    check(token in gate,f'release gate includes {token}')
workflow=(ROOT/'.github/workflows/windows-release-gate.yml').read_text()
check('runs-on: windows-latest' in workflow,'CI release gate is Windows-native')
check('cargo test --manifest-path src-tauri/Cargo.toml' in workflow,'CI runs Rust integration tests')
check('npm run tauri:build' in workflow and '*-setup.exe' in workflow,'CI builds and captures NSIS installer')
check('[profile.release]' in cargo and 'lto = true' in cargo and 'panic = "abort"' in cargo,'Rust release profile is hardened for desktop bundle')
bootstrap=(ROOT/'scripts/windows-bootstrap.ps1').read_text()
check(('npm install --no-audit --no-fund' in bootstrap or 'npm.cmd install --no-audit --no-fund' in bootstrap) and 'cargo generate-lockfile' in bootstrap,'Windows bootstrap creates dependency lockfiles before seal')
check((ROOT/'P3_WINDOWS_SMOKE_TEST.md').exists() and 'Replay' in (ROOT/'P3_WINDOWS_SMOKE_TEST.md').read_text(),'manual Windows native smoke-test contract is present')
if failures:
    print(f'P3 FAILED: {len(failures)} invariant(s)')
    sys.exit(1)
print('ALL P3 RELEASE-CANDIDATE INVARIANTS PASSED')
