from __future__ import annotations
from pathlib import Path
import json, sqlite3, tempfile

ROOT=Path(__file__).resolve().parents[1]
MIGRATIONS=[ROOT/'src-tauri/migrations'/f'{i:03d}_{name}.sql' for i,name in [
(1,'initial_schema'),(2,'items_and_equipment'),(3,'skills'),(4,'relationships'),(5,'timeline'),(6,'combat_runtime'),(7,'status_effects')]]

def migrate(conn:sqlite3.Connection, through=7):
    conn.execute('PRAGMA foreign_keys=ON')
    for p in MIGRATIONS[:through]: conn.executescript(p.read_text())

def stats(): return {'strength':0,'agility':20,'vitality':0,'intelligence':0,'mind':0,'weaponDamage':0,'armor':0,'armorPenetration':0,'magicPenetration':0,'criticalChance':0,'damageReduction':0}
def snap(cid,name,hp=500,mana=100): return {'sourceCharacterId':cid,'displayName':name,'effectiveStats':stats(),'maxHp':hp,'maxMana':mana,'skills':[]}
def active(instance='burn-instance',definition='effect-burn',name='Burn',power=20,duration=2,source='aren',kind='damage_over_time',applied=1,modifier=None): return {'instanceId':instance,'definitionId':definition,'name':name,'sourceCombatantId':source,'kind':kind,'stackingPolicy':'refresh','power':power,'durationRemaining':duration,'modifier':modifier,'appliedSequence':applied}
def state(hp=500,mana=100,effects=None,defeated=False): return {'currentHp':hp,'currentMana':mana,'isDefeated':defeated,'cooldowns':[],'activeEffects':effects or []}
def put_session(conn, actor_state=None,target_state=None):
    conn.execute("INSERT INTO combat_sessions(id,status,rng_seed,round_number,turn_index,next_action_sequence,created_at,updated_at) VALUES('s1','running','42',1,0,1,'2026-08-27T12:00:00Z','2026-08-27T12:00:00Z')")
    conn.execute("INSERT INTO combatants(id,session_id,source_character_id,position,snapshot,runtime_state) VALUES('aren','s1','char-aren',0,?,?)",(json.dumps(snap('char-aren','Aren')),json.dumps(actor_state or state())))
    conn.execute("INSERT INTO combatants(id,session_id,source_character_id,position,snapshot,runtime_state) VALUES('elysia','s1','char-elysia',1,?,?)",(json.dumps(snap('char-elysia','Elysia',400,80)),json.dumps(target_state or state(400,80))))
    conn.commit()

def action(conn, aid, seq, kind, execution='turn-1',actor='aren',target='elysia',resolution=None):
    conn.execute("INSERT INTO combat_actions(id,session_id,turn_execution_id,sequence_number,round_number,turn_index,actor_combatant_id,target_combatant_id,action_kind,input_json,resolution_json,created_at) VALUES(?,?,?,?,1,0,?,?,?,?,?,'2026-08-27T12:01:00Z')",(aid,'s1',execution,seq,actor,target,kind,'{}',json.dumps(resolution or {})))

# Canonical registry exists and C2.2 deliberately supports only Refresh.
conn=sqlite3.connect(':memory:');migrate(conn)
rows=conn.execute("SELECT effect_key,kind,stacking_policy,duration_turns,power,modifier_kind,modifier_multiplier,created_at FROM status_effect_definitions ORDER BY effect_key").fetchall()
assert len(rows)==6 and {r[0] for r in rows}>={'burn','poison','regeneration','stun','armor_break','weakness'}
assert all(r[2]=='refresh' for r in rows)
assert all('T' in r[7] and r[7].endswith('Z') for r in rows)
print('PASS canonical StatusEffectDefinition registry is typed, RFC3339 and Refresh-only in C2.2')

# Skill -> definition binding is typed and duplicate-proof.
conn.execute("INSERT INTO skills(id,name,description,kind,resource_kind,base_power,resource_cost,cooldown_turns,scaling,tags,created_at,updated_at) VALUES('skill-burn','Fire Slash','','physical','mana',10,5,0,'[]','[]','2026-08-27T12:00:00Z','2026-08-27T12:00:00Z')")
conn.execute("INSERT INTO skill_status_effects(skill_id,effect_definition_id) VALUES('skill-burn','effect-burn')")
try:
    conn.execute("INSERT INTO skill_status_effects(skill_id,effect_definition_id) VALUES('skill-burn','effect-burn')")
    raise AssertionError('duplicate skill status effect binding accepted')
except sqlite3.IntegrityError: conn.rollback()
print('PASS Skill -> StatusEffectDefinition binding is canonical and duplicate-proof')

# Refresh golden rule: identity preserved, source/power/duration replaced, active count stays one.
before=active(power=20,duration=2,source='old-source',applied=3)
incoming={'definitionId':'effect-burn','name':'Burn','kind':'damage_over_time','stackingPolicy':'refresh','power':30,'durationTurns':4,'modifier':None}
def refresh(existing:dict,incoming:dict,new_source:str,new_sequence:int)->dict:
    assert existing['definitionId']==incoming['definitionId']
    result=dict(existing)
    result.update({'sourceCombatantId':new_source,'name':incoming['name'],'kind':incoming['kind'],'stackingPolicy':incoming['stackingPolicy'],'power':incoming['power'],'durationRemaining':incoming['durationTurns'],'modifier':incoming['modifier'],'appliedSequence':new_sequence})
    return result
after=refresh(before,incoming,'new-source',9)
assert after['instanceId']==before['instanceId'] and after['power']==30 and after['durationRemaining']==4 and after['sourceCombatantId']=='new-source'
assert len([after])==1
print('PASS Refresh preserves runtime instance identity and replaces source/power/duration')

# Exact duration semantics: duration=2 ticks exactly twice and disappears before a third tick.
def own_turn(effect:dict)->tuple[int,dict|None]:
    tick=1 if effect['kind'] in ('damage_over_time','heal_over_time','stun') else 0
    next_effect=dict(effect);next_effect['durationRemaining']-=1
    return tick, next_effect if next_effect['durationRemaining']>0 else None
e=active(duration=2); ticks=0
for _ in range(3):
    if e is None: continue
    t,e=own_turn(e);ticks+=t
assert ticks==2 and e is None
print('PASS duration=2 produces exactly two start-of-turn ticks and then expires')

# Newly applied/refreshed self-effects keep full duration through the same post-turn phase.
turn_start_sequence=10
self_effect=active(duration=2,applied=10)
if self_effect['appliedSequence'] < turn_start_sequence:
    self_effect['durationRemaining']-=1
assert self_effect['durationRemaining']==2
print('PASS same-turn applied/refresh effect keeps full incoming duration')

# Combat runtime tables remain isolated from canonical status/skill/character tables.
combat_fk_targets=set()
for table in ('combatants','combat_actions','combat_turn_executions'):
    combat_fk_targets.update(row[2] for row in conn.execute(f"PRAGMA foreign_key_list({table})"))
assert combat_fk_targets <= {'combat_sessions','combat_turn_executions'}, combat_fk_targets
print('PASS C2.2 combat runtime adds no canonical foreign keys')

# Runtime modifiers are projection-time multipliers; snapshot values are not mutated.
snapshot_armor=100.0; armor_break=0.5; snapshot_damage=120.0; weakness=0.8
assert snapshot_armor*armor_break==50.0 and snapshot_damage*weakness==96.0
assert snapshot_armor==100.0 and snapshot_damage==120.0
print('PASS runtime modifiers derive effective combat values without mutating snapshots')

# TurnExecution groups multiple actions under one transaction and survives restart.
with tempfile.TemporaryDirectory() as td:
    db=Path(td)/'c22.sqlite';conn=sqlite3.connect(db);migrate(conn);put_session(conn,actor_state=state(100,100,[active(power=10,duration=2)]))
    conn.execute('BEGIN')
    conn.execute("INSERT INTO combat_turn_executions(id,session_id,round_number,turn_index,actor_combatant_id,created_at) VALUES('turn-1','s1',1,0,'aren','2026-08-27T12:01:00Z')")
    action(conn,'a1',1,'effect_tick',resolution={'hpDelta':-10})
    action(conn,'a2',2,'use_skill',resolution={'hpDelta':-120})
    action(conn,'a3',3,'effect_expired',resolution={'durationRemaining':0})
    conn.execute("UPDATE combatants SET runtime_state=? WHERE id='aren'",(json.dumps(state(90,80,[])),))
    conn.execute("UPDATE combat_sessions SET turn_index=1,next_action_sequence=4,updated_at='2026-08-27T12:01:00Z' WHERE id='s1'")
    conn.commit();conn.close()
    reopened=sqlite3.connect(db);reopened.execute('PRAGMA foreign_keys=ON')
    assert reopened.execute("SELECT COUNT(DISTINCT turn_execution_id),COUNT(*) FROM combat_actions WHERE session_id='s1'").fetchone()==(1,3)
    runtime=json.loads(reopened.execute("SELECT runtime_state FROM combatants WHERE id='aren'").fetchone()[0]);assert runtime['currentHp']==90 and runtime['currentMana']==80
    reopened.close()
print('PASS one durable TurnExecution groups multiple ordered actions and survives restart')

# Atomic Poison death: on success tick+skip+state are one committed turn.
conn=sqlite3.connect(':memory:');migrate(conn);put_session(conn,actor_state=state(15,100,[active(definition='effect-poison',name='Poison',power=20,duration=2)]))
conn.execute('BEGIN');conn.execute("INSERT INTO combat_turn_executions VALUES('turn-death','s1',1,0,'aren','2026-08-27T12:01:00Z')")
action(conn,'tick-death',1,'effect_tick','turn-death','aren','aren',{'hpDelta':-20,'preventsAction':False})
action(conn,'skip-death',2,'turn_skipped','turn-death','aren','aren',{'reason':'defeated_by_start_of_turn_effect'})
new_effect=active(definition='effect-poison',name='Poison',power=20,duration=1)
conn.execute("UPDATE combatants SET runtime_state=? WHERE id='aren'",(json.dumps(state(0,100,[new_effect],True)),));conn.execute("UPDATE combat_sessions SET status='completed',next_action_sequence=3,completed_at='2026-08-27T12:01:00Z' WHERE id='s1'");conn.commit()
rt=json.loads(conn.execute("SELECT runtime_state FROM combatants WHERE id='aren'").fetchone()[0]);kinds=[r[0] for r in conn.execute("SELECT action_kind FROM combat_actions ORDER BY sequence_number")]
assert rt['currentHp']==0 and rt['isDefeated'] is True and kinds==['effect_tick','turn_skipped'] and 'use_skill' not in kinds
print('PASS Poison can defeat at pre-turn, logs EffectTick, skips Main Action and ends turn')

# Forced failure after action writes rolls back execution, tick, HP, duration, turn and logs.
conn=sqlite3.connect(':memory:');migrate(conn);put_session(conn,actor_state=state(15,100,[active(definition='effect-poison',name='Poison',power=20,duration=2)]))
conn.execute("CREATE TEMP TRIGGER fail_runtime BEFORE UPDATE OF runtime_state ON combatants WHEN OLD.id='aren' BEGIN SELECT RAISE(ABORT,'forced c2.2 state failure'); END;")
try:
    conn.execute('BEGIN');conn.execute("INSERT INTO combat_turn_executions VALUES('turn-fail','s1',1,0,'aren','2026-08-27T12:01:00Z')")
    action(conn,'tick-fail',1,'effect_tick','turn-fail','aren','aren',{'hpDelta':-20})
    action(conn,'skip-fail',2,'turn_skipped','turn-fail','aren','aren',{'reason':'defeated'})
    conn.execute("UPDATE combatants SET runtime_state=? WHERE id='aren'",(json.dumps(state(0,100,[],True)),));conn.commit();raise AssertionError('forced failure did not fire')
except sqlite3.DatabaseError: conn.rollback()
rt=json.loads(conn.execute("SELECT runtime_state FROM combatants WHERE id='aren'").fetchone()[0])
assert rt['currentHp']==15 and rt['activeEffects'][0]['durationRemaining']==2
assert conn.execute("SELECT COUNT(*) FROM combat_actions").fetchone()[0]==0 and conn.execute("SELECT COUNT(*) FROM combat_turn_executions").fetchone()[0]==0
assert conn.execute("SELECT turn_index,next_action_sequence FROM combat_sessions WHERE id='s1'").fetchone()==(0,1)
print('PASS forced C2.2 mid-turn failure rolls back effects, HP, turn execution and every action')

# Migration compatibility: C2.1 action is preserved and grouped when 007 is applied.
conn=sqlite3.connect(':memory:');migrate(conn,through=6);put_session(conn)
old_input=json.dumps({'sessionId':'s1','actorCombatantId':'aren','targetCombatantId':'elysia','skillId':'dragon'})
old_res=json.dumps({'rawPower':120,'resolvedPower':120,'hpDelta':-120,'manaDelta':-20,'wasCritical':False,'wasDodged':False,'rollCritical':0,'rollDodge':0})
conn.execute("INSERT INTO combat_actions(id,session_id,sequence_number,round_number,turn_index,actor_combatant_id,target_combatant_id,action_kind,input_json,resolution_json,created_at) VALUES('legacy-a','s1',1,1,0,'aren','elysia','use_skill',?,?,'2026-08-27T12:01:00Z')",(old_input,old_res));conn.commit();conn.executescript(MIGRATIONS[6].read_text())
row=conn.execute("SELECT turn_execution_id,action_kind FROM combat_actions WHERE id='legacy-a'").fetchone();assert row and row[0].startswith('legacy:s1:') and row[1]=='use_skill'
assert conn.execute("SELECT COUNT(*) FROM combat_turn_executions").fetchone()[0]==1
print('PASS migration 007 preserves C2.1 action history and backfills TurnExecution grouping')

# Source-level architectural contracts.
domain=(ROOT/'src-tauri/src/combat/domain/combat.rs').read_text();app=(ROOT/'src-tauri/src/combat/application/use_cases.rs').read_text();repo=(ROOT/'src-tauri/src/combat/infrastructure/sqlite_combat_repository.rs').read_text();ui=(ROOT/'frontend/modules/combat/ui/CombatScreen.ts').read_text();binding=(ROOT/'frontend/modules/status_effects/ui/SkillEffectBindingPanel.ts').read_text()
assert 'StatusEffectDefinition' not in app.split('pub fn use_skill',1)[1], 'live canonical effect definition leaked into turn resolver'
start_block=app.split('pub struct StartCombatServices',1)[1].split('pub fn get_session',1)[0]
assert '.status_effects' in start_block and '.list_for_skill' in start_block, 'effect definitions are not frozen during combat start'
assert '#[serde(default)] pub effects' in domain and '#[serde(default)] pub active_effects' in domain, 'C2.1 session JSON upgrade safety missing'
assert 'CombatStackingPolicy::Refresh' in app and 'Independent' not in domain and 'Intensity' not in domain
assert 'with_turn_transaction' in app and 'Vec<CombatAction>' in repo and 'combat_turn_executions' in repo
assert 'thread_rng' not in app and 'rand::' not in app
assert 'timeline::' not in app and 'relationships::' not in app
assert 'gateway.previewImpact' in ui and 'invoke(' not in ui and 'style="' not in ui
assert 'gateway.setForSkill' in binding and 'invoke(' not in binding
print('PASS C2.2 durable runtime remains frozen/UoW-batched; Manual Arena stays read-only behind gateways')
print('ALL C2.2 INVARIANTS PASSED')
