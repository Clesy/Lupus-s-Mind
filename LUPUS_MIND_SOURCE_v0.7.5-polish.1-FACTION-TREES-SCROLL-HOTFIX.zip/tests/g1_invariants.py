from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
domain=(ROOT/'src-tauri/src/creative_generators/domain/generator.rs').read_text();app=(ROOT/'src-tauri/src/creative_generators/application/generate.rs').read_text();ui=(ROOT/'frontend/modules/creative_generators/ui/GeneratorScreen.ts').read_text();gateway=(ROOT/'frontend/modules/creative_generators/application/GeneratorGateway.ts').read_text();lib=(ROOT/'src-tauri/src/lib.rs').read_text()
assert all(k in domain for k in ['CharacterName','LocationName','ItemName','GeneratorTone','GeneratedCandidate'])
assert 'CharacterRepository' not in app and 'ItemRepository' not in app and 'TimelineRepository' not in app and 'rusqlite' not in app and 'Sqlite' not in app
assert 'thread_rng' not in app and 'rand::' not in app and 'mix(seed' in app
assert 'GeneratedCandidate' in gateway and 'GeneratorGateway' in gateway
assert 'invoke(' not in ui and 'GeneratedCandidate ≠ Character / Location / Item' in ui
assert 'creative_generate' in lib
print('PASS G1 supports Character / Location / Item candidate generation')
print('PASS G1 is deterministic and has zero canonical repository/write dependency')
print('PASS G1 UI is gateway-only and explicitly non-canonical')
print('ALL G1 INVARIANTS PASSED')
