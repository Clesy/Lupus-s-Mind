from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

item_screen = (ROOT / "frontend/modules/items/ui/ItemScreen.ts").read_text()
item_editor = (ROOT / "frontend/modules/items/ui/ItemEditor.ts").read_text()
equipment_panel = (ROOT / "frontend/modules/equipment/ui/CharacterEquipmentPanel.ts").read_text()
equipment_gateway = (ROOT / "frontend/modules/equipment/application/EquipmentGateway.ts").read_text()
equipment_use_cases = (ROOT / "src-tauri/src/equipment/application/use_cases.rs").read_text()

assert "gateway.create" in item_editor, "Item Editor must create through ItemGateway"
assert "gateway.update" in item_editor, "Item Editor must update through ItemGateway"
assert "gateway.remove" in item_screen, "Item delete flow must use ItemGateway"
assert "compatibleItems" in equipment_gateway, "EquipmentGateway must expose compatibility query"
assert "gateway.compatibleItems" in equipment_panel, "Inspector must query compatibility from gateway"
assert "gateway.equip" in equipment_panel and "gateway.unequip" in equipment_panel, "Inspector must support equip and unequip"
assert "compatible(item.item_type, slot)" in equipment_use_cases, "Rust application layer must apply domain compatibility"
assert "find_by_item" in equipment_use_cases, "Compatibility query must surface unique-equipment occupancy"

for path in (ROOT / "frontend/modules/items/ui").glob("*.ts"):
    assert 'style="' not in path.read_text(), f"Inline style leaked into {path.name}"
for path in (ROOT / "frontend/modules/equipment/ui").glob("*.ts"):
    assert 'style="' not in path.read_text(), f"Inline style leaked into {path.name}"

print("PASS Item Editor create/update/delete gateway flow is present")
print("PASS Equipment Inspector consumes Rust-backed compatibility candidates")
print("PASS Equip/unequip actions remain behind EquipmentGateway")
print("PASS I1 UI modules contain no inline style attributes")
print("ALL I1 UI INVARIANTS PASSED")
