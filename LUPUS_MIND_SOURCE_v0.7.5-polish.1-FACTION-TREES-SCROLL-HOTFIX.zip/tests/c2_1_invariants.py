from __future__ import annotations
from pathlib import Path
import json, sqlite3, tempfile

ROOT=Path(__file__).resolve().parents[1]
MIGRATIONS=[ROOT/'src-tauri/migrations'/f'{i:03d}_{name}.sql' for i,name in [
(1,'initial_schema'),(2,'items_and_equipment'),(3,'skills'),(4,'relationships'),(5,'timeline'),(6,'combat_runtime')]]

def migrate(conn:sqlite3.Connection):
    conn.execute('PRAGMA foreign_keys=ON')
    for p in MIGRATIONS: conn.executescript(p.read_text())

def state(hp,mana,defeated=False,cooldowns=None): return json.dumps({'currentHp':hp,'currentMana':mana,'isDefeated':defeated,'cooldowns':cooldowns or []})
def snap(char_id,name,hp,mana,agi=10): return json.dumps({'sourceCharacterId':char_id,'displayName':name,'effectiveStats':{'strength':0,'agility':agi,'vitality':0,'intelligence':0,'mind':0,'weaponDamage':0,'armor':0,'armorPenetration':0,'magicPenetration':0,'criticalChance':0,'damageReduction':0},'maxHp':hp,'maxMana':mana,'skills':[{'skillId':'dragon','name':'Dragon Strike','kind':'physical','resourceKind':'mana','basePower':120,'resourceCost':20,'cooldownTurns':2,'scaling':[]}]})

def insert_session(conn,path_seed='42'):
    conn.execute("INSERT INTO combat_sessions(id,status,rng_seed,round_number,turn_index,next_action_sequence,created_at,updated_at) VALUES('s1','running',?,1,0,1,'2026-08-27T12:00:00Z','2026-08-27T12:00:00Z')",(path_seed,))
    conn.execute("INSERT INTO combatants(id,session_id,source_character_id,position,snapshot,runtime_state) VALUES('aren','s1','char-aren',0,?,?)",(snap('char-aren','Aren',500,100,20),state(500,100)))
    conn.execute("INSERT INTO combatants(id,session_id,source_character_id,position,snapshot,runtime_state) VALUES('elysia','s1','char-elysia',1,?,?)",(snap('char-elysia','Elysia',400,80,10),state(400,80)))
    conn.commit()

# Combat schema has no FK to canonical tables: only session-local FK allowed.
conn=sqlite3.connect(':memory:');migrate(conn)
fks=conn.execute("PRAGMA foreign_key_list(combatants)").fetchall()
assert len(fks)==1 and fks[0][2]=='combat_sessions', fks
combat_sql=(ROOT/'src-tauri/migrations/006_combat_runtime.sql').read_text()
assert 'REFERENCES characters' not in combat_sql and 'REFERENCES skills' not in combat_sql and 'REFERENCES items' not in combat_sql
print('PASS combat runtime has no canonical foreign keys')

# Golden durable turn: 100 mana -> 80, target 400 -> 280, turn advances, action #1 exists.
with tempfile.TemporaryDirectory() as td:
    db=Path(td)/'combat.sqlite'
    conn=sqlite3.connect(db);migrate(conn);insert_session(conn)
    conn.execute('BEGIN')
    input_json=json.dumps({'sessionId':'s1','actorCombatantId':'aren','targetCombatantId':'elysia','skillId':'dragon'})
    resolution=json.dumps({'rawPower':120,'resolvedPower':120,'hpDelta':-120,'manaDelta':-20,'wasCritical':False,'wasDodged':False,'rollCritical':50,'rollDodge':50})
    conn.execute("INSERT INTO combat_actions(id,session_id,sequence_number,round_number,turn_index,actor_combatant_id,target_combatant_id,action_kind,input_json,resolution_json,created_at) VALUES('a1','s1',1,1,0,'aren','elysia','use_skill',?,?, '2026-08-27T12:01:00Z')",(input_json,resolution))
    conn.execute("UPDATE combatants SET runtime_state=? WHERE id='aren'",(state(500,80,cooldowns=[{'skillId':'dragon','remainingTurns':2}]),))
    conn.execute("UPDATE combatants SET runtime_state=? WHERE id='elysia'",(state(280,80),))
    conn.execute("UPDATE combat_sessions SET turn_index=1,next_action_sequence=2,updated_at='2026-08-27T12:01:00Z' WHERE id='s1'")
    conn.commit();conn.close()
    # restart: fresh connection, DB is source of truth
    conn=sqlite3.connect(db);conn.execute('PRAGMA foreign_keys=ON')
    aren=json.loads(conn.execute("SELECT runtime_state FROM combatants WHERE id='aren'").fetchone()[0]);elysia=json.loads(conn.execute("SELECT runtime_state FROM combatants WHERE id='elysia'").fetchone()[0])
    turn,seq=conn.execute("SELECT turn_index,next_action_sequence FROM combat_sessions WHERE id='s1'").fetchone();actions=conn.execute("SELECT COUNT(*) FROM combat_actions WHERE session_id='s1'").fetchone()[0]
    assert aren['currentMana']==80 and aren['currentHp']==500
    assert elysia['currentHp']==280
    assert turn==1 and seq==2 and actions==1
    conn.close()
print('PASS golden combat turn survives restart exactly')

# Rollback after action insert: force target state update to fail after log insert and actor mutation.
conn=sqlite3.connect(':memory:');migrate(conn);insert_session(conn)
conn.executescript("CREATE TEMP TRIGGER fail_target_update BEFORE UPDATE OF runtime_state ON combatants WHEN OLD.id='elysia' BEGIN SELECT RAISE(ABORT,'forced target write failure'); END;")
try:
    conn.execute('BEGIN')
    conn.execute("INSERT INTO combat_actions(id,session_id,sequence_number,round_number,turn_index,actor_combatant_id,target_combatant_id,action_kind,input_json,resolution_json,created_at) VALUES('rollback-action','s1',1,1,0,'aren','elysia','use_skill','{}','{}','2026-08-27T12:02:00Z')")
    conn.execute("UPDATE combatants SET runtime_state=? WHERE id='aren'",(state(500,80),))
    conn.execute("UPDATE combatants SET runtime_state=? WHERE id='elysia'",(state(280,80),))
    conn.commit();raise AssertionError('forced write failure did not fire')
except sqlite3.DatabaseError:
    conn.rollback()
aren=json.loads(conn.execute("SELECT runtime_state FROM combatants WHERE id='aren'").fetchone()[0]);elysia=json.loads(conn.execute("SELECT runtime_state FROM combatants WHERE id='elysia'").fetchone()[0]);actions=conn.execute("SELECT COUNT(*) FROM combat_actions WHERE session_id='s1'").fetchone()[0];turn=conn.execute("SELECT turn_index FROM combat_sessions WHERE id='s1'").fetchone()[0]
assert aren['currentMana']==100 and elysia['currentHp']==400 and actions==0 and turn==0
print('PASS forced mid-turn failure rolls back mana, HP, turn and action log')

# Terminal sessions are frozen and reject new actions.
conn.execute("UPDATE combat_sessions SET status='completed',completed_at='2026-08-27T13:00:00Z' WHERE id='s1'");conn.commit()
try:
    conn.execute("INSERT INTO combat_actions(id,session_id,sequence_number,round_number,turn_index,actor_combatant_id,action_kind,input_json,resolution_json,created_at) VALUES('late','s1',1,1,0,'aren','use_skill','{}','{}','2026-08-27T13:01:00Z')")
    raise AssertionError('terminal action accepted')
except sqlite3.DatabaseError: conn.rollback()
try:
    conn.execute("UPDATE combat_sessions SET round_number=9 WHERE id='s1'")
    raise AssertionError('terminal session mutated')
except sqlite3.DatabaseError: conn.rollback()
print('PASS completed session rejects later actions and mutation')

# Schema uniqueness / deterministic sequence guards.
conn=sqlite3.connect(':memory:');migrate(conn);insert_session(conn)
try:
    conn.execute("INSERT INTO combatants(id,session_id,source_character_id,position,snapshot,runtime_state) VALUES('duplicate','s1','char-aren',2,'{}','{}')")
    raise AssertionError('duplicate source character accepted')
except sqlite3.IntegrityError: conn.rollback()
print('PASS combatant/session uniqueness invariants')

# Seed algorithm mirror: same seed+sequence+salt is stable, sequence changes stream.
MASK=(1<<64)-1
def u64(x):return x&MASK
def stable(seed,sequence,salt):
    z=u64(seed ^ u64(sequence*0x9E3779B97F4A7C15) ^ salt);z=u64(z+0x9E3779B97F4A7C15);z=u64((z^(z>>30))*0xBF58476D1CE4E5B9);z=u64((z^(z>>27))*0x94D049BB133111EB);return u64(z^(z>>31))
assert all(stable(42,i,7)==stable(42,i,7) for i in range(1,1000));assert stable(42,1,7)!=stable(42,2,7)
print('PASS seeded RNG stream is reproducible by seed + action sequence')

# Boundary source checks.
combat_app=(ROOT/'src-tauri/src/combat/application/use_cases.rs').read_text()
assert 'thread_rng' not in combat_app and 'rand::' not in combat_app
assert 'timeline::' not in combat_app and 'relationships::' not in combat_app
assert 'CharacterRepository' in combat_app and 'get_sheet' in combat_app, 'canonical read is allowed only during start snapshot creation'
assert ('with_session_transaction' in combat_app or 'with_turn_transaction' in combat_app), 'turn resolution must cross UoW boundary'
assert 'skills.get' not in combat_app.split('pub fn use_skill',1)[1], 'live skill repository lookup leaked into turn resolver'
combat_ui=(ROOT/'frontend/modules/combat/ui/CombatScreen.ts').read_text()
assert 'gateway.previewImpact' in combat_ui and 'gateway.start(' not in combat_ui and 'gateway.useSkill(' not in combat_ui
assert 'invoke(' not in combat_ui
assert 'style="' not in combat_ui, 'inline style attribute leaked into CombatScreen'
print('PASS Durable Combat resolver remains snapshot-only; Manual Arena uses read-only CombatGateway preview')
print('PASS C2.1 Obsidian UI has no inline style attributes')
print('ALL C2.1 INVARIANTS PASSED')
