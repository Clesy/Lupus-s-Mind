from pathlib import Path
import sqlite3, tempfile, json

ROOT = Path(__file__).resolve().parents[1]
MIGRATIONS = sorted((ROOT / 'src-tauri/migrations').glob('*.sql'))
assert (ROOT / 'src-tauri/migrations/009_desktop_hardening.sql').exists()

# Full migration chain must remain applicable from an empty workspace.
conn = sqlite3.connect(':memory:')
conn.execute('PRAGMA foreign_keys=ON')
for migration in MIGRATIONS:
    conn.executescript(migration.read_text())
settings = dict(conn.execute('SELECT key,value FROM workspace_settings').fetchall())
assert settings['compact_navigation'] == 'false'
assert settings['reduce_motion'] == 'false'
assert settings['confirm_destructive_actions'] == 'true'
assert settings['restore_last_route'] == 'true'
assert settings['default_generator_count'] == '8'
print('PASS 009 desktop settings remain present with safe defaults after later migrations')

# SQLite snapshot strategy must be a consistent DB-native snapshot, not raw copy of a WAL database.
with tempfile.TemporaryDirectory() as d:
    src = Path(d) / 'source.sqlite'
    dst = Path(d) / 'backup.sqlite'
    c = sqlite3.connect(src)
    c.execute('PRAGMA journal_mode=WAL')
    c.execute('CREATE TABLE probe(id INTEGER PRIMARY KEY, value TEXT NOT NULL)')
    c.execute("INSERT INTO probe(value) VALUES('before')")
    c.commit()
    escaped = str(dst).replace("'", "''")
    c.execute(f"VACUUM INTO '{escaped}'")
    c.execute("INSERT INTO probe(value) VALUES('after')")
    c.commit(); c.close()
    b = sqlite3.connect(dst)
    assert b.execute('PRAGMA quick_check').fetchone() == ('ok',)
    assert b.execute('SELECT value FROM probe ORDER BY id').fetchall() == [('before',)]
    b.close()
print('PASS VACUUM INTO produces a consistent point-in-time SQLite backup under WAL mode')

workspace_app = ''.join(p.read_text() for p in (ROOT/'src-tauri/src/workspace/application').rglob('*.rs'))
workspace_infra = (ROOT/'src-tauri/src/workspace/infrastructure/sqlite_workspace_operations.rs').read_text()
database = (ROOT/'src-tauri/src/shared/database.rs').read_text()
lib = (ROOT/'src-tauri/src/lib.rs').read_text()
state = (ROOT/'src-tauri/src/app_state.rs').read_text()

assert 'rusqlite' not in workspace_app and 'Sqlite' not in workspace_app and 'app_state' not in workspace_app
assert 'VACUUM INTO' in workspace_infra
assert 'PRAGMA quick_check' in workspace_infra and 'PRAGMA foreign_key_check' in workspace_infra
assert 'lupus-mind-pre-migration' in database and 'recovery_snapshot' in database
assert '009_desktop_hardening.sql' in database
assert 'workspace_health' in lib and 'workspace_backup_create' in lib and 'workspace_export_json' in lib
assert 'workspace:SqliteWorkspaceOperations' in ''.join(state.split())
print('PASS workspace application remains infrastructure-agnostic and exposes health/backup/export through a bounded port')
print('PASS pre-migration recovery snapshot is created before pending disk migrations')

# Export/backup operations may not write into canonical domain tables.
for forbidden in ['INSERT INTO characters','UPDATE characters','DELETE FROM characters','INSERT INTO items','UPDATE items','DELETE FROM items','INSERT INTO timeline_events','UPDATE timeline_events','INSERT INTO relationships']:
    assert forbidden not in workspace_infra
assert 'INSERT INTO workspace_settings' in workspace_infra
print('PASS desktop operations mutate only workspace_settings; backup/export cannot mutate canon')

app = (ROOT/'frontend/AppShell.ts').read_text()
main = (ROOT/'frontend/main.ts').read_text()
workspace_ui = (ROOT/'frontend/modules/workspace/ui/WorkspaceScreen.ts').read_text()
workspace_gateway = (ROOT/'frontend/modules/workspace/application/WorkspaceGateway.ts').read_text()
workspace_tauri = (ROOT/'frontend/modules/workspace/infrastructure/TauriWorkspaceGateway.ts').read_text()
preferences = (ROOT/'frontend/shared/preferences.ts').read_text()
generator = (ROOT/'frontend/modules/creative_generators/ui/GeneratorScreen.ts').read_text()

assert '"workspace"' in app and 'new WorkspaceScreen' in app
assert 'Ctrl ,' in app and 'event.key==="?"' in app.replace(' ', '') and 'event.key==="Escape"' in app.replace(' ', '')
assert 'compact-nav' in app and 'reduce-motion' in app
assert 'restoreLastRoute' in app and 'defaultGeneratorCount' in app
assert 'tauriWorkspaceGateway' in main and 'styles/workspace.css' in main
assert 'invoke(' not in workspace_ui and 'invoke(' not in workspace_gateway
assert 'invoke<DatabaseHealth>("workspace_health")' in workspace_tauri
assert 'createBackup' in workspace_ui and 'exportJson' in workspace_ui and 'saveSettings' in workspace_ui
assert 'shouldConfirmDestructive' in preferences
assert 'private readonly defaultCount=8' in generator
print('PASS Workspace is a first-class shell route with keyboard help, health, artifacts and settings')
print('PASS UI remains Gateway-only; Tauri IPC is isolated in infrastructure')
print('PASS persisted settings drive shell density/motion/route restore/generator count/destructive confirmation')

print('ALL P2 DESKTOP HARDENING INVARIANTS PASSED')
