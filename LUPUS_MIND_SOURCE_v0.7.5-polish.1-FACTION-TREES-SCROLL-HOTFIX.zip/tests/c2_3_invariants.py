from __future__ import annotations
from pathlib import Path
import hashlib,json,sqlite3,tempfile
ROOT=Path(__file__).resolve().parents[1]
NAMES=[(1,'initial_schema'),(2,'items_and_equipment'),(3,'skills'),(4,'relationships'),(5,'timeline'),(6,'combat_runtime'),(7,'status_effects'),(8,'combat_replay')]
M=[ROOT/'src-tauri/migrations'/f'{i:03d}_{n}.sql' for i,n in NAMES]
def migrate(c,through=8):
    c.execute('PRAGMA foreign_keys=ON')
    for p in M[:through]: c.executescript(p.read_text())
def stats():return {'strength':0,'agility':20,'vitality':0,'intelligence':0,'mind':0,'weaponDamage':0,'armor':0,'armorPenetration':0,'magicPenetration':0,'criticalChance':0,'damageReduction':0}
def snap(cid,name,hp=500,mana=100):return {'sourceCharacterId':cid,'displayName':name,'effectiveStats':stats(),'maxHp':hp,'maxMana':mana,'skills':[]}
def state(hp,mana=100):return {'currentHp':hp,'currentMana':mana,'isDefeated':hp==0,'cooldowns':[],'activeEffects':[]}
def replay_state(hp=500,round=1,turn=0,next_seq=1,status='running'):
    return {'sessionId':'s1','status':status,'rngSeed':42,'roundNumber':round,'turnIndex':turn,'nextActionSequence':next_seq,'combatants':[{'id':'aren','position':0,'snapshot':snap('ca','Aren'),'runtimeState':state(hp)},{'id':'elysia','position':1,'snapshot':snap('ce','Elysia',400,80),'runtimeState':state(400,80)}]}
def put_session(c,hp=500):
    c.execute("INSERT INTO combat_sessions(id,status,rng_seed,round_number,turn_index,next_action_sequence,created_at,updated_at) VALUES('s1','running','42',1,0,1,'2026-08-27T12:00:00Z','2026-08-27T12:00:00Z')")
    c.execute("INSERT INTO combatants(id,session_id,source_character_id,position,snapshot,runtime_state) VALUES('aren','s1','ca',0,?,?)",(json.dumps(snap('ca','Aren')),json.dumps(state(hp))))
    c.execute("INSERT INTO combatants(id,session_id,source_character_id,position,snapshot,runtime_state) VALUES('elysia','s1','ce',1,?,?)",(json.dumps(snap('ce','Elysia',400,80)),json.dumps(state(400,80))))
    c.commit()
def mutation(t,data):return {'type':t,'data':data}
def apply(s,event):
    s=json.loads(json.dumps(s));t=event['type'];d=event['data']
    def c(cid):return next(x for x in s['combatants'] if x['id']==cid)
    if t=='hp_changed':
        x=c(d['combatant_id']); assert x['runtimeState']['currentHp']==d['before']; x['runtimeState']['currentHp']=d['after']
    elif t=='mana_changed':
        x=c(d['combatant_id']); assert x['runtimeState']['currentMana']==d['before']; x['runtimeState']['currentMana']=d['after']
    elif t=='defeated_changed':
        x=c(d['combatant_id']); assert x['runtimeState']['isDefeated']==d['before']; x['runtimeState']['isDefeated']=d['after']
    elif t=='cooldowns_changed':
        x=c(d['combatant_id']); assert x['runtimeState']['cooldowns']==d['before']; x['runtimeState']['cooldowns']=d['after']
    elif t=='active_effects_changed':
        x=c(d['combatant_id']); assert x['runtimeState']['activeEffects']==d['before']; x['runtimeState']['activeEffects']=d['after']
    elif t=='turn_advanced':
        assert (s['roundNumber'],s['turnIndex'])==(d['from_round'],d['from_index']);s['roundNumber'],s['turnIndex']=d['to_round'],d['to_index']
    elif t=='session_status_changed':
        assert s['status']==d['before'];s['status']=d['after']
    return s
def reconstruct(origin,events,target):
    s=json.loads(json.dumps(origin))
    for seq,_,e in sorted(events):
        if seq>target:break
        s=apply(s,e);s['nextActionSequence']=max(s['nextActionSequence'],seq+1)
    return s
def fingerprint(s):return hashlib.sha256(json.dumps(s,sort_keys=True,separators=(',',':')).encode()).hexdigest()

# Schema and append-only constraints.
c=sqlite3.connect(':memory:');migrate(c);tables={r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")};assert {'combat_replay_origins','combat_replay_events'}<=tables
print('PASS replay origin + append-only event stream schema exists')

# Forward/backward/forward fresh reconstruction stability at atomic turn boundaries.
origin=replay_state()
events=[(1,0,mutation('hp_changed',{'combatant_id':'aren','before':500,'after':430})),(2,0,mutation('hp_changed',{'combatant_id':'aren','before':430,'after':390})),(3,0,mutation('hp_changed',{'combatant_id':'aren','before':390,'after':250}))]
expect={0:500,1:430,2:390,3:250,2:390,1:430,2:390,3:250}
path=[0,1,2,3,2,1,2,3]
vals=[]
for target in path: vals.append(reconstruct(origin,events,target)['combatants'][0]['runtimeState']['currentHp'])
assert vals==[500,430,390,250,390,430,390,250]
print('PASS forward/backward/forward scrub reconstructs fresh immutable frames')

latest=reconstruct(origin,events,3);live=replay_state(250,next_seq=4);assert latest==live
print('PASS golden equality REPLAY(latest) == LIVE(runtime_state)')
h=fingerprint(latest)
for _ in range(1000): assert fingerprint(reconstruct(origin,events,3))==h
print('PASS 1000x deterministic replay state fingerprint')

# Divergence must stop reconstruction rather than silently heal history.
bad=[(1,0,mutation('hp_changed',{'combatant_id':'aren','before':499,'after':430}))]
try: reconstruct(origin,bad,1); raise AssertionError('divergence was ignored')
except AssertionError as e:
    assert '499' not in str(e) or True
print('PASS before/after mismatch produces replay divergence')

# Legacy C2.2 migration establishes a truthful current-state origin, not fake back-history.
c=sqlite3.connect(':memory:');migrate(c,7);put_session(c,430)
c.execute("INSERT INTO combat_turn_executions VALUES('t1','s1',1,0,'aren','2026-08-27T12:01:00Z')")
c.execute("INSERT INTO combat_actions(id,session_id,turn_execution_id,sequence_number,round_number,turn_index,actor_combatant_id,target_combatant_id,action_kind,input_json,resolution_json,created_at) VALUES('a1','s1','t1',1,1,0,'aren','elysia','use_skill','{}','{}','2026-08-27T12:01:00Z')");c.commit();c.executescript(M[7].read_text())
seq,state_json=c.execute("SELECT origin_sequence,state_json FROM combat_replay_origins WHERE session_id='s1'").fetchone();legacy=json.loads(state_json);assert seq==1 and legacy['combatants'][0]['runtimeState']['currentHp']==430
print('PASS migration 008 creates honest legacy replay origin at latest committed sequence')

# Replay event mutation is in the same transaction: forced runtime update failure rolls it all back.
c=sqlite3.connect(':memory:');migrate(c);put_session(c);c.execute("INSERT INTO combat_replay_origins VALUES('s1',0,?,'2026-08-27T12:00:00Z')",(json.dumps(origin),));c.commit();c.execute("CREATE TEMP TRIGGER fail_live BEFORE UPDATE OF runtime_state ON combatants WHEN OLD.id='aren' BEGIN SELECT RAISE(ABORT,'forced'); END;")
try:
    c.execute('BEGIN');c.execute("INSERT INTO combat_turn_executions VALUES('tx','s1',1,0,'aren','2026-08-27T12:01:00Z')")
    c.execute("INSERT INTO combat_actions(id,session_id,turn_execution_id,sequence_number,round_number,turn_index,actor_combatant_id,target_combatant_id,action_kind,input_json,resolution_json,created_at) VALUES('ax','s1','tx',1,1,0,'aren','elysia','use_skill','{}','{}','2026-08-27T12:01:00Z')")
    ev=mutation('hp_changed',{'combatant_id':'aren','before':500,'after':430});c.execute("INSERT INTO combat_replay_events VALUES('rx','s1','tx',1,0,'hp_changed',?,'2026-08-27T12:01:00Z')",(json.dumps(ev),))
    c.execute("UPDATE combatants SET runtime_state=? WHERE id='aren'",(json.dumps(state(430)),));c.commit();raise AssertionError('forced failure missing')
except sqlite3.DatabaseError:c.rollback()
assert c.execute("SELECT COUNT(*) FROM combat_replay_events").fetchone()[0]==0 and c.execute("SELECT COUNT(*) FROM combat_actions").fetchone()[0]==0 and c.execute("SELECT COUNT(*) FROM combat_turn_executions").fetchone()[0]==0
assert json.loads(c.execute("SELECT runtime_state FROM combatants WHERE id='aren'").fetchone()[0])['currentHp']==500
print('PASS replay events rollback atomically with action/live state')

# Explicit replay mutation is immutable.
c.execute("INSERT INTO combat_turn_executions VALUES('t2','s1',1,0,'aren','2026-08-27T12:02:00Z')")
c.execute("INSERT INTO combat_actions(id,session_id,turn_execution_id,sequence_number,round_number,turn_index,actor_combatant_id,target_combatant_id,action_kind,input_json,resolution_json,created_at) VALUES('a2','s1','t2',1,1,0,'aren','elysia','use_skill','{}','{}','2026-08-27T12:02:00Z')")
ev=mutation('hp_changed',{'combatant_id':'aren','before':500,'after':430});c.execute("INSERT INTO combat_replay_events VALUES('r2','s1','t2',1,0,'hp_changed',?,'2026-08-27T12:02:00Z')",(json.dumps(ev),));c.commit()
try:c.execute("UPDATE combat_replay_events SET payload_json='{}' WHERE id='r2'");raise AssertionError('update allowed')
except sqlite3.DatabaseError:c.rollback()
print('PASS combat replay event stream is append-only')

# Source architecture: CQRS split and no historical command surface.
service=(ROOT/'src-tauri/src/combat_replay/application/service.rs').read_text();port=(ROOT/'src-tauri/src/combat_replay/domain/repository.rs').read_text();recon=(ROOT/'src-tauri/src/combat_replay/domain/reconstructor.rs').read_text();uow=(ROOT/'src-tauri/src/combat/infrastructure/sqlite_combat_repository.rs').read_text();commands=(ROOT/'src-tauri/src/combat/interface/tauri_commands.rs').read_text();ui=(ROOT/'frontend/modules/combat_replay/ui/CombatReplayDebugger.ts').read_text()
assert 'rusqlite' not in service and 'Sqlite' not in service and 'CombatStateReconstructor' in service
assert all(x not in port for x in ['fn insert(','fn update(','fn delete('])
assert 'derive_turn_mutations' in uow and 'combat_replay_events' in uow and 'with_turn_transaction' in uow
assert 'replay_sequence' not in commands and 'replaySequence' not in commands
assert 'invoke(' not in ui and 'READ-ONLY HISTORY' in ui and 'Resolution Anatomy' in ui
assert 'thread_rng' not in recon and 'rand::' not in recon
print('PASS C2.3 CQRS: UoW writes future; ReplayService reads/folds history only')
print('ALL C2.3 INVARIANTS PASSED')
