from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
app = (ROOT / 'frontend/AppShell.ts').read_text()
main = (ROOT / 'frontend/main.ts').read_text()
shell_css = (ROOT / 'frontend/styles/shell.css').read_text()
items_css = (ROOT / 'frontend/styles/items.css').read_text()
characters = (ROOT / 'frontend/modules/characters/ui/CharacterScreen.ts').read_text()
editor = (ROOT / 'frontend/modules/characters/ui/CharacterEditor.ts').read_text()
dashboard = (ROOT / 'frontend/modules/dashboard/ui/DashboardScreen.ts').read_text()

# The complete canonical character slice must now be reachable from the product shell.
compact = ''.join(app.split())
assert '"characters"' in app and 'newCharacterScreen(host,this.characters,this.equipment,this.skills' in compact
assert 'intent?.kind==="create"' in compact and 'intent?.kind==="select"' in compact
assert '"dashboard"' in app and 'new DashboardScreen(' in app
assert 'restoreLastRoute' in app and 'this.restoreRoute()' in app and '"dashboard"' in app

# Shell async rendering must be guarded against stale route completion and must have a retry boundary.
assert 'renderEpoch' in app
assert 'epoch!==this.renderEpoch' in compact
assert 'retry-route' in app
assert 'content.replaceChildren(host)' in compact

# Shell design belongs to the shell, not to a feature module.
assert '.app-shell' in shell_css and '.app-sidebar' in shell_css and '.app-topbar' in shell_css
assert '.app-shell' not in items_css and '.app-sidebar' not in items_css
assert 'import "./styles/shell.css"' in main

# Character CRUD is gateway-only and editor-grade rather than direct IPC / inline-style scripting.
assert 'CharacterGateway' in characters and 'CharacterEditor' in characters
assert 'gateway.remove' in characters and 'gateway.list' in characters
assert 'gateway.create' in editor and 'gateway.update' in editor
assert 'invoke(' not in characters and 'invoke(' not in editor
assert 'style=' not in characters and 'style=' not in editor

# Dashboard is read-only aggregation and navigation; it must not mutate canonical data.
assert 'Promise.allSettled' in dashboard
assert '.create(' not in dashboard and '.update(' not in dashboard and '.remove(' not in dashboard
# v0.7.5 polish replaces the runtime battle panel with existing Quick Notes while preserving read-only aggregation.
assert 'listNotes' in dashboard
assert 'data-route-jump' in dashboard

print('PASS Dashboard and Characters are first-class product routes')
print('PASS async route epoch prevents stale screen overwrite and exposes retry boundary')
print('PASS shell styling is owned by shell.css, not a feature module')
print('PASS Character CRUD remains Gateway-only and editor-grade')
print('PASS Dashboard is read-only aggregation over existing bounded contexts')
print('ALL P1 PRODUCTIZATION INVARIANTS PASSED')
