# LUPUS'S MIND v0.7.0-alpha.1 — Authoring & Navigation Foundation

This alpha is the first v0.7 vertical slice built on the stable v0.6 native checkpoint.
It intentionally focuses on **access, authoring and visual navigation** instead of adding another large simulation domain.

## Shipped in this slice

### Multi-Project Workspace

- Centered Project Switcher in the global top bar.
- Every project owns a **separate SQLite database file**.
- Existing `lupus-mind.sqlite` is automatically preserved as the first `My World` project.
- Creating a project creates a fully migrated isolated database.
- Switching replaces the shared repository connection only after the target DB is verified.
- A registered-but-missing DB fails closed instead of silently recreating an empty world.
- If writing `projects.json` fails during a switch, the active connection is rolled back to the previous project.
- Pending/in-flight Manuscript autosaves are flushed **before** a project database switch.

Invariant:

```text
Project A database != Project B database
```

No `project_id` column was scattered through existing canonical tables.

### Manuscript / Chapters

- First-class `Manuscript` route.
- Chapter number, title, status (`draft / revised / final`).
- Long-form chapter content.
- Chapter notes and tags.
- Live word count.
- 650 ms debounced autosave with Saved / Saving / Save failed feedback.
- Focus Mode for distraction-reduced writing.
- Chapter list/search.
- Quick Notes / "Aklımda Bulunsun" panel with pin/unpin/delete.

Important boundary:

```text
ChapterDraft != TimelineEvent != Canonical State
```

Writing text does not silently mutate canon.

### Global Search / Command Palette

- Right-side `Search everything…` control.
- `Ctrl/Cmd + K` opens the palette.
- Searches the **active project only**.
- Current searchable data:
  - Characters
  - Items
  - Skills
  - Timeline events
  - Manuscript chapters/content/notes/tags
  - Relationships
- Navigation commands are mixed into the same palette.
- Character / Item / Skill / Chapter hits can open their concrete editor/profile.

### Quick Create

`Ctrl/Cmd + N` or the top-bar `+` opens Quick Create for:

- Character
- Item
- Skill
- Chapter

Creation always happens inside the active project.

### Character Gallery Redesign

- Cards view is the default visual direction.
- Table view remains available for dense workflows.
- Character cards expose core stats, class/alias and tags.
- Monogram art slot prepares the visual language for a later local Asset Library / portrait feature.
- Right-side Character Inspector shows:
  - Base stats
  - Effective stats
  - Equipped items
  - Learned skills
  - Biography
  - Edit/delete
  - Manage Equipment / Manage Skills

Real portrait upload/storage is **not yet implemented** in this alpha. The future design should use a local asset reference instead of base64 blobs in SQLite.

### Top-Bar / Shell UX

```text
Breadcrumb                 Project Switcher                Search   +   Settings
Studio > Characters        [ ELYSIUM v ]                  [Ctrl K]
```

Keyboard changes:

- `Ctrl/Cmd + K` — Global Search
- `Ctrl/Cmd + N` — Quick Create
- `Ctrl/Cmd + ,` — Workspace
- `Alt+1` — Overview
- `Alt+2` — Manuscript
- `Alt+3..0` — remaining primary modules
- `?` — Shortcut help
- `Esc` — close overlay

## Migration

`010_authoring_and_search.sql`

Adds:

- `manuscript_chapters`
- `quick_notes`

Expected schema version is now `10`.

## Test contract

Packaging-environment verification includes:

- Full C1 -> P3 regression chain.
- Migration 010 on the complete SQLite migration chain.
- Manuscript persistence semantics.
- Exact Rust Global Search SQL executed against SQLite test data.
- Multi-project architecture / fail-closed source invariants.
- Manuscript autosave flush-before-project-switch invariant.
- Gateway-only frontend boundary.
- Character card/inspector contract.

A native Rust integration test is also included:

`src-tauri/tests/authoring_project_flow.rs`

It must be run on a Windows/Rust machine before promoting this alpha:

```powershell
cargo test --manifest-path .\src-tauri\Cargo.toml
```

The golden integration scenario verifies:

```text
Project A: Aren + Chapter 184
        -> switch Project B
Project B: Aren absent, manuscript empty
        -> add Kael
        -> switch Project A
Project A: Aren + Chapter 184 restored, Kael absent
```

Global Search is checked at each project boundary.

## Explicitly NOT in this slice

These remain the next waves; they are not claimed as implemented here:

- Interactive Atlas
- Procedural/random map generator
- Faction / Clan domain and relationship matrix
- Army/unit management and faction wars
- Inventory ownership
- Quest system
- Lore Wiki / backlinks
- Family tree / hierarchy
- Secret / knowledge-flow matrix
- Custom calendar
- Relic/crafting system
- Character arc tracker / scene planner
- Universal generator expansion
- Dashboard analytics / compare mode
- Lore Bible PDF/EPUB export
- World-aware AI
- Cloud sync / licensing / advertising

The default Manual Combat Arena remains intentionally simple and unchanged.
