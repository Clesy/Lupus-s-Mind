# LUPUS'S MIND v0.7.5-polish.1 — Faction Trees Scroll Hotfix

This hotfix applies the bounded viewport behavior to both Factions tree views.

## Hierarchy

- Organization toolbar stays outside the scroll canvas.
- Organization chart header stays fixed inside the panel.
- Tree canvas scrolls vertically/horizontally inside its own panel.
- Role inspector remains independently scrollable.

## Lineages

- Lineage toolbar stays outside the scroll canvas.
- Lineage tree header stays fixed inside the panel.
- Tree canvas scrolls vertically/horizontally inside its own panel.
- Lineage inspector remains independently scrollable.

Other Factions modes are unchanged.

## Verification

- TypeScript strict check: PASS
- v0.7.5 hierarchy + lineage scroll invariants: PASS
- v0.7.3.1 hierarchy/lineage invariants: PASS
- v0.7.3 world systems invariants: PASS
