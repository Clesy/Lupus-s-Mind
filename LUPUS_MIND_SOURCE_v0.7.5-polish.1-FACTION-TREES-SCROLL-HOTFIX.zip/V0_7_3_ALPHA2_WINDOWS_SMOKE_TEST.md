# v0.7.3-alpha.2 Windows Smoke Test

Run from the extracted source folder:

```powershell
npm.cmd install
npm.cmd run verify
npm.cmd run build
cargo test --manifest-path .\src-tauri\Cargo.toml
npm.cmd run tauri:dev
```

## Inventory visual check
1. Open Items and make sure at least two items exist; give one item artwork and at least one stat modifier.
2. Equip/own at least one item and leave another unowned.
3. Open Inventory.
4. Confirm Chapter / Owner / Find item controls are directly below the page heading.
5. Confirm cards begin immediately below the filter/summary strip; there must not be a giant empty panel above them.
6. Confirm the existing Item artwork appears on the Inventory card.
7. Confirm stat modifier chips use the same semantic colors as Item cards.
8. Toggle All / Equipped / Owned / Unowned and verify counts/results.
9. Change Owner and Chapter; verify ownership state updates without changing equipment state.
10. Test Transfer and Release.

No migration change is expected for this hotfix.
