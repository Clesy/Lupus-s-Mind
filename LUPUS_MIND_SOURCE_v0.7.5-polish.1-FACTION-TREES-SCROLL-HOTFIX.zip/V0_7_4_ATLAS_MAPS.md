# v0.7.4 — Atlas & Map Systems

Package checkpoint: **0.7.4-alpha.2**.

## Product goal

Add a real spatial/world-navigation layer without turning generated content into canon automatically.

```text
Location          = canonical place
AtlasMap          = canonical map record
MapPin            = spatial placement/link to a Location
MapConnection     = spatial connection between pinned Locations
GeneratedMapDraft != Canon
```

The generator is preview-only until the user explicitly chooses **Accept into World**.

## Atlas lenses

### Atlas

- Map list with blank-map creation.
- SVG map canvas.
- Persisted generated terrain preview for accepted generated maps.
- Canonical Location pins.
- Click-to-place a selected unpinned Location.
- Drag pins to reposition them; coordinates are normalized to `0..1`.
- Remove pins without deleting the underlying Location.
- Add/remove map connections: road, sea route, portal, border, path.
- Scope a map to a Location.
- Nest maps through `parent_map_id`.
- Parent-map UI excludes descendants; SQLite remains the final cycle guard.

### Locations

Canonical location hierarchy:

```text
World
  -> Continent
    -> Country
      -> Region / Province
        -> City / Town / Village
          -> District / Building / Landmark / Dungeon
```

Locations support name, kind, parent, description, color and tags. Parent selection excludes the current node and descendants. Deleting a parent does not silently delete its children; child parent references become null.

### Generator

Deterministic controls:

- seed
- map name
- width / height
- continent count
- ocean ratio
- mountain density
- river count
- settlement count

The generator uses a pure deterministic RNG and does not know SQLite, Tauri state, wall-clock time or system randomness.

The same request + same seed must produce the same `GeneratedMapDraft`.

Generated data includes:

- irregular landmass polygons
- mountains
- rivers
- settlements

`Generate` / `Regenerate` modifies only the in-memory draft. `Accept into World` persists the map. When the create-locations option is enabled, acceptance also creates continent + settlement Locations and map pins in one SQLite transaction. Generated settlements are assigned to their nearest generated landmass rather than an arbitrary continent.


## alpha.2 viewport controls

The canonical Atlas canvas now behaves like a desktop map viewport:

- wheel zoom around pointer
- `+` / `-` zoom controls
- `Fit` full-map reset
- drag empty map space to pan
- pin drag remains independent
- camera state is UI-only
- inspector scroll is independent from the map

Zoom/pan never modifies `AtlasMap`, `Location`, generated terrain, or normalized `MapPin` coordinates.

## Persistence

Migration: `014_atlas.sql`.

Tables:

- `locations`
- `atlas_maps`
- `map_pins`
- `map_connections`

`atlas_maps.terrain_json` stores accepted generated terrain so reopening the map does not reroll it. `generator_seed` records the accepted seed.

## Reliability rules

- Location hierarchy cycles are rejected in SQLite.
- Nested-map cycles are rejected in SQLite.
- One Location can appear only once on a given map.
- Pin X/Y coordinates are constrained to normalized map space.
- Map connections cannot connect a Location to itself.
- Generated drafts perform no canonical writes before explicit acceptance.
- Generated-map acceptance is transactional.
- Project isolation remains inherited from the separate-project-SQLite architecture.

## Architecture

```text
AtlasScreen
  -> AtlasGateway
    -> TauriAtlasGateway
      -> atlas Tauri commands
        -> Atlas application use cases
          -> AtlasRepository
            -> SqliteAtlasRepository
```

Only `TauriAtlasGateway` may invoke Tauri from this module.

## Search / navigation

Global Search now includes canonical Locations and Atlas Maps. Results route to the Atlas module. Quick Create includes Location.

## Deferred intentionally

Not part of this alpha:

- freehand terrain sculpting / raster painting
- custom background-image maps
- polygon territory editor
- temporal faction territory overlays
- route distance/pathfinding simulation
- weather/climate simulation
- procedural political borders
- canonical world writes during generator preview

These should build on the stable Location/Map/Pin layer rather than bypass it.
