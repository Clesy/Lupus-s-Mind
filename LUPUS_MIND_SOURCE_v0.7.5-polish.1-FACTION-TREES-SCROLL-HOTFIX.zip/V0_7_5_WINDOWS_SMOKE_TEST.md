# LUPUS'S MIND — v0.7.5-polish.1 Windows Smoke Test

Run from the extracted source root in PowerShell:

```powershell
npm.cmd install
npm.cmd run verify
npm.cmd run build
cargo test --manifest-path .\src-tauri\Cargo.toml
npm.cmd run tauri:dev
```

Do not promote the candidate if any command fails. Preserve the exact console output and the previous known-good source as rollback material.

## #001 Workspace — schema health

1. Open a normal migrated project.
2. Open **Workspace**.
3. Confirm database health is **Healthy** and schema is **14 / 14**.
4. `quick_check` should be `ok` and foreign-key violations `0`.

## #002 Overview — Quick Notes

1. Add two Quick Notes from Manuscript.
2. Open **Overview**.
3. Confirm the lower panel shows **Quick Notes**, not Active Battles/Arena sessions.
4. Use the panel action to jump back to Manuscript.
5. Confirm Combat/Arena still works from its own route.

## #003 Workspace — Reset settings

1. Change several Workspace settings: compact navigation, reduce motion, destructive confirmation, restore-last-route and generator count.
2. Save and verify the shell reacts.
3. Press **Reset defaults**.
4. Confirm defaults are immediately reflected in UI.
5. Restart the app and confirm defaults persisted.

Expected defaults:

```text
Compact navigation:       off
Reduce motion:            off
Confirm destructive:      on
Restore last route:       on
Default generator count:  8
```

## #004 Workspace — Recovery Restore

Use a disposable project for this check.

1. Create recognizable data, then create a SQLite backup in Workspace.
2. Change/delete some disposable data after the backup.
3. In Workspace artifacts, press **Restore** on the earlier SQLite backup.
4. Confirm a destructive restore prompt appears.
5. Confirm the project returns to the backed-up state without restarting.
6. Confirm a fresh `pre-restore` recovery point appears in artifacts.
7. Open Workspace health again and confirm 14 / 14, `quick_check ok`, FK violations 0.
8. Confirm JSON exports do **not** expose a Restore action.

## #005 Manuscript & Lore — read-first

1. Open an existing Chapter: it should show a clean reading view, not editable text fields.
2. Press **Edit**, change text, then **Done**.
3. Confirm the change persists and the screen returns to reading view.
4. Create a new Chapter; it should enter Edit directly.
5. Repeat all four behaviors for a Lore Page.
6. Confirm project switching/autosave still preserves text.

## #006 Atlas — manual world-map drawing

1. Create a blank/manual Atlas map.
2. Press **Draw Land** and drag a closed-ish coastline on the canvas.
3. Release after drawing at least several points; confirm the landmass appears.
4. Navigate away/back and confirm it persists.
5. Add another landmass, use **Undo**, then draw again.
6. Use **Clear** and confirm only map terrain clears; Locations themselves remain canonical and untouched.

## #007 Atlas — Location deletion

Use disposable locations.

1. Create Parent -> Child locations.
2. Pin Parent to a map and create a route involving Parent.
3. Delete Parent.
4. Confirm Child still exists and becomes top-level.
5. Confirm Parent pin and routes are removed.
6. Confirm the map still opens and no FK/health warning appears.

## #008 Atlas — generated-map quality

Baseline:

```text
Seed:        482193
Continents:  3
Ocean:       55%
Mountains:   55
Rivers:      6
Settlements: 12
```

Confirm:

1. Generate twice with identical parameters; maps must be identical.
2. Coastlines should be high-resolution, irregular and visibly less ellipse/polygon-like.
3. Landmasses should show bays/peninsulas and more varied elongation/rotation.
4. Mountain ranges should read as coherent ranges rather than dense random noise.
5. Rivers still originate inland/high areas and reach coast/confluence.
6. Settlements remain on land, reasonably distributed and uniquely named.
7. Before **Accept into World**, canonical Map/Location counts must not change.
8. Accept and reopen; terrain and settlement kinds must persist.

Also sample seeds `11883`, `991271`, and `20480017`.

## #009 Atlas — zoom-aware pins

1. Add a mix of city, town and village pins.
2. Zoom from 100% to several higher levels.
3. Marker/icon screen size should remain readable and broadly stable.
4. City/high-level labels should remain available earlier.
5. Town labels should appear around deeper zoom; village labels later still.
6. Routes/rivers/coast strokes should not become excessively thick when zooming.
7. Drag/pan and pin repositioning must still work outside Draw Land mode.

## #010 Atlas — first-map empty state

Use a new/disposable project with zero Atlas maps.

1. Open **Atlas** and confirm a purposeful first-map screen appears.
2. **Draw manually** should create/select a blank map and enable manual cartography workflow.
3. In another clean project, **Generate from seed** should open Generator.
4. **Create locations first** should open the new Location form.
5. Confirm the canonical-boundary explanation is visible.

## Final regression spot checks

- Character portrait/cards and Item artwork still load.
- Inventory, Factions, Quests and Secrets routes still open.
- Timeline Fit all still works.
- Manual Combat Arena remains manual-only.
- Backup/export still works after restore testing.
- Global Search can still open Location/Map results.
