# P2 — Desktop Hardening

Status: **architecture/invariant freeze complete; native compile gate pending local toolchain**.

P2 moves LUPUS'S MIND from an integrated product shell toward a recoverable desktop workspace. It adds no new canonical world domain.

## Delivered

- `009_desktop_hardening.sql` with durable `workspace_settings`.
- First-class **Workspace & Settings** route.
- Database health using SQLite `PRAGMA quick_check`, `foreign_key_check`, schema-version and file-size inspection.
- Consistent SQLite backups using `VACUUM INTO` rather than raw file copying under WAL mode.
- Portable full-workspace JSON export.
- Artifact inventory for manual backups, JSON exports and automatic recovery points.
- **Automatic pre-migration recovery snapshot** before pending migrations on disk workspaces.
- Persisted settings for compact navigation, reduced motion, destructive-action confirmation, last-route restore and generator default count.
- Settings are consumed by the product shell/features; they are not dead configuration.
- Keyboard ergonomics: Alt+1..0 module navigation, Ctrl/Cmd+, Workspace, `?` shortcut sheet, Escape close.
- Route failure screen links directly to Workspace health.

## Safety boundaries

`WorkspaceOperations` is an application port. Application code has no rusqlite/AppState dependency.

Backup/export/health operations have **zero canonical writes**. The only mutable table in this bounded capability is `workspace_settings`.

A pre-migration recovery point is a safety artifact, not canonical knowledge and not a migration substitute. Migrations remain transactional.

## Local release gate

```bash
npm install
npm run verify
npm run build
cd src-tauri
cargo test
npm run tauri dev
```

The current execution environment does not contain Vite or the Rust toolchain, therefore native compile success is intentionally not claimed here.
