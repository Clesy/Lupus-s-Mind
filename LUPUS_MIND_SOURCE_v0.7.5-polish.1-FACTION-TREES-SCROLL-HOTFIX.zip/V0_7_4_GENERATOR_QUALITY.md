# LUPUS'S MIND v0.7.4-alpha.3 — World Generator Quality Pass

## Scope freeze

This checkpoint deliberately adds **no new product module**. It improves the existing Atlas procedural world generator after visual review exposed three quality problems:

1. coastlines were angular / polygonal,
2. settlements clustered without geographic logic and shared one weak icon language,
3. rivers were random walks biased toward the bottom of the map.

The canonical boundary remains unchanged:

```text
GeneratedMapDraft != Canonical Atlas
Generate / Regenerate -> no canonical write
Accept into World      -> transactional canonical write
```

No migration was added. Existing accepted v0.7.4 maps remain readable because the `GeneratedMapDraft` JSON shape is unchanged.

## Generator v2 pipeline

The generator now derives independent deterministic RNG streams from the user seed for geography, mountain ranges, hydrology, settlements and names. This prevents an internal sampling change in one layer from unpredictably scrambling unrelated layers.

### Coastlines

- 18-point jittered ellipses were removed.
- Each continent now uses 160 boundary samples.
- Low-frequency harmonic shaping creates continent-scale asymmetry.
- Explicit positive macro features create peninsulas / lobes.
- Explicit negative macro features create bays / coastal dents.
- A restrained smoothing pass removes accidental spikes.
- Frontend rendering uses Catmull-Rom-style cubic SVG paths rather than straight `<polygon>` edges.

The data remains a normal ordered point list; only the generation and rendering quality changed.

### Mountain ranges

Mountains are no longer independently scattered around a centroid. Markers are generated along one or more curved range axes inside each landmass. The density slider still controls the total amount.

### Rivers / hydrology

The old rule was effectively:

```text
x += random left/right
y += always positive
```

That rule was removed.

Generator v2 creates a deterministic synthetic elevation field from:

- distance from coast,
- mountain peaks / ranges.

A river starts in a high/interior source and repeatedly chooses a lower-elevation candidate. It can flow in any compass direction, meanders with bounded inertia, remains inside its landmass, and terminates at a coastline or a confluence with an existing river.

River SVG rendering is also curved with rounded caps/joins.

### Settlement suitability

Settlement placement is no longer `continent centroid +/- random offset`.

Candidates are sampled on valid land and scored using:

- access to rivers,
- useful coastal proximity,
- inland viability,
- penalty for sitting directly on a mountain peak,
- deterministic small variation.

A minimum-distance pass prevents obvious stacking/clumping. Counts are distributed across landmasses by land area, while giving each continent a primary city when the requested count allows it.

Generated settlement kinds are now:

- `city`
- `town`
- `village`

They receive different visual markers in the Generator preview and accepted Atlas map. Village labels are suppressed in the generator preview until hover to reduce label noise.

Generated settlement names are unique inside one draft.

### Accept into World

When generated locations are accepted:

- settlement `kind` is preserved,
- map pin icon/color reflects city/town/village,
- the containing generated landmass is used as the preferred parent continent,
- nearest-continent fallback remains only as a defensive fallback.

## Architectural constraints preserved

- Generator remains a pure Rust application function.
- No `rusqlite`, `AppState`, clock, OS RNG, or UUID dependency exists in generator code.
- Same request + same seed remains deterministic.
- Preview generation cannot mutate canonical SQLite data.
- Accept remains the single transaction boundary.
- Frontend remains Gateway-only; Atlas UI does not invoke Tauri directly.

## Verification

Local source verification for this checkpoint:

```text
TypeScript strict                         PASS
Architecture invariants                  PASS
SQLite/domain regressions                PASS
C1 -> v0.7.4 full npm run verify          PASS
Generator v2 source quality invariants   PASS
Rust delimiter/source sanity             PASS
```

Native Rust compilation and the new generator-quality assertions in `src-tauri/tests/atlas_flow.rs` must still be sealed on the Windows development machine with `cargo test`.
