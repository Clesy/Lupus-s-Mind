use serde::Serialize; use thiserror::Error;
#[derive(Error,Debug,Serialize)] pub enum CharacterError{#[error("Character not found: {0}")] NotFound(String),#[error("Database error: {0}")] DatabaseError(String),#[error("Validation error: {0}")] ValidationError(String),#[error("Mapping error: {0}")] MappingError(String)}
