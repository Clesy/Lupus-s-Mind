use chrono::{DateTime,Utc}; use serde::{Deserialize,Serialize};
#[derive(Debug,Clone,Serialize,Deserialize,PartialEq,Eq,Hash)] pub struct CharacterId(pub String);
#[derive(Debug,Clone,Serialize,Deserialize,PartialEq)] #[serde(rename_all="camelCase")] pub struct CharacterStats{pub str:u32,pub agi:u32,pub vit:u32,pub int:u32,pub mnd:u32}
#[derive(Debug,Clone,Serialize,Deserialize)] pub struct Character{pub id:CharacterId,pub name:String,pub alias:Option<String>,pub class_label:Option<String>,pub level:u32,pub base_stats:CharacterStats,pub biography:String,pub tags:Vec<String>,pub created_at:DateTime<Utc>,pub updated_at:DateTime<Utc>}
