use tauri::State; use crate::{app_state::AppState,shared::api_error::ApiError}; use crate::characters::application::use_cases::{self,CharacterDto,CharacterSummaryDto,UpsertCharacterInput};
#[tauri::command] pub fn characters_list(state:State<'_,AppState>)->Result<Vec<CharacterSummaryDto>,ApiError>{use_cases::list(&state.characters).map_err(Into::into)}
#[tauri::command] pub fn characters_get(state:State<'_,AppState>,id:String)->Result<CharacterDto,ApiError>{use_cases::get(&state.characters,id).map_err(Into::into)}
#[tauri::command] pub fn characters_create(state:State<'_,AppState>,input:UpsertCharacterInput)->Result<CharacterDto,ApiError>{use_cases::create(&state.characters,input).map_err(Into::into)}
#[tauri::command] pub fn characters_update(state:State<'_,AppState>,id:String,input:UpsertCharacterInput)->Result<CharacterDto,ApiError>{use_cases::update(&state.characters,id,input).map_err(Into::into)}
#[tauri::command] pub fn characters_delete(state:State<'_,AppState>,id:String)->Result<(),ApiError>{use_cases::delete(&state.characters,id).map_err(Into::into)}
