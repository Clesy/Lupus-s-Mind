use std::{
    fs,
    path::{Path, PathBuf},
    sync::{Arc, Mutex},
    time::UNIX_EPOCH,
};

use chrono::{DateTime, Utc};
use rusqlite::{params, types::ValueRef, Connection, OptionalExtension};
use serde_json::{json, Map, Value};

use crate::{
    projects::infrastructure::project_registry::SharedDatabasePath,
    shared::database::{Database, SharedConnection, LATEST_SCHEMA_VERSION},
    workspace::{
        application::port::WorkspaceOperations,
        domain::{
            error::WorkspaceError,
            workspace::{AppSettings, DatabaseHealth, WorkspaceArtifact},
        },
    },
};

#[derive(Clone)]
pub struct SqliteWorkspaceOperations {
    conn: SharedConnection,
    database_path: SharedDatabasePath,
    gate: Arc<Mutex<()>>,
}

impl SqliteWorkspaceOperations {
    pub fn new(conn: SharedConnection, database_path: SharedDatabasePath) -> Self {
        Self { conn, database_path, gate: Arc::new(Mutex::new(())) }
    }

    fn now_stamp() -> String { Utc::now().format("%Y%m%dT%H%M%SZ").to_string() }

    fn current_database_path(&self) -> Result<PathBuf, WorkspaceError> {
        self.database_path.lock().map(|path| path.clone()).map_err(|e| WorkspaceError::Filesystem(e.to_string()))
    }

    fn artifact_dir(&self) -> Result<PathBuf, WorkspaceError> {
        let database_path = self.current_database_path()?;
        let parent = database_path.parent().unwrap_or_else(|| Path::new("."));
        let file_name = database_path.file_name().and_then(|value| value.to_str()).unwrap_or("");
        if file_name.eq_ignore_ascii_case("lupus-mind.sqlite") {
            return Ok(parent.join("workspace-artifacts"));
        }
        let stem = database_path.file_stem().and_then(|value| value.to_str()).unwrap_or("workspace");
        Ok(parent.join(format!("{}-artifacts", stem)))
    }

    fn ensure_artifact_dir(&self) -> Result<PathBuf, WorkspaceError> {
        let dir = self.artifact_dir()?;
        fs::create_dir_all(&dir).map_err(|e| WorkspaceError::Filesystem(e.to_string()))?;
        Ok(dir)
    }

    fn escaped_sql_path(path: &Path) -> String { path.to_string_lossy().replace('\'', "''") }

    fn sidecar(path: &Path, suffix: &str) -> PathBuf {
        PathBuf::from(format!("{}{}", path.to_string_lossy(), suffix))
    }

    fn remove_sqlite_sidecars(path: &Path) {
        let _ = fs::remove_file(Self::sidecar(path, "-wal"));
        let _ = fs::remove_file(Self::sidecar(path, "-shm"));
    }

    fn artifact(&self, path: &Path, kind: &str) -> Result<WorkspaceArtifact, WorkspaceError> {
        let meta = fs::metadata(path).map_err(|e| WorkspaceError::Filesystem(e.to_string()))?;
        let modified: DateTime<Utc> = meta.modified().unwrap_or(UNIX_EPOCH).into();
        Ok(WorkspaceArtifact {
            name: path.file_name().and_then(|v| v.to_str()).unwrap_or("artifact").to_string(),
            kind: kind.to_string(),
            path: path.to_string_lossy().to_string(),
            size_bytes: meta.len(),
            modified_at: modified.to_rfc3339(),
        })
    }

    fn setting_bool(conn: &Connection, key: &str, fallback: bool) -> Result<bool, WorkspaceError> {
        let value: Option<String> = conn
            .query_row("SELECT value FROM workspace_settings WHERE key=?1", params![key], |r| r.get(0))
            .optional()
            .map_err(|e| WorkspaceError::Database(e.to_string()))?;
        Ok(value.map(|v| v == "true").unwrap_or(fallback))
    }

    fn setting_u32(conn: &Connection, key: &str, fallback: u32) -> Result<u32, WorkspaceError> {
        let value: Option<String> = conn
            .query_row("SELECT value FROM workspace_settings WHERE key=?1", params![key], |r| r.get(0))
            .optional()
            .map_err(|e| WorkspaceError::Database(e.to_string()))?;
        Ok(value.and_then(|v| v.parse::<u32>().ok()).unwrap_or(fallback))
    }

    fn persist_settings(conn: &mut Connection, settings: &AppSettings) -> Result<AppSettings, WorkspaceError> {
        if !(1..=50).contains(&settings.default_generator_count) {
            return Err(WorkspaceError::Validation("default_generator_count must be between 1 and 50".into()));
        }
        let tx = conn.transaction().map_err(|e| WorkspaceError::Database(e.to_string()))?;
        let pairs = [
            ("compact_navigation", settings.compact_navigation.to_string()),
            ("reduce_motion", settings.reduce_motion.to_string()),
            ("confirm_destructive_actions", settings.confirm_destructive_actions.to_string()),
            ("restore_last_route", settings.restore_last_route.to_string()),
            ("default_generator_count", settings.default_generator_count.to_string()),
        ];
        for (key, value) in pairs {
            tx.execute(
                "INSERT INTO workspace_settings(key,value,updated_at) VALUES(?1,?2,strftime('%Y-%m-%dT%H:%M:%fZ','now')) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at",
                params![key, value],
            )
            .map_err(|e| WorkspaceError::Database(e.to_string()))?;
        }
        tx.commit().map_err(|e| WorkspaceError::Database(e.to_string()))?;
        Ok(settings.clone())
    }

    fn snapshot_current_to(&self, path: &Path) -> Result<(), WorkspaceError> {
        if path.exists() {
            return Err(WorkspaceError::Filesystem("snapshot target already exists".into()));
        }
        let escaped = Self::escaped_sql_path(path);
        let conn = self.conn.lock().map_err(|e| WorkspaceError::Database(e.to_string()))?;
        conn.execute_batch(&format!("VACUUM INTO '{}';", escaped))
            .map_err(|e| WorkspaceError::Database(e.to_string()))
    }

    fn validate_restore_source(&self, source: &Path) -> Result<PathBuf, WorkspaceError> {
        if source.extension().and_then(|v| v.to_str()).map(|v| v.eq_ignore_ascii_case("sqlite")) != Some(true) {
            return Err(WorkspaceError::Validation("only SQLite backup/recovery artifacts can be restored".into()));
        }
        let artifact_dir = self.ensure_artifact_dir()?;
        let canonical_dir = fs::canonicalize(&artifact_dir).map_err(|e| WorkspaceError::Filesystem(e.to_string()))?;
        let canonical_source = fs::canonicalize(source).map_err(|e| WorkspaceError::Filesystem(e.to_string()))?;
        if !canonical_source.starts_with(&canonical_dir) {
            return Err(WorkspaceError::Validation("restore source must be a workspace recovery artifact".into()));
        }
        let source_conn = Connection::open(&canonical_source).map_err(|e| WorkspaceError::Database(e.to_string()))?;
        let quick: String = source_conn
            .query_row("PRAGMA quick_check", [], |r| r.get(0))
            .map_err(|e| WorkspaceError::Database(e.to_string()))?;
        if quick != "ok" {
            return Err(WorkspaceError::Validation(format!("restore source failed SQLite quick_check: {quick}")));
        }
        Ok(canonical_source)
    }

    fn table_names(conn: &Connection) -> Result<Vec<String>, WorkspaceError> {
        let mut stmt = conn
            .prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")
            .map_err(|e| WorkspaceError::Database(e.to_string()))?;
        let rows = stmt.query_map([], |r| r.get::<_, String>(0)).map_err(|e| WorkspaceError::Database(e.to_string()))?;
        let mut out = Vec::new();
        for row in rows { out.push(row.map_err(|e| WorkspaceError::Database(e.to_string()))?); }
        Ok(out)
    }

    fn quote_ident(value: &str) -> String { format!("\"{}\"", value.replace('"', "\"\"")) }

    fn table_json(conn: &Connection, table: &str) -> Result<Value, WorkspaceError> {
        let sql = format!("SELECT * FROM {}", Self::quote_ident(table));
        let mut stmt = conn.prepare(&sql).map_err(|e| WorkspaceError::Database(e.to_string()))?;
        let names: Vec<String> = stmt.column_names().iter().map(|s| s.to_string()).collect();
        let rows = stmt
            .query_map([], |row| {
                let mut object = Map::new();
                for (index, name) in names.iter().enumerate() {
                    let value = match row.get_ref(index)? {
                        ValueRef::Null => Value::Null,
                        ValueRef::Integer(v) => json!(v),
                        ValueRef::Real(v) => json!(v),
                        ValueRef::Text(v) => Value::String(String::from_utf8_lossy(v).to_string()),
                        ValueRef::Blob(v) => Value::String(format!("<blob:{} bytes>", v.len())),
                    };
                    object.insert(name.clone(), value);
                }
                Ok(Value::Object(object))
            })
            .map_err(|e| WorkspaceError::Database(e.to_string()))?;
        let mut values = Vec::new();
        for row in rows { values.push(row.map_err(|e| WorkspaceError::Database(e.to_string()))?); }
        Ok(Value::Array(values))
    }
}

impl WorkspaceOperations for SqliteWorkspaceOperations {
    fn health(&self) -> Result<DatabaseHealth, WorkspaceError> {
        let database_path = self.current_database_path()?;
        let conn = self.conn.lock().map_err(|e| WorkspaceError::Database(e.to_string()))?;
        let quick_check: String = conn.query_row("PRAGMA quick_check", [], |r| r.get(0)).map_err(|e| WorkspaceError::Database(e.to_string()))?;
        let foreign_key_violations: u32 = {
            let mut stmt = conn.prepare("PRAGMA foreign_key_check").map_err(|e| WorkspaceError::Database(e.to_string()))?;
            let mut rows = stmt.query([]).map_err(|e| WorkspaceError::Database(e.to_string()))?;
            let mut count = 0u32;
            while rows.next().map_err(|e| WorkspaceError::Database(e.to_string()))?.is_some() { count += 1; }
            count
        };
        let schema_version: u32 = conn
            .query_row("SELECT COALESCE(MAX(version),0) FROM schema_migrations", [], |r| r.get(0))
            .map_err(|e| WorkspaceError::Database(e.to_string()))?;
        drop(conn);
        let size = fs::metadata(&database_path).map(|m| m.len()).unwrap_or(0);
        let backup_count = self
            .list_artifacts()?
            .into_iter()
            .filter(|a| a.kind == "sqlite-backup" || a.kind == "recovery-point")
            .count() as u32;
        let healthy = quick_check == "ok" && foreign_key_violations == 0 && schema_version == LATEST_SCHEMA_VERSION;
        Ok(DatabaseHealth {
            status: if healthy { "healthy" } else { "attention" }.into(),
            quick_check,
            foreign_key_violations,
            schema_version,
            expected_schema_version: LATEST_SCHEMA_VERSION,
            database_size_bytes: size,
            database_path: database_path.to_string_lossy().to_string(),
            backup_count,
        })
    }

    fn settings(&self) -> Result<AppSettings, WorkspaceError> {
        let conn = self.conn.lock().map_err(|e| WorkspaceError::Database(e.to_string()))?;
        Ok(AppSettings {
            compact_navigation: Self::setting_bool(&conn, "compact_navigation", false)?,
            reduce_motion: Self::setting_bool(&conn, "reduce_motion", false)?,
            confirm_destructive_actions: Self::setting_bool(&conn, "confirm_destructive_actions", true)?,
            restore_last_route: Self::setting_bool(&conn, "restore_last_route", true)?,
            default_generator_count: Self::setting_u32(&conn, "default_generator_count", 8)?,
        })
    }

    fn save_settings(&self, settings: &AppSettings) -> Result<AppSettings, WorkspaceError> {
        let mut conn = self.conn.lock().map_err(|e| WorkspaceError::Database(e.to_string()))?;
        Self::persist_settings(&mut conn, settings)
    }

    fn reset_settings(&self) -> Result<AppSettings, WorkspaceError> {
        let defaults = AppSettings::default();
        let mut conn = self.conn.lock().map_err(|e| WorkspaceError::Database(e.to_string()))?;
        Self::persist_settings(&mut conn, &defaults)
    }

    fn create_backup(&self) -> Result<WorkspaceArtifact, WorkspaceError> {
        let _guard = self.gate.lock().map_err(|e| WorkspaceError::Filesystem(e.to_string()))?;
        let artifact_dir = self.ensure_artifact_dir()?;
        let path = artifact_dir.join(format!("lupus-mind-backup-{}.sqlite", Self::now_stamp()));
        self.snapshot_current_to(&path)?;
        self.artifact(&path, "sqlite-backup")
    }

    fn export_json(&self) -> Result<WorkspaceArtifact, WorkspaceError> {
        let _guard = self.gate.lock().map_err(|e| WorkspaceError::Filesystem(e.to_string()))?;
        let artifact_dir = self.ensure_artifact_dir()?;
        let path = artifact_dir.join(format!("lupus-mind-export-{}.json", Self::now_stamp()));
        let conn = self.conn.lock().map_err(|e| WorkspaceError::Database(e.to_string()))?;
        let mut tables = Map::new();
        for table in Self::table_names(&conn)? { tables.insert(table.clone(), Self::table_json(&conn, &table)?); }
        let schema_version: u32 = conn
            .query_row("SELECT COALESCE(MAX(version),0) FROM schema_migrations", [], |r| r.get(0))
            .map_err(|e| WorkspaceError::Database(e.to_string()))?;
        let document = json!({
            "format":"lupus-mind-workspace-export",
            "formatVersion":1,
            "schemaVersion":schema_version,
            "exportedAt":Utc::now().to_rfc3339(),
            "tables":tables
        });
        drop(conn);
        fs::write(
            &path,
            serde_json::to_vec_pretty(&document).map_err(|e| WorkspaceError::Serialization(e.to_string()))?,
        )
        .map_err(|e| WorkspaceError::Filesystem(e.to_string()))?;
        self.artifact(&path, "json-export")
    }

    fn list_artifacts(&self) -> Result<Vec<WorkspaceArtifact>, WorkspaceError> {
        let artifact_dir = self.artifact_dir()?;
        if !artifact_dir.exists() { return Ok(Vec::new()); }
        let mut out = Vec::new();
        for entry in fs::read_dir(&artifact_dir).map_err(|e| WorkspaceError::Filesystem(e.to_string()))? {
            let path = entry.map_err(|e| WorkspaceError::Filesystem(e.to_string()))?.path();
            if !path.is_file() { continue; }
            let name = path.file_name().and_then(|v| v.to_str()).unwrap_or("");
            let kind = if name.contains("pre-migration") || name.contains("pre-restore") {
                "recovery-point"
            } else if path.extension().and_then(|v| v.to_str()) == Some("sqlite") {
                "sqlite-backup"
            } else if path.extension().and_then(|v| v.to_str()) == Some("json") {
                "json-export"
            } else {
                continue;
            };
            out.push(self.artifact(&path, kind)?);
        }
        out.sort_by(|a, b| b.modified_at.cmp(&a.modified_at));
        Ok(out)
    }

    fn restore_artifact(&self, path: &str) -> Result<DatabaseHealth, WorkspaceError> {
        let _guard = self.gate.lock().map_err(|e| WorkspaceError::Filesystem(e.to_string()))?;
        let active_path = self.current_database_path()?;
        if active_path == PathBuf::from(":memory:") {
            return Err(WorkspaceError::Validation("recovery restore is unavailable for an in-memory workspace".into()));
        }
        let source = self.validate_restore_source(Path::new(path))?;
        let artifact_dir = self.ensure_artifact_dir()?;
        let safety = artifact_dir.join(format!("lupus-mind-pre-restore-{}.sqlite", Self::now_stamp()));
        self.snapshot_current_to(&safety)?;

        let parent = active_path.parent().unwrap_or_else(|| Path::new("."));
        let stem = active_path.file_stem().and_then(|v| v.to_str()).unwrap_or("lupus-mind");
        let stamp = Utc::now().timestamp_millis();
        let stage = parent.join(format!(".{stem}-restore-stage-{stamp}.sqlite"));
        let rollback = parent.join(format!(".{stem}-restore-rollback-{stamp}.sqlite"));
        fs::copy(&source, &stage).map_err(|e| WorkspaceError::Filesystem(e.to_string()))?;

        {
            let stage_conn = Database::open_configured_connection_for_restore(&stage)
                .map_err(|e| WorkspaceError::Database(format!("restore source migration failed: {e}")))?;
            let quick: String = stage_conn
                .query_row("PRAGMA quick_check", [], |r| r.get(0))
                .map_err(|e| WorkspaceError::Database(e.to_string()))?;
            if quick != "ok" {
                let _ = fs::remove_file(&stage);
                Self::remove_sqlite_sidecars(&stage);
                return Err(WorkspaceError::Validation(format!("restored database failed SQLite quick_check: {quick}")));
            }
            let mut stmt = stage_conn.prepare("PRAGMA foreign_key_check").map_err(|e| WorkspaceError::Database(e.to_string()))?;
            let mut rows = stmt.query([]).map_err(|e| WorkspaceError::Database(e.to_string()))?;
            if rows.next().map_err(|e| WorkspaceError::Database(e.to_string()))?.is_some() {
                let _ = fs::remove_file(&stage);
                Self::remove_sqlite_sidecars(&stage);
                return Err(WorkspaceError::Validation("restored database contains foreign-key violations".into()));
            }
            drop(rows);
            drop(stmt);
            stage_conn.execute_batch("PRAGMA wal_checkpoint(TRUNCATE);").map_err(|e| WorkspaceError::Database(e.to_string()))?;
        }
        Self::remove_sqlite_sidecars(&stage);

        let placeholder = Connection::open_in_memory().map_err(|e| WorkspaceError::Database(e.to_string()))?;
        let old_connection = {
            let mut active = self.conn.lock().map_err(|e| WorkspaceError::Database(e.to_string()))?;
            active.execute_batch("PRAGMA wal_checkpoint(TRUNCATE);").map_err(|e| WorkspaceError::Database(e.to_string()))?;
            std::mem::replace(&mut *active, placeholder)
        };
        drop(old_connection);
        Self::remove_sqlite_sidecars(&active_path);

        if rollback.exists() { let _ = fs::remove_file(&rollback); }
        if let Err(error) = fs::rename(&active_path, &rollback) {
            let _ = fs::remove_file(&stage);
            Self::remove_sqlite_sidecars(&stage);
            let replacement = Database::open_configured_connection(&active_path)
                .map_err(|reopen_error| WorkspaceError::Database(format!("could not stage current workspace for restore ({error}); reopening the active workspace also failed ({reopen_error})")))?;
            let mut active = self.conn.lock().map_err(|e| WorkspaceError::Database(e.to_string()))?;
            *active = replacement;
            return Err(WorkspaceError::Filesystem(format!("could not stage current workspace for restore: {error}")));
        }
        if let Err(error) = fs::rename(&stage, &active_path) {
            let _ = fs::rename(&rollback, &active_path);
            let replacement = Database::open_configured_connection(&active_path).map_err(|e| WorkspaceError::Database(e.to_string()))?;
            let mut active = self.conn.lock().map_err(|e| WorkspaceError::Database(e.to_string()))?;
            *active = replacement;
            return Err(WorkspaceError::Filesystem(format!("could not activate restore: {error}")));
        }

        match Database::open_configured_connection(&active_path) {
            Ok(replacement) => {
                let mut active = self.conn.lock().map_err(|e| WorkspaceError::Database(e.to_string()))?;
                *active = replacement;
                drop(active);
                let _ = fs::remove_file(&rollback);
                Self::remove_sqlite_sidecars(&rollback);
                self.health()
            }
            Err(error) => {
                let _ = fs::remove_file(&active_path);
                Self::remove_sqlite_sidecars(&active_path);
                let rollback_result = fs::rename(&rollback, &active_path);
                if rollback_result.is_err() {
                    let _ = fs::copy(&safety, &active_path);
                }
                let replacement = Database::open_configured_connection(&active_path)
                    .map_err(|rollback_error| WorkspaceError::Database(format!("restore failed ({error}); rollback also failed ({rollback_error})")))?;
                let mut active = self.conn.lock().map_err(|e| WorkspaceError::Database(e.to_string()))?;
                *active = replacement;
                Err(WorkspaceError::Database(format!("restore failed and was rolled back safely: {error}")))
            }
        }
    }
}
