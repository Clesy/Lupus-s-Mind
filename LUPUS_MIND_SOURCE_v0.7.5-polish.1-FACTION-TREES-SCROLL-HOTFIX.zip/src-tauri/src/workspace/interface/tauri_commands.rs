use tauri::State;
use crate::{app_state::AppState, shared::api_error::ApiError, workspace::{application::service, domain::workspace::{AppSettings, DatabaseHealth, WorkspaceArtifact}}};

#[tauri::command] pub fn workspace_health(state: State<'_, AppState>) -> Result<DatabaseHealth, ApiError> { service::health(&state.workspace).map_err(Into::into) }
#[tauri::command] pub fn workspace_settings_get(state: State<'_, AppState>) -> Result<AppSettings, ApiError> { service::settings(&state.workspace).map_err(Into::into) }
#[tauri::command] pub fn workspace_settings_save(state: State<'_, AppState>, settings: AppSettings) -> Result<AppSettings, ApiError> { service::save_settings(&state.workspace, settings).map_err(Into::into) }
#[tauri::command] pub fn workspace_settings_reset(state: State<'_, AppState>) -> Result<AppSettings, ApiError> { service::reset_settings(&state.workspace).map_err(Into::into) }
#[tauri::command] pub fn workspace_backup_create(state: State<'_, AppState>) -> Result<WorkspaceArtifact, ApiError> { service::create_backup(&state.workspace).map_err(Into::into) }
#[tauri::command] pub fn workspace_export_json(state: State<'_, AppState>) -> Result<WorkspaceArtifact, ApiError> { service::export_json(&state.workspace).map_err(Into::into) }
#[tauri::command] pub fn workspace_artifacts_list(state: State<'_, AppState>) -> Result<Vec<WorkspaceArtifact>, ApiError> { service::list_artifacts(&state.workspace).map_err(Into::into) }
#[tauri::command] pub fn workspace_artifact_restore(state: State<'_, AppState>, path: String) -> Result<DatabaseHealth, ApiError> { service::restore_artifact(&state.workspace, &path).map_err(Into::into) }
