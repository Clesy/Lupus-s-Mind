use crate::workspace::{application::port::WorkspaceOperations, domain::{error::WorkspaceError, workspace::{AppSettings, DatabaseHealth, WorkspaceArtifact}}};

pub fn health(ops: &dyn WorkspaceOperations) -> Result<DatabaseHealth, WorkspaceError> { ops.health() }
pub fn settings(ops: &dyn WorkspaceOperations) -> Result<AppSettings, WorkspaceError> { ops.settings() }
pub fn save_settings(ops: &dyn WorkspaceOperations, settings: AppSettings) -> Result<AppSettings, WorkspaceError> { ops.save_settings(&settings) }
pub fn reset_settings(ops: &dyn WorkspaceOperations) -> Result<AppSettings, WorkspaceError> { ops.reset_settings() }
pub fn create_backup(ops: &dyn WorkspaceOperations) -> Result<WorkspaceArtifact, WorkspaceError> { ops.create_backup() }
pub fn export_json(ops: &dyn WorkspaceOperations) -> Result<WorkspaceArtifact, WorkspaceError> { ops.export_json() }
pub fn list_artifacts(ops: &dyn WorkspaceOperations) -> Result<Vec<WorkspaceArtifact>, WorkspaceError> { ops.list_artifacts() }
pub fn restore_artifact(ops: &dyn WorkspaceOperations, path: &str) -> Result<DatabaseHealth, WorkspaceError> { ops.restore_artifact(path) }
