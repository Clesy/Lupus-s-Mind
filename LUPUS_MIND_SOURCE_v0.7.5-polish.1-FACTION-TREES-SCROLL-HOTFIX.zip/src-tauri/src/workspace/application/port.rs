use crate::workspace::domain::{error::WorkspaceError, workspace::{AppSettings, DatabaseHealth, WorkspaceArtifact}};

pub trait WorkspaceOperations: Send + Sync {
    fn health(&self) -> Result<DatabaseHealth, WorkspaceError>;
    fn settings(&self) -> Result<AppSettings, WorkspaceError>;
    fn save_settings(&self, settings: &AppSettings) -> Result<AppSettings, WorkspaceError>;
    fn reset_settings(&self) -> Result<AppSettings, WorkspaceError>;
    fn create_backup(&self) -> Result<WorkspaceArtifact, WorkspaceError>;
    fn export_json(&self) -> Result<WorkspaceArtifact, WorkspaceError>;
    fn list_artifacts(&self) -> Result<Vec<WorkspaceArtifact>, WorkspaceError>;
    fn restore_artifact(&self, path: &str) -> Result<DatabaseHealth, WorkspaceError>;
}
