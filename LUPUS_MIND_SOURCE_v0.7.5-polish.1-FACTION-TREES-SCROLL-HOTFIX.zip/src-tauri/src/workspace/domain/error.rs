use serde::Serialize;
use thiserror::Error;

#[derive(Debug, Error, Serialize)]
pub enum WorkspaceError {
    #[error("Workspace database error: {0}")]
    Database(String),
    #[error("Workspace filesystem error: {0}")]
    Filesystem(String),
    #[error("Workspace serialization error: {0}")]
    Serialization(String),
    #[error("Workspace validation error: {0}")]
    Validation(String),
}
