use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AppSettings {
    pub compact_navigation: bool,
    pub reduce_motion: bool,
    pub confirm_destructive_actions: bool,
    pub restore_last_route: bool,
    pub default_generator_count: u32,
}

impl Default for AppSettings {
    fn default() -> Self {
        Self {
            compact_navigation: false,
            reduce_motion: false,
            confirm_destructive_actions: true,
            restore_last_route: true,
            default_generator_count: 8,
        }
    }
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct DatabaseHealth {
    pub status: String,
    pub quick_check: String,
    pub foreign_key_violations: u32,
    pub schema_version: u32,
    pub expected_schema_version: u32,
    pub database_size_bytes: u64,
    pub database_path: String,
    pub backup_count: u32,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct WorkspaceArtifact {
    pub name: String,
    pub kind: String,
    pub path: String,
    pub size_bytes: u64,
    pub modified_at: String,
}
