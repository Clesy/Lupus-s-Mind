use rusqlite::{params,Transaction};
use crate::{knowledge_links::domain::{error::LinkError,link::{EntityBacklink,EntityMention},repository::KnowledgeLinkRepository},shared::database::SharedConnection};

#[derive(Clone)]pub struct SqliteKnowledgeLinkRepository{conn:SharedConnection}
#[derive(Clone)]struct Target{kind:String,id:String,label:String}
impl SqliteKnowledgeLinkRepository{pub fn new(conn:SharedConnection)->Self{Self{conn}}
 fn targets(tx:&Transaction<'_>)->Result<Vec<Target>,LinkError>{
  let mut out=Vec::new();
  for (sql,kind) in [
   ("SELECT id,name FROM characters","character"),("SELECT id,name FROM items","item"),("SELECT id,name FROM skills","skill"),("SELECT id,title FROM lore_pages","lore")]{
   let mut s=tx.prepare(sql).map_err(db)?;let rows=s.query_map([],|r|Ok((r.get::<_,String>(0)?,r.get::<_,String>(1)?))).map_err(db)?;
   for row in rows{let (id,label)=row.map_err(db)?;if !label.trim().is_empty(){out.push(Target{kind:kind.into(),id,label});}}
  }
  let mut aliases=tx.prepare("SELECT id,alias FROM characters WHERE alias IS NOT NULL AND trim(alias)<>''").map_err(db)?;
  let rows=aliases.query_map([],|r|Ok((r.get::<_,String>(0)?,r.get::<_,String>(1)?))).map_err(db)?;
  for row in rows{let(id,label)=row.map_err(db)?;out.push(Target{kind:"character".into(),id,label});}
  out.sort_by(|a,b|b.label.len().cmp(&a.label.len()).then_with(||a.label.cmp(&b.label)));Ok(out)
 }
 fn scan(text:&str,targets:&[Target])->Vec<(Target,u32,u32,String)>{
  let mut found=Vec::new();let bytes=text.as_bytes();let mut i=0usize;
  while i<bytes.len(){if bytes[i]!=b'@'{i+=1;continue;}let start=i;i+=1;let mut matched:Option<(Target,usize,String)>=None;
   for target in targets{let end=i+target.label.len();if end>text.len()||!text.is_char_boundary(i)||!text.is_char_boundary(end){continue;}let Some(slice)=text.get(i..end)else{continue};if slice.to_lowercase()!=target.label.to_lowercase(){continue;}let boundary=text.get(end..).and_then(|s|s.chars().next()).map(|c|!c.is_alphanumeric()&&c!='_'&&c!='-').unwrap_or(true);if boundary{matched=Some((target.clone(),end,slice.to_string()));break;}}
   if let Some((target,end,display))=matched{found.push((target,start.min(u32::MAX as usize) as u32,end.min(u32::MAX as usize) as u32,display));i=end;}else{i=start+1;}
  }found
 }
}
fn db(e:rusqlite::Error)->LinkError{LinkError::Database(e.to_string())}
fn valid_source(v:&str)->bool{matches!(v,"chapter"|"lore")}
fn valid_target(v:&str)->bool{matches!(v,"character"|"item"|"skill"|"lore")}
impl KnowledgeLinkRepository for SqliteKnowledgeLinkRepository{
 fn refresh_source(&self,source_kind:&str,source_id:&str,text:&str)->Result<(),LinkError>{if !valid_source(source_kind){return Err(LinkError::Validation("unsupported source kind".into()));}let mut c=self.conn.lock().map_err(|e|LinkError::Database(e.to_string()))?;let tx=c.transaction().map_err(db)?;let targets=Self::targets(&tx)?;let mentions=Self::scan(text,&targets);tx.execute("DELETE FROM entity_mentions WHERE source_kind=? AND source_id=?",params![source_kind,source_id]).map_err(db)?;for(target,start,end,display)in mentions{tx.execute("INSERT INTO entity_mentions(source_kind,source_id,target_kind,target_id,display_text,start_offset,end_offset) VALUES(?,?,?,?,?,?,?)",params![source_kind,source_id,target.kind,target.id,display,i64::from(start),i64::from(end)]).map_err(db)?;}tx.commit().map_err(db)}
 fn delete_source(&self,source_kind:&str,source_id:&str)->Result<(),LinkError>{if !valid_source(source_kind){return Err(LinkError::Validation("unsupported source kind".into()));}let c=self.conn.lock().map_err(|e|LinkError::Database(e.to_string()))?;c.execute("DELETE FROM entity_mentions WHERE source_kind=? AND source_id=?",params![source_kind,source_id]).map_err(db)?;Ok(())}
 fn mentions_for_source(&self,source_kind:&str,source_id:&str)->Result<Vec<EntityMention>,LinkError>{if !valid_source(source_kind){return Err(LinkError::Validation("unsupported source kind".into()));}let c=self.conn.lock().map_err(|e|LinkError::Database(e.to_string()))?;let sql=r#"SELECT m.source_kind,m.source_id,CASE m.source_kind WHEN 'chapter' THEN COALESCE(NULLIF(ch.title,''),'Chapter '||ch.chapter_number) ELSE lp.title END,m.target_kind,m.target_id,COALESCE(tc.name,ti.name,ts.name,tl.title,m.display_text),CASE m.target_kind WHEN 'character' THEN 'characters' WHEN 'item' THEN 'items' WHEN 'skill' THEN 'skills' ELSE 'lore' END,m.display_text,m.start_offset,m.end_offset FROM entity_mentions m LEFT JOIN manuscript_chapters ch ON m.source_kind='chapter' AND ch.id=m.source_id LEFT JOIN lore_pages lp ON m.source_kind='lore' AND lp.id=m.source_id LEFT JOIN characters tc ON m.target_kind='character' AND tc.id=m.target_id LEFT JOIN items ti ON m.target_kind='item' AND ti.id=m.target_id LEFT JOIN skills ts ON m.target_kind='skill' AND ts.id=m.target_id LEFT JOIN lore_pages tl ON m.target_kind='lore' AND tl.id=m.target_id WHERE m.source_kind=? AND m.source_id=? ORDER BY m.start_offset"#;let mut s=c.prepare(sql).map_err(db)?;let rows=s.query_map(params![source_kind,source_id],|r|Ok(EntityMention{source_kind:r.get(0)?,source_id:r.get(1)?,source_title:r.get::<_,Option<String>>(2)?.unwrap_or_default(),target_kind:r.get(3)?,target_id:r.get(4)?,target_title:r.get(5)?,route:r.get(6)?,display_text:r.get(7)?,start_offset:r.get::<_,i64>(8)?.max(0) as u32,end_offset:r.get::<_,i64>(9)?.max(0) as u32})).map_err(db)?;rows.map(|r|r.map_err(db)).collect()}
 fn backlinks_for_target(&self,target_kind:&str,target_id:&str)->Result<Vec<EntityBacklink>,LinkError>{if !valid_target(target_kind){return Err(LinkError::Validation("unsupported target kind".into()));}let c=self.conn.lock().map_err(|e|LinkError::Database(e.to_string()))?;let sql=r#"SELECT m.source_kind,m.source_id,CASE m.source_kind WHEN 'chapter' THEN COALESCE(NULLIF(ch.title,''),'Chapter '||ch.chapter_number) ELSE lp.title END,CASE m.source_kind WHEN 'chapter' THEN 'manuscript' ELSE 'lore' END,MIN(m.display_text),COUNT(*) FROM entity_mentions m LEFT JOIN manuscript_chapters ch ON m.source_kind='chapter' AND ch.id=m.source_id LEFT JOIN lore_pages lp ON m.source_kind='lore' AND lp.id=m.source_id WHERE m.target_kind=? AND m.target_id=? GROUP BY m.source_kind,m.source_id ORDER BY CASE m.source_kind WHEN 'chapter' THEN ch.chapter_number ELSE 2147483647 END, m.source_id"#;let mut s=c.prepare(sql).map_err(db)?;let rows=s.query_map(params![target_kind,target_id],|r|Ok(EntityBacklink{source_kind:r.get(0)?,source_id:r.get(1)?,source_title:r.get::<_,Option<String>>(2)?.unwrap_or_default(),route:r.get(3)?,display_text:r.get(4)?,occurrences:r.get::<_,i64>(5)?.max(0) as u32})).map_err(db)?;rows.map(|r|r.map_err(db)).collect()}
}
