use serde::Serialize;
#[derive(Debug,Clone,Serialize)]#[serde(rename_all="camelCase")]
pub struct EntityMention{pub source_kind:String,pub source_id:String,pub source_title:String,pub target_kind:String,pub target_id:String,pub target_title:String,pub route:String,pub display_text:String,pub start_offset:u32,pub end_offset:u32}
#[derive(Debug,Clone,Serialize)]#[serde(rename_all="camelCase")]
pub struct EntityBacklink{pub source_kind:String,pub source_id:String,pub source_title:String,pub route:String,pub display_text:String,pub occurrences:u32}
