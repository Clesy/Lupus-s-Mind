use crate::knowledge_links::domain::{error::LinkError,link::{EntityBacklink,EntityMention}};
pub trait KnowledgeLinkRepository:Send+Sync{
 fn refresh_source(&self,source_kind:&str,source_id:&str,text:&str)->Result<(),LinkError>;
 fn delete_source(&self,source_kind:&str,source_id:&str)->Result<(),LinkError>;
 fn mentions_for_source(&self,source_kind:&str,source_id:&str)->Result<Vec<EntityMention>,LinkError>;
 fn backlinks_for_target(&self,target_kind:&str,target_id:&str)->Result<Vec<EntityBacklink>,LinkError>;
}
