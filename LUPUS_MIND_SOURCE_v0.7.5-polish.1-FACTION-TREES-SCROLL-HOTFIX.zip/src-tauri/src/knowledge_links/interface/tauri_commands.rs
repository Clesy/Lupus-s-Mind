use tauri::State;
use crate::{app_state::AppState,knowledge_links::domain::{link::{EntityBacklink,EntityMention},repository::KnowledgeLinkRepository},shared::api_error::ApiError};
#[tauri::command]pub fn knowledge_mentions_for_source(state:State<'_,AppState>,source_kind:String,source_id:String)->Result<Vec<EntityMention>,ApiError>{state.links.mentions_for_source(&source_kind,&source_id).map_err(Into::into)}
#[tauri::command]pub fn knowledge_backlinks_for_target(state:State<'_,AppState>,target_kind:String,target_id:String)->Result<Vec<EntityBacklink>,ApiError>{state.links.backlinks_for_target(&target_kind,&target_id).map_err(Into::into)}
