use crate::projects::domain::{error::ProjectError, project::{CreateProjectInput, ProjectSummary}};

pub trait ProjectOperations: Send + Sync {
    fn list(&self) -> Result<Vec<ProjectSummary>, ProjectError>;
    fn current(&self) -> Result<ProjectSummary, ProjectError>;
    fn create(&self, input: &CreateProjectInput) -> Result<ProjectSummary, ProjectError>;
    fn switch(&self, id: &str) -> Result<ProjectSummary, ProjectError>;
}
