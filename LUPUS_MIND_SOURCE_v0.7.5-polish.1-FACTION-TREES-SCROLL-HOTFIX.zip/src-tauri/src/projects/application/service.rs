use crate::projects::{application::port::ProjectOperations, domain::{error::ProjectError, project::{CreateProjectInput, ProjectSummary}}};

pub fn list(ops: &dyn ProjectOperations) -> Result<Vec<ProjectSummary>, ProjectError> { ops.list() }
pub fn current(ops: &dyn ProjectOperations) -> Result<ProjectSummary, ProjectError> { ops.current() }
pub fn create(ops: &dyn ProjectOperations, input: CreateProjectInput) -> Result<ProjectSummary, ProjectError> { ops.create(&input) }
pub fn switch(ops: &dyn ProjectOperations, id: &str) -> Result<ProjectSummary, ProjectError> { ops.switch(id) }
