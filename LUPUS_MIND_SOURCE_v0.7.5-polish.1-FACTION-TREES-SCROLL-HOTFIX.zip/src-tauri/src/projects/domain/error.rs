use thiserror::Error;

#[derive(Debug, Error)]
pub enum ProjectError {
    #[error("validation error: {0}")]
    Validation(String),
    #[error("project not found: {0}")]
    NotFound(String),
    #[error("filesystem error: {0}")]
    Filesystem(String),
    #[error("database error: {0}")]
    Database(String),
    #[error("serialization error: {0}")]
    Serialization(String),
}
