use tauri::State;
use crate::{app_state::AppState, projects::{application::service, domain::project::{CreateProjectInput, ProjectSummary}}, shared::api_error::ApiError};

#[tauri::command] pub fn projects_list(state: State<'_, AppState>) -> Result<Vec<ProjectSummary>, ApiError> { service::list(&state.projects).map_err(Into::into) }
#[tauri::command] pub fn projects_current(state: State<'_, AppState>) -> Result<ProjectSummary, ApiError> { service::current(&state.projects).map_err(Into::into) }
#[tauri::command] pub fn projects_create(state: State<'_, AppState>, input: CreateProjectInput) -> Result<ProjectSummary, ApiError> { service::create(&state.projects, input).map_err(Into::into) }
#[tauri::command] pub fn projects_switch(state: State<'_, AppState>, id: String) -> Result<ProjectSummary, ApiError> { service::switch(&state.projects, &id).map_err(Into::into) }
