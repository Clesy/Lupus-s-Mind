use std::{fs, path::{Path, PathBuf}, sync::{Arc, Mutex}};
use chrono::Utc;
use serde::{Deserialize, Serialize};
use uuid::Uuid;
use crate::{projects::{application::port::ProjectOperations, domain::{error::ProjectError, project::{CreateProjectInput, ProjectSummary}}}, shared::database::{Database, SharedConnection}};

pub type SharedDatabasePath = Arc<Mutex<PathBuf>>;

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
struct RegistryProject {
    id: String,
    name: String,
    database_file: String,
    created_at: String,
    last_opened_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
struct ProjectRegistryFile {
    active_project_id: String,
    projects: Vec<RegistryProject>,
}

#[derive(Clone)]
pub struct ProjectRegistry {
    base_dir: PathBuf,
    registry_path: PathBuf,
    conn: SharedConnection,
    active_database_path: SharedDatabasePath,
    gate: Arc<Mutex<()>>,
}

impl ProjectRegistry {
    pub fn bootstrap(base_dir: &Path) -> Result<PathBuf, ProjectError> {
        fs::create_dir_all(base_dir).map_err(|e| ProjectError::Filesystem(e.to_string()))?;
        let registry_path = base_dir.join("projects.json");
        if registry_path.exists() {
            let registry = Self::read_registry_path(&registry_path)?;
            let active = registry.projects.iter().find(|project| project.id == registry.active_project_id)
                .ok_or_else(|| ProjectError::NotFound(registry.active_project_id.clone()))?;
            let active_path = base_dir.join(&active.database_file);
            if !active_path.is_file() {
                return Err(ProjectError::Filesystem(format!("project database is missing: {}", active_path.display())));
            }
            return Ok(active_path);
        }

        let now = Utc::now().to_rfc3339();
        let legacy_path = base_dir.join("lupus-mind.sqlite");
        let database_file = "lupus-mind.sqlite".to_string();
        let project = RegistryProject {
            id: Uuid::new_v4().to_string(),
            name: "My World".to_string(),
            database_file,
            created_at: now.clone(),
            last_opened_at: now,
        };
        let registry = ProjectRegistryFile { active_project_id: project.id.clone(), projects: vec![project] };
        Self::write_registry_path(&registry_path, &registry)?;
        Ok(legacy_path)
    }

    pub fn new(base_dir: PathBuf, conn: SharedConnection, active_database_path: SharedDatabasePath) -> Self {
        let registry_path = base_dir.join("projects.json");
        Self { base_dir, registry_path, conn, active_database_path, gate: Arc::new(Mutex::new(())) }
    }

    fn read_registry_path(path: &Path) -> Result<ProjectRegistryFile, ProjectError> {
        let bytes = fs::read(path).map_err(|e| ProjectError::Filesystem(e.to_string()))?;
        serde_json::from_slice(&bytes).map_err(|e| ProjectError::Serialization(e.to_string()))
    }

    fn write_registry_path(path: &Path, registry: &ProjectRegistryFile) -> Result<(), ProjectError> {
        let bytes = serde_json::to_vec_pretty(registry).map_err(|e| ProjectError::Serialization(e.to_string()))?;
        fs::write(path, bytes).map_err(|e| ProjectError::Filesystem(e.to_string()))
    }

    fn read_registry(&self) -> Result<ProjectRegistryFile, ProjectError> { Self::read_registry_path(&self.registry_path) }
    fn write_registry(&self, registry: &ProjectRegistryFile) -> Result<(), ProjectError> { Self::write_registry_path(&self.registry_path, registry) }

    fn summary(project: &RegistryProject, active_id: &str) -> ProjectSummary {
        ProjectSummary {
            id: project.id.clone(),
            name: project.name.clone(),
            created_at: project.created_at.clone(),
            last_opened_at: project.last_opened_at.clone(),
            is_current: project.id == active_id,
        }
    }

    fn validate_name(name: &str) -> Result<String, ProjectError> {
        let trimmed = name.trim();
        if trimmed.is_empty() { return Err(ProjectError::Validation("project name is required".into())); }
        if trimmed.chars().count() > 80 { return Err(ProjectError::Validation("project name must be 80 characters or fewer".into())); }
        Ok(trimmed.to_string())
    }
}

impl ProjectOperations for ProjectRegistry {
    fn list(&self) -> Result<Vec<ProjectSummary>, ProjectError> {
        let registry = self.read_registry()?;
        let mut projects: Vec<ProjectSummary> = registry.projects.iter().map(|project| Self::summary(project, &registry.active_project_id)).collect();
        projects.sort_by(|a, b| b.last_opened_at.cmp(&a.last_opened_at).then_with(|| a.name.cmp(&b.name)));
        Ok(projects)
    }

    fn current(&self) -> Result<ProjectSummary, ProjectError> {
        let registry = self.read_registry()?;
        let project = registry.projects.iter().find(|project| project.id == registry.active_project_id)
            .ok_or_else(|| ProjectError::NotFound(registry.active_project_id.clone()))?;
        Ok(Self::summary(project, &registry.active_project_id))
    }

    fn create(&self, input: &CreateProjectInput) -> Result<ProjectSummary, ProjectError> {
        let _guard = self.gate.lock().map_err(|e| ProjectError::Filesystem(e.to_string()))?;
        let name = Self::validate_name(&input.name)?;
        let mut registry = self.read_registry()?;
        if registry.projects.iter().any(|project| project.name.eq_ignore_ascii_case(&name)) {
            return Err(ProjectError::Validation("a project with this name already exists".into()));
        }
        let id = Uuid::new_v4().to_string();
        let projects_dir = self.base_dir.join("projects");
        fs::create_dir_all(&projects_dir).map_err(|e| ProjectError::Filesystem(e.to_string()))?;
        let relative = format!("projects/{}.sqlite", id);
        let path = self.base_dir.join(&relative);
        Database::open(&path).map_err(|e| ProjectError::Database(e.to_string()))?;
        let now = Utc::now().to_rfc3339();
        let project = RegistryProject { id: id.clone(), name, database_file: relative, created_at: now.clone(), last_opened_at: now };
        registry.projects.push(project.clone());
        if let Err(error) = self.write_registry(&registry) {
            let _ = fs::remove_file(&path);
            return Err(error);
        }
        Ok(Self::summary(&project, &registry.active_project_id))
    }

    fn switch(&self, id: &str) -> Result<ProjectSummary, ProjectError> {
        let _guard = self.gate.lock().map_err(|e| ProjectError::Filesystem(e.to_string()))?;
        let mut registry = self.read_registry()?;
        let index = registry.projects.iter().position(|project| project.id == id).ok_or_else(|| ProjectError::NotFound(id.to_string()))?;
        let target_path = self.base_dir.join(&registry.projects[index].database_file);
        if !target_path.is_file() {
            return Err(ProjectError::Filesystem(format!("project database is missing: {}", target_path.display())));
        }
        let previous_path = self.active_database_path.lock()
            .map(|path| path.clone())
            .map_err(|e| ProjectError::Filesystem(e.to_string()))?;
        Database::replace_shared_connection(&self.conn, &target_path).map_err(|e| ProjectError::Database(e.to_string()))?;
        {
            let mut active = self.active_database_path.lock().map_err(|e| ProjectError::Filesystem(e.to_string()))?;
            *active = target_path.clone();
        }
        registry.active_project_id = id.to_string();
        registry.projects[index].last_opened_at = Utc::now().to_rfc3339();
        let summary = Self::summary(&registry.projects[index], &registry.active_project_id);
        if let Err(error) = self.write_registry(&registry) {
            let rollback = Database::replace_shared_connection(&self.conn, &previous_path);
            if rollback.is_ok() {
                if let Ok(mut active) = self.active_database_path.lock() { *active = previous_path; }
                return Err(error);
            }
            return Err(ProjectError::Database(format!("project registry update failed ({error}); connection rollback also failed")));
        }
        Ok(summary)
    }
}
