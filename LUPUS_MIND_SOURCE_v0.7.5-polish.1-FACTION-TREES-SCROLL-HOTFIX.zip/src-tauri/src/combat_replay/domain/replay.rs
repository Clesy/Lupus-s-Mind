use chrono::{DateTime,Utc};
use serde::{Deserialize,Serialize};
use crate::combat::domain::combat::{ActiveStatusEffect,CombatAction,CombatStatus,Combatant,CooldownState};

#[derive(Debug,Clone,Serialize,Deserialize,PartialEq)]
#[serde(rename_all="camelCase")]
pub struct CombatReplayState {
    pub session_id:String,
    pub status:CombatStatus,
    pub rng_seed:u64,
    pub round_number:u32,
    pub turn_index:u32,
    pub next_action_sequence:u64,
    pub combatants:Vec<Combatant>,
}
impl CombatReplayState {
    pub fn from_live(session:&crate::combat::domain::combat::CombatSession)->Self{Self{session_id:session.id.0.clone(),status:session.status,rng_seed:session.rng_seed,round_number:session.round_number,turn_index:session.turn_index,next_action_sequence:session.next_action_sequence,combatants:session.combatants.clone()}}
}

#[derive(Debug,Clone,Serialize,Deserialize,PartialEq)]
#[serde(tag="type",content="data",rename_all="snake_case")]
pub enum CombatReplayMutation {
    HpChanged{combatant_id:String,before:u32,after:u32},
    ManaChanged{combatant_id:String,before:u32,after:u32},
    DefeatedChanged{combatant_id:String,before:bool,after:bool},
    CooldownsChanged{combatant_id:String,before:Vec<CooldownState>,after:Vec<CooldownState>},
    ActiveEffectsChanged{combatant_id:String,before:Vec<ActiveStatusEffect>,after:Vec<ActiveStatusEffect>},
    TurnAdvanced{from_round:u32,from_index:u32,to_round:u32,to_index:u32},
    SessionStatusChanged{before:CombatStatus,after:CombatStatus},
}
impl CombatReplayMutation {
    pub fn kind(&self)->&'static str{match self{Self::HpChanged{..}=>"hp_changed",Self::ManaChanged{..}=>"mana_changed",Self::DefeatedChanged{..}=>"defeated_changed",Self::CooldownsChanged{..}=>"cooldowns_changed",Self::ActiveEffectsChanged{..}=>"active_effects_changed",Self::TurnAdvanced{..}=>"turn_advanced",Self::SessionStatusChanged{..}=>"session_status_changed"}}
}

#[derive(Debug,Clone,Serialize,Deserialize,PartialEq)]
#[serde(rename_all="camelCase")]
pub struct CombatReplayEvent {
    pub id:String,
    pub session_id:String,
    pub turn_execution_id:String,
    pub sequence_number:u64,
    pub event_index:u32,
    pub mutation:CombatReplayMutation,
    pub created_at:DateTime<Utc>,
}

#[derive(Debug,Clone,Serialize,Deserialize,PartialEq)]
#[serde(rename_all="camelCase")]
pub struct ReplayOrigin { pub session_id:String,pub origin_sequence:u64,pub state:CombatReplayState,pub created_at:DateTime<Utc> }

#[derive(Debug,Clone,Serialize,Deserialize,PartialEq)]
#[serde(rename_all="camelCase")]
pub struct TurnExecutionSummary {
    pub id:String,pub round_number:u32,pub turn_index:u32,pub actor_combatant_id:String,
    pub first_sequence:u64,pub last_sequence:u64,pub action_count:u32,pub created_at:DateTime<Utc>
}

#[derive(Debug,Clone,Serialize,Deserialize,PartialEq)]
#[serde(rename_all="camelCase")]
pub struct ReplayFrame {
    pub state:CombatReplayState,
    pub origin_sequence:u64,
    pub requested_sequence:u64,
    pub resolved_sequence:u64,
    pub turn_execution:Option<TurnExecutionSummary>,
    pub actions:Vec<CombatAction>,
    pub is_latest:bool,
    pub latest_sequence:u64,
    pub fingerprint:String,
}

#[derive(Debug,Clone,Serialize,Deserialize,PartialEq)]
#[serde(rename_all="camelCase")]
pub struct ReplayVerification {pub matches_live:bool,pub replay_fingerprint:String,pub live_fingerprint:String,pub latest_sequence:u64}
