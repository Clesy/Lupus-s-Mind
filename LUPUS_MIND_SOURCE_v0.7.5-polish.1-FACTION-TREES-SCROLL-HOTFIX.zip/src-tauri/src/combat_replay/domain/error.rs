use thiserror::Error;
#[derive(Debug,Error)]
pub enum ReplayError{
    #[error("combat replay session not found: {0}")] SessionNotFound(String),
    #[error("replay frame is unavailable before legacy origin sequence {0}")] BeforeOrigin(u64),
    #[error("turn execution not found: {0}")] ExecutionNotFound(String),
    #[error("replay divergence at sequence {sequence}: expected {expected}, actual {actual}")] Divergence{sequence:u64,expected:String,actual:String},
    #[error("replay database error: {0}")] Database(String),
    #[error("replay mapping error: {0}")] Mapping(String),
    #[error("replay validation error: {0}")] Validation(String),
}
