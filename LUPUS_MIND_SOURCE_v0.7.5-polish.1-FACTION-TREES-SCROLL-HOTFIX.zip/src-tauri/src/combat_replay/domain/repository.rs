use crate::{combat::domain::combat::CombatAction,combat_replay::domain::{error::ReplayError,replay::{CombatReplayEvent,CombatReplayState,ReplayOrigin,TurnExecutionSummary}}};
pub trait CombatReplayRepository:Send+Sync{
    fn origin(&self,session_id:&str)->Result<Option<ReplayOrigin>,ReplayError>;
    fn events_through(&self,session_id:&str,sequence:u64)->Result<Vec<CombatReplayEvent>,ReplayError>;
    fn turns(&self,session_id:&str)->Result<Vec<TurnExecutionSummary>,ReplayError>;
    fn actions_for_execution(&self,execution_id:&str)->Result<Vec<CombatAction>,ReplayError>;
    fn latest_sequence(&self,session_id:&str)->Result<u64,ReplayError>;
    fn live_state(&self,session_id:&str)->Result<Option<CombatReplayState>,ReplayError>;
}
