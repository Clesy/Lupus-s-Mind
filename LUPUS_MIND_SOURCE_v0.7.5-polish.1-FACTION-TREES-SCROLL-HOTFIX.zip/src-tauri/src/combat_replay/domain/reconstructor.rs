use crate::{combat::domain::combat::CombatSession,combat_replay::domain::{error::ReplayError,replay::{CombatReplayEvent,CombatReplayMutation,CombatReplayState}}};

pub struct CombatStateReconstructor;
impl CombatStateReconstructor {
    pub fn rebuild(initial:&CombatReplayState,events:&[CombatReplayEvent])->Result<CombatReplayState,ReplayError>{
        let mut state=initial.clone();
        for event in events{Self::apply(&mut state,event)?;state.next_action_sequence=state.next_action_sequence.max(event.sequence_number.saturating_add(1));}
        Ok(state)
    }
    fn combatant_mut<'a>(state:&'a mut CombatReplayState,id:&str,sequence:u64)->Result<&'a mut crate::combat::domain::combat::Combatant,ReplayError>{state.combatants.iter_mut().find(|c|c.id.0==id).ok_or_else(||ReplayError::Divergence{sequence,expected:format!("combatant {id}"),actual:"missing".into()})}
    pub fn apply(state:&mut CombatReplayState,event:&CombatReplayEvent)->Result<(),ReplayError>{
        let seq=event.sequence_number;
        match &event.mutation{
            CombatReplayMutation::HpChanged{combatant_id,before,after}=>{let c=Self::combatant_mut(state,combatant_id,seq)?;if c.runtime_state.current_hp!=*before{return Err(ReplayError::Divergence{sequence:seq,expected:format!("HP={before}"),actual:format!("HP={}",c.runtime_state.current_hp)});}c.runtime_state.current_hp=*after;}
            CombatReplayMutation::ManaChanged{combatant_id,before,after}=>{let c=Self::combatant_mut(state,combatant_id,seq)?;if c.runtime_state.current_mana!=*before{return Err(ReplayError::Divergence{sequence:seq,expected:format!("Mana={before}"),actual:format!("Mana={}",c.runtime_state.current_mana)});}c.runtime_state.current_mana=*after;}
            CombatReplayMutation::DefeatedChanged{combatant_id,before,after}=>{let c=Self::combatant_mut(state,combatant_id,seq)?;if c.runtime_state.is_defeated!=*before{return Err(ReplayError::Divergence{sequence:seq,expected:format!("defeated={before}"),actual:format!("defeated={}",c.runtime_state.is_defeated)});}c.runtime_state.is_defeated=*after;}
            CombatReplayMutation::CooldownsChanged{combatant_id,before,after}=>{let c=Self::combatant_mut(state,combatant_id,seq)?;if c.runtime_state.cooldowns!=*before{return Err(ReplayError::Divergence{sequence:seq,expected:format!("cooldowns={before:?}"),actual:format!("cooldowns={:?}",c.runtime_state.cooldowns)});}c.runtime_state.cooldowns=after.clone();}
            CombatReplayMutation::ActiveEffectsChanged{combatant_id,before,after}=>{let c=Self::combatant_mut(state,combatant_id,seq)?;if c.runtime_state.active_effects!=*before{return Err(ReplayError::Divergence{sequence:seq,expected:format!("effects={before:?}"),actual:format!("effects={:?}",c.runtime_state.active_effects)});}c.runtime_state.active_effects=after.clone();}
            CombatReplayMutation::TurnAdvanced{from_round,from_index,to_round,to_index}=>{if state.round_number!=*from_round||state.turn_index!=*from_index{return Err(ReplayError::Divergence{sequence:seq,expected:format!("R{from_round}/T{from_index}"),actual:format!("R{}/T{}",state.round_number,state.turn_index)});}state.round_number=*to_round;state.turn_index=*to_index;}
            CombatReplayMutation::SessionStatusChanged{before,after}=>{if state.status!=*before{return Err(ReplayError::Divergence{sequence:seq,expected:format!("status={before:?}"),actual:format!("status={:?}",state.status)});}state.status=*after;}
        }
        Ok(())
    }
}

pub fn derive_turn_mutations(before:&CombatSession,after:&CombatSession)->Vec<CombatReplayMutation>{
    let mut out=Vec::new();
    for old in &before.combatants{
        if let Some(new)=after.combatants.iter().find(|c|c.id==old.id){
            let a=&old.runtime_state;let b=&new.runtime_state;
            if a.current_hp!=b.current_hp{out.push(CombatReplayMutation::HpChanged{combatant_id:old.id.0.clone(),before:a.current_hp,after:b.current_hp});}
            if a.current_mana!=b.current_mana{out.push(CombatReplayMutation::ManaChanged{combatant_id:old.id.0.clone(),before:a.current_mana,after:b.current_mana});}
            if a.is_defeated!=b.is_defeated{out.push(CombatReplayMutation::DefeatedChanged{combatant_id:old.id.0.clone(),before:a.is_defeated,after:b.is_defeated});}
            if a.cooldowns!=b.cooldowns{out.push(CombatReplayMutation::CooldownsChanged{combatant_id:old.id.0.clone(),before:a.cooldowns.clone(),after:b.cooldowns.clone()});}
            if a.active_effects!=b.active_effects{out.push(CombatReplayMutation::ActiveEffectsChanged{combatant_id:old.id.0.clone(),before:a.active_effects.clone(),after:b.active_effects.clone()});}
        }
    }
    if before.round_number!=after.round_number||before.turn_index!=after.turn_index{out.push(CombatReplayMutation::TurnAdvanced{from_round:before.round_number,from_index:before.turn_index,to_round:after.round_number,to_index:after.turn_index});}
    if before.status!=after.status{out.push(CombatReplayMutation::SessionStatusChanged{before:before.status,after:after.status});}
    out
}

pub fn state_fingerprint(state:&CombatReplayState)->Result<String,ReplayError>{
    let bytes=serde_json::to_vec(state).map_err(|e|ReplayError::Mapping(e.to_string()))?;
    let mut hash:u64=0xcbf29ce484222325;
    for b in bytes{hash^=b as u64;hash=hash.wrapping_mul(0x100000001b3);}
    Ok(format!("fnv1a64:{hash:016x}"))
}

pub fn states_semantically_equal(replay:&CombatReplayState,live:&CombatSession)->bool{replay==&CombatReplayState::from_live(live)}

#[cfg(test)]
mod tests{
    use super::*;use crate::combat::domain::combat::*;use chrono::Utc;
    fn session()->CombatSession{let snap=CombatantSnapshot{source_character_id:"c".into(),display_name:"A".into(),effective_stats:CombatStats::default(),max_hp:500,max_mana:100,skills:vec![]};CombatSession{id:CombatSessionId("s".into()),status:CombatStatus::Running,rng_seed:42,round_number:1,turn_index:0,next_action_sequence:1,combatants:vec![Combatant{id:CombatantId("a".into()),position:0,runtime_state:CombatantRuntimeState::fresh(&snap),snapshot:snap}],created_at:Utc::now(),updated_at:Utc::now(),completed_at:None}}
    #[test]fn same_state_hash_is_repeatable(){let s=CombatReplayState::from_live(&session());let first=state_fingerprint(&s).expect("fingerprint");for _ in 0..1000{assert_eq!(first,state_fingerprint(&s).expect("fingerprint"));}}
}
