use chrono::{DateTime, Utc};
use rusqlite::{params, OptionalExtension};

use crate::{
    combat::domain::combat::{
        CombatAction, CombatActionId, CombatActionInput, CombatActionKind,
        CombatActionResolution, CombatResolution, CombatStatus, Combatant, CombatantId,
        CombatantRuntimeState, CombatantSnapshot, CombatTurnExecutionId, UseSkillCommand,
    },
    combat_replay::domain::{
        error::ReplayError,
        replay::{
            CombatReplayEvent, CombatReplayMutation, CombatReplayState, ReplayOrigin,
            TurnExecutionSummary,
        },
        repository::CombatReplayRepository,
    },
    shared::database::SharedConnection,
};

pub struct SqliteCombatReplayRepository {
    conn: SharedConnection,
}

impl SqliteCombatReplayRepository {
    pub fn new(conn: SharedConnection) -> Self {
        Self { conn }
    }
}

fn db(e: impl std::fmt::Display) -> ReplayError {
    ReplayError::Database(e.to_string())
}

fn parse_time(s: String) -> Result<DateTime<Utc>, ReplayError> {
    DateTime::parse_from_rfc3339(&s)
        .map(|d| d.with_timezone(&Utc))
        .map_err(|e| ReplayError::Mapping(e.to_string()))
}

fn from_json<T: for<'de> serde::Deserialize<'de>>(raw: &str) -> Result<T, ReplayError> {
    serde_json::from_str(raw).map_err(|e| ReplayError::Mapping(e.to_string()))
}

fn sqlite_i64(value: u64, field: &str) -> Result<i64, ReplayError> {
    i64::try_from(value)
        .map_err(|_| ReplayError::Mapping(format!("{field} exceeds SQLite INTEGER range: {value}")))
}

fn domain_u64(value: i64, field: &str) -> Result<u64, ReplayError> {
    u64::try_from(value)
        .map_err(|_| ReplayError::Mapping(format!("negative SQLite INTEGER for {field}: {value}")))
}

fn parse_action_input(kind: CombatActionKind, raw: &str) -> Result<CombatActionInput, ReplayError> {
    if let Ok(v) = from_json::<CombatActionInput>(raw) {
        return Ok(v);
    }
    if kind == CombatActionKind::UseSkill {
        return Ok(CombatActionInput::UseSkill(from_json::<UseSkillCommand>(raw)?));
    }
    Err(ReplayError::Mapping(
        "invalid combat action input payload".into(),
    ))
}

fn parse_action_resolution(
    kind: CombatActionKind,
    raw: &str,
) -> Result<CombatActionResolution, ReplayError> {
    if let Ok(v) = from_json::<CombatActionResolution>(raw) {
        return Ok(v);
    }
    if kind == CombatActionKind::UseSkill {
        return Ok(CombatActionResolution::Skill(from_json::<CombatResolution>(raw)?));
    }
    Err(ReplayError::Mapping(
        "invalid combat action resolution payload".into(),
    ))
}

impl CombatReplayRepository for SqliteCombatReplayRepository {
    fn origin(&self, session_id: &str) -> Result<Option<ReplayOrigin>, ReplayError> {
        let conn = match self.conn.lock() {
            Ok(c) => c,
            Err(p) => p.into_inner(),
        };
        let row = conn
            .query_row(
                "SELECT origin_sequence,state_json,created_at FROM combat_replay_origins WHERE session_id=?",
                params![session_id],
                |r| {
                    Ok((
                        r.get::<_, i64>(0)?,
                        r.get::<_, String>(1)?,
                        r.get::<_, String>(2)?,
                    ))
                },
            )
            .optional()
            .map_err(db)?;

        row.map(|(seq_db, state, created)| {
            Ok(ReplayOrigin {
                session_id: session_id.into(),
                origin_sequence: domain_u64(seq_db, "combat_replay_origins.origin_sequence")?,
                state: from_json(&state)?,
                created_at: parse_time(created)?,
            })
        })
        .transpose()
    }

    fn events_through(
        &self,
        session_id: &str,
        sequence: u64,
    ) -> Result<Vec<CombatReplayEvent>, ReplayError> {
        let conn = match self.conn.lock() {
            Ok(c) => c,
            Err(p) => p.into_inner(),
        };
        let sequence_db = sqlite_i64(sequence, "combat_replay_events.sequence_number")?;
        let mut stmt = conn
            .prepare("SELECT id,turn_execution_id,sequence_number,event_index,payload_json,created_at FROM combat_replay_events WHERE session_id=? AND sequence_number<=? ORDER BY sequence_number,event_index")
            .map_err(db)?;
        let rows = stmt
            .query_map(params![session_id, sequence_db], |r| {
                Ok((
                    r.get::<_, String>(0)?,
                    r.get::<_, String>(1)?,
                    r.get::<_, i64>(2)?,
                    r.get::<_, u32>(3)?,
                    r.get::<_, String>(4)?,
                    r.get::<_, String>(5)?,
                ))
            })
            .map_err(db)?;

        let mut out = Vec::new();
        for row in rows {
            let (id, execution, seq_db, index, payload, created) = row.map_err(db)?;
            out.push(CombatReplayEvent {
                id,
                session_id: session_id.into(),
                turn_execution_id: execution,
                sequence_number: domain_u64(seq_db, "combat_replay_events.sequence_number")?,
                event_index: index,
                mutation: from_json::<CombatReplayMutation>(&payload)?,
                created_at: parse_time(created)?,
            });
        }
        Ok(out)
    }

    fn turns(&self, session_id: &str) -> Result<Vec<TurnExecutionSummary>, ReplayError> {
        let conn = match self.conn.lock() {
            Ok(c) => c,
            Err(p) => p.into_inner(),
        };
        let mut stmt = conn
            .prepare("SELECT e.id,e.round_number,e.turn_index,e.actor_combatant_id,MIN(a.sequence_number),MAX(a.sequence_number),COUNT(a.id),e.created_at FROM combat_turn_executions e JOIN combat_actions a ON a.turn_execution_id=e.id WHERE e.session_id=? GROUP BY e.id,e.round_number,e.turn_index,e.actor_combatant_id,e.created_at ORDER BY MIN(a.sequence_number)")
            .map_err(db)?;
        let rows = stmt
            .query_map(params![session_id], |r| {
                Ok((
                    r.get::<_, String>(0)?,
                    r.get::<_, u32>(1)?,
                    r.get::<_, u32>(2)?,
                    r.get::<_, String>(3)?,
                    r.get::<_, i64>(4)?,
                    r.get::<_, i64>(5)?,
                    r.get::<_, u32>(6)?,
                    r.get::<_, String>(7)?,
                ))
            })
            .map_err(db)?;

        let mut out = Vec::new();
        for row in rows {
            let (id, round, turn, actor, first_db, last_db, count, created) = row.map_err(db)?;
            out.push(TurnExecutionSummary {
                id,
                round_number: round,
                turn_index: turn,
                actor_combatant_id: actor,
                first_sequence: domain_u64(first_db, "combat_actions.sequence_number")?,
                last_sequence: domain_u64(last_db, "combat_actions.sequence_number")?,
                action_count: count,
                created_at: parse_time(created)?,
            });
        }
        Ok(out)
    }

    fn actions_for_execution(&self, execution_id: &str) -> Result<Vec<CombatAction>, ReplayError> {
        let conn = match self.conn.lock() {
            Ok(c) => c,
            Err(p) => p.into_inner(),
        };
        let mut stmt = conn
            .prepare("SELECT id,session_id,sequence_number,round_number,turn_index,actor_combatant_id,target_combatant_id,action_kind,input_json,resolution_json,created_at FROM combat_actions WHERE turn_execution_id=? ORDER BY sequence_number")
            .map_err(db)?;
        let rows = stmt
            .query_map(params![execution_id], |r| {
                Ok((
                    r.get::<_, String>(0)?,
                    r.get::<_, String>(1)?,
                    r.get::<_, i64>(2)?,
                    r.get::<_, u32>(3)?,
                    r.get::<_, u32>(4)?,
                    r.get::<_, String>(5)?,
                    r.get::<_, Option<String>>(6)?,
                    r.get::<_, String>(7)?,
                    r.get::<_, String>(8)?,
                    r.get::<_, String>(9)?,
                    r.get::<_, String>(10)?,
                ))
            })
            .map_err(db)?;

        let mut out = Vec::new();
        for row in rows {
            let (id, session, seq_db, round, turn, actor, target, kind_raw, input, resolution, created) =
                row.map_err(db)?;
            let kind = CombatActionKind::from_db(&kind_raw)
                .ok_or_else(|| ReplayError::Mapping(format!("unknown action kind: {kind_raw}")))?;
            out.push(CombatAction {
                id: CombatActionId(id),
                session_id: crate::combat::domain::combat::CombatSessionId(session),
                turn_execution_id: CombatTurnExecutionId(execution_id.into()),
                sequence_number: domain_u64(seq_db, "combat_actions.sequence_number")?,
                round_number: round,
                turn_index: turn,
                actor_combatant_id: CombatantId(actor),
                target_combatant_id: target.map(CombatantId),
                action_kind: kind,
                input: parse_action_input(kind, &input)?,
                resolution: parse_action_resolution(kind, &resolution)?,
                created_at: parse_time(created)?,
            });
        }
        Ok(out)
    }

    fn latest_sequence(&self, session_id: &str) -> Result<u64, ReplayError> {
        let conn = match self.conn.lock() {
            Ok(c) => c,
            Err(p) => p.into_inner(),
        };
        let origin_db: Option<i64> = conn
            .query_row(
                "SELECT origin_sequence FROM combat_replay_origins WHERE session_id=?",
                params![session_id],
                |r| r.get(0),
            )
            .optional()
            .map_err(db)?;
        let origin = origin_db
            .map(|v| domain_u64(v, "combat_replay_origins.origin_sequence"))
            .transpose()?
            .unwrap_or(0);

        let latest_db: Option<i64> = conn
            .query_row(
                "SELECT MAX(sequence_number) FROM combat_actions WHERE session_id=?",
                params![session_id],
                |r| r.get(0),
            )
            .map_err(db)?;
        let latest = latest_db
            .map(|v| domain_u64(v, "combat_actions.sequence_number"))
            .transpose()?;

        Ok(latest.unwrap_or(origin).max(origin))
    }

    fn live_state(&self, session_id: &str) -> Result<Option<CombatReplayState>, ReplayError> {
        let conn = match self.conn.lock() {
            Ok(c) => c,
            Err(p) => p.into_inner(),
        };
        let row = conn
            .query_row(
                "SELECT status,rng_seed,round_number,turn_index,next_action_sequence FROM combat_sessions WHERE id=?",
                params![session_id],
                |r| {
                    Ok((
                        r.get::<_, String>(0)?,
                        r.get::<_, String>(1)?,
                        r.get::<_, u32>(2)?,
                        r.get::<_, u32>(3)?,
                        r.get::<_, i64>(4)?,
                    ))
                },
            )
            .optional()
            .map_err(db)?;

        let Some((status_raw, seed_raw, round, turn, next_seq_db)) = row else {
            return Ok(None);
        };
        let status = CombatStatus::from_db(&status_raw)
            .ok_or_else(|| ReplayError::Mapping(format!("unknown combat status: {status_raw}")))?;
        let rng_seed = seed_raw
            .parse::<u64>()
            .map_err(|e| ReplayError::Mapping(e.to_string()))?;
        let next_action_sequence = domain_u64(next_seq_db, "combat_sessions.next_action_sequence")?;

        let mut stmt = conn
            .prepare("SELECT id,position,snapshot,runtime_state FROM combatants WHERE session_id=? ORDER BY position")
            .map_err(db)?;
        let rows = stmt
            .query_map(params![session_id], |r| {
                Ok((
                    r.get::<_, String>(0)?,
                    r.get::<_, u32>(1)?,
                    r.get::<_, String>(2)?,
                    r.get::<_, String>(3)?,
                ))
            })
            .map_err(db)?;

        let mut combatants = Vec::new();
        for row in rows {
            let (id, position, snapshot, runtime) = row.map_err(db)?;
            combatants.push(Combatant {
                id: CombatantId(id),
                position,
                snapshot: from_json::<CombatantSnapshot>(&snapshot)?,
                runtime_state: from_json::<CombatantRuntimeState>(&runtime)?,
            });
        }

        Ok(Some(CombatReplayState {
            session_id: session_id.into(),
            status,
            rng_seed,
            round_number: round,
            turn_index: turn,
            next_action_sequence,
            combatants,
        }))
    }
}
