use tauri::State;
use crate::{app_state::AppState,combat_replay::{application::service::CombatReplayService,domain::{error::ReplayError,replay::{ReplayFrame,ReplayVerification,TurnExecutionSummary}}},shared::api_error::ApiError};
fn api(error:ReplayError)->ApiError{ApiError{code:"combat_replay_error".into(),message:error.to_string()}}
#[tauri::command]pub fn combat_replay_start(state:State<'_,AppState>,session_id:String)->Result<ReplayFrame,ApiError>{CombatReplayService{repo:&state.combat_replay}.start(&session_id).map_err(api)}
#[tauri::command]pub fn combat_replay_at_sequence(state:State<'_,AppState>,session_id:String,sequence:u64)->Result<ReplayFrame,ApiError>{CombatReplayService{repo:&state.combat_replay}.at_sequence(&session_id,sequence).map_err(api)}
#[tauri::command]pub fn combat_replay_at_execution(state:State<'_,AppState>,session_id:String,execution_id:String)->Result<ReplayFrame,ApiError>{CombatReplayService{repo:&state.combat_replay}.at_execution(&session_id,&execution_id).map_err(api)}
#[tauri::command]pub fn combat_replay_latest(state:State<'_,AppState>,session_id:String)->Result<ReplayFrame,ApiError>{CombatReplayService{repo:&state.combat_replay}.latest(&session_id).map_err(api)}
#[tauri::command]pub fn combat_replay_turns(state:State<'_,AppState>,session_id:String)->Result<Vec<TurnExecutionSummary>,ApiError>{CombatReplayService{repo:&state.combat_replay}.turns(&session_id).map_err(api)}
#[tauri::command]pub fn combat_replay_verify_latest(state:State<'_,AppState>,session_id:String)->Result<ReplayVerification,ApiError>{CombatReplayService{repo:&state.combat_replay}.verify_latest(&session_id).map_err(api)}
