use crate::combat_replay::domain::{error::ReplayError,reconstructor::{state_fingerprint,CombatStateReconstructor},replay::{ReplayFrame,ReplayVerification,TurnExecutionSummary},repository::CombatReplayRepository};

pub struct CombatReplayService<'a>{pub repo:&'a dyn CombatReplayRepository}
impl<'a> CombatReplayService<'a>{
    fn frame_for(&self,session_id:&str,requested:u64,forced_turn:Option<TurnExecutionSummary>)->Result<ReplayFrame,ReplayError>{
        let origin=self.repo.origin(session_id)?.ok_or_else(||ReplayError::SessionNotFound(session_id.into()))?;
        if requested<origin.origin_sequence{return Err(ReplayError::BeforeOrigin(origin.origin_sequence));}
        let latest=self.repo.latest_sequence(session_id)?.max(origin.origin_sequence);
        let turns=self.repo.turns(session_id)?;
        let selected=if let Some(t)=forced_turn{Some(t)}else if requested==origin.origin_sequence&&requested<turns.first().map(|t|t.first_sequence).unwrap_or(u64::MAX){None}else{turns.iter().find(|t|requested>=t.first_sequence&&requested<=t.last_sequence).cloned().or_else(||turns.iter().filter(|t|t.last_sequence<=requested).last().cloned())};
        let resolved=selected.as_ref().map(|t|t.last_sequence).unwrap_or(origin.origin_sequence).min(latest);
        let events=self.repo.events_through(session_id,resolved)?;
        let state=CombatStateReconstructor::rebuild(&origin.state,&events)?;
        let actions=match &selected{Some(t)=>self.repo.actions_for_execution(&t.id)?,None=>vec![]};
        let fingerprint=state_fingerprint(&state)?;
        Ok(ReplayFrame{state,origin_sequence:origin.origin_sequence,requested_sequence:requested,resolved_sequence:resolved,turn_execution:selected,actions,is_latest:resolved==latest,latest_sequence:latest,fingerprint})
    }
    pub fn start(&self,session_id:&str)->Result<ReplayFrame,ReplayError>{let origin=self.repo.origin(session_id)?.ok_or_else(||ReplayError::SessionNotFound(session_id.into()))?;self.frame_for(session_id,origin.origin_sequence,None)}
    pub fn at_sequence(&self,session_id:&str,sequence:u64)->Result<ReplayFrame,ReplayError>{self.frame_for(session_id,sequence,None)}
    pub fn at_execution(&self,session_id:&str,execution_id:&str)->Result<ReplayFrame,ReplayError>{let turn=self.repo.turns(session_id)?.into_iter().find(|t|t.id==execution_id).ok_or_else(||ReplayError::ExecutionNotFound(execution_id.into()))?;self.frame_for(session_id,turn.last_sequence,Some(turn))}
    pub fn latest(&self,session_id:&str)->Result<ReplayFrame,ReplayError>{let latest=self.repo.latest_sequence(session_id)?;self.frame_for(session_id,latest,None)}
    pub fn turns(&self,session_id:&str)->Result<Vec<TurnExecutionSummary>,ReplayError>{self.repo.turns(session_id)}
    pub fn verify_latest(&self,session_id:&str)->Result<ReplayVerification,ReplayError>{let frame=self.latest(session_id)?;let live=self.repo.live_state(session_id)?.ok_or_else(||ReplayError::SessionNotFound(session_id.into()))?;let live_fingerprint=state_fingerprint(&live)?;Ok(ReplayVerification{matches_live:frame.state==live,replay_fingerprint:frame.fingerprint,live_fingerprint,latest_sequence:frame.latest_sequence})}
}
