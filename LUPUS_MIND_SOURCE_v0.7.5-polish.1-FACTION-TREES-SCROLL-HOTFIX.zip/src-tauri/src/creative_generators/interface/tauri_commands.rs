use crate::{creative_generators::{application::generate::generate,domain::generator::{GeneratedCandidate,GenerationRequest}},shared::api_error::ApiError};
#[tauri::command]pub fn creative_generate(input:GenerationRequest)->Result<Vec<GeneratedCandidate>,ApiError>{generate(input).map_err(|message|ApiError{code:"generator_error".into(),message})}
