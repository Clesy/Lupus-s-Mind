use serde::{Deserialize,Serialize};
#[derive(Debug,Clone,Copy,Serialize,Deserialize,PartialEq,Eq)]#[serde(rename_all="snake_case")]pub enum GeneratorKind{CharacterName,LocationName,ItemName}
#[derive(Debug,Clone,Copy,Serialize,Deserialize,PartialEq,Eq)]#[serde(rename_all="snake_case")]pub enum GeneratorTone{Noble,Dark,Ancient,Harsh,Elegant,Mystic}
#[derive(Debug,Clone,Serialize,Deserialize)]#[serde(rename_all="camelCase")]pub struct GenerationRequest{pub kind:GeneratorKind,pub tone:GeneratorTone,pub subtype:String,pub count:u32,pub seed:u64}
#[derive(Debug,Clone,Serialize,Deserialize,PartialEq,Eq)]#[serde(rename_all="camelCase")]pub struct GeneratedCandidate{pub id:String,pub value:String,pub note:String}
