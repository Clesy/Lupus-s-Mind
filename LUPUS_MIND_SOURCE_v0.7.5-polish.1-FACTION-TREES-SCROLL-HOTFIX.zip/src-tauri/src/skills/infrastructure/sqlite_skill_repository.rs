use chrono::{DateTime, Utc};
use rusqlite::{params, OptionalExtension, Row};
use crate::{
    characters::domain::character::CharacterId,
    shared::database::SharedConnection,
    skills::domain::{
        error::SkillError,
        repository::{CharacterSkillRepository, SkillRepository},
        skill::{ResourceKind, ScalingTerm, Skill, SkillId, SkillKind},
    },
};

pub struct SqliteSkillRepository {
    conn: SharedConnection,
}

struct RawSkill {
    id: String,
    name: String,
    description: String,
    kind: String,
    resource_kind: String,
    base_power: f64,
    resource_cost: u32,
    cooldown_turns: u32,
    scaling: String,
    tags: String,
    created_at: String,
    updated_at: String,
}

impl SqliteSkillRepository {
    pub fn new(conn: SharedConnection) -> Self { Self { conn } }

    fn raw(row: &Row<'_>) -> rusqlite::Result<RawSkill> {
        Ok(RawSkill {
            id: row.get(0)?, name: row.get(1)?, description: row.get(2)?, kind: row.get(3)?,
            resource_kind: row.get(4)?, base_power: row.get(5)?, resource_cost: row.get(6)?,
            cooldown_turns: row.get(7)?, scaling: row.get(8)?, tags: row.get(9)?,
            created_at: row.get(10)?, updated_at: row.get(11)?,
        })
    }

    fn map(raw: RawSkill) -> Result<Skill, SkillError> {
        let kind = SkillKind::from_db(&raw.kind).ok_or_else(|| SkillError::Mapping(format!("unknown skill kind: {}", raw.kind)))?;
        let resource_kind = ResourceKind::from_db(&raw.resource_kind).ok_or_else(|| SkillError::Mapping(format!("unknown resource kind: {}", raw.resource_kind)))?;
        let scaling: Vec<ScalingTerm> = serde_json::from_str(&raw.scaling).map_err(|e| SkillError::Mapping(e.to_string()))?;
        let tags: Vec<String> = serde_json::from_str(&raw.tags).map_err(|e| SkillError::Mapping(e.to_string()))?;
        let created_at = DateTime::parse_from_rfc3339(&raw.created_at).map(|d| d.with_timezone(&Utc)).map_err(|e| SkillError::Mapping(e.to_string()))?;
        let updated_at = DateTime::parse_from_rfc3339(&raw.updated_at).map(|d| d.with_timezone(&Utc)).map_err(|e| SkillError::Mapping(e.to_string()))?;
        Ok(Skill { id: SkillId(raw.id), name: raw.name, description: raw.description, kind, resource_kind, base_power: raw.base_power, resource_cost: raw.resource_cost, cooldown_turns: raw.cooldown_turns, scaling, tags, created_at, updated_at })
    }

    fn db(error: rusqlite::Error) -> SkillError { SkillError::Database(error.to_string()) }
}

impl SkillRepository for SqliteSkillRepository {
    fn list(&self) -> Result<Vec<Skill>, SkillError> {
        let conn = self.conn.lock().map_err(|e| SkillError::Database(e.to_string()))?;
        let mut stmt = conn.prepare("SELECT id,name,description,kind,resource_kind,base_power,resource_cost,cooldown_turns,scaling,tags,created_at,updated_at FROM skills ORDER BY name COLLATE NOCASE").map_err(Self::db)?;
        let rows = stmt.query_map([], Self::raw).map_err(Self::db)?;
        let mut skills = Vec::new();
        for row in rows { skills.push(Self::map(row.map_err(Self::db)?)?); }
        Ok(skills)
    }

    fn get(&self, id: &SkillId) -> Result<Option<Skill>, SkillError> {
        let conn = self.conn.lock().map_err(|e| SkillError::Database(e.to_string()))?;
        let raw = conn.query_row("SELECT id,name,description,kind,resource_kind,base_power,resource_cost,cooldown_turns,scaling,tags,created_at,updated_at FROM skills WHERE id=?", params![&id.0], Self::raw).optional().map_err(Self::db)?;
        raw.map(Self::map).transpose()
    }

    fn insert(&self, skill: &Skill) -> Result<(), SkillError> {
        let scaling = serde_json::to_string(&skill.scaling).map_err(|e| SkillError::Mapping(e.to_string()))?;
        let tags = serde_json::to_string(&skill.tags).map_err(|e| SkillError::Mapping(e.to_string()))?;
        let conn = self.conn.lock().map_err(|e| SkillError::Database(e.to_string()))?;
        conn.execute("INSERT INTO skills(id,name,description,kind,resource_kind,base_power,resource_cost,cooldown_turns,scaling,tags,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)", params![&skill.id.0,&skill.name,&skill.description,skill.kind.as_db(),skill.resource_kind.as_db(),skill.base_power,skill.resource_cost,skill.cooldown_turns,scaling,tags,skill.created_at.to_rfc3339(),skill.updated_at.to_rfc3339()]).map_err(Self::db)?;
        Ok(())
    }

    fn update(&self, skill: &Skill) -> Result<(), SkillError> {
        let scaling = serde_json::to_string(&skill.scaling).map_err(|e| SkillError::Mapping(e.to_string()))?;
        let tags = serde_json::to_string(&skill.tags).map_err(|e| SkillError::Mapping(e.to_string()))?;
        let conn = self.conn.lock().map_err(|e| SkillError::Database(e.to_string()))?;
        let affected = conn.execute("UPDATE skills SET name=?,description=?,kind=?,resource_kind=?,base_power=?,resource_cost=?,cooldown_turns=?,scaling=?,tags=?,updated_at=? WHERE id=?", params![&skill.name,&skill.description,skill.kind.as_db(),skill.resource_kind.as_db(),skill.base_power,skill.resource_cost,skill.cooldown_turns,scaling,tags,skill.updated_at.to_rfc3339(),&skill.id.0]).map_err(Self::db)?;
        if affected == 0 { return Err(SkillError::NotFound(skill.id.0.clone())); }
        Ok(())
    }

    fn delete(&self, id: &SkillId) -> Result<(), SkillError> {
        let conn = self.conn.lock().map_err(|e| SkillError::Database(e.to_string()))?;
        let affected = conn.execute("DELETE FROM skills WHERE id=?", params![&id.0]).map_err(Self::db)?;
        if affected == 0 { return Err(SkillError::NotFound(id.0.clone())); }
        Ok(())
    }
}

impl CharacterSkillRepository for SqliteSkillRepository {
    fn list_skill_ids(&self, character: &CharacterId) -> Result<Vec<SkillId>, SkillError> {
        let conn = self.conn.lock().map_err(|e| SkillError::Database(e.to_string()))?;
        let mut stmt = conn.prepare("SELECT skill_id FROM character_skills WHERE character_id=? ORDER BY learned_at, skill_id").map_err(Self::db)?;
        let rows = stmt.query_map(params![&character.0], |row| row.get::<_, String>(0)).map_err(Self::db)?;
        let mut ids = Vec::new();
        for row in rows { ids.push(SkillId(row.map_err(Self::db)?)); }
        Ok(ids)
    }

    fn is_learned(&self, character: &CharacterId, skill: &SkillId) -> Result<bool, SkillError> {
        let conn = self.conn.lock().map_err(|e| SkillError::Database(e.to_string()))?;
        let count: i64 = conn.query_row("SELECT COUNT(*) FROM character_skills WHERE character_id=? AND skill_id=?", params![&character.0,&skill.0], |row| row.get(0)).map_err(Self::db)?;
        Ok(count > 0)
    }

    fn teach(&self, character: &CharacterId, skill: &SkillId) -> Result<(), SkillError> {
        let conn = self.conn.lock().map_err(|e| SkillError::Database(e.to_string()))?;
        match conn.execute("INSERT INTO character_skills(character_id,skill_id,learned_at) VALUES(?,?,?)", params![&character.0,&skill.0,Utc::now().to_rfc3339()]) {
            Ok(_) => Ok(()),
            Err(rusqlite::Error::SqliteFailure(code, _)) if code.extended_code == 1555 || code.extended_code == 2067 => Err(SkillError::AlreadyLearned(skill.0.clone())),
            Err(error) => Err(Self::db(error)),
        }
    }

    fn forget(&self, character: &CharacterId, skill: &SkillId) -> Result<(), SkillError> {
        let conn = self.conn.lock().map_err(|e| SkillError::Database(e.to_string()))?;
        let affected = conn.execute("DELETE FROM character_skills WHERE character_id=? AND skill_id=?", params![&character.0,&skill.0]).map_err(Self::db)?;
        if affected == 0 { return Err(SkillError::NotLearned(skill.0.clone())); }
        Ok(())
    }
}
