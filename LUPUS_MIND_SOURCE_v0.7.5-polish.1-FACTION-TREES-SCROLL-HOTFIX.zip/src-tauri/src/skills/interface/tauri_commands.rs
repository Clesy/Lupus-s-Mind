use tauri::State;
use crate::{
    app_state::AppState,
    shared::api_error::ApiError,
    skill_evaluation::{
        application::preview_skill::{PreviewSkillServices, SkillPreviewDto, SkillPreviewError},
        domain::evaluator::DeterministicSkillEvaluator,
    },
    skills::application::use_cases::{self, SkillDto, SkillSummaryDto, UpsertSkillInput},
};

fn preview_api(error: SkillPreviewError) -> ApiError {
    ApiError { code: "skill_preview_error".into(), message: error.to_string() }
}

#[tauri::command]
pub fn skills_list(state: State<'_, AppState>) -> Result<Vec<SkillSummaryDto>, ApiError> {
    use_cases::list(&state.skills).map_err(Into::into)
}

#[tauri::command]
pub fn skills_get(state: State<'_, AppState>, id: String) -> Result<SkillDto, ApiError> {
    use_cases::get(&state.skills, id).map_err(Into::into)
}

#[tauri::command]
pub fn skills_create(state: State<'_, AppState>, input: UpsertSkillInput) -> Result<SkillDto, ApiError> {
    use_cases::create(&state.skills, input).map_err(Into::into)
}

#[tauri::command]
pub fn skills_update(state: State<'_, AppState>, id: String, input: UpsertSkillInput) -> Result<SkillDto, ApiError> {
    use_cases::update(&state.skills, id, input).map_err(Into::into)
}

#[tauri::command]
pub fn skills_delete(state: State<'_, AppState>, id: String) -> Result<(), ApiError> {
    use_cases::delete(&state.skills, id).map_err(Into::into)
}

#[tauri::command]
pub fn skills_teach(state: State<'_, AppState>, character_id: String, skill_id: String) -> Result<(), ApiError> {
    use_cases::teach(&state.characters, &state.skills, &state.skills, character_id, skill_id).map_err(Into::into)
}

#[tauri::command]
pub fn skills_forget(state: State<'_, AppState>, character_id: String, skill_id: String) -> Result<(), ApiError> {
    use_cases::forget(&state.skills, character_id, skill_id).map_err(Into::into)
}

#[tauri::command]
pub fn skills_list_for_character(state: State<'_, AppState>, character_id: String) -> Result<Vec<SkillDto>, ApiError> {
    use_cases::list_for_character(&state.characters, &state.skills, &state.skills, character_id).map_err(Into::into)
}

#[tauri::command]
pub fn skills_preview(state: State<'_, AppState>, character_id: String, skill_id: String) -> Result<SkillPreviewDto, ApiError> {
    let evaluator = DeterministicSkillEvaluator;
    PreviewSkillServices { characters: &state.characters, items: &state.items, equipment: &state.equipment, skills: &state.skills, evaluator: &evaluator }.preview(character_id, skill_id).map_err(preview_api)
}
