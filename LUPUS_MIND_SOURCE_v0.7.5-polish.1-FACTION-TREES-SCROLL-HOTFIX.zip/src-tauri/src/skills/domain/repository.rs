use crate::characters::domain::character::CharacterId;
use super::{error::SkillError, skill::{Skill, SkillId}};

pub trait SkillRepository: Send + Sync {
    fn list(&self) -> Result<Vec<Skill>, SkillError>;
    fn get(&self, id: &SkillId) -> Result<Option<Skill>, SkillError>;
    fn insert(&self, skill: &Skill) -> Result<(), SkillError>;
    fn update(&self, skill: &Skill) -> Result<(), SkillError>;
    fn delete(&self, id: &SkillId) -> Result<(), SkillError>;
}

pub trait CharacterSkillRepository: Send + Sync {
    fn list_skill_ids(&self, character: &CharacterId) -> Result<Vec<SkillId>, SkillError>;
    fn is_learned(&self, character: &CharacterId, skill: &SkillId) -> Result<bool, SkillError>;
    fn teach(&self, character: &CharacterId, skill: &SkillId) -> Result<(), SkillError>;
    fn forget(&self, character: &CharacterId, skill: &SkillId) -> Result<(), SkillError>;
}
