use serde::Serialize;
use thiserror::Error;

#[derive(Debug, Error, Serialize)]
pub enum SkillError {
    #[error("Skill not found: {0}")]
    NotFound(String),
    #[error("Character not found: {0}")]
    CharacterNotFound(String),
    #[error("Skill already learned: {0}")]
    AlreadyLearned(String),
    #[error("Skill is not learned: {0}")]
    NotLearned(String),
    #[error("Validation error: {0}")]
    Validation(String),
    #[error("Database error: {0}")]
    Database(String),
    #[error("Mapping error: {0}")]
    Mapping(String),
}
