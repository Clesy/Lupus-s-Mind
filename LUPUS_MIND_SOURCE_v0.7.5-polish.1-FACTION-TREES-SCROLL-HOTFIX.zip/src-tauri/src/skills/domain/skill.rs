use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, Hash)]
pub struct SkillId(pub String);

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum SkillKind {
    Physical,
    Magical,
    Healing,
    Utility,
}

impl SkillKind {
    pub fn as_db(self) -> &'static str {
        match self {
            Self::Physical => "physical",
            Self::Magical => "magical",
            Self::Healing => "healing",
            Self::Utility => "utility",
        }
    }

    pub fn from_db(value: &str) -> Option<Self> {
        Some(match value {
            "physical" => Self::Physical,
            "magical" => Self::Magical,
            "healing" => Self::Healing,
            "utility" => Self::Utility,
            _ => return None,
        })
    }
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum ResourceKind {
    None,
    Mana,
    Stamina,
    Health,
}

impl ResourceKind {
    pub fn as_db(self) -> &'static str {
        match self {
            Self::None => "none",
            Self::Mana => "mana",
            Self::Stamina => "stamina",
            Self::Health => "health",
        }
    }

    pub fn from_db(value: &str) -> Option<Self> {
        Some(match value {
            "none" => Self::None,
            "mana" => Self::Mana,
            "stamina" => Self::Stamina,
            "health" => Self::Health,
            _ => return None,
        })
    }
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq, Hash)]
#[serde(rename_all = "snake_case")]
pub enum ScalingStat {
    Strength,
    Agility,
    Vitality,
    Intelligence,
    Mind,
    WeaponDamage,
    Armor,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct ScalingTerm {
    pub stat: ScalingStat,
    pub coefficient: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Skill {
    pub id: SkillId,
    pub name: String,
    pub description: String,
    pub kind: SkillKind,
    pub resource_kind: ResourceKind,
    pub base_power: f64,
    pub resource_cost: u32,
    pub cooldown_turns: u32,
    pub scaling: Vec<ScalingTerm>,
    pub tags: Vec<String>,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
}
