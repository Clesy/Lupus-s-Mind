use std::collections::HashSet;
use chrono::Utc;
use serde::{Deserialize, Serialize};
use uuid::Uuid;
use crate::{
    characters::domain::{character::CharacterId, repository::CharacterRepository},
    skills::domain::{
        error::SkillError,
        repository::{CharacterSkillRepository, SkillRepository},
        skill::{ResourceKind, ScalingStat, ScalingTerm, Skill, SkillId, SkillKind},
    },
};

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct UpsertSkillInput {
    pub name: String,
    pub description: Option<String>,
    pub kind: SkillKind,
    pub resource_kind: ResourceKind,
    pub base_power: f64,
    pub resource_cost: u32,
    pub cooldown_turns: u32,
    pub scaling: Vec<ScalingTerm>,
    pub tags: Vec<String>,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct SkillSummaryDto {
    pub id: String,
    pub name: String,
    pub kind: SkillKind,
    pub resource_kind: ResourceKind,
    pub base_power: f64,
    pub resource_cost: u32,
    pub cooldown_turns: u32,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct SkillDto {
    pub id: String,
    pub name: String,
    pub description: String,
    pub kind: SkillKind,
    pub resource_kind: ResourceKind,
    pub base_power: f64,
    pub resource_cost: u32,
    pub cooldown_turns: u32,
    pub scaling: Vec<ScalingTerm>,
    pub tags: Vec<String>,
    pub created_at: String,
    pub updated_at: String,
}

pub fn summary(skill: Skill) -> SkillSummaryDto {
    SkillSummaryDto { id: skill.id.0, name: skill.name, kind: skill.kind, resource_kind: skill.resource_kind, base_power: skill.base_power, resource_cost: skill.resource_cost, cooldown_turns: skill.cooldown_turns }
}

pub fn dto(skill: Skill) -> SkillDto {
    SkillDto { id: skill.id.0, name: skill.name, description: skill.description, kind: skill.kind, resource_kind: skill.resource_kind, base_power: skill.base_power, resource_cost: skill.resource_cost, cooldown_turns: skill.cooldown_turns, scaling: skill.scaling, tags: skill.tags, created_at: skill.created_at.to_rfc3339(), updated_at: skill.updated_at.to_rfc3339() }
}

fn validate(input: &UpsertSkillInput) -> Result<(), SkillError> {
    if input.name.trim().is_empty() { return Err(SkillError::Validation("name is required".into())); }
    if !input.base_power.is_finite() || input.base_power < 0.0 { return Err(SkillError::Validation("basePower must be finite and >= 0".into())); }
    if input.resource_kind == ResourceKind::None && input.resource_cost != 0 { return Err(SkillError::Validation("resourceCost must be 0 when resourceKind is none".into())); }
    let mut stats = HashSet::<ScalingStat>::new();
    for term in &input.scaling {
        if !term.coefficient.is_finite() || term.coefficient < 0.0 { return Err(SkillError::Validation("scaling coefficients must be finite and >= 0".into())); }
        if !stats.insert(term.stat) { return Err(SkillError::Validation(format!("duplicate scaling stat: {:?}", term.stat))); }
    }
    Ok(())
}

pub fn list(repository: &dyn SkillRepository) -> Result<Vec<SkillSummaryDto>, SkillError> {
    Ok(repository.list()?.into_iter().map(summary).collect())
}

pub fn get(repository: &dyn SkillRepository, id: String) -> Result<SkillDto, SkillError> {
    repository.get(&SkillId(id.clone()))?.map(dto).ok_or(SkillError::NotFound(id))
}

pub fn create(repository: &dyn SkillRepository, input: UpsertSkillInput) -> Result<SkillDto, SkillError> {
    validate(&input)?;
    let now = Utc::now();
    let skill = Skill { id: SkillId(Uuid::new_v4().to_string()), name: input.name.trim().into(), description: input.description.unwrap_or_default(), kind: input.kind, resource_kind: input.resource_kind, base_power: input.base_power, resource_cost: input.resource_cost, cooldown_turns: input.cooldown_turns, scaling: input.scaling, tags: input.tags, created_at: now, updated_at: now };
    repository.insert(&skill)?;
    Ok(dto(skill))
}

pub fn update(repository: &dyn SkillRepository, id: String, input: UpsertSkillInput) -> Result<SkillDto, SkillError> {
    validate(&input)?;
    let mut skill = repository.get(&SkillId(id.clone()))?.ok_or(SkillError::NotFound(id))?;
    skill.name = input.name.trim().into();
    skill.description = input.description.unwrap_or_default();
    skill.kind = input.kind;
    skill.resource_kind = input.resource_kind;
    skill.base_power = input.base_power;
    skill.resource_cost = input.resource_cost;
    skill.cooldown_turns = input.cooldown_turns;
    skill.scaling = input.scaling;
    skill.tags = input.tags;
    skill.updated_at = Utc::now();
    repository.update(&skill)?;
    Ok(dto(skill))
}

pub fn delete(repository: &dyn SkillRepository, id: String) -> Result<(), SkillError> {
    repository.delete(&SkillId(id))
}

pub fn teach(characters: &dyn CharacterRepository, skills: &dyn SkillRepository, assignments: &dyn CharacterSkillRepository, character_id: String, skill_id: String) -> Result<(), SkillError> {
    let character = CharacterId(character_id.clone());
    let skill = SkillId(skill_id.clone());
    if characters.get(&character).map_err(|e| SkillError::Database(e.to_string()))?.is_none() { return Err(SkillError::CharacterNotFound(character_id)); }
    if skills.get(&skill)?.is_none() { return Err(SkillError::NotFound(skill_id)); }
    if assignments.is_learned(&character, &skill)? { return Err(SkillError::AlreadyLearned(skill.0)); }
    assignments.teach(&character, &skill)
}

pub fn forget(assignments: &dyn CharacterSkillRepository, character_id: String, skill_id: String) -> Result<(), SkillError> {
    assignments.forget(&CharacterId(character_id), &SkillId(skill_id))
}

pub fn list_for_character(characters: &dyn CharacterRepository, skills: &dyn SkillRepository, assignments: &dyn CharacterSkillRepository, character_id: String) -> Result<Vec<SkillDto>, SkillError> {
    let character = CharacterId(character_id.clone());
    if characters.get(&character).map_err(|e| SkillError::Database(e.to_string()))?.is_none() { return Err(SkillError::CharacterNotFound(character_id)); }
    let ids = assignments.list_skill_ids(&character)?;
    let mut output = Vec::with_capacity(ids.len());
    for id in ids {
        let skill = skills.get(&id)?.ok_or_else(|| SkillError::Mapping(format!("character_skills references missing skill: {}", id.0)))?;
        output.push(dto(skill));
    }
    Ok(output)
}
