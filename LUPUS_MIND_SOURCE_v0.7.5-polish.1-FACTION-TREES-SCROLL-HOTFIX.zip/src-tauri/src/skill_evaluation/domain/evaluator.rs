use serde::Serialize;
use crate::skills::domain::skill::{ScalingStat, Skill};

#[derive(Debug, Clone, Copy, Default, PartialEq)]
pub struct EvaluationStats {
    pub strength: f64,
    pub agility: f64,
    pub vitality: f64,
    pub intelligence: f64,
    pub mind: f64,
    pub weapon_damage: f64,
    pub armor: f64,
}

impl EvaluationStats {
    pub fn value(&self, stat: ScalingStat) -> f64 {
        match stat {
            ScalingStat::Strength => self.strength,
            ScalingStat::Agility => self.agility,
            ScalingStat::Vitality => self.vitality,
            ScalingStat::Intelligence => self.intelligence,
            ScalingStat::Mind => self.mind,
            ScalingStat::WeaponDamage => self.weapon_damage,
            ScalingStat::Armor => self.armor,
        }
    }
}

#[derive(Debug, Clone, Serialize, PartialEq)]
#[serde(rename_all = "camelCase")]
pub struct ScalingContribution {
    pub stat: ScalingStat,
    pub source_value: f64,
    pub coefficient: f64,
    pub contribution: f64,
}

#[derive(Debug, Clone, Serialize, PartialEq)]
#[serde(rename_all = "camelCase")]
pub struct SkillEvaluation {
    pub theoretical_power: f64,
    pub resource_cost: u32,
    pub cooldown_turns: u32,
    pub contributions: Vec<ScalingContribution>,
}

pub trait SkillEvaluator: Send + Sync {
    fn evaluate(&self, skill: &Skill, stats: &EvaluationStats) -> SkillEvaluation;
}

#[derive(Debug, Default, Clone, Copy)]
pub struct DeterministicSkillEvaluator;

impl SkillEvaluator for DeterministicSkillEvaluator {
    fn evaluate(&self, skill: &Skill, stats: &EvaluationStats) -> SkillEvaluation {
        let mut theoretical_power = skill.base_power;
        let mut contributions = Vec::with_capacity(skill.scaling.len());
        for term in &skill.scaling {
            let source_value = stats.value(term.stat);
            let contribution = source_value * term.coefficient;
            theoretical_power += contribution;
            contributions.push(ScalingContribution {
                stat: term.stat,
                source_value,
                coefficient: term.coefficient,
                contribution,
            });
        }
        SkillEvaluation {
            theoretical_power,
            resource_cost: skill.resource_cost,
            cooldown_turns: skill.cooldown_turns,
            contributions,
        }
    }
}

#[cfg(test)]
mod tests {
    use chrono::Utc;
    use super::*;
    use crate::skills::domain::skill::{ResourceKind, ScalingTerm, SkillId, SkillKind};

    fn dragon_strike() -> Skill {
        let now = Utc::now();
        Skill {
            id: SkillId("dragon-strike".into()),
            name: "Dragon Strike".into(),
            description: String::new(),
            kind: SkillKind::Physical,
            resource_kind: ResourceKind::Mana,
            base_power: 65.0,
            resource_cost: 20,
            cooldown_turns: 2,
            scaling: vec![
                ScalingTerm { stat: ScalingStat::Strength, coefficient: 1.5 },
                ScalingTerm { stat: ScalingStat::WeaponDamage, coefficient: 0.8 },
            ],
            tags: vec![],
            created_at: now,
            updated_at: now,
        }
    }

    #[test]
    fn same_input_produces_exactly_same_output() {
        let evaluator = DeterministicSkillEvaluator;
        let stats = EvaluationStats { strength: 18.0, weapon_damage: 120.0, ..Default::default() };
        let skill = dragon_strike();
        let expected = evaluator.evaluate(&skill, &stats);
        for _ in 0..1000 { assert_eq!(expected, evaluator.evaluate(&skill, &stats)); }
        assert!((expected.theoretical_power - 188.0).abs() < f64::EPSILON);
    }
}
