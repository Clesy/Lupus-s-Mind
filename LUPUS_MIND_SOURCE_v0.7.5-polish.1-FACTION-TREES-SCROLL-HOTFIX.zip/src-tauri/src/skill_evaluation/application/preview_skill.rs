use serde::Serialize;
use crate::{
    character_sheet::application::get_character_sheet::{get_sheet, SheetError},
    characters::domain::repository::CharacterRepository,
    equipment::domain::repository::EquipmentRepository,
    items::domain::repository::ItemRepository,
    skill_evaluation::domain::evaluator::{EvaluationStats, ScalingContribution, SkillEvaluator},
    skills::domain::{error::SkillError, repository::SkillRepository, skill::{ResourceKind, SkillId, SkillKind}},
};

#[derive(Debug, thiserror::Error)]
pub enum SkillPreviewError {
    #[error(transparent)] Skill(#[from] SkillError),
    #[error(transparent)] Sheet(#[from] SheetError),
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct SkillPreviewDto {
    pub character_id: String,
    pub skill_id: String,
    pub skill_name: String,
    pub kind: SkillKind,
    pub resource_kind: ResourceKind,
    pub theoretical_power: f64,
    pub resource_cost: u32,
    pub cooldown_turns: u32,
    pub contributions: Vec<ScalingContribution>,
}

pub struct PreviewSkillServices<'a> {
    pub characters: &'a dyn CharacterRepository,
    pub items: &'a dyn ItemRepository,
    pub equipment: &'a dyn EquipmentRepository,
    pub skills: &'a dyn SkillRepository,
    pub evaluator: &'a dyn SkillEvaluator,
}

impl<'a> PreviewSkillServices<'a> {
    pub fn preview(&self, character_id: String, skill_id: String) -> Result<SkillPreviewDto, SkillPreviewError> {
        let skill = self.skills.get(&SkillId(skill_id.clone()))?.ok_or_else(|| SkillError::NotFound(skill_id.clone()))?;
        let sheet = get_sheet(self.characters, self.items, self.equipment, character_id.clone())?;
        let stats = EvaluationStats {
            strength: sheet.effective_stats.strength,
            agility: sheet.effective_stats.agility,
            vitality: sheet.effective_stats.vitality,
            intelligence: sheet.effective_stats.intelligence,
            mind: sheet.effective_stats.mind,
            weapon_damage: sheet.effective_stats.weapon_damage,
            armor: sheet.effective_stats.armor,
        };
        let evaluation = self.evaluator.evaluate(&skill, &stats);
        Ok(SkillPreviewDto { character_id, skill_id: skill.id.0, skill_name: skill.name, kind: skill.kind, resource_kind: skill.resource_kind, theoretical_power: evaluation.theoretical_power, resource_cost: evaluation.resource_cost, cooldown_turns: evaluation.cooldown_turns, contributions: evaluation.contributions })
    }
}
