#![cfg_attr(not(debug_assertions),windows_subsystem="windows")]
fn main(){lupus_mind_lib::run();}
