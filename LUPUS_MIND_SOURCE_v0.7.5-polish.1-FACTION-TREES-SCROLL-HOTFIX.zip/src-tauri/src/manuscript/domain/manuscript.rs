use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ChapterStatus { Draft, Revised, Final }

impl ChapterStatus {
    pub fn as_str(self) -> &'static str { match self { Self::Draft => "draft", Self::Revised => "revised", Self::Final => "final" } }
    pub fn parse(value: &str) -> Option<Self> { match value { "draft" => Some(Self::Draft), "revised" => Some(Self::Revised), "final" => Some(Self::Final), _ => None } }
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ChapterSummary {
    pub id: String,
    pub chapter_number: u32,
    pub title: String,
    pub status: ChapterStatus,
    pub word_count: u32,
    pub tags: Vec<String>,
    pub updated_at: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct Chapter {
    pub id: String,
    pub chapter_number: u32,
    pub title: String,
    pub status: ChapterStatus,
    pub content: String,
    pub notes: String,
    pub tags: Vec<String>,
    pub word_count: u32,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
}

#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct UpsertChapterInput {
    pub chapter_number: u32,
    #[serde(default)] pub title: String,
    pub status: ChapterStatus,
    #[serde(default)] pub content: String,
    #[serde(default)] pub notes: String,
    #[serde(default)] pub tags: Vec<String>,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct QuickNote {
    pub id: String,
    pub body: String,
    pub pinned: bool,
    pub link_kind: Option<String>,
    pub link_id: Option<String>,
    pub link_label: Option<String>,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
}

#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct UpsertQuickNoteInput {
    pub body: String,
    #[serde(default)] pub pinned: bool,
    #[serde(default)] pub link_kind: Option<String>,
    #[serde(default)] pub link_id: Option<String>,
    #[serde(default)] pub link_label: Option<String>,
}

pub fn word_count(content: &str) -> u32 { content.split_whitespace().count().min(u32::MAX as usize) as u32 }
