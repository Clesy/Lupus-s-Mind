use thiserror::Error;

#[derive(Debug, Error)]
pub enum ManuscriptError {
    #[error("chapter not found: {0}")]
    NotFound(String),
    #[error("quick note not found: {0}")]
    NoteNotFound(String),
    #[error("validation error: {0}")]
    Validation(String),
    #[error("database error: {0}")]
    Database(String),
    #[error("mapping error: {0}")]
    Mapping(String),
}
