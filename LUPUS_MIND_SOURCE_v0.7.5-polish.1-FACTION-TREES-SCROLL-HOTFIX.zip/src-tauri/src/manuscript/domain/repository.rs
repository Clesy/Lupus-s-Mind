use crate::manuscript::domain::{error::ManuscriptError, manuscript::{Chapter, ChapterSummary, QuickNote, UpsertChapterInput, UpsertQuickNoteInput}};

pub trait ManuscriptRepository: Send + Sync {
    fn list_chapters(&self) -> Result<Vec<ChapterSummary>, ManuscriptError>;
    fn get_chapter(&self, id: &str) -> Result<Chapter, ManuscriptError>;
    fn create_chapter(&self, input: &UpsertChapterInput) -> Result<Chapter, ManuscriptError>;
    fn update_chapter(&self, id: &str, input: &UpsertChapterInput) -> Result<Chapter, ManuscriptError>;
    fn delete_chapter(&self, id: &str) -> Result<(), ManuscriptError>;
    fn list_notes(&self) -> Result<Vec<QuickNote>, ManuscriptError>;
    fn create_note(&self, input: &UpsertQuickNoteInput) -> Result<QuickNote, ManuscriptError>;
    fn update_note(&self, id: &str, input: &UpsertQuickNoteInput) -> Result<QuickNote, ManuscriptError>;
    fn delete_note(&self, id: &str) -> Result<(), ManuscriptError>;
}
