use chrono::{DateTime, Utc};
use rusqlite::{params, OptionalExtension};
use uuid::Uuid;
use crate::{manuscript::domain::{error::ManuscriptError, manuscript::{word_count, Chapter, ChapterStatus, ChapterSummary, QuickNote, UpsertChapterInput, UpsertQuickNoteInput}, repository::ManuscriptRepository}, shared::database::SharedConnection};

#[derive(Clone)]
pub struct SqliteManuscriptRepository { conn: SharedConnection }
impl SqliteManuscriptRepository { pub fn new(conn: SharedConnection) -> Self { Self { conn } } }

fn db(error: rusqlite::Error) -> ManuscriptError { ManuscriptError::Database(error.to_string()) }
fn map_time(value: String) -> Result<DateTime<Utc>, rusqlite::Error> {
    DateTime::parse_from_rfc3339(&value).map(|dt| dt.with_timezone(&Utc)).map_err(|_| rusqlite::Error::InvalidQuery)
}
fn map_status(value: String) -> Result<ChapterStatus, rusqlite::Error> { ChapterStatus::parse(&value).ok_or(rusqlite::Error::InvalidQuery) }
fn tags(value: String) -> Result<Vec<String>, rusqlite::Error> { serde_json::from_str(&value).map_err(|_| rusqlite::Error::InvalidQuery) }

impl SqliteManuscriptRepository {
    fn chapter_from_row(row: &rusqlite::Row<'_>) -> Result<Chapter, rusqlite::Error> {
        let number_i64: i64 = row.get(1)?;
        let content: String = row.get(4)?;
        Ok(Chapter {
            id: row.get(0)?, chapter_number: u32::try_from(number_i64).map_err(|_| rusqlite::Error::InvalidQuery)?, title: row.get(2)?,
            status: map_status(row.get(3)?)?, content: content.clone(), notes: row.get(5)?, tags: tags(row.get(6)?)?, word_count: word_count(&content),
            created_at: map_time(row.get(7)?)?, updated_at: map_time(row.get(8)?)?,
        })
    }
    fn get_required(&self, id: &str) -> Result<Chapter, ManuscriptError> {
        let conn = self.conn.lock().map_err(|e| ManuscriptError::Database(e.to_string()))?;
        conn.query_row("SELECT id,chapter_number,title,status,content,notes,tags,created_at,updated_at FROM manuscript_chapters WHERE id=?1", params![id], Self::chapter_from_row)
            .optional().map_err(db)?.ok_or_else(|| ManuscriptError::NotFound(id.to_string()))
    }
    fn note_from_row(row: &rusqlite::Row<'_>) -> Result<QuickNote, rusqlite::Error> {
        Ok(QuickNote { id: row.get(0)?, body: row.get(1)?, pinned: row.get::<_, i64>(2)? != 0, link_kind: row.get(3)?, link_id: row.get(4)?, link_label: row.get(5)?, created_at: map_time(row.get(6)?)?, updated_at: map_time(row.get(7)?)? })
    }
}

impl ManuscriptRepository for SqliteManuscriptRepository {
    fn list_chapters(&self) -> Result<Vec<ChapterSummary>, ManuscriptError> {
        let conn = self.conn.lock().map_err(|e| ManuscriptError::Database(e.to_string()))?;
        let mut stmt = conn.prepare("SELECT id,chapter_number,title,status,content,tags,updated_at FROM manuscript_chapters ORDER BY chapter_number").map_err(db)?;
        let rows = stmt.query_map([], |row| {
            let number_i64: i64 = row.get(1)?; let content: String = row.get(4)?;
            Ok(ChapterSummary { id: row.get(0)?, chapter_number: u32::try_from(number_i64).map_err(|_| rusqlite::Error::InvalidQuery)?, title: row.get(2)?, status: map_status(row.get(3)?)?, word_count: word_count(&content), tags: tags(row.get(5)?)?, updated_at: map_time(row.get(6)?)? })
        }).map_err(db)?;
        let mut out = Vec::new(); for row in rows { out.push(row.map_err(db)?); } Ok(out)
    }
    fn get_chapter(&self, id: &str) -> Result<Chapter, ManuscriptError> { self.get_required(id) }
    fn create_chapter(&self, input: &UpsertChapterInput) -> Result<Chapter, ManuscriptError> {
        let id = Uuid::new_v4().to_string(); let now = Utc::now().to_rfc3339(); let tags = serde_json::to_string(&input.tags).map_err(|e| ManuscriptError::Mapping(e.to_string()))?;
        let conn = self.conn.lock().map_err(|e| ManuscriptError::Database(e.to_string()))?;
        conn.execute("INSERT INTO manuscript_chapters(id,chapter_number,title,status,content,notes,tags,created_at,updated_at) VALUES(?1,?2,?3,?4,?5,?6,?7,?8,?8)", params![id, i64::from(input.chapter_number), input.title.trim(), input.status.as_str(), input.content, input.notes, tags, now]).map_err(db)?;
        drop(conn); self.get_required(&id)
    }
    fn update_chapter(&self, id: &str, input: &UpsertChapterInput) -> Result<Chapter, ManuscriptError> {
        let tags = serde_json::to_string(&input.tags).map_err(|e| ManuscriptError::Mapping(e.to_string()))?; let now = Utc::now().to_rfc3339();
        let conn = self.conn.lock().map_err(|e| ManuscriptError::Database(e.to_string()))?;
        let changed = conn.execute("UPDATE manuscript_chapters SET chapter_number=?2,title=?3,status=?4,content=?5,notes=?6,tags=?7,updated_at=?8 WHERE id=?1", params![id, i64::from(input.chapter_number), input.title.trim(), input.status.as_str(), input.content, input.notes, tags, now]).map_err(db)?;
        if changed == 0 { return Err(ManuscriptError::NotFound(id.to_string())); } drop(conn); self.get_required(id)
    }
    fn delete_chapter(&self, id: &str) -> Result<(), ManuscriptError> { let conn=self.conn.lock().map_err(|e| ManuscriptError::Database(e.to_string()))?; let changed=conn.execute("DELETE FROM manuscript_chapters WHERE id=?1",params![id]).map_err(db)?; if changed==0{return Err(ManuscriptError::NotFound(id.to_string()));} Ok(()) }
    fn list_notes(&self) -> Result<Vec<QuickNote>, ManuscriptError> { let conn=self.conn.lock().map_err(|e| ManuscriptError::Database(e.to_string()))?; let mut stmt=conn.prepare("SELECT id,body,pinned,link_kind,link_id,link_label,created_at,updated_at FROM quick_notes ORDER BY pinned DESC, updated_at DESC").map_err(db)?; let rows=stmt.query_map([],Self::note_from_row).map_err(db)?; let mut out=Vec::new(); for row in rows{out.push(row.map_err(db)?);} Ok(out) }
    fn create_note(&self, input: &UpsertQuickNoteInput) -> Result<QuickNote, ManuscriptError> { let id=Uuid::new_v4().to_string(); let now=Utc::now().to_rfc3339(); let conn=self.conn.lock().map_err(|e| ManuscriptError::Database(e.to_string()))?; conn.execute("INSERT INTO quick_notes(id,body,pinned,link_kind,link_id,link_label,created_at,updated_at) VALUES(?1,?2,?3,?4,?5,?6,?7,?7)",params![id,input.body.trim(),if input.pinned {1}else{0},&input.link_kind,&input.link_id,&input.link_label,now]).map_err(db)?; let note=conn.query_row("SELECT id,body,pinned,link_kind,link_id,link_label,created_at,updated_at FROM quick_notes WHERE id=?1",params![id],Self::note_from_row).map_err(db)?; Ok(note) }
    fn update_note(&self, id: &str, input: &UpsertQuickNoteInput) -> Result<QuickNote, ManuscriptError> { let now=Utc::now().to_rfc3339(); let conn=self.conn.lock().map_err(|e| ManuscriptError::Database(e.to_string()))?; let changed=conn.execute("UPDATE quick_notes SET body=?2,pinned=?3,link_kind=?4,link_id=?5,link_label=?6,updated_at=?7 WHERE id=?1",params![id,input.body.trim(),if input.pinned {1}else{0},&input.link_kind,&input.link_id,&input.link_label,now]).map_err(db)?; if changed==0{return Err(ManuscriptError::NoteNotFound(id.to_string()));} conn.query_row("SELECT id,body,pinned,link_kind,link_id,link_label,created_at,updated_at FROM quick_notes WHERE id=?1",params![id],Self::note_from_row).map_err(db) }
    fn delete_note(&self, id: &str) -> Result<(), ManuscriptError> { let conn=self.conn.lock().map_err(|e| ManuscriptError::Database(e.to_string()))?; let changed=conn.execute("DELETE FROM quick_notes WHERE id=?1",params![id]).map_err(db)?; if changed==0{return Err(ManuscriptError::NoteNotFound(id.to_string()));} Ok(()) }
}
