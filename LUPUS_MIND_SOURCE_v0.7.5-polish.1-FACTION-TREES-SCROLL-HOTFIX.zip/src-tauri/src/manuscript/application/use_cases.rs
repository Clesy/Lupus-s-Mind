use crate::manuscript::domain::{error::ManuscriptError, manuscript::{Chapter, ChapterSummary, QuickNote, UpsertChapterInput, UpsertQuickNoteInput}, repository::ManuscriptRepository};

fn validate_chapter(input: &UpsertChapterInput) -> Result<(), ManuscriptError> {
    if input.chapter_number == 0 { return Err(ManuscriptError::Validation("chapter number must be greater than zero".into())); }
    if input.title.chars().count() > 180 { return Err(ManuscriptError::Validation("chapter title must be 180 characters or fewer".into())); }
    if input.tags.len() > 100 { return Err(ManuscriptError::Validation("chapter may contain at most 100 tags".into())); }
    Ok(())
}
fn validate_note(input: &UpsertQuickNoteInput) -> Result<(), ManuscriptError> {
    if input.body.trim().is_empty() { return Err(ManuscriptError::Validation("note body is required".into())); }
    if input.body.chars().count() > 4000 { return Err(ManuscriptError::Validation("note must be 4000 characters or fewer".into())); }
    if input.link_kind.is_some() != input.link_id.is_some() { return Err(ManuscriptError::Validation("note link kind and id must be supplied together".into())); }
    Ok(())
}

pub fn list(repo: &dyn ManuscriptRepository) -> Result<Vec<ChapterSummary>, ManuscriptError> { repo.list_chapters() }
pub fn get(repo: &dyn ManuscriptRepository, id: &str) -> Result<Chapter, ManuscriptError> { repo.get_chapter(id) }
pub fn create(repo: &dyn ManuscriptRepository, input: UpsertChapterInput) -> Result<Chapter, ManuscriptError> { validate_chapter(&input)?; repo.create_chapter(&input) }
pub fn update(repo: &dyn ManuscriptRepository, id: &str, input: UpsertChapterInput) -> Result<Chapter, ManuscriptError> { validate_chapter(&input)?; repo.update_chapter(id, &input) }
pub fn delete(repo: &dyn ManuscriptRepository, id: &str) -> Result<(), ManuscriptError> { repo.delete_chapter(id) }
pub fn list_notes(repo: &dyn ManuscriptRepository) -> Result<Vec<QuickNote>, ManuscriptError> { repo.list_notes() }
pub fn create_note(repo: &dyn ManuscriptRepository, input: UpsertQuickNoteInput) -> Result<QuickNote, ManuscriptError> { validate_note(&input)?; repo.create_note(&input) }
pub fn update_note(repo: &dyn ManuscriptRepository, id: &str, input: UpsertQuickNoteInput) -> Result<QuickNote, ManuscriptError> { validate_note(&input)?; repo.update_note(id, &input) }
pub fn delete_note(repo: &dyn ManuscriptRepository, id: &str) -> Result<(), ManuscriptError> { repo.delete_note(id) }
