use std::collections::HashMap;
use serde::Serialize;
use crate::{
    characters::domain::repository::CharacterRepository,
    timeline::{
        application::use_cases::{TimelineEventDto, TimelineParticipantDto},
        domain::{error::TimelineError, repository::TimelineRepository, timeline::{EventImportance, TimelineEventKind, TemporalKind}},
    },
};

#[derive(Debug,Clone,Serialize)]
#[serde(rename_all="camelCase")]
pub struct TimelineParticipantProjectionDto { pub character_id:String,pub character_name:String,pub role:String }
#[derive(Debug,Clone,Serialize)]
#[serde(rename_all="camelCase")]
pub struct TimelineEntryDto { pub event_id:String,pub title:String,pub kind:TimelineEventKind,pub importance:EventImportance,pub temporal_kind:TemporalKind,pub start_chapter:u32,pub end_chapter:Option<u32>,pub location_label:Option<String>,pub participants:Vec<TimelineParticipantProjectionDto>,pub source_count:usize }
#[derive(Debug,Clone,Serialize)]
#[serde(rename_all="camelCase")]
pub struct TimelineProjectionDto { pub start_chapter:u32,pub end_chapter:u32,pub entries:Vec<TimelineEntryDto> }

fn map_entry(event:TimelineEventDto,names:&HashMap<String,String>)->TimelineEntryDto{
    let participants=event.participants.iter().map(|p:&TimelineParticipantDto|TimelineParticipantProjectionDto{character_id:p.character_id.clone(),character_name:names.get(&p.character_id).cloned().unwrap_or_else(||p.character_id.clone()),role:format!("{:?}",p.role).to_lowercase()}).collect();
    TimelineEntryDto{event_id:event.id,title:event.title,kind:event.kind,importance:event.importance,temporal_kind:event.temporal_kind,start_chapter:event.start_chapter,end_chapter:event.end_chapter,location_label:event.location_label,participants,source_count:event.sources.len()}
}

pub fn chronicle_between(characters:&dyn CharacterRepository,repo:&dyn TimelineRepository,start:u32,end:u32)->Result<TimelineProjectionDto,TimelineError>{
    if start==0||end<=start{return Err(TimelineError::Validation("range must satisfy 0 < start < end".into()));}
    let names=characters.list().map_err(|e|TimelineError::Database(e.to_string()))?.into_iter().map(|c|(c.id.0,c.name)).collect::<HashMap<_,_>>();
    let events=crate::timeline::application::use_cases::between(repo,start,end)?;
    Ok(TimelineProjectionDto{start_chapter:start,end_chapter:end,entries:events.into_iter().map(|e|map_entry(e,&names)).collect()})
}

pub fn character_thread(characters:&dyn CharacterRepository,repo:&dyn TimelineRepository,character_id:String)->Result<Vec<TimelineEntryDto>,TimelineError>{
    let names=characters.list().map_err(|e|TimelineError::Database(e.to_string()))?.into_iter().map(|c|(c.id.0,c.name)).collect::<HashMap<_,_>>();
    Ok(crate::timeline::application::use_cases::for_character(characters,repo,character_id,None,None)?.into_iter().map(|e|map_entry(e,&names)).collect())
}
