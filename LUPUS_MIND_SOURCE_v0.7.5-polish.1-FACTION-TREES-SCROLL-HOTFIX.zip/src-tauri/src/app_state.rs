use std::{path::{Path, PathBuf}, sync::{Arc, Mutex}};
use crate::{
    combat_replay::infrastructure::sqlite_combat_replay_repository::SqliteCombatReplayRepository,
    combat::infrastructure::sqlite_combat_repository::SqliteCombatRepository,
    status_effects::infrastructure::sqlite_status_effect_repository::SqliteStatusEffectRepository,
    characters::infrastructure::sqlite_character_repository::SqliteCharacterRepository,
    equipment::infrastructure::sqlite_equipment_repository::SqliteEquipmentRepository,
    items::infrastructure::sqlite_item_repository::SqliteItemRepository,
    skills::infrastructure::sqlite_skill_repository::SqliteSkillRepository,
    relationships::infrastructure::sqlite_relationship_repository::SqliteRelationshipRepository,
    timeline::infrastructure::sqlite_timeline_repository::SqliteTimelineRepository,
    workspace::infrastructure::sqlite_workspace_operations::SqliteWorkspaceOperations,
    projects::infrastructure::project_registry::{ProjectRegistry, SharedDatabasePath},
    manuscript::infrastructure::sqlite_manuscript_repository::SqliteManuscriptRepository,
    global_search::infrastructure::sqlite_global_search_repository::SqliteGlobalSearchRepository,
    assets::infrastructure::filesystem_asset_store::FileSystemAssetStore,
    lore::infrastructure::sqlite_lore_repository::SqliteLoreRepository,
    knowledge_links::infrastructure::sqlite_knowledge_link_repository::SqliteKnowledgeLinkRepository,
    authoring::infrastructure::sqlite_authoring_repository::SqliteAuthoringRepository,
    factions::infrastructure::sqlite_faction_repository::SqliteFactionRepository,
    inventory::infrastructure::sqlite_inventory_repository::SqliteInventoryRepository,
    quests::infrastructure::sqlite_quest_repository::SqliteQuestRepository,
    secrets::infrastructure::sqlite_secret_repository::SqliteSecretRepository,
    atlas::infrastructure::sqlite_atlas_repository::SqliteAtlasRepository,
    shared::database::Database,
};

pub struct AppState {
    pub combat: SqliteCombatRepository,
    pub combat_replay: SqliteCombatReplayRepository,
    pub status_effects: SqliteStatusEffectRepository,
    pub characters: SqliteCharacterRepository,
    pub items: SqliteItemRepository,
    pub equipment: SqliteEquipmentRepository,
    pub skills: SqliteSkillRepository,
    pub relationships: SqliteRelationshipRepository,
    pub timeline: SqliteTimelineRepository,
    pub workspace: SqliteWorkspaceOperations,
    pub projects: ProjectRegistry,
    pub manuscript: SqliteManuscriptRepository,
    pub search: SqliteGlobalSearchRepository,
    pub assets: FileSystemAssetStore,
    pub lore: SqliteLoreRepository,
    pub links: SqliteKnowledgeLinkRepository,
    pub authoring: SqliteAuthoringRepository,
    pub factions: SqliteFactionRepository,
    pub inventory: SqliteInventoryRepository,
    pub quests: SqliteQuestRepository,
    pub secrets: SqliteSecretRepository,
    pub atlas: SqliteAtlasRepository,
}

impl AppState {
    pub fn open(path: &Path) -> Result<Self, rusqlite::Error> {
        let db = Database::open(path)?;
        let active_path: SharedDatabasePath = Arc::new(Mutex::new(path.to_path_buf()));
        let base_dir = path.parent().unwrap_or_else(|| Path::new(".")).to_path_buf();
        Ok(Self::from_db(db, active_path, base_dir))
    }

    pub fn open_managed(base_dir: &Path) -> Result<Self, Box<dyn std::error::Error>> {
        let active = ProjectRegistry::bootstrap(base_dir)?;
        let db = Database::open(&active)?;
        let active_path: SharedDatabasePath = Arc::new(Mutex::new(active));
        Ok(Self::from_db(db, active_path, base_dir.to_path_buf()))
    }

    pub fn in_memory() -> Result<Self, rusqlite::Error> {
        let db = Database::open_in_memory()?;
        let active_path: SharedDatabasePath = Arc::new(Mutex::new(PathBuf::from(":memory:")));
        let base_dir = std::env::temp_dir().join("lupus-mind-in-memory");
        Ok(Self::from_db(db, active_path, base_dir))
    }

    fn from_db(db: Database, active_path: SharedDatabasePath, base_dir: PathBuf) -> Self {
        let c = db.shared();
        let asset_path = active_path.clone();
        Self {
            combat: SqliteCombatRepository::new(c.clone()),
            combat_replay: SqliteCombatReplayRepository::new(c.clone()),
            status_effects: SqliteStatusEffectRepository::new(c.clone()),
            characters: SqliteCharacterRepository::new(c.clone()),
            items: SqliteItemRepository::new(c.clone()),
            equipment: SqliteEquipmentRepository::new(c.clone()),
            skills: SqliteSkillRepository::new(c.clone()),
            relationships: SqliteRelationshipRepository::new(c.clone()),
            timeline: SqliteTimelineRepository::new(c.clone()),
            workspace: SqliteWorkspaceOperations::new(c.clone(), active_path.clone()),
            projects: ProjectRegistry::new(base_dir, c.clone(), active_path),
            manuscript: SqliteManuscriptRepository::new(c.clone()),
            search: SqliteGlobalSearchRepository::new(c.clone()),
            lore: SqliteLoreRepository::new(c.clone()),
            links: SqliteKnowledgeLinkRepository::new(c.clone()),
            authoring: SqliteAuthoringRepository::new(c.clone()),
            factions: SqliteFactionRepository::new(c.clone()),
            inventory: SqliteInventoryRepository::new(c.clone()),
            quests: SqliteQuestRepository::new(c.clone()),
            secrets: SqliteSecretRepository::new(c.clone()),
            atlas: SqliteAtlasRepository::new(c),
            assets: FileSystemAssetStore::new(asset_path),
        }
    }
}
