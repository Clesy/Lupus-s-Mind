use crate::authoring::domain::{authoring::{CharacterArcPoint,ScenePlan,UpsertArcPointInput,UpsertScenePlanInput},error::AuthoringError};
pub trait AuthoringRepository:Send+Sync{
 fn arc_for_character(&self,character_id:&str)->Result<Vec<CharacterArcPoint>,AuthoringError>;
 fn create_arc(&self,input:&UpsertArcPointInput)->Result<CharacterArcPoint,AuthoringError>;
 fn update_arc(&self,id:&str,input:&UpsertArcPointInput)->Result<CharacterArcPoint,AuthoringError>;
 fn delete_arc(&self,id:&str)->Result<(),AuthoringError>;
 fn scenes_for_chapter(&self,chapter_id:&str)->Result<Vec<ScenePlan>,AuthoringError>;
 fn create_scene(&self,input:&UpsertScenePlanInput)->Result<ScenePlan,AuthoringError>;
 fn update_scene(&self,id:&str,input:&UpsertScenePlanInput)->Result<ScenePlan,AuthoringError>;
 fn delete_scene(&self,id:&str)->Result<(),AuthoringError>;
}
