use tauri::State;
use crate::{app_state::AppState,knowledge_links::domain::repository::KnowledgeLinkRepository,lore::{application::use_cases,domain::lore::{LorePage,LoreSummary,UpsertLoreInput}},shared::api_error::ApiError};
#[tauri::command]pub fn lore_pages_list(state:State<'_,AppState>)->Result<Vec<LoreSummary>,ApiError>{use_cases::list(&state.lore).map_err(Into::into)}
#[tauri::command]pub fn lore_page_get(state:State<'_,AppState>,id:String)->Result<LorePage,ApiError>{use_cases::get(&state.lore,&id).map_err(Into::into)}
#[tauri::command]pub fn lore_page_create(state:State<'_,AppState>,input:UpsertLoreInput)->Result<LorePage,ApiError>{let page=use_cases::create(&state.lore,input).map_err(ApiError::from)?;let _=state.links.refresh_source("lore",&page.id,&format!("{}\n{}\n{}",page.title,page.summary,page.content));Ok(page)}
#[tauri::command]pub fn lore_page_update(state:State<'_,AppState>,id:String,input:UpsertLoreInput)->Result<LorePage,ApiError>{let page=use_cases::update(&state.lore,&id,input).map_err(ApiError::from)?;let _=state.links.refresh_source("lore",&page.id,&format!("{}\n{}\n{}",page.title,page.summary,page.content));Ok(page)}
#[tauri::command]pub fn lore_page_delete(state:State<'_,AppState>,id:String)->Result<(),ApiError>{use_cases::delete(&state.lore,&id).map_err(ApiError::from)?;let _=state.links.delete_source("lore",&id);Ok(())}
