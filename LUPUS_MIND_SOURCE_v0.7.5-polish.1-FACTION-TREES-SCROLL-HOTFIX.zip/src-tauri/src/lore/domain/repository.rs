use crate::lore::domain::{error::LoreError,lore::{LorePage,LoreSummary,UpsertLoreInput}};
pub trait LoreRepository:Send+Sync{
 fn list(&self)->Result<Vec<LoreSummary>,LoreError>;
 fn get(&self,id:&str)->Result<LorePage,LoreError>;
 fn create(&self,input:&UpsertLoreInput)->Result<LorePage,LoreError>;
 fn update(&self,id:&str,input:&UpsertLoreInput)->Result<LorePage,LoreError>;
 fn delete(&self,id:&str)->Result<(),LoreError>;
}
