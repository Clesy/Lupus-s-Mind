use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all="camelCase")]
pub struct LorePage {
    pub id:String, pub title:String, pub category:String, pub summary:String, pub content:String,
    pub tags:Vec<String>, pub word_count:u32, pub created_at:DateTime<Utc>, pub updated_at:DateTime<Utc>,
}
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all="camelCase")]
pub struct LoreSummary {
    pub id:String, pub title:String, pub category:String, pub summary:String, pub tags:Vec<String>, pub updated_at:DateTime<Utc>,
}
#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all="camelCase")]
pub struct UpsertLoreInput {
    pub title:String,
    #[serde(default="default_category")] pub category:String,
    #[serde(default)] pub summary:String,
    #[serde(default)] pub content:String,
    #[serde(default)] pub tags:Vec<String>,
}
fn default_category()->String{"General".into()}
pub fn word_count(content:&str)->u32{content.split_whitespace().count().min(u32::MAX as usize) as u32}
