use chrono::{DateTime,Utc};
use rusqlite::{params,Row};
use uuid::Uuid;
use crate::{lore::domain::{error::LoreError,lore::{word_count,LorePage,LoreSummary,UpsertLoreInput},repository::LoreRepository},shared::database::SharedConnection};
#[derive(Clone)]pub struct SqliteLoreRepository{conn:SharedConnection}
impl SqliteLoreRepository{pub fn new(conn:SharedConnection)->Self{Self{conn}}
 fn page(row:&Row<'_>)->rusqlite::Result<(String,String,String,String,String,String,String,String)>{Ok((row.get(0)?,row.get(1)?,row.get(2)?,row.get(3)?,row.get(4)?,row.get(5)?,row.get(6)?,row.get(7)?))}
 fn map(raw:(String,String,String,String,String,String,String,String))->Result<LorePage,LoreError>{
  let tags=serde_json::from_str(&raw.5).map_err(|e|LoreError::Mapping(e.to_string()))?;
  let created_at=DateTime::parse_from_rfc3339(&raw.6).map(|v|v.with_timezone(&Utc)).map_err(|e|LoreError::Mapping(e.to_string()))?;
  let updated_at=DateTime::parse_from_rfc3339(&raw.7).map(|v|v.with_timezone(&Utc)).map_err(|e|LoreError::Mapping(e.to_string()))?;
  Ok(LorePage{id:raw.0,title:raw.1,category:raw.2,summary:raw.3,content:raw.4.clone(),tags,word_count:word_count(&raw.4),created_at,updated_at})
 }
}
fn db(e:rusqlite::Error)->LoreError{LoreError::Database(e.to_string())}
impl LoreRepository for SqliteLoreRepository{
 fn list(&self)->Result<Vec<LoreSummary>,LoreError>{let c=self.conn.lock().map_err(|e|LoreError::Database(e.to_string()))?;let mut s=c.prepare("SELECT id,title,category,summary,tags,updated_at FROM lore_pages ORDER BY updated_at DESC,title COLLATE NOCASE").map_err(db)?;let rows=s.query_map([],|r|Ok((r.get::<_,String>(0)?,r.get::<_,String>(1)?,r.get::<_,String>(2)?,r.get::<_,String>(3)?,r.get::<_,String>(4)?,r.get::<_,String>(5)?))).map_err(db)?;let mut out=Vec::new();for row in rows{let r=row.map_err(db)?;out.push(LoreSummary{id:r.0,title:r.1,category:r.2,summary:r.3,tags:serde_json::from_str(&r.4).map_err(|e|LoreError::Mapping(e.to_string()))?,updated_at:DateTime::parse_from_rfc3339(&r.5).map(|v|v.with_timezone(&Utc)).map_err(|e|LoreError::Mapping(e.to_string()))?});}Ok(out)}
 fn get(&self,id:&str)->Result<LorePage,LoreError>{let c=self.conn.lock().map_err(|e|LoreError::Database(e.to_string()))?;let raw=c.query_row("SELECT id,title,category,summary,content,tags,created_at,updated_at FROM lore_pages WHERE id=?",params![id],Self::page).map_err(|e|match e{rusqlite::Error::QueryReturnedNoRows=>LoreError::NotFound(id.into()),other=>db(other)})?;Self::map(raw)}
 fn create(&self,input:&UpsertLoreInput)->Result<LorePage,LoreError>{let id=Uuid::new_v4().to_string();let now=Utc::now().to_rfc3339();let tags=serde_json::to_string(&input.tags).map_err(|e|LoreError::Mapping(e.to_string()))?;let c=self.conn.lock().map_err(|e|LoreError::Database(e.to_string()))?;c.execute("INSERT INTO lore_pages(id,title,category,summary,content,tags,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)",params![&id,input.title.trim(),input.category.trim(),&input.summary,&input.content,tags,&now,&now]).map_err(db)?;drop(c);self.get(&id)}
 fn update(&self,id:&str,input:&UpsertLoreInput)->Result<LorePage,LoreError>{let now=Utc::now().to_rfc3339();let tags=serde_json::to_string(&input.tags).map_err(|e|LoreError::Mapping(e.to_string()))?;let c=self.conn.lock().map_err(|e|LoreError::Database(e.to_string()))?;let n=c.execute("UPDATE lore_pages SET title=?,category=?,summary=?,content=?,tags=?,updated_at=? WHERE id=?",params![input.title.trim(),input.category.trim(),&input.summary,&input.content,tags,now,id]).map_err(db)?;if n==0{return Err(LoreError::NotFound(id.into()));}drop(c);self.get(id)}
 fn delete(&self,id:&str)->Result<(),LoreError>{let c=self.conn.lock().map_err(|e|LoreError::Database(e.to_string()))?;let n=c.execute("DELETE FROM lore_pages WHERE id=?",params![id]).map_err(db)?;if n==0{Err(LoreError::NotFound(id.into()))}else{Ok(())}}
}
