use super::{error::FactionError, hierarchy::*};

pub trait FactionHierarchyRepository: Send + Sync {
    fn hierarchy_roles(&self, faction_id: &str) -> Result<Vec<HierarchyRole>, FactionError>;
    fn create_hierarchy_role(&self, input: UpsertHierarchyRoleInput) -> Result<HierarchyRole, FactionError>;
    fn update_hierarchy_role(&self, id: &str, input: UpsertHierarchyRoleInput) -> Result<HierarchyRole, FactionError>;
    fn delete_hierarchy_role(&self, id: &str) -> Result<(), FactionError>;
    fn seed_default_hierarchy(&self, faction_id: &str) -> Result<Vec<HierarchyRole>, FactionError>;
    fn role_assignments(&self, faction_id: &str, chapter: u32) -> Result<Vec<RoleAssignment>, FactionError>;
    fn assign_role(&self, input: AssignRoleInput) -> Result<RoleAssignment, FactionError>;
    fn end_role_assignment(&self, id: &str, chapter: u32) -> Result<(), FactionError>;

    fn lineages(&self, affiliated_faction_id: Option<&str>) -> Result<Vec<Lineage>, FactionError>;
    fn create_lineage(&self, input: UpsertLineageInput) -> Result<Lineage, FactionError>;
    fn update_lineage(&self, id: &str, input: UpsertLineageInput) -> Result<Lineage, FactionError>;
    fn delete_lineage(&self, id: &str) -> Result<(), FactionError>;
    fn lineage_memberships(&self, lineage_id: &str, chapter: u32) -> Result<Vec<LineageMembership>, FactionError>;
    fn add_lineage_membership(&self, input: AddLineageMembershipInput) -> Result<LineageMembership, FactionError>;
    fn end_lineage_membership(&self, id: &str, chapter: u32) -> Result<(), FactionError>;
}
