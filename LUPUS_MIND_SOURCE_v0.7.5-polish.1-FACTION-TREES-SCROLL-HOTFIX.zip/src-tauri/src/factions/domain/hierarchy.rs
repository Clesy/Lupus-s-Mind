use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct HierarchyRole {
    pub id: String,
    pub faction_id: String,
    pub name: String,
    pub parent_role_id: Option<String>,
    pub tier: u32,
    pub capacity: Option<u32>,
    pub color: String,
    pub sort_order: i32,
}

#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct UpsertHierarchyRoleInput {
    pub faction_id: String,
    pub name: String,
    pub parent_role_id: Option<String>,
    pub tier: u32,
    pub capacity: Option<u32>,
    pub color: Option<String>,
    pub sort_order: i32,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct RoleAssignment {
    pub id: String,
    pub faction_id: String,
    pub role_id: String,
    pub role_name: String,
    pub character_id: String,
    pub character_name: String,
    pub valid_from_chapter: u32,
    pub valid_to_chapter: Option<u32>,
    pub title_override: String,
    pub notes: String,
}

#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AssignRoleInput {
    pub role_id: String,
    pub character_id: String,
    pub valid_from_chapter: u32,
    pub title_override: Option<String>,
    pub notes: Option<String>,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct Lineage {
    pub id: String,
    pub name: String,
    pub kind: String,
    pub description: String,
    pub color: String,
    pub tags: Vec<String>,
    pub affiliated_faction_id: Option<String>,
    pub affiliated_faction_name: Option<String>,
    pub member_count: u32,
}

#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct UpsertLineageInput {
    pub name: String,
    pub kind: String,
    pub description: Option<String>,
    pub color: Option<String>,
    pub tags: Vec<String>,
    pub affiliated_faction_id: Option<String>,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct LineageMembership {
    pub id: String,
    pub lineage_id: String,
    pub lineage_name: String,
    pub character_id: String,
    pub character_name: String,
    pub branch_label: String,
    pub title: String,
    pub joined_chapter: u32,
    pub left_chapter: Option<u32>,
}

#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AddLineageMembershipInput {
    pub lineage_id: String,
    pub character_id: String,
    pub branch_label: Option<String>,
    pub title: Option<String>,
    pub joined_chapter: u32,
}
