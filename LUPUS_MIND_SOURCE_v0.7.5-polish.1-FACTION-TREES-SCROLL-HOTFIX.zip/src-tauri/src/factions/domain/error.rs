use thiserror::Error;
#[derive(Debug,Error)]pub enum FactionError{#[error("faction not found: {0}")]NotFound(String),#[error("membership not found: {0}")]MembershipNotFound(String),#[error("validation error: {0}")]Validation(String),#[error("database error: {0}")]Database(String),#[error("mapping error: {0}")]Mapping(String)}
