use tauri::State;use crate::{app_state::AppState,factions::{application::use_cases,domain::faction::*},shared::api_error::ApiError};
#[tauri::command]pub fn factions_list(state:State<'_,AppState>)->Result<Vec<Faction>,ApiError>{use_cases::list(&state.factions).map_err(Into::into)}
#[tauri::command]pub fn faction_get(state:State<'_,AppState>,id:String)->Result<Faction,ApiError>{use_cases::get(&state.factions,&id).map_err(Into::into)}
#[tauri::command]pub fn faction_create(state:State<'_,AppState>,input:UpsertFactionInput)->Result<Faction,ApiError>{use_cases::create(&state.factions,input).map_err(Into::into)}
#[tauri::command]pub fn faction_update(state:State<'_,AppState>,id:String,input:UpsertFactionInput)->Result<Faction,ApiError>{use_cases::update(&state.factions,&id,input).map_err(Into::into)}
#[tauri::command]pub fn faction_delete(state:State<'_,AppState>,id:String)->Result<(),ApiError>{use_cases::delete(&state.factions,&id).map_err(Into::into)}
#[tauri::command]pub fn faction_memberships_list(state:State<'_,AppState>,faction_id:Option<String>,character_id:Option<String>,chapter:Option<u32>)->Result<Vec<FactionMembership>,ApiError>{use_cases::memberships(&state.factions,faction_id.as_deref(),character_id.as_deref(),chapter).map_err(Into::into)}
#[tauri::command]pub fn faction_membership_add(state:State<'_,AppState>,input:AddMembershipInput)->Result<FactionMembership,ApiError>{use_cases::add_membership(&state.factions,input).map_err(Into::into)}
#[tauri::command]pub fn faction_membership_end(state:State<'_,AppState>,id:String,left_chapter:u32)->Result<(),ApiError>{use_cases::end_membership(&state.factions,&id,left_chapter).map_err(Into::into)}
#[tauri::command]pub fn faction_relations_at(state:State<'_,AppState>,chapter:u32)->Result<Vec<FactionRelationState>,ApiError>{use_cases::relations_at(&state.factions,chapter).map_err(Into::into)}
#[tauri::command]pub fn faction_relation_set(state:State<'_,AppState>,input:SetFactionRelationInput)->Result<FactionRelationState,ApiError>{use_cases::set_relation(&state.factions,input).map_err(Into::into)}

#[tauri::command]
pub fn faction_hierarchy_roles_list(state:State<'_,AppState>,faction_id:String)->Result<Vec<crate::factions::domain::hierarchy::HierarchyRole>,ApiError>{
    crate::factions::application::hierarchy_use_cases::roles(&state.factions,&faction_id).map_err(Into::into)
}
#[tauri::command]
pub fn faction_hierarchy_role_create(state:State<'_,AppState>,input:crate::factions::domain::hierarchy::UpsertHierarchyRoleInput)->Result<crate::factions::domain::hierarchy::HierarchyRole,ApiError>{
    crate::factions::application::hierarchy_use_cases::create_role(&state.factions,input).map_err(Into::into)
}
#[tauri::command]
pub fn faction_hierarchy_role_update(state:State<'_,AppState>,id:String,input:crate::factions::domain::hierarchy::UpsertHierarchyRoleInput)->Result<crate::factions::domain::hierarchy::HierarchyRole,ApiError>{
    crate::factions::application::hierarchy_use_cases::update_role(&state.factions,&id,input).map_err(Into::into)
}
#[tauri::command]
pub fn faction_hierarchy_role_delete(state:State<'_,AppState>,id:String)->Result<(),ApiError>{
    crate::factions::application::hierarchy_use_cases::delete_role(&state.factions,&id).map_err(Into::into)
}
#[tauri::command]
pub fn faction_hierarchy_seed_defaults(state:State<'_,AppState>,faction_id:String)->Result<Vec<crate::factions::domain::hierarchy::HierarchyRole>,ApiError>{
    crate::factions::application::hierarchy_use_cases::seed_defaults(&state.factions,&faction_id).map_err(Into::into)
}
#[tauri::command]
pub fn faction_role_assignments_at(state:State<'_,AppState>,faction_id:String,chapter:u32)->Result<Vec<crate::factions::domain::hierarchy::RoleAssignment>,ApiError>{
    crate::factions::application::hierarchy_use_cases::assignments(&state.factions,&faction_id,chapter).map_err(Into::into)
}
#[tauri::command]
pub fn faction_role_assign(state:State<'_,AppState>,input:crate::factions::domain::hierarchy::AssignRoleInput)->Result<crate::factions::domain::hierarchy::RoleAssignment,ApiError>{
    crate::factions::application::hierarchy_use_cases::assign(&state.factions,input).map_err(Into::into)
}
#[tauri::command]
pub fn faction_role_assignment_end(state:State<'_,AppState>,id:String,chapter:u32)->Result<(),ApiError>{
    crate::factions::application::hierarchy_use_cases::end_assignment(&state.factions,&id,chapter).map_err(Into::into)
}
#[tauri::command]
pub fn lineages_list(state:State<'_,AppState>,faction_id:Option<String>)->Result<Vec<crate::factions::domain::hierarchy::Lineage>,ApiError>{
    crate::factions::application::hierarchy_use_cases::lineages(&state.factions,faction_id.as_deref()).map_err(Into::into)
}
#[tauri::command]
pub fn lineage_create(state:State<'_,AppState>,input:crate::factions::domain::hierarchy::UpsertLineageInput)->Result<crate::factions::domain::hierarchy::Lineage,ApiError>{
    crate::factions::application::hierarchy_use_cases::create_lineage(&state.factions,input).map_err(Into::into)
}
#[tauri::command]
pub fn lineage_update(state:State<'_,AppState>,id:String,input:crate::factions::domain::hierarchy::UpsertLineageInput)->Result<crate::factions::domain::hierarchy::Lineage,ApiError>{
    crate::factions::application::hierarchy_use_cases::update_lineage(&state.factions,&id,input).map_err(Into::into)
}
#[tauri::command]
pub fn lineage_delete(state:State<'_,AppState>,id:String)->Result<(),ApiError>{
    crate::factions::application::hierarchy_use_cases::delete_lineage(&state.factions,&id).map_err(Into::into)
}
#[tauri::command]
pub fn lineage_memberships_at(state:State<'_,AppState>,lineage_id:String,chapter:u32)->Result<Vec<crate::factions::domain::hierarchy::LineageMembership>,ApiError>{
    crate::factions::application::hierarchy_use_cases::lineage_memberships(&state.factions,&lineage_id,chapter).map_err(Into::into)
}
#[tauri::command]
pub fn lineage_membership_add(state:State<'_,AppState>,input:crate::factions::domain::hierarchy::AddLineageMembershipInput)->Result<crate::factions::domain::hierarchy::LineageMembership,ApiError>{
    crate::factions::application::hierarchy_use_cases::add_lineage_member(&state.factions,input).map_err(Into::into)
}
#[tauri::command]
pub fn lineage_membership_end(state:State<'_,AppState>,id:String,chapter:u32)->Result<(),ApiError>{
    crate::factions::application::hierarchy_use_cases::end_lineage_member(&state.factions,&id,chapter).map_err(Into::into)
}
