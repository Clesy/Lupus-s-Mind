use chrono::Utc;use rusqlite::{params,OptionalExtension};use uuid::Uuid;use crate::{factions::domain::{error::FactionError,faction::*,repository::FactionRepository},shared::database::SharedConnection};
#[derive(Clone)]pub struct SqliteFactionRepository{conn:SharedConnection}impl SqliteFactionRepository{pub fn new(conn:SharedConnection)->Self{Self{conn}}}
fn valid_kind(v:&str)->bool{matches!(v,"faction"|"clan"|"guild"|"kingdom"|"order"|"house")}fn valid_relation(v:&str)->bool{matches!(v,"allied"|"friendly"|"neutral"|"tense"|"hostile"|"war"|"vassal")}
impl FactionRepository for SqliteFactionRepository{
fn list(&self)->Result<Vec<Faction>,FactionError>{let c=self.conn.lock().map_err(|e|FactionError::Database(e.to_string()))?;let mut s=c.prepare("SELECT f.id,f.name,f.kind,f.description,f.motto,f.color,f.tags,f.created_at,f.updated_at,COUNT(m.id) FROM factions f LEFT JOIN faction_memberships m ON m.faction_id=f.id AND m.left_chapter IS NULL GROUP BY f.id ORDER BY f.name COLLATE NOCASE").map_err(|e|FactionError::Database(e.to_string()))?;let rows=s.query_map([],|r|Ok((r.get::<_,String>(0)?,r.get::<_,String>(1)?,r.get::<_,String>(2)?,r.get::<_,String>(3)?,r.get::<_,String>(4)?,r.get::<_,String>(5)?,r.get::<_,String>(6)?,r.get::<_,String>(7)?,r.get::<_,String>(8)?,r.get::<_,i64>(9)?))).map_err(|e|FactionError::Database(e.to_string()))?;rows.map(|x|{let x=x.map_err(|e|FactionError::Database(e.to_string()))?;Ok(Faction{id:x.0,name:x.1,kind:x.2,description:x.3,motto:x.4,color:x.5,tags:serde_json::from_str(&x.6).map_err(|e|FactionError::Mapping(e.to_string()))?,created_at:x.7,updated_at:x.8,member_count:u32::try_from(x.9).unwrap_or(0)})}).collect()}
fn get(&self,id:&str)->Result<Option<Faction>,FactionError>{Ok(self.list()?.into_iter().find(|x|x.id==id))}
fn create(&self,i:UpsertFactionInput)->Result<Faction,FactionError>{let name=i.name.trim();if name.is_empty(){return Err(FactionError::Validation("name is required".into()))}if !valid_kind(&i.kind){return Err(FactionError::Validation("invalid faction kind".into()))}let id=Uuid::new_v4().to_string();let now=Utc::now().to_rfc3339();let tags=serde_json::to_string(&i.tags).map_err(|e|FactionError::Mapping(e.to_string()))?;let c=self.conn.lock().map_err(|e|FactionError::Database(e.to_string()))?;c.execute("INSERT INTO factions(id,name,kind,description,motto,color,tags,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)",params![id,name,i.kind,i.description.unwrap_or_default(),i.motto.unwrap_or_default(),i.color.unwrap_or_else(||"#8b7cf6".into()),tags,now,now]).map_err(|e|FactionError::Database(e.to_string()))?;drop(c);self.get(&id)?.ok_or_else(||FactionError::NotFound(id))}
fn update(&self,id:&str,i:UpsertFactionInput)->Result<Faction,FactionError>{if i.name.trim().is_empty(){return Err(FactionError::Validation("name is required".into()))}if !valid_kind(&i.kind){return Err(FactionError::Validation("invalid faction kind".into()))}let tags=serde_json::to_string(&i.tags).map_err(|e|FactionError::Mapping(e.to_string()))?;let c=self.conn.lock().map_err(|e|FactionError::Database(e.to_string()))?;let n=c.execute("UPDATE factions SET name=?,kind=?,description=?,motto=?,color=?,tags=?,updated_at=? WHERE id=?",params![i.name.trim(),i.kind,i.description.unwrap_or_default(),i.motto.unwrap_or_default(),i.color.unwrap_or_else(||"#8b7cf6".into()),tags,Utc::now().to_rfc3339(),id]).map_err(|e|FactionError::Database(e.to_string()))?;drop(c);if n==0{Err(FactionError::NotFound(id.into()))}else{self.get(id)?.ok_or_else(||FactionError::NotFound(id.into()))}}
fn delete(&self,id:&str)->Result<(),FactionError>{let c=self.conn.lock().map_err(|e|FactionError::Database(e.to_string()))?;let n=c.execute("DELETE FROM factions WHERE id=?",params![id]).map_err(|e|FactionError::Database(e.to_string()))?;if n==0{Err(FactionError::NotFound(id.into()))}else{Ok(())}}
fn memberships(&self,faction_id:Option<&str>,character_id:Option<&str>,chapter:Option<u32>)->Result<Vec<FactionMembership>,FactionError>{let c=self.conn.lock().map_err(|e|FactionError::Database(e.to_string()))?;let mut sql=String::from("SELECT m.id,m.faction_id,f.name,m.character_id,c.name,m.role,m.rank,m.joined_chapter,m.left_chapter FROM faction_memberships m JOIN factions f ON f.id=m.faction_id JOIN characters c ON c.id=m.character_id WHERE 1=1");let mut args:Vec<Box<dyn rusqlite::ToSql>>=Vec::new();if let Some(v)=faction_id{sql.push_str(" AND m.faction_id=?");args.push(Box::new(v.to_string()));}if let Some(v)=character_id{sql.push_str(" AND m.character_id=?");args.push(Box::new(v.to_string()));}if let Some(ch)=chapter{sql.push_str(" AND m.joined_chapter<=? AND (m.left_chapter IS NULL OR m.left_chapter>?)");args.push(Box::new(i64::from(ch)));args.push(Box::new(i64::from(ch)));}sql.push_str(" ORDER BY f.name,c.name,m.joined_chapter");let mut s=c.prepare(&sql).map_err(|e|FactionError::Database(e.to_string()))?;let refs:Vec<&dyn rusqlite::ToSql>=args.iter().map(|x|x.as_ref()).collect();let rows=s.query_map(refs.as_slice(),|r|Ok(FactionMembership{id:r.get(0)?,faction_id:r.get(1)?,faction_name:r.get(2)?,character_id:r.get(3)?,character_name:r.get(4)?,role:r.get(5)?,rank:r.get(6)?,joined_chapter:u32::try_from(r.get::<_,i64>(7)?).unwrap_or(1),left_chapter:r.get::<_,Option<i64>>(8)?.and_then(|v|u32::try_from(v).ok())})).map_err(|e|FactionError::Database(e.to_string()))?;rows.map(|x|x.map_err(|e|FactionError::Database(e.to_string()))).collect()}
fn add_membership(&self,i:AddMembershipInput)->Result<FactionMembership,FactionError>{if i.joined_chapter==0{return Err(FactionError::Validation("joined chapter must be positive".into()))}let id=Uuid::new_v4().to_string();let now=Utc::now().to_rfc3339();let c=self.conn.lock().map_err(|e|FactionError::Database(e.to_string()))?;c.execute("INSERT INTO faction_memberships(id,faction_id,character_id,role,rank,joined_chapter,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)",params![id,i.faction_id,i.character_id,if i.role.trim().is_empty(){"Member"}else{i.role.trim()},i.rank.trim(),i.joined_chapter,now,now]).map_err(|e|FactionError::Database(e.to_string()))?;drop(c);self.memberships(None,None,None)?.into_iter().find(|m|m.id==id).ok_or_else(||FactionError::MembershipNotFound(id))}
fn end_membership(&self,id:&str,ch:u32)->Result<(),FactionError>{let c=self.conn.lock().map_err(|e|FactionError::Database(e.to_string()))?;let joined:Option<i64>=c.query_row("SELECT joined_chapter FROM faction_memberships WHERE id=? AND left_chapter IS NULL",params![id],|r|r.get(0)).optional().map_err(|e|FactionError::Database(e.to_string()))?;let Some(joined)=joined else{return Err(FactionError::MembershipNotFound(id.into()))};if i64::from(ch)<=joined{return Err(FactionError::Validation("left chapter must be after joined chapter".into()))}c.execute("UPDATE faction_memberships SET left_chapter=?,updated_at=? WHERE id=?",params![ch,Utc::now().to_rfc3339(),id]).map_err(|e|FactionError::Database(e.to_string()))?;Ok(())}
fn relations_at(&self,ch:u32)->Result<Vec<FactionRelationState>,FactionError>{let c=self.conn.lock().map_err(|e|FactionError::Database(e.to_string()))?;let mut s=c.prepare("SELECT r.id,r.faction_a_id,a.name,r.faction_b_id,b.name,r.relation_type,r.valid_from_chapter,r.valid_to_chapter,r.notes FROM faction_relationship_states r JOIN factions a ON a.id=r.faction_a_id JOIN factions b ON b.id=r.faction_b_id WHERE r.valid_from_chapter<=? AND (r.valid_to_chapter IS NULL OR r.valid_to_chapter>?) ORDER BY a.name,b.name").map_err(|e|FactionError::Database(e.to_string()))?;let rows=s.query_map(params![ch,ch],|r|Ok(FactionRelationState{id:r.get(0)?,faction_a_id:r.get(1)?,faction_a_name:r.get(2)?,faction_b_id:r.get(3)?,faction_b_name:r.get(4)?,relation_type:r.get(5)?,valid_from_chapter:u32::try_from(r.get::<_,i64>(6)?).unwrap_or(1),valid_to_chapter:r.get::<_,Option<i64>>(7)?.and_then(|v|u32::try_from(v).ok()),notes:r.get(8)?})).map_err(|e|FactionError::Database(e.to_string()))?;rows.map(|x|x.map_err(|e|FactionError::Database(e.to_string()))).collect()}
fn set_relation(&self,i:SetFactionRelationInput)->Result<FactionRelationState,FactionError>{if i.chapter==0||i.faction_a_id==i.faction_b_id{return Err(FactionError::Validation("two distinct factions and a positive chapter are required".into()))}if !valid_relation(&i.relation_type){return Err(FactionError::Validation("invalid faction relation".into()))}let(a,b)=if i.faction_a_id<i.faction_b_id{(i.faction_a_id,i.faction_b_id)}else{(i.faction_b_id,i.faction_a_id)};let mut c=self.conn.lock().map_err(|e|FactionError::Database(e.to_string()))?;let tx=c.transaction().map_err(|e|FactionError::Database(e.to_string()))?;let current:Option<(String,i64)>=tx.query_row("SELECT id,valid_from_chapter FROM faction_relationship_states WHERE faction_a_id=? AND faction_b_id=? AND valid_to_chapter IS NULL",params![a,b],|r|Ok((r.get(0)?,r.get(1)?))).optional().map_err(|e|FactionError::Database(e.to_string()))?;if let Some((id,start))=current{if i64::from(i.chapter)<=start{return Err(FactionError::Validation("relation change chapter must be after current state start".into()))}tx.execute("UPDATE faction_relationship_states SET valid_to_chapter=? WHERE id=?",params![i.chapter,id]).map_err(|e|FactionError::Database(e.to_string()))?;}let id=Uuid::new_v4().to_string();tx.execute("INSERT INTO faction_relationship_states(id,faction_a_id,faction_b_id,relation_type,valid_from_chapter,notes,created_at) VALUES(?,?,?,?,?,?,?)",params![id,a,b,i.relation_type,i.chapter,i.notes.unwrap_or_default(),Utc::now().to_rfc3339()]).map_err(|e|FactionError::Database(e.to_string()))?;tx.commit().map_err(|e|FactionError::Database(e.to_string()))?;drop(c);self.relations_at(i.chapter)?.into_iter().find(|x|x.id==id).ok_or_else(||FactionError::NotFound(id))}
}

use crate::factions::domain::{hierarchy::*, hierarchy_repository::FactionHierarchyRepository};

fn valid_lineage_kind(value: &str) -> bool {
    matches!(value, "family" | "dynasty" | "bloodline" | "house")
}

impl FactionHierarchyRepository for SqliteFactionRepository {
    fn hierarchy_roles(&self, faction_id: &str) -> Result<Vec<HierarchyRole>, FactionError> {
        let c = self.conn.lock().map_err(|e| FactionError::Database(e.to_string()))?;
        let mut s = c.prepare(
            "SELECT id,faction_id,name,parent_role_id,tier,capacity,color,sort_order FROM faction_hierarchy_roles WHERE faction_id=? ORDER BY tier,sort_order,name COLLATE NOCASE"
        ).map_err(|e| FactionError::Database(e.to_string()))?;
        let rows = s.query_map(params![faction_id], |r| {
            Ok(HierarchyRole {
                id: r.get(0)?, faction_id: r.get(1)?, name: r.get(2)?, parent_role_id: r.get(3)?,
                tier: u32::try_from(r.get::<_, i64>(4)?).unwrap_or(1),
                capacity: r.get::<_, Option<i64>>(5)?.and_then(|v| u32::try_from(v).ok()),
                color: r.get(6)?, sort_order: r.get(7)?,
            })
        }).map_err(|e| FactionError::Database(e.to_string()))?;
        rows.map(|x| x.map_err(|e| FactionError::Database(e.to_string()))).collect()
    }

    fn create_hierarchy_role(&self, input: UpsertHierarchyRoleInput) -> Result<HierarchyRole, FactionError> {
        if input.name.trim().is_empty() { return Err(FactionError::Validation("role name is required".into())); }
        if input.tier == 0 { return Err(FactionError::Validation("role tier must be positive".into())); }
        if input.capacity == Some(0) { return Err(FactionError::Validation("role capacity must be positive".into())); }
        let id = Uuid::new_v4().to_string(); let now = Utc::now().to_rfc3339();
        let c = self.conn.lock().map_err(|e| FactionError::Database(e.to_string()))?;
        c.execute(
            "INSERT INTO faction_hierarchy_roles(id,faction_id,name,parent_role_id,tier,capacity,color,sort_order,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
            params![id,input.faction_id,input.name.trim(),input.parent_role_id,input.tier,input.capacity,input.color.unwrap_or_else(||"#8b7cf6".into()),input.sort_order,now,now]
        ).map_err(|e| FactionError::Database(e.to_string()))?;
        drop(c);
        self.hierarchy_roles(&input.faction_id)?.into_iter().find(|r| r.id == id).ok_or_else(|| FactionError::NotFound(id))
    }

    fn update_hierarchy_role(&self, id: &str, input: UpsertHierarchyRoleInput) -> Result<HierarchyRole, FactionError> {
        if input.name.trim().is_empty() || input.tier == 0 || input.capacity == Some(0) { return Err(FactionError::Validation("valid role name, tier and capacity are required".into())); }
        if input.parent_role_id.as_deref() == Some(id) { return Err(FactionError::Validation("a role cannot be its own parent".into())); }
        let c = self.conn.lock().map_err(|e| FactionError::Database(e.to_string()))?;
        if let Some(cap) = input.capacity {
            let open: i64 = c.query_row("SELECT COUNT(*) FROM faction_role_assignments WHERE role_id=? AND valid_to_chapter IS NULL",params![id],|r|r.get(0)).map_err(|e|FactionError::Database(e.to_string()))?;
            if open > i64::from(cap) { return Err(FactionError::Validation("capacity cannot be lower than current occupants".into())); }
        }
        let n = c.execute("UPDATE faction_hierarchy_roles SET name=?,parent_role_id=?,tier=?,capacity=?,color=?,sort_order=?,updated_at=? WHERE id=? AND faction_id=?",
            params![input.name.trim(),input.parent_role_id,input.tier,input.capacity,input.color.unwrap_or_else(||"#8b7cf6".into()),input.sort_order,Utc::now().to_rfc3339(),id,input.faction_id]
        ).map_err(|e| FactionError::Database(e.to_string()))?;
        drop(c);
        if n == 0 { return Err(FactionError::NotFound(id.into())); }
        self.hierarchy_roles(&input.faction_id)?.into_iter().find(|r|r.id==id).ok_or_else(||FactionError::NotFound(id.into()))
    }

    fn delete_hierarchy_role(&self, id: &str) -> Result<(), FactionError> {
        let c = self.conn.lock().map_err(|e| FactionError::Database(e.to_string()))?;
        let n = c.execute("DELETE FROM faction_hierarchy_roles WHERE id=?", params![id]).map_err(|e| FactionError::Database(e.to_string()))?;
        if n == 0 { Err(FactionError::NotFound(id.into())) } else { Ok(()) }
    }

    fn seed_default_hierarchy(&self, faction_id: &str) -> Result<Vec<HierarchyRole>, FactionError> {
        let existing = self.hierarchy_roles(faction_id)?;
        if !existing.is_empty() { return Ok(existing); }
        let kind = {
            let c = self.conn.lock().map_err(|e| FactionError::Database(e.to_string()))?;
            c.query_row("SELECT kind FROM factions WHERE id=?",params![faction_id],|r|r.get::<_,String>(0)).optional().map_err(|e|FactionError::Database(e.to_string()))?.ok_or_else(||FactionError::NotFound(faction_id.into()))?
        };
        let defs: Vec<(&str, Option<&str>, u32, Option<u32>, i32, &str)> = match kind.as_str() {
            "clan" => vec![
                ("Clan Leader",None,1,Some(1),10,"#c9a35a"),("Vice Leader",Some("Clan Leader"),2,Some(1),20,"#9b8cff"),("Grand Elder",Some("Clan Leader"),2,Some(1),30,"#d2b56f"),("Elder",Some("Grand Elder"),3,None,40,"#a28ccf"),("Elite Captain",Some("Vice Leader"),3,None,50,"#6fa8dc"),("Captain",Some("Elite Captain"),4,None,60,"#65b9a6"),("Member",Some("Captain"),5,None,70,"#7f8898")
            ],
            "kingdom" => vec![
                ("Monarch",None,1,Some(1),10,"#c9a35a"),("Prime Minister",Some("Monarch"),2,Some(1),20,"#9b8cff"),("Grand Marshal",Some("Monarch"),2,Some(1),30,"#d46f6f"),("Royal Council",Some("Monarch"),2,None,40,"#a28ccf"),("Minister",Some("Prime Minister"),3,None,50,"#6fa8dc"),("Governor",Some("Prime Minister"),3,None,60,"#65b9a6"),("General",Some("Grand Marshal"),3,None,70,"#d88b5f"),("Officer",Some("General"),4,None,80,"#7f8898")
            ],
            "guild" => vec![
                ("Guild Master",None,1,Some(1),10,"#c9a35a"),("Vice Master",Some("Guild Master"),2,Some(1),20,"#9b8cff"),("Officer",Some("Vice Master"),3,None,30,"#6fa8dc"),("Elite Member",Some("Officer"),4,None,40,"#65b9a6"),("Member",Some("Elite Member"),5,None,50,"#7f8898"),("Recruit",Some("Member"),6,None,60,"#687080")
            ],
            "order" => vec![
                ("Grand Master",None,1,Some(1),10,"#c9a35a"),("Deputy Master",Some("Grand Master"),2,Some(1),20,"#9b8cff"),("Commander",Some("Deputy Master"),3,None,30,"#d46f6f"),("Captain",Some("Commander"),4,None,40,"#6fa8dc"),("Knight",Some("Captain"),5,None,50,"#65b9a6"),("Initiate",Some("Knight"),6,None,60,"#7f8898")
            ],
            "house" => vec![
                ("House Head",None,1,Some(1),10,"#c9a35a"),("Heir",Some("House Head"),2,Some(1),20,"#d2b56f"),("Steward",Some("House Head"),2,Some(1),30,"#9b8cff"),("Retainer",Some("Steward"),3,None,40,"#6fa8dc"),("House Member",Some("House Head"),3,None,50,"#7f8898")
            ],
            _ => vec![
                ("Leader",None,1,Some(1),10,"#c9a35a"),("Deputy Leader",Some("Leader"),2,Some(1),20,"#9b8cff"),("Commander",Some("Deputy Leader"),3,None,30,"#d46f6f"),("Officer",Some("Commander"),4,None,40,"#6fa8dc"),("Member",Some("Officer"),5,None,50,"#7f8898")
            ],
        };
        let mut by_name = std::collections::HashMap::<String,String>::new();
        for (name,parent,tier,capacity,sort_order,color) in defs {
            let parent_role_id = parent.and_then(|p|by_name.get(p).cloned());
            let role = self.create_hierarchy_role(UpsertHierarchyRoleInput{faction_id:faction_id.into(),name:name.into(),parent_role_id,tier,capacity,color:Some(color.into()),sort_order})?;
            by_name.insert(name.into(), role.id);
        }
        self.hierarchy_roles(faction_id)
    }

    fn role_assignments(&self, faction_id: &str, chapter: u32) -> Result<Vec<RoleAssignment>, FactionError> {
        if chapter == 0 { return Err(FactionError::Validation("chapter must be positive".into())); }
        let c = self.conn.lock().map_err(|e| FactionError::Database(e.to_string()))?;
        let mut s = c.prepare("SELECT a.id,r.faction_id,a.role_id,r.name,a.character_id,c.name,a.valid_from_chapter,a.valid_to_chapter,a.title_override,a.notes FROM faction_role_assignments a JOIN faction_hierarchy_roles r ON r.id=a.role_id JOIN characters c ON c.id=a.character_id WHERE r.faction_id=? AND a.valid_from_chapter<=? AND (a.valid_to_chapter IS NULL OR a.valid_to_chapter>?) ORDER BY r.tier,r.sort_order,c.name COLLATE NOCASE").map_err(|e|FactionError::Database(e.to_string()))?;
        let rows=s.query_map(params![faction_id,chapter,chapter],|r|Ok(RoleAssignment{id:r.get(0)?,faction_id:r.get(1)?,role_id:r.get(2)?,role_name:r.get(3)?,character_id:r.get(4)?,character_name:r.get(5)?,valid_from_chapter:u32::try_from(r.get::<_,i64>(6)?).unwrap_or(1),valid_to_chapter:r.get::<_,Option<i64>>(7)?.and_then(|v|u32::try_from(v).ok()),title_override:r.get(8)?,notes:r.get(9)?})).map_err(|e|FactionError::Database(e.to_string()))?;
        rows.map(|x|x.map_err(|e|FactionError::Database(e.to_string()))).collect()
    }

    fn assign_role(&self, input: AssignRoleInput) -> Result<RoleAssignment, FactionError> {
        if input.valid_from_chapter == 0 { return Err(FactionError::Validation("assignment chapter must be positive".into())); }
        let id=Uuid::new_v4().to_string();let now=Utc::now().to_rfc3339();
        let faction_id = {
            let c=self.conn.lock().map_err(|e|FactionError::Database(e.to_string()))?;
            c.query_row("SELECT faction_id FROM faction_hierarchy_roles WHERE id=?",params![input.role_id],|r|r.get::<_,String>(0)).optional().map_err(|e|FactionError::Database(e.to_string()))?.ok_or_else(||FactionError::NotFound(input.role_id.clone()))?
        };
        let c=self.conn.lock().map_err(|e|FactionError::Database(e.to_string()))?;
        c.execute("INSERT INTO faction_role_assignments(id,role_id,character_id,valid_from_chapter,title_override,notes,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)",params![id,input.role_id,input.character_id,input.valid_from_chapter,input.title_override.unwrap_or_default(),input.notes.unwrap_or_default(),now,now]).map_err(|e|FactionError::Database(e.to_string()))?;
        drop(c);
        self.role_assignments(&faction_id,input.valid_from_chapter)?.into_iter().find(|a|a.id==id).ok_or_else(||FactionError::NotFound(id))
    }

    fn end_role_assignment(&self, id: &str, chapter: u32) -> Result<(), FactionError> {
        let c=self.conn.lock().map_err(|e|FactionError::Database(e.to_string()))?;
        let start:Option<i64>=c.query_row("SELECT valid_from_chapter FROM faction_role_assignments WHERE id=? AND valid_to_chapter IS NULL",params![id],|r|r.get(0)).optional().map_err(|e|FactionError::Database(e.to_string()))?;
        let Some(start)=start else{return Err(FactionError::NotFound(id.into()))};
        if i64::from(chapter)<=start{return Err(FactionError::Validation("end chapter must be after assignment start".into()))}
        c.execute("UPDATE faction_role_assignments SET valid_to_chapter=?,updated_at=? WHERE id=?",params![chapter,Utc::now().to_rfc3339(),id]).map_err(|e|FactionError::Database(e.to_string()))?;Ok(())
    }

    fn lineages(&self, affiliated_faction_id: Option<&str>) -> Result<Vec<Lineage>, FactionError> {
        let c=self.conn.lock().map_err(|e|FactionError::Database(e.to_string()))?;
        let mut sql=String::from("SELECT l.id,l.name,l.kind,l.description,l.color,l.tags,l.affiliated_faction_id,f.name,COUNT(m.id) FROM lineages l LEFT JOIN factions f ON f.id=l.affiliated_faction_id LEFT JOIN lineage_memberships m ON m.lineage_id=l.id AND m.left_chapter IS NULL");
        if affiliated_faction_id.is_some(){sql.push_str(" WHERE l.affiliated_faction_id=?");}
        sql.push_str(" GROUP BY l.id ORDER BY l.name COLLATE NOCASE");
        let mut s=c.prepare(&sql).map_err(|e|FactionError::Database(e.to_string()))?;
        let map=|r:&rusqlite::Row<'_>|->rusqlite::Result<(String,String,String,String,String,String,Option<String>,Option<String>,i64)>{Ok((r.get(0)?,r.get(1)?,r.get(2)?,r.get(3)?,r.get(4)?,r.get(5)?,r.get(6)?,r.get(7)?,r.get(8)?))};
        let mut out=Vec::new();
        if let Some(fid)=affiliated_faction_id { let rows=s.query_map(params![fid],map).map_err(|e|FactionError::Database(e.to_string()))?;for row in rows{let x=row.map_err(|e|FactionError::Database(e.to_string()))?;out.push(Lineage{id:x.0,name:x.1,kind:x.2,description:x.3,color:x.4,tags:serde_json::from_str(&x.5).map_err(|e|FactionError::Mapping(e.to_string()))?,affiliated_faction_id:x.6,affiliated_faction_name:x.7,member_count:u32::try_from(x.8).unwrap_or(0)});}}
        else { let rows=s.query_map([],map).map_err(|e|FactionError::Database(e.to_string()))?;for row in rows{let x=row.map_err(|e|FactionError::Database(e.to_string()))?;out.push(Lineage{id:x.0,name:x.1,kind:x.2,description:x.3,color:x.4,tags:serde_json::from_str(&x.5).map_err(|e|FactionError::Mapping(e.to_string()))?,affiliated_faction_id:x.6,affiliated_faction_name:x.7,member_count:u32::try_from(x.8).unwrap_or(0)});}}
        Ok(out)
    }

    fn create_lineage(&self, input: UpsertLineageInput) -> Result<Lineage, FactionError> {
        if input.name.trim().is_empty()||!valid_lineage_kind(&input.kind){return Err(FactionError::Validation("valid lineage name and kind are required".into()))}
        let id=Uuid::new_v4().to_string();let now=Utc::now().to_rfc3339();let tags=serde_json::to_string(&input.tags).map_err(|e|FactionError::Mapping(e.to_string()))?;
        let c=self.conn.lock().map_err(|e|FactionError::Database(e.to_string()))?;c.execute("INSERT INTO lineages(id,name,kind,description,color,tags,affiliated_faction_id,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)",params![id,input.name.trim(),input.kind,input.description.unwrap_or_default(),input.color.unwrap_or_else(||"#c9a35a".into()),tags,input.affiliated_faction_id,now,now]).map_err(|e|FactionError::Database(e.to_string()))?;drop(c);
        self.lineages(None)?.into_iter().find(|x|x.id==id).ok_or_else(||FactionError::NotFound(id))
    }

    fn update_lineage(&self, id:&str, input:UpsertLineageInput)->Result<Lineage,FactionError>{
        if input.name.trim().is_empty()||!valid_lineage_kind(&input.kind){return Err(FactionError::Validation("valid lineage name and kind are required".into()))}
        let tags=serde_json::to_string(&input.tags).map_err(|e|FactionError::Mapping(e.to_string()))?;let c=self.conn.lock().map_err(|e|FactionError::Database(e.to_string()))?;let n=c.execute("UPDATE lineages SET name=?,kind=?,description=?,color=?,tags=?,affiliated_faction_id=?,updated_at=? WHERE id=?",params![input.name.trim(),input.kind,input.description.unwrap_or_default(),input.color.unwrap_or_else(||"#c9a35a".into()),tags,input.affiliated_faction_id,Utc::now().to_rfc3339(),id]).map_err(|e|FactionError::Database(e.to_string()))?;drop(c);if n==0{return Err(FactionError::NotFound(id.into()))}self.lineages(None)?.into_iter().find(|x|x.id==id).ok_or_else(||FactionError::NotFound(id.into()))
    }

    fn delete_lineage(&self,id:&str)->Result<(),FactionError>{let c=self.conn.lock().map_err(|e|FactionError::Database(e.to_string()))?;let n=c.execute("DELETE FROM lineages WHERE id=?",params![id]).map_err(|e|FactionError::Database(e.to_string()))?;if n==0{Err(FactionError::NotFound(id.into()))}else{Ok(())}}

    fn lineage_memberships(&self,lineage_id:&str,chapter:u32)->Result<Vec<LineageMembership>,FactionError>{if chapter==0{return Err(FactionError::Validation("chapter must be positive".into()))}let c=self.conn.lock().map_err(|e|FactionError::Database(e.to_string()))?;let mut s=c.prepare("SELECT m.id,m.lineage_id,l.name,m.character_id,c.name,m.branch_label,m.title,m.joined_chapter,m.left_chapter FROM lineage_memberships m JOIN lineages l ON l.id=m.lineage_id JOIN characters c ON c.id=m.character_id WHERE m.lineage_id=? AND m.joined_chapter<=? AND (m.left_chapter IS NULL OR m.left_chapter>?) ORDER BY c.name COLLATE NOCASE").map_err(|e|FactionError::Database(e.to_string()))?;let rows=s.query_map(params![lineage_id,chapter,chapter],|r|Ok(LineageMembership{id:r.get(0)?,lineage_id:r.get(1)?,lineage_name:r.get(2)?,character_id:r.get(3)?,character_name:r.get(4)?,branch_label:r.get(5)?,title:r.get(6)?,joined_chapter:u32::try_from(r.get::<_,i64>(7)?).unwrap_or(1),left_chapter:r.get::<_,Option<i64>>(8)?.and_then(|v|u32::try_from(v).ok())})).map_err(|e|FactionError::Database(e.to_string()))?;rows.map(|x|x.map_err(|e|FactionError::Database(e.to_string()))).collect()}

    fn add_lineage_membership(&self,input:AddLineageMembershipInput)->Result<LineageMembership,FactionError>{if input.joined_chapter==0{return Err(FactionError::Validation("joined chapter must be positive".into()))}let id=Uuid::new_v4().to_string();let now=Utc::now().to_rfc3339();let c=self.conn.lock().map_err(|e|FactionError::Database(e.to_string()))?;c.execute("INSERT INTO lineage_memberships(id,lineage_id,character_id,branch_label,title,joined_chapter,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)",params![id,input.lineage_id,input.character_id,input.branch_label.unwrap_or_default(),input.title.unwrap_or_default(),input.joined_chapter,now,now]).map_err(|e|FactionError::Database(e.to_string()))?;drop(c);self.lineage_memberships(&input.lineage_id,input.joined_chapter)?.into_iter().find(|x|x.id==id).ok_or_else(||FactionError::NotFound(id))}

    fn end_lineage_membership(&self,id:&str,chapter:u32)->Result<(),FactionError>{let c=self.conn.lock().map_err(|e|FactionError::Database(e.to_string()))?;let start:Option<i64>=c.query_row("SELECT joined_chapter FROM lineage_memberships WHERE id=? AND left_chapter IS NULL",params![id],|r|r.get(0)).optional().map_err(|e|FactionError::Database(e.to_string()))?;let Some(start)=start else{return Err(FactionError::NotFound(id.into()))};if i64::from(chapter)<=start{return Err(FactionError::Validation("end chapter must be after lineage membership start".into()))}c.execute("UPDATE lineage_memberships SET left_chapter=?,updated_at=? WHERE id=?",params![chapter,Utc::now().to_rfc3339(),id]).map_err(|e|FactionError::Database(e.to_string()))?;Ok(())}
}
