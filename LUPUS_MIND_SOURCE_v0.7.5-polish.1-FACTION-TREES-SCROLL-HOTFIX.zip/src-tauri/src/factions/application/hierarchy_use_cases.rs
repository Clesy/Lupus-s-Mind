use crate::factions::domain::{
    error::FactionError,
    hierarchy::*,
    hierarchy_repository::FactionHierarchyRepository,
};

pub fn roles(r:&impl FactionHierarchyRepository,faction_id:&str)->Result<Vec<HierarchyRole>,FactionError>{r.hierarchy_roles(faction_id)}
pub fn create_role(r:&impl FactionHierarchyRepository,input:UpsertHierarchyRoleInput)->Result<HierarchyRole,FactionError>{r.create_hierarchy_role(input)}
pub fn update_role(r:&impl FactionHierarchyRepository,id:&str,input:UpsertHierarchyRoleInput)->Result<HierarchyRole,FactionError>{r.update_hierarchy_role(id,input)}
pub fn delete_role(r:&impl FactionHierarchyRepository,id:&str)->Result<(),FactionError>{r.delete_hierarchy_role(id)}
pub fn seed_defaults(r:&impl FactionHierarchyRepository,faction_id:&str)->Result<Vec<HierarchyRole>,FactionError>{r.seed_default_hierarchy(faction_id)}
pub fn assignments(r:&impl FactionHierarchyRepository,faction_id:&str,chapter:u32)->Result<Vec<RoleAssignment>,FactionError>{r.role_assignments(faction_id,chapter)}
pub fn assign(r:&impl FactionHierarchyRepository,input:AssignRoleInput)->Result<RoleAssignment,FactionError>{r.assign_role(input)}
pub fn end_assignment(r:&impl FactionHierarchyRepository,id:&str,chapter:u32)->Result<(),FactionError>{r.end_role_assignment(id,chapter)}
pub fn lineages(r:&impl FactionHierarchyRepository,faction_id:Option<&str>)->Result<Vec<Lineage>,FactionError>{r.lineages(faction_id)}
pub fn create_lineage(r:&impl FactionHierarchyRepository,input:UpsertLineageInput)->Result<Lineage,FactionError>{r.create_lineage(input)}
pub fn update_lineage(r:&impl FactionHierarchyRepository,id:&str,input:UpsertLineageInput)->Result<Lineage,FactionError>{r.update_lineage(id,input)}
pub fn delete_lineage(r:&impl FactionHierarchyRepository,id:&str)->Result<(),FactionError>{r.delete_lineage(id)}
pub fn lineage_memberships(r:&impl FactionHierarchyRepository,lineage_id:&str,chapter:u32)->Result<Vec<LineageMembership>,FactionError>{r.lineage_memberships(lineage_id,chapter)}
pub fn add_lineage_member(r:&impl FactionHierarchyRepository,input:AddLineageMembershipInput)->Result<LineageMembership,FactionError>{r.add_lineage_membership(input)}
pub fn end_lineage_member(r:&impl FactionHierarchyRepository,id:&str,chapter:u32)->Result<(),FactionError>{r.end_lineage_membership(id,chapter)}
