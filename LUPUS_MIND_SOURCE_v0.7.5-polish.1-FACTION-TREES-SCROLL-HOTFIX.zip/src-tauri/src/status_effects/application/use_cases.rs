use serde::Serialize;
use crate::skills::domain::{repository::SkillRepository,skill::SkillId};
use super::super::domain::{error::StatusEffectError,repository::{SkillStatusEffectRepository,StatusEffectDefinitionRepository},status_effect::{StatusEffectDefinition,StatusEffectDefinitionId}};

#[derive(Debug,Clone,Serialize)]
#[serde(rename_all="camelCase")]
pub struct StatusEffectDefinitionDto {
    pub id:String,pub effect_key:String,pub name:String,pub kind:crate::status_effects::domain::status_effect::StatusEffectKind,pub stacking_policy:crate::status_effects::domain::status_effect::StackingPolicy,pub duration_turns:u32,pub power:f64,pub modifier:Option<crate::status_effects::domain::status_effect::StatusModifierSpec>
}
fn dto(d:StatusEffectDefinition)->StatusEffectDefinitionDto{StatusEffectDefinitionDto{id:d.id.0,effect_key:d.effect_key,name:d.name,kind:d.kind,stacking_policy:d.stacking_policy,duration_turns:d.duration_turns,power:d.power,modifier:d.modifier}}

pub fn list(repo:&dyn StatusEffectDefinitionRepository)->Result<Vec<StatusEffectDefinitionDto>,StatusEffectError>{Ok(repo.list()?.into_iter().map(dto).collect())}
pub fn for_skill(repo:&dyn StatusEffectDefinitionRepository,skill_id:String)->Result<Vec<StatusEffectDefinitionDto>,StatusEffectError>{Ok(repo.list_for_skill(&SkillId(skill_id))?.into_iter().map(dto).collect())}
pub fn set_for_skill(skills:&dyn SkillRepository,assignments:&dyn SkillStatusEffectRepository,definitions:&dyn StatusEffectDefinitionRepository,skill_id:String,effect_ids:Vec<String>)->Result<(),StatusEffectError>{
    let skill=SkillId(skill_id.clone());
    if skills.get(&skill).map_err(|e|StatusEffectError::Database(e.to_string()))?.is_none(){return Err(StatusEffectError::SkillNotFound(skill_id));}
    let mut seen=std::collections::HashSet::new();let mut typed=Vec::new();
    for id in effect_ids{if !seen.insert(id.clone()){return Err(StatusEffectError::Validation(format!("duplicate status effect: {id}")));}let typed_id=StatusEffectDefinitionId(id.clone());if definitions.get(&typed_id)?.is_none(){return Err(StatusEffectError::NotFound(id));}typed.push(typed_id);}
    assignments.replace_skill_effects(&skill,&typed)
}
