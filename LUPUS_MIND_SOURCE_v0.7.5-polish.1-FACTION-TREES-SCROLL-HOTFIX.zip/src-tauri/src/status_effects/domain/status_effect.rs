use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct StatusEffectDefinitionId(pub String);

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum StatusEffectKind { DamageOverTime, HealOverTime, Stun, StatModifier }
impl StatusEffectKind {
    pub fn from_db(value:&str)->Option<Self>{Some(match value{"damage_over_time"=>Self::DamageOverTime,"heal_over_time"=>Self::HealOverTime,"stun"=>Self::Stun,"stat_modifier"=>Self::StatModifier,_=>return None})}
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum StackingPolicy { Refresh }
impl StackingPolicy { pub fn from_db(value:&str)->Option<Self>{Some(match value{"refresh"=>Self::Refresh,_=>return None})} }

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum StatusModifierKind { ArmorMultiplier, DamageMultiplier }
impl StatusModifierKind { pub fn from_db(value:&str)->Option<Self>{Some(match value{"armor_multiplier"=>Self::ArmorMultiplier,"damage_multiplier"=>Self::DamageMultiplier,_=>return None})} }

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct StatusModifierSpec { pub kind: StatusModifierKind, pub multiplier: f64 }

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct StatusEffectDefinition {
    pub id: StatusEffectDefinitionId,
    pub effect_key: String,
    pub name: String,
    pub kind: StatusEffectKind,
    pub stacking_policy: StackingPolicy,
    pub duration_turns: u32,
    pub power: f64,
    pub modifier: Option<StatusModifierSpec>,
    pub created_at: DateTime<Utc>,
}
