use crate::skills::domain::skill::SkillId;
use super::{error::StatusEffectError,status_effect::{StatusEffectDefinition,StatusEffectDefinitionId}};

pub trait StatusEffectDefinitionRepository: Send + Sync {
    fn list(&self)->Result<Vec<StatusEffectDefinition>,StatusEffectError>;
    fn get(&self,id:&StatusEffectDefinitionId)->Result<Option<StatusEffectDefinition>,StatusEffectError>;
    fn list_for_skill(&self,skill:&SkillId)->Result<Vec<StatusEffectDefinition>,StatusEffectError>;
}

pub trait SkillStatusEffectRepository: Send + Sync {
    fn effect_ids_for_skill(&self,skill:&SkillId)->Result<Vec<StatusEffectDefinitionId>,StatusEffectError>;
    fn replace_skill_effects(&self,skill:&SkillId,effects:&[StatusEffectDefinitionId])->Result<(),StatusEffectError>;
}
