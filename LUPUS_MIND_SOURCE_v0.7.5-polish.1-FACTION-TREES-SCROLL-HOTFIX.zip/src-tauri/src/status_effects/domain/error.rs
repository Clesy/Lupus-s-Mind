use serde::Serialize;
use thiserror::Error;
#[derive(Debug, Error, Serialize)]
#[serde(tag="kind",content="detail",rename_all="snake_case")]
pub enum StatusEffectError {
    #[error("Status effect definition not found: {0}")] NotFound(String),
    #[error("Skill not found: {0}")] SkillNotFound(String),
    #[error("Validation error: {0}")] Validation(String),
    #[error("Mapping error: {0}")] Mapping(String),
    #[error("Database error: {0}")] Database(String),
}
