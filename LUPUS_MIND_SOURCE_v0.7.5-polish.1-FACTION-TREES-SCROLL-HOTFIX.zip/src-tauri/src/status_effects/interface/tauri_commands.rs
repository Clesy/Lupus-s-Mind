use tauri::State;
use crate::{app_state::AppState,shared::api_error::ApiError,status_effects::{application::use_cases::{self,StatusEffectDefinitionDto},domain::error::StatusEffectError}};
fn api(e:StatusEffectError)->ApiError{ApiError{code:"status_effect_error".into(),message:e.to_string()}}
#[tauri::command]pub fn status_effects_list(state:State<'_,AppState>)->Result<Vec<StatusEffectDefinitionDto>,ApiError>{use_cases::list(&state.status_effects).map_err(api)}
#[tauri::command]pub fn status_effects_for_skill(state:State<'_,AppState>,skill_id:String)->Result<Vec<StatusEffectDefinitionDto>,ApiError>{use_cases::for_skill(&state.status_effects,skill_id).map_err(api)}
#[tauri::command]pub fn status_effects_set_for_skill(state:State<'_,AppState>,skill_id:String,effect_ids:Vec<String>)->Result<(),ApiError>{use_cases::set_for_skill(&state.skills,&state.status_effects,&state.status_effects,skill_id,effect_ids).map_err(api)}
