use serde::Serialize;
use crate::{
    characters::domain::{character::{CharacterId,CharacterStats},error::CharacterError,repository::CharacterRepository},
    equipment::domain::{equipment::EquipmentSlot,error::EquipmentError,repository::EquipmentRepository},
    items::domain::{item::{Item,ItemId,ItemRarity,ItemType,StatKey,StatModifier},repository::ItemRepository},
};
#[derive(Debug,Default,Serialize,PartialEq)]
#[serde(rename_all="camelCase")]
pub struct EffectiveStats{pub strength:f64,pub agility:f64,pub vitality:f64,pub intelligence:f64,pub mind:f64,pub weapon_damage:f64,pub armor:f64,pub armor_penetration:f64,pub magic_penetration:f64,pub critical_chance:f64,pub damage_reduction:f64}
#[derive(Debug,Serialize)]
#[serde(rename_all="camelCase")]
pub struct ItemSnapshotDto{pub id:String,pub name:String,pub description:String,pub item_type:ItemType,pub rarity:ItemRarity,pub modifiers:Vec<StatModifier>,pub tags:Vec<String>,pub created_at:String,pub updated_at:String}
impl From<Item> for ItemSnapshotDto{fn from(i:Item)->Self{Self{id:i.id.0,name:i.name,description:i.description,item_type:i.item_type,rarity:i.rarity,modifiers:i.modifiers,tags:i.tags,created_at:i.created_at.to_rfc3339(),updated_at:i.updated_at.to_rfc3339()}}}
#[derive(Debug,Serialize)]
#[serde(rename_all="camelCase")]
pub struct EquippedItemDto{pub slot:EquipmentSlot,pub item:ItemSnapshotDto}
#[derive(Debug,Serialize)]
#[serde(rename_all="camelCase")]
pub struct CharacterSheetDto{pub character_id:String,pub name:String,pub base_stats:CharacterStats,pub effective_stats:EffectiveStats,pub equipment:Vec<EquippedItemDto>}
#[derive(Debug,thiserror::Error)]
pub enum SheetError{#[error(transparent)]Character(#[from]CharacterError),#[error(transparent)]Equipment(#[from]EquipmentError),#[error("Item missing from equipment relation: {0}")]MissingItem(String),#[error("Item error: {0}")]Item(String)}
pub fn get_sheet(characters:&dyn CharacterRepository,items:&dyn ItemRepository,equipment:&dyn EquipmentRepository,id:String)->Result<CharacterSheetDto,SheetError>{
 let c=characters.get(&CharacterId(id.clone()))?.ok_or(CharacterError::NotFound(id))?;
 let mut eff=EffectiveStats{strength:c.base_stats.str as f64,agility:c.base_stats.agi as f64,vitality:c.base_stats.vit as f64,intelligence:c.base_stats.int as f64,mind:c.base_stats.mnd as f64,..Default::default()};
 let mut equipped=Vec::new();
 for e in equipment.list_for_character(&c.id)?{
   let item=items.get(&ItemId(e.item_id.0.clone())).map_err(|x|SheetError::Item(x.to_string()))?.ok_or_else(||SheetError::MissingItem(e.item_id.0.clone()))?;
   for m in &item.modifiers{match m.stat{StatKey::Strength=>eff.strength+=m.value,StatKey::Agility=>eff.agility+=m.value,StatKey::Vitality=>eff.vitality+=m.value,StatKey::Intelligence=>eff.intelligence+=m.value,StatKey::Mind=>eff.mind+=m.value,StatKey::WeaponDamage=>eff.weapon_damage+=m.value,StatKey::Armor=>eff.armor+=m.value,StatKey::ArmorPenetration=>eff.armor_penetration+=m.value,StatKey::MagicPenetration=>eff.magic_penetration+=m.value,StatKey::CriticalChance=>eff.critical_chance+=m.value,StatKey::DamageReduction=>eff.damage_reduction+=m.value}}
   equipped.push(EquippedItemDto{slot:e.slot,item:item.into()});
 }
 Ok(CharacterSheetDto{character_id:c.id.0,name:c.name,base_stats:c.base_stats,effective_stats:eff,equipment:equipped})
}
