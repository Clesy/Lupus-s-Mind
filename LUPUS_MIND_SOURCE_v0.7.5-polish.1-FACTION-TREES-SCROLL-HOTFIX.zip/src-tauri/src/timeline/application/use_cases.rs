use chrono::Utc;
use serde::{Deserialize,Serialize};
use uuid::Uuid;
use crate::{
    characters::domain::{character::CharacterId,repository::CharacterRepository},
    timeline::domain::{
        error::TimelineError,
        repository::{TimelineRepository,TimelineSourceReferenceRepository},
        timeline::{EventImportance,EventParticipantRole,TemporalKind,TemporalPoint,TemporalSpan,TimelineAggregate,TimelineEvent,TimelineEventId,TimelineEventKind,TimelineParticipant,TimelineSourceKind,TimelineSourceLink},
    },
};

#[derive(Debug,Clone,Deserialize)]
#[serde(rename_all="camelCase")]
pub struct ParticipantInput { pub character_id:String,pub role:EventParticipantRole }
#[derive(Debug,Clone,Deserialize)]
#[serde(rename_all="camelCase")]
pub struct SourceInput { pub source_kind:TimelineSourceKind,pub source_id:String }
#[derive(Debug,Clone,Deserialize)]
#[serde(rename_all="camelCase")]
pub struct UpsertTimelineEventInput {
    pub title:String,pub description:Option<String>,pub kind:TimelineEventKind,pub importance:EventImportance,
    pub temporal_kind:TemporalKind,pub start_chapter:u32,pub end_chapter:Option<u32>,
    pub world_time_start:Option<String>,pub world_time_end:Option<String>,pub location_label:Option<String>,
    pub tags:Vec<String>,pub participants:Vec<ParticipantInput>,pub sources:Vec<SourceInput>,
}

#[derive(Debug,Clone,Serialize)]
#[serde(rename_all="camelCase")]
pub struct TimelineBoundsDto { pub start_chapter:u32,pub end_chapter:u32 }
#[derive(Debug,Clone,Serialize)]
#[serde(rename_all="camelCase")]
pub struct TimelineParticipantDto { pub character_id:String,pub role:EventParticipantRole }
#[derive(Debug,Clone,Serialize)]
#[serde(rename_all="camelCase")]
pub struct TimelineSourceDto { pub source_kind:TimelineSourceKind,pub source_id:String }
#[derive(Debug,Clone,Serialize)]
#[serde(rename_all="camelCase")]
pub struct TimelineEventDto {
    pub id:String,pub title:String,pub description:String,pub kind:TimelineEventKind,pub importance:EventImportance,
    pub temporal_kind:TemporalKind,pub start_chapter:u32,pub end_chapter:Option<u32>,
    pub world_time_start:Option<String>,pub world_time_end:Option<String>,pub location_label:Option<String>,
    pub tags:Vec<String>,pub participants:Vec<TimelineParticipantDto>,pub sources:Vec<TimelineSourceDto>,
    pub created_at:String,pub updated_at:String,
}

fn validate(input:&UpsertTimelineEventInput)->Result<(),TimelineError>{
    if input.title.trim().is_empty(){return Err(TimelineError::Validation("title is required".into()));}
    if input.start_chapter==0{return Err(TimelineError::Validation("start chapter must be > 0".into()));}
    match input.temporal_kind {
        TemporalKind::Point if input.end_chapter.is_some()=>return Err(TimelineError::Validation("point event cannot have end chapter".into())),
        TemporalKind::Span => match input.end_chapter { Some(end) if end>input.start_chapter=>{},_=>return Err(TimelineError::Validation("span end chapter must be greater than start chapter".into())) },
        _=>{}
    }
    let mut participant_keys=std::collections::HashSet::new();
    for p in &input.participants { if !participant_keys.insert((p.character_id.clone(),p.role.as_db())) { return Err(TimelineError::Validation("duplicate participant role".into())); } }
    let mut source_keys=std::collections::HashSet::new();
    for s in &input.sources { if s.source_id.trim().is_empty(){return Err(TimelineError::Validation("source id cannot be empty".into()));} if !source_keys.insert((s.source_kind.as_db(),s.source_id.clone())){return Err(TimelineError::Validation("duplicate source link".into()));} }
    Ok(())
}

fn validate_refs(characters:&dyn CharacterRepository,sources:&dyn TimelineSourceReferenceRepository,input:&UpsertTimelineEventInput)->Result<(),TimelineError>{
    for p in &input.participants { let id=CharacterId(p.character_id.clone()); if characters.get(&id).map_err(|e|TimelineError::Database(e.to_string()))?.is_none(){return Err(TimelineError::CharacterNotFound(p.character_id.clone()));} }
    for source in &input.sources { if source.source_kind==TimelineSourceKind::Manual {continue;} if !sources.source_exists(source.source_kind,&source.source_id)?{return Err(TimelineError::SourceNotFound(source.source_id.clone()));} }
    Ok(())
}

fn aggregate(id:TimelineEventId,created_at:chrono::DateTime<Utc>,input:UpsertTimelineEventInput)->TimelineAggregate{
    let now=Utc::now();
    let end=input.end_chapter.map(|chapter|TemporalPoint{chapter,world_time:input.world_time_end});
    TimelineAggregate{
        event:TimelineEvent{id,title:input.title.trim().to_string(),description:input.description.unwrap_or_default(),kind:input.kind,importance:input.importance,temporal_span:TemporalSpan{kind:input.temporal_kind,start:TemporalPoint{chapter:input.start_chapter,world_time:input.world_time_start},end},location_label:input.location_label,tags:input.tags,created_at,updated_at:now},
        participants:input.participants.into_iter().map(|p|TimelineParticipant{character_id:CharacterId(p.character_id),role:p.role}).collect(),
        sources:input.sources.into_iter().map(|s|TimelineSourceLink{source_kind:s.source_kind,source_id:s.source_id}).collect(),
    }
}
fn dto(a:TimelineAggregate)->TimelineEventDto{let end_chapter=a.event.temporal_span.end.as_ref().map(|p|p.chapter);let world_time_end=a.event.temporal_span.end.as_ref().and_then(|p|p.world_time.clone());TimelineEventDto{id:a.event.id.0,title:a.event.title,description:a.event.description,kind:a.event.kind,importance:a.event.importance,temporal_kind:a.event.temporal_span.kind,start_chapter:a.event.temporal_span.start.chapter,end_chapter,world_time_start:a.event.temporal_span.start.world_time,world_time_end,location_label:a.event.location_label,tags:a.event.tags,participants:a.participants.into_iter().map(|p|TimelineParticipantDto{character_id:p.character_id.0,role:p.role}).collect(),sources:a.sources.into_iter().map(|s|TimelineSourceDto{source_kind:s.source_kind,source_id:s.source_id}).collect(),created_at:a.event.created_at.to_rfc3339(),updated_at:a.event.updated_at.to_rfc3339()}}

pub fn create(characters:&dyn CharacterRepository,source_refs:&dyn TimelineSourceReferenceRepository,repo:&dyn TimelineRepository,input:UpsertTimelineEventInput)->Result<TimelineEventDto,TimelineError>{validate(&input)?;validate_refs(characters,source_refs,&input)?;let now=Utc::now();let a=aggregate(TimelineEventId(Uuid::new_v4().to_string()),now,input);repo.create_atomic(&a)?;Ok(dto(a))}
pub fn update(characters:&dyn CharacterRepository,source_refs:&dyn TimelineSourceReferenceRepository,repo:&dyn TimelineRepository,id:String,input:UpsertTimelineEventInput)->Result<TimelineEventDto,TimelineError>{validate(&input)?;validate_refs(characters,source_refs,&input)?;let old=repo.get(&TimelineEventId(id.clone()))?.ok_or(TimelineError::NotFound(id.clone()))?;let a=aggregate(TimelineEventId(id),old.event.created_at,input);repo.update_atomic(&a)?;Ok(dto(a))}
pub fn get(repo:&dyn TimelineRepository,id:String)->Result<TimelineEventDto,TimelineError>{repo.get(&TimelineEventId(id.clone()))?.map(dto).ok_or(TimelineError::NotFound(id))}
pub fn delete(repo:&dyn TimelineRepository,id:String)->Result<(),TimelineError>{repo.delete(&TimelineEventId(id))}
pub fn at(repo:&dyn TimelineRepository,chapter:u32)->Result<Vec<TimelineEventDto>,TimelineError>{if chapter==0{return Err(TimelineError::Validation("chapter must be > 0".into()));}Ok(repo.list_at(chapter)?.into_iter().map(dto).collect())}
pub fn between(repo:&dyn TimelineRepository,start:u32,end:u32)->Result<Vec<TimelineEventDto>,TimelineError>{if start==0||end<=start{return Err(TimelineError::Validation("range must satisfy 0 < start < end".into()));}Ok(repo.list_between(start,end)?.into_iter().map(dto).collect())}
pub fn for_character(characters:&dyn CharacterRepository,repo:&dyn TimelineRepository,character_id:String,start:Option<u32>,end:Option<u32>)->Result<Vec<TimelineEventDto>,TimelineError>{let id=CharacterId(character_id.clone());if characters.get(&id).map_err(|e|TimelineError::Database(e.to_string()))?.is_none(){return Err(TimelineError::CharacterNotFound(character_id));}if let(Some(s),Some(e))=(start,end){if s==0||e<=s{return Err(TimelineError::Validation("range must satisfy 0 < start < end".into()));}}Ok(repo.list_for_character(&id,start,end)?.into_iter().map(dto).collect())}

pub fn bounds(repo:&dyn TimelineRepository)->Result<Option<TimelineBoundsDto>,TimelineError>{Ok(repo.bounds()?.map(|(start_chapter,end_chapter)|TimelineBoundsDto{start_chapter,end_chapter}))}
