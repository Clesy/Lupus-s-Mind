use tauri::State;
use crate::{app_state::AppState,shared::api_error::ApiError,timeline::application::use_cases::{self,TimelineBoundsDto,TimelineEventDto,UpsertTimelineEventInput},timeline_projection::application::projections::{self,TimelineEntryDto,TimelineProjectionDto}};

#[tauri::command]
pub fn timeline_create(state:State<'_,AppState>,input:UpsertTimelineEventInput)->Result<TimelineEventDto,ApiError>{use_cases::create(&state.characters,&state.timeline,&state.timeline,input).map_err(Into::into)}
#[tauri::command]
pub fn timeline_update(state:State<'_,AppState>,id:String,input:UpsertTimelineEventInput)->Result<TimelineEventDto,ApiError>{use_cases::update(&state.characters,&state.timeline,&state.timeline,id,input).map_err(Into::into)}
#[tauri::command]
pub fn timeline_get(state:State<'_,AppState>,id:String)->Result<TimelineEventDto,ApiError>{use_cases::get(&state.timeline,id).map_err(Into::into)}
#[tauri::command]
pub fn timeline_delete(state:State<'_,AppState>,id:String)->Result<(),ApiError>{use_cases::delete(&state.timeline,id).map_err(Into::into)}
#[tauri::command]
pub fn timeline_at(state:State<'_,AppState>,chapter:u32)->Result<Vec<TimelineEventDto>,ApiError>{use_cases::at(&state.timeline,chapter).map_err(Into::into)}
#[tauri::command]
pub fn timeline_between(state:State<'_,AppState>,start:u32,end:u32)->Result<Vec<TimelineEventDto>,ApiError>{use_cases::between(&state.timeline,start,end).map_err(Into::into)}
#[tauri::command]
pub fn timeline_for_character(state:State<'_,AppState>,character_id:String,start:Option<u32>,end:Option<u32>)->Result<Vec<TimelineEventDto>,ApiError>{use_cases::for_character(&state.characters,&state.timeline,character_id,start,end).map_err(Into::into)}
#[tauri::command]
pub fn timeline_projection_between(state:State<'_,AppState>,start:u32,end:u32)->Result<TimelineProjectionDto,ApiError>{projections::chronicle_between(&state.characters,&state.timeline,start,end).map_err(Into::into)}
#[tauri::command]
pub fn timeline_character_thread(state:State<'_,AppState>,character_id:String)->Result<Vec<TimelineEntryDto>,ApiError>{projections::character_thread(&state.characters,&state.timeline,character_id).map_err(Into::into)}

#[tauri::command]
pub fn timeline_bounds(state:State<'_,AppState>)->Result<Option<TimelineBoundsDto>,ApiError>{use_cases::bounds(&state.timeline).map_err(Into::into)}
