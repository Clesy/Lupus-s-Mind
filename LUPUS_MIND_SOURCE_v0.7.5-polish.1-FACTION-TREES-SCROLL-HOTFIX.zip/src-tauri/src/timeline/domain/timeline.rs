use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use crate::characters::domain::character::CharacterId;

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, Hash)]
pub struct TimelineEventId(pub String);

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum TimelineEventKind { Personal, Conflict, Political, Discovery, Death, Birth, Journey, Alliance, Betrayal, Battle, Catastrophe, Revelation }
impl TimelineEventKind {
    pub fn as_db(self)->&'static str { match self { Self::Personal=>"personal",Self::Conflict=>"conflict",Self::Political=>"political",Self::Discovery=>"discovery",Self::Death=>"death",Self::Birth=>"birth",Self::Journey=>"journey",Self::Alliance=>"alliance",Self::Betrayal=>"betrayal",Self::Battle=>"battle",Self::Catastrophe=>"catastrophe",Self::Revelation=>"revelation" } }
    pub fn from_db(v:&str)->Option<Self>{Some(match v{"personal"=>Self::Personal,"conflict"=>Self::Conflict,"political"=>Self::Political,"discovery"=>Self::Discovery,"death"=>Self::Death,"birth"=>Self::Birth,"journey"=>Self::Journey,"alliance"=>Self::Alliance,"betrayal"=>Self::Betrayal,"battle"=>Self::Battle,"catastrophe"=>Self::Catastrophe,"revelation"=>Self::Revelation,_=>return None})}
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum EventImportance { Minor, Standard, Major, Critical }
impl EventImportance { pub fn as_db(self)->&'static str{match self{Self::Minor=>"minor",Self::Standard=>"standard",Self::Major=>"major",Self::Critical=>"critical"}} pub fn from_db(v:&str)->Option<Self>{Some(match v{"minor"=>Self::Minor,"standard"=>Self::Standard,"major"=>Self::Major,"critical"=>Self::Critical,_=>return None})} }

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum TemporalKind { Point, Span }
impl TemporalKind { pub fn as_db(self)->&'static str{match self{Self::Point=>"point",Self::Span=>"span"}} pub fn from_db(v:&str)->Option<Self>{Some(match v{"point"=>Self::Point,"span"=>Self::Span,_=>return None})} }

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct TemporalPoint { pub chapter:u32, pub world_time:Option<String> }

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct TemporalSpan { pub kind:TemporalKind, pub start:TemporalPoint, pub end:Option<TemporalPoint> }
impl TemporalSpan {
    pub fn contains(&self, chapter:u32)->bool { match self.kind { TemporalKind::Point=>self.start.chapter==chapter, TemporalKind::Span=>self.start.chapter<=chapter && self.end.as_ref().map(|e|chapter<e.chapter).unwrap_or(false) } }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TimelineEvent {
    pub id:TimelineEventId,
    pub title:String,
    pub description:String,
    pub kind:TimelineEventKind,
    pub importance:EventImportance,
    pub temporal_span:TemporalSpan,
    pub location_label:Option<String>,
    pub tags:Vec<String>,
    pub created_at:DateTime<Utc>,
    pub updated_at:DateTime<Utc>,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum EventParticipantRole { Actor, Target, Witness, Victim, Beneficiary, Commander, Participant }
impl EventParticipantRole { pub fn as_db(self)->&'static str{match self{Self::Actor=>"actor",Self::Target=>"target",Self::Witness=>"witness",Self::Victim=>"victim",Self::Beneficiary=>"beneficiary",Self::Commander=>"commander",Self::Participant=>"participant"}} pub fn from_db(v:&str)->Option<Self>{Some(match v{"actor"=>Self::Actor,"target"=>Self::Target,"witness"=>Self::Witness,"victim"=>Self::Victim,"beneficiary"=>Self::Beneficiary,"commander"=>Self::Commander,"participant"=>Self::Participant,_=>return None})} }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TimelineParticipant { pub character_id:CharacterId, pub role:EventParticipantRole }

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum TimelineSourceKind { RelationshipTransition, Manual }
impl TimelineSourceKind { pub fn as_db(self)->&'static str{match self{Self::RelationshipTransition=>"relationship_transition",Self::Manual=>"manual"}} pub fn from_db(v:&str)->Option<Self>{Some(match v{"relationship_transition"=>Self::RelationshipTransition,"manual"=>Self::Manual,_=>return None})} }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TimelineSourceLink { pub source_kind:TimelineSourceKind, pub source_id:String }

#[derive(Debug, Clone)]
pub struct TimelineAggregate { pub event:TimelineEvent, pub participants:Vec<TimelineParticipant>, pub sources:Vec<TimelineSourceLink> }
