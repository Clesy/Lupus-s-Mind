use serde::Serialize;
use thiserror::Error;

#[derive(Debug, Error, Serialize)]
#[serde(tag = "kind", content = "message", rename_all = "snake_case")]
pub enum TimelineError {
    #[error("Timeline event not found: {0}")]
    NotFound(String),
    #[error("Character not found: {0}")]
    CharacterNotFound(String),
    #[error("Timeline source not found: {0}")]
    SourceNotFound(String),
    #[error("Validation error: {0}")]
    Validation(String),
    #[error("Database error: {0}")]
    Database(String),
    #[error("Mapping error: {0}")]
    Mapping(String),
}
