use crate::characters::domain::character::CharacterId;
use super::{error::TimelineError,timeline::{TimelineAggregate,TimelineEventId,TimelineSourceKind}};

pub trait TimelineRepository: Send + Sync {
    fn get(&self,id:&TimelineEventId)->Result<Option<TimelineAggregate>,TimelineError>;
    fn list_at(&self,chapter:u32)->Result<Vec<TimelineAggregate>,TimelineError>;
    fn list_between(&self,start:u32,end:u32)->Result<Vec<TimelineAggregate>,TimelineError>;
    fn list_for_character(&self,character:&CharacterId,start:Option<u32>,end:Option<u32>)->Result<Vec<TimelineAggregate>,TimelineError>;
    fn bounds(&self)->Result<Option<(u32,u32)>,TimelineError>;
    fn create_atomic(&self,aggregate:&TimelineAggregate)->Result<(),TimelineError>;
    fn update_atomic(&self,aggregate:&TimelineAggregate)->Result<(),TimelineError>;
    fn delete(&self,id:&TimelineEventId)->Result<(),TimelineError>;
}

pub trait TimelineSourceReferenceRepository: Send + Sync {
    fn source_exists(&self,kind:TimelineSourceKind,source_id:&str)->Result<bool,TimelineError>;
}
