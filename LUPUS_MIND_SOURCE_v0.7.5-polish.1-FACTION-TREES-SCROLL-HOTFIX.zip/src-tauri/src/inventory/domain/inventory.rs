use serde::{Deserialize,Serialize};
#[derive(Debug,Clone,Serialize)]#[serde(rename_all="camelCase")]pub struct Ownership{pub id:String,pub item_id:String,pub item_name:String,pub item_type:String,pub rarity:String,pub owner_kind:String,pub owner_id:String,pub owner_name:String,pub acquired_chapter:u32,pub released_chapter:Option<u32>,pub note:String,pub is_equipped:bool}
#[derive(Debug,Clone,Deserialize)]#[serde(rename_all="camelCase")]pub struct TransferOwnershipInput{pub item_id:String,pub owner_kind:String,pub owner_id:String,pub chapter:u32,pub note:Option<String>}
