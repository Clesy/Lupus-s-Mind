use chrono::Utc;
use rusqlite::{params, OptionalExtension};
use uuid::Uuid;
use crate::{atlas::domain::{atlas::*, error::AtlasError, repository::AtlasRepository}, shared::database::SharedConnection};

#[derive(Clone)]
pub struct SqliteAtlasRepository { conn: SharedConnection }
impl SqliteAtlasRepository {
    pub fn new(conn: SharedConnection) -> Self { Self { conn } }
    fn db(e: rusqlite::Error) -> AtlasError { AtlasError::Database(e.to_string()) }
    fn tags(raw:String)->Vec<String>{serde_json::from_str(&raw).unwrap_or_default()}
    fn generated_land_contains(points:&[MapPoint],x:f64,y:f64)->bool{
        if points.len()<3{return false}
        let mut inside=false;let mut j=points.len()-1;
        for i in 0..points.len(){let a=&points[i];let b=&points[j];if (a.y>y)!=(b.y>y){let hit=(b.x-a.x)*(y-a.y)/(b.y-a.y)+a.x;if x<hit{inside=!inside}}j=i;}
        inside
    }
    fn validate_kind(kind:&str)->Result<(),AtlasError>{
        const K:&[&str]=&["world","continent","country","region","province","city","town","village","district","building","landmark","dungeon","biome","location"];
        if K.contains(&kind){Ok(())}else{Err(AtlasError::Validation(format!("unsupported location kind: {kind}")))}
    }
    fn validate_map_dims(w:u32,h:u32)->Result<(),AtlasError>{if (320..=8192).contains(&w)&&(240..=8192).contains(&h){Ok(())}else{Err(AtlasError::Validation("map dimensions are out of range".into()))}}
    fn map_row(conn:&rusqlite::Connection,id:&str)->Result<Option<AtlasMap>,AtlasError>{
        conn.query_row(r#"SELECT m.id,m.name,m.scope_location_id,l.name,m.parent_map_id,m.width,m.height,m.background,m.terrain_json,m.generator_seed,
          (SELECT COUNT(*) FROM map_pins p WHERE p.map_id=m.id),m.created_at,m.updated_at
          FROM atlas_maps m LEFT JOIN locations l ON l.id=m.scope_location_id WHERE m.id=?"#,params![id],|r|{
            let terrain_raw:String=r.get(8)?;let seed:Option<i64>=r.get(9)?;
            Ok(AtlasMap{id:r.get(0)?,name:r.get(1)?,scope_location_id:r.get(2)?,scope_location_name:r.get(3)?,parent_map_id:r.get(4)?,width:u32::try_from(r.get::<_,i64>(5)?).unwrap_or(1200),height:u32::try_from(r.get::<_,i64>(6)?).unwrap_or(760),background:r.get(7)?,terrain:if terrain_raw.trim().is_empty(){None}else{serde_json::from_str(&terrain_raw).ok()},generator_seed:seed.and_then(|v|u32::try_from(v).ok()),pin_count:u32::try_from(r.get::<_,i64>(10)?).unwrap_or(0),created_at:r.get(11)?,updated_at:r.get(12)?})
        }).optional().map_err(Self::db)
    }
    fn location_row(conn:&rusqlite::Connection,id:&str)->Result<Option<Location>,AtlasError>{
        conn.query_row(r#"SELECT l.id,l.name,l.kind,l.parent_location_id,p.name,l.description,l.color,l.tags,
          (SELECT COUNT(*) FROM locations c WHERE c.parent_location_id=l.id),l.created_at,l.updated_at
          FROM locations l LEFT JOIN locations p ON p.id=l.parent_location_id WHERE l.id=?"#,params![id],|r|{
            Ok(Location{id:r.get(0)?,name:r.get(1)?,kind:r.get(2)?,parent_location_id:r.get(3)?,parent_location_name:r.get(4)?,description:r.get(5)?,color:r.get(6)?,tags:Self::tags(r.get(7)?),child_count:u32::try_from(r.get::<_,i64>(8)?).unwrap_or(0),created_at:r.get(9)?,updated_at:r.get(10)?})
        }).optional().map_err(Self::db)
    }
}

impl AtlasRepository for SqliteAtlasRepository {
    fn locations(&self)->Result<Vec<Location>,AtlasError>{
        let c=self.conn.lock().map_err(|e|AtlasError::Database(e.to_string()))?;
        let mut s=c.prepare(r#"SELECT l.id,l.name,l.kind,l.parent_location_id,p.name,l.description,l.color,l.tags,
          (SELECT COUNT(*) FROM locations c2 WHERE c2.parent_location_id=l.id),l.created_at,l.updated_at
          FROM locations l LEFT JOIN locations p ON p.id=l.parent_location_id ORDER BY l.name COLLATE NOCASE"#).map_err(Self::db)?;
        let rows=s.query_map([],|r|Ok(Location{id:r.get(0)?,name:r.get(1)?,kind:r.get(2)?,parent_location_id:r.get(3)?,parent_location_name:r.get(4)?,description:r.get(5)?,color:r.get(6)?,tags:Self::tags(r.get(7)?),child_count:u32::try_from(r.get::<_,i64>(8)?).unwrap_or(0),created_at:r.get(9)?,updated_at:r.get(10)?})).map_err(Self::db)?;
        rows.map(|x|x.map_err(Self::db)).collect()
    }
    fn location(&self,id:&str)->Result<Option<Location>,AtlasError>{let c=self.conn.lock().map_err(|e|AtlasError::Database(e.to_string()))?;Self::location_row(&c,id)}
    fn create_location(&self,input:UpsertLocationInput)->Result<Location,AtlasError>{
        if input.name.trim().is_empty(){return Err(AtlasError::Validation("location name is required".into()))}Self::validate_kind(&input.kind)?;
        let id=Uuid::new_v4().to_string();let now=Utc::now().to_rfc3339();let tags=serde_json::to_string(&input.tags).map_err(|e|AtlasError::Mapping(e.to_string()))?;
        let c=self.conn.lock().map_err(|e|AtlasError::Database(e.to_string()))?;
        c.execute("INSERT INTO locations(id,name,kind,parent_location_id,description,color,tags,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)",params![id,input.name.trim(),input.kind,input.parent_location_id,input.description.unwrap_or_default(),input.color.unwrap_or_else(||"#70b7c4".into()),tags,now,now]).map_err(Self::db)?;
        Self::location_row(&c,&id)?.ok_or_else(||AtlasError::NotFound(id))
    }
    fn update_location(&self,id:&str,input:UpsertLocationInput)->Result<Location,AtlasError>{
        if input.name.trim().is_empty(){return Err(AtlasError::Validation("location name is required".into()))}Self::validate_kind(&input.kind)?;let tags=serde_json::to_string(&input.tags).map_err(|e|AtlasError::Mapping(e.to_string()))?;
        let c=self.conn.lock().map_err(|e|AtlasError::Database(e.to_string()))?;let n=c.execute("UPDATE locations SET name=?,kind=?,parent_location_id=?,description=?,color=?,tags=?,updated_at=? WHERE id=?",params![input.name.trim(),input.kind,input.parent_location_id,input.description.unwrap_or_default(),input.color.unwrap_or_else(||"#70b7c4".into()),tags,Utc::now().to_rfc3339(),id]).map_err(Self::db)?;if n==0{return Err(AtlasError::NotFound(id.into()))}Self::location_row(&c,id)?.ok_or_else(||AtlasError::NotFound(id.into()))
    }
    fn delete_location(&self,id:&str)->Result<(),AtlasError>{
        let mut c=self.conn.lock().map_err(|e|AtlasError::Database(e.to_string()))?;
        let tx=c.transaction().map_err(Self::db)?;
        let exists:i64=tx.query_row("SELECT COUNT(*) FROM locations WHERE id=?",params![id],|r|r.get(0)).map_err(Self::db)?;
        if exists==0{return Err(AtlasError::NotFound(id.into()))}
        tx.execute("UPDATE locations SET parent_location_id=NULL,updated_at=? WHERE parent_location_id=?",params![Utc::now().to_rfc3339(),id]).map_err(Self::db)?;
        tx.execute("UPDATE atlas_maps SET scope_location_id=NULL,updated_at=? WHERE scope_location_id=?",params![Utc::now().to_rfc3339(),id]).map_err(Self::db)?;
        tx.execute("DELETE FROM map_connections WHERE from_location_id=? OR to_location_id=?",params![id,id]).map_err(Self::db)?;
        tx.execute("DELETE FROM map_pins WHERE location_id=?",params![id]).map_err(Self::db)?;
        tx.execute("DELETE FROM locations WHERE id=?",params![id]).map_err(Self::db)?;
        tx.commit().map_err(Self::db)?;
        Ok(())
    }

    fn maps(&self)->Result<Vec<AtlasMap>,AtlasError>{
        let c=self.conn.lock().map_err(|e|AtlasError::Database(e.to_string()))?;let mut s=c.prepare("SELECT id FROM atlas_maps ORDER BY name COLLATE NOCASE").map_err(Self::db)?;let ids=s.query_map([],|r|r.get::<_,String>(0)).map_err(Self::db)?.collect::<Result<Vec<_>,_>>().map_err(Self::db)?;ids.iter().map(|id|Self::map_row(&c,id)?.ok_or_else(||AtlasError::NotFound(id.clone()))).collect()
    }
    fn map(&self,id:&str)->Result<Option<AtlasMap>,AtlasError>{let c=self.conn.lock().map_err(|e|AtlasError::Database(e.to_string()))?;Self::map_row(&c,id)}
    fn create_map(&self,input:UpsertMapInput)->Result<AtlasMap,AtlasError>{
        if input.name.trim().is_empty(){return Err(AtlasError::Validation("map name is required".into()))}
        Self::validate_map_dims(input.width,input.height)?;
        let id=Uuid::new_v4().to_string();let now=Utc::now().to_rfc3339();
        let terrain=input.terrain.as_ref().map(serde_json::to_string).transpose().map_err(|e|AtlasError::Mapping(e.to_string()))?.unwrap_or_default();
        let c=self.conn.lock().map_err(|e|AtlasError::Database(e.to_string()))?;
        c.execute("INSERT INTO atlas_maps(id,name,scope_location_id,parent_map_id,width,height,background,terrain_json,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)",params![id,input.name.trim(),input.scope_location_id,input.parent_map_id,input.width,input.height,input.background.unwrap_or_else(||"ocean".into()),terrain,now,now]).map_err(Self::db)?;
        Self::map_row(&c,&id)?.ok_or_else(||AtlasError::NotFound(id))
    }
    fn update_map(&self,id:&str,input:UpsertMapInput)->Result<AtlasMap,AtlasError>{
        if input.name.trim().is_empty(){return Err(AtlasError::Validation("map name is required".into()))}
        Self::validate_map_dims(input.width,input.height)?;
        let terrain=input.terrain.as_ref().map(serde_json::to_string).transpose().map_err(|e|AtlasError::Mapping(e.to_string()))?.unwrap_or_default();
        let c=self.conn.lock().map_err(|e|AtlasError::Database(e.to_string()))?;
        let n=c.execute("UPDATE atlas_maps SET name=?,scope_location_id=?,parent_map_id=?,width=?,height=?,background=?,terrain_json=?,updated_at=? WHERE id=?",params![input.name.trim(),input.scope_location_id,input.parent_map_id,input.width,input.height,input.background.unwrap_or_else(||"ocean".into()),terrain,Utc::now().to_rfc3339(),id]).map_err(Self::db)?;
        if n==0{return Err(AtlasError::NotFound(id.into()))}
        Self::map_row(&c,id)?.ok_or_else(||AtlasError::NotFound(id.into()))
    }
    fn delete_map(&self,id:&str)->Result<(),AtlasError>{let c=self.conn.lock().map_err(|e|AtlasError::Database(e.to_string()))?;let n=c.execute("DELETE FROM atlas_maps WHERE id=?",params![id]).map_err(Self::db)?;if n==0{Err(AtlasError::NotFound(id.into()))}else{Ok(())}}

    fn pins(&self,map_id:&str)->Result<Vec<MapPin>,AtlasError>{let c=self.conn.lock().map_err(|e|AtlasError::Database(e.to_string()))?;let mut s=c.prepare("SELECT p.id,p.map_id,p.location_id,l.name,l.kind,p.label,p.x,p.y,p.icon,p.color FROM map_pins p JOIN locations l ON l.id=p.location_id WHERE p.map_id=? ORDER BY l.name COLLATE NOCASE").map_err(Self::db)?;let rows=s.query_map(params![map_id],|r|Ok(MapPin{id:r.get(0)?,map_id:r.get(1)?,location_id:r.get(2)?,location_name:r.get(3)?,location_kind:r.get(4)?,label:r.get(5)?,x:r.get(6)?,y:r.get(7)?,icon:r.get(8)?,color:r.get(9)?})).map_err(Self::db)?;rows.map(|x|x.map_err(Self::db)).collect()}
    fn upsert_pin(&self,input:UpsertPinInput)->Result<MapPin,AtlasError>{if !(0.0..=1.0).contains(&input.x)||!(0.0..=1.0).contains(&input.y){return Err(AtlasError::Validation("pin coordinates must be normalized 0..1".into()))}let c=self.conn.lock().map_err(|e|AtlasError::Database(e.to_string()))?;let id:Option<String>=c.query_row("SELECT id FROM map_pins WHERE map_id=? AND location_id=?",params![input.map_id,input.location_id],|r|r.get(0)).optional().map_err(Self::db)?;let id=id.unwrap_or_else(||Uuid::new_v4().to_string());let now=Utc::now().to_rfc3339();c.execute("INSERT INTO map_pins(id,map_id,location_id,label,x,y,icon,color,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(map_id,location_id) DO UPDATE SET label=excluded.label,x=excluded.x,y=excluded.y,icon=excluded.icon,color=excluded.color,updated_at=excluded.updated_at",params![id,input.map_id,input.location_id,input.label.unwrap_or_default(),input.x,input.y,input.icon.unwrap_or_else(||"pin".into()),input.color.unwrap_or_else(||"#d9b45b".into()),now,now]).map_err(Self::db)?;drop(c);self.pins(&input.map_id)?.into_iter().find(|p|p.location_id==input.location_id).ok_or_else(||AtlasError::NotFound(id))}
    fn delete_pin(&self,id:&str)->Result<(),AtlasError>{let c=self.conn.lock().map_err(|e|AtlasError::Database(e.to_string()))?;let n=c.execute("DELETE FROM map_pins WHERE id=?",params![id]).map_err(Self::db)?;if n==0{Err(AtlasError::NotFound(id.into()))}else{Ok(())}}

    fn connections(&self,map_id:&str)->Result<Vec<MapConnection>,AtlasError>{let c=self.conn.lock().map_err(|e|AtlasError::Database(e.to_string()))?;let mut s=c.prepare("SELECT c.id,c.map_id,c.from_location_id,a.name,c.to_location_id,b.name,c.kind,c.label,c.color FROM map_connections c JOIN locations a ON a.id=c.from_location_id JOIN locations b ON b.id=c.to_location_id WHERE c.map_id=? ORDER BY c.kind,a.name,b.name").map_err(Self::db)?;let rows=s.query_map(params![map_id],|r|Ok(MapConnection{id:r.get(0)?,map_id:r.get(1)?,from_location_id:r.get(2)?,from_location_name:r.get(3)?,to_location_id:r.get(4)?,to_location_name:r.get(5)?,kind:r.get(6)?,label:r.get(7)?,color:r.get(8)?})).map_err(Self::db)?;rows.map(|x|x.map_err(Self::db)).collect()}
    fn upsert_connection(&self,input:UpsertConnectionInput)->Result<MapConnection,AtlasError>{if input.from_location_id==input.to_location_id{return Err(AtlasError::Validation("connection endpoints must differ".into()))}const K:&[&str]=&["road","sea_route","portal","border","path"];if !K.contains(&input.kind.as_str()){return Err(AtlasError::Validation("unsupported map connection kind".into()))}let c=self.conn.lock().map_err(|e|AtlasError::Database(e.to_string()))?;let id:Option<String>=c.query_row("SELECT id FROM map_connections WHERE map_id=? AND from_location_id=? AND to_location_id=? AND kind=?",params![input.map_id,input.from_location_id,input.to_location_id,input.kind],|r|r.get(0)).optional().map_err(Self::db)?;let id=id.unwrap_or_else(||Uuid::new_v4().to_string());let now=Utc::now().to_rfc3339();c.execute("INSERT INTO map_connections(id,map_id,from_location_id,to_location_id,kind,label,color,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(map_id,from_location_id,to_location_id,kind) DO UPDATE SET label=excluded.label,color=excluded.color,updated_at=excluded.updated_at",params![id,input.map_id,input.from_location_id,input.to_location_id,input.kind,input.label.unwrap_or_default(),input.color.unwrap_or_else(||"#7d8b98".into()),now,now]).map_err(Self::db)?;drop(c);self.connections(&input.map_id)?.into_iter().find(|x|x.id==id).ok_or_else(||AtlasError::NotFound(id))}
    fn delete_connection(&self,id:&str)->Result<(),AtlasError>{let c=self.conn.lock().map_err(|e|AtlasError::Database(e.to_string()))?;let n=c.execute("DELETE FROM map_connections WHERE id=?",params![id]).map_err(Self::db)?;if n==0{Err(AtlasError::NotFound(id.into()))}else{Ok(())}}

    fn accept_generated_map(&self,input:AcceptGeneratedMapInput)->Result<AcceptGeneratedMapResult,AtlasError>{
        if input.map_name.trim().is_empty(){return Err(AtlasError::Validation("map name is required".into()))}
        let mut c=self.conn.lock().map_err(|e|AtlasError::Database(e.to_string()))?;let tx=c.transaction().map_err(Self::db)?;let now=Utc::now().to_rfc3339();let map_id=Uuid::new_v4().to_string();let terrain=serde_json::to_string(&input.draft).map_err(|e|AtlasError::Mapping(e.to_string()))?;
        tx.execute("INSERT INTO atlas_maps(id,name,width,height,background,terrain_json,generator_seed,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)",params![map_id,input.map_name.trim(),input.draft.width,input.draft.height,"generated",terrain,input.draft.seed,now,now]).map_err(Self::db)?;
        let mut created=Vec::new();
        if input.create_locations {
            let mut continent_ids=Vec::new();
            for land in &input.draft.landmasses {let id=Uuid::new_v4().to_string();tx.execute("INSERT INTO locations(id,name,kind,description,color,tags,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)",params![id,land.name,"continent","Generated from procedural map.","#79a66c","[]",now,now]).map_err(Self::db)?;created.push(id.clone());continent_ids.push(id);}
            for s in &input.draft.settlements {
                let id=Uuid::new_v4().to_string();
                let containing=input.draft.landmasses.iter().position(|land|Self::generated_land_contains(&land.points,s.x,s.y));
                let nearest=containing.or_else(||input.draft.landmasses.iter().enumerate().map(|(idx,land)|{
                    let (sx,sy)=land.points.iter().fold((0.0,0.0),|(x,y),p|(x+p.x,y+p.y));
                    let n=land.points.len().max(1) as f64;let dx=s.x-sx/n;let dy=s.y-sy/n;(idx,dx*dx+dy*dy)
                }).min_by(|a,b|a.1.partial_cmp(&b.1).unwrap_or(std::cmp::Ordering::Equal)).map(|(idx,_)|idx));
                let parent=nearest.and_then(|idx|continent_ids.get(idx).cloned());
                let (pin_icon,pin_color)=match s.kind.as_str(){"city"=>("city","#e6c76d"),"town"=>("town","#d7b861"),"village"=>("village","#bba867"),_=>("settlement","#d9b45b")};
                tx.execute("INSERT INTO locations(id,name,kind,parent_location_id,description,color,tags,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)",params![id,s.name,s.kind,parent,"Generated settlement.",pin_color,"[]",now,now]).map_err(Self::db)?;
                let pin_id=Uuid::new_v4().to_string();
                tx.execute("INSERT INTO map_pins(id,map_id,location_id,label,x,y,icon,color,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)",params![pin_id,map_id,id,s.name,s.x,s.y,pin_icon,pin_color,now,now]).map_err(Self::db)?;created.push(id);
            }
        }
        tx.commit().map_err(Self::db)?;drop(c);let map=self.map(&map_id)?.ok_or_else(||AtlasError::NotFound(map_id))?;Ok(AcceptGeneratedMapResult{map,created_location_ids:created})
    }
}
