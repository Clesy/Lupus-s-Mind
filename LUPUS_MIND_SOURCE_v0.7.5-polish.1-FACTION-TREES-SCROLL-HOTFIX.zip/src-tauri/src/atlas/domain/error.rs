use thiserror::Error;

#[derive(Debug, Error)]
pub enum AtlasError {
    #[error("atlas record not found: {0}")]
    NotFound(String),
    #[error("validation error: {0}")]
    Validation(String),
    #[error("database error: {0}")]
    Database(String),
    #[error("mapping error: {0}")]
    Mapping(String),
}
