use super::{atlas::*, error::AtlasError};

pub trait AtlasRepository: Send + Sync {
    fn locations(&self) -> Result<Vec<Location>, AtlasError>;
    fn location(&self, id: &str) -> Result<Option<Location>, AtlasError>;
    fn create_location(&self, input: UpsertLocationInput) -> Result<Location, AtlasError>;
    fn update_location(&self, id: &str, input: UpsertLocationInput) -> Result<Location, AtlasError>;
    fn delete_location(&self, id: &str) -> Result<(), AtlasError>;

    fn maps(&self) -> Result<Vec<AtlasMap>, AtlasError>;
    fn map(&self, id: &str) -> Result<Option<AtlasMap>, AtlasError>;
    fn create_map(&self, input: UpsertMapInput) -> Result<AtlasMap, AtlasError>;
    fn update_map(&self, id: &str, input: UpsertMapInput) -> Result<AtlasMap, AtlasError>;
    fn delete_map(&self, id: &str) -> Result<(), AtlasError>;

    fn pins(&self, map_id: &str) -> Result<Vec<MapPin>, AtlasError>;
    fn upsert_pin(&self, input: UpsertPinInput) -> Result<MapPin, AtlasError>;
    fn delete_pin(&self, id: &str) -> Result<(), AtlasError>;

    fn connections(&self, map_id: &str) -> Result<Vec<MapConnection>, AtlasError>;
    fn upsert_connection(&self, input: UpsertConnectionInput) -> Result<MapConnection, AtlasError>;
    fn delete_connection(&self, id: &str) -> Result<(), AtlasError>;

    fn accept_generated_map(&self, input: AcceptGeneratedMapInput) -> Result<AcceptGeneratedMapResult, AtlasError>;
}
