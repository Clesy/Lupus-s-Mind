use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Location {
    pub id: String,
    pub name: String,
    pub kind: String,
    pub parent_location_id: Option<String>,
    pub parent_location_name: Option<String>,
    pub description: String,
    pub color: String,
    pub tags: Vec<String>,
    pub child_count: u32,
    pub created_at: String,
    pub updated_at: String,
}

#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct UpsertLocationInput {
    pub name: String,
    pub kind: String,
    pub parent_location_id: Option<String>,
    pub description: Option<String>,
    pub color: Option<String>,
    pub tags: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AtlasMap {
    pub id: String,
    pub name: String,
    pub scope_location_id: Option<String>,
    pub scope_location_name: Option<String>,
    pub parent_map_id: Option<String>,
    pub width: u32,
    pub height: u32,
    pub background: String,
    pub terrain: Option<GeneratedMapDraft>,
    pub generator_seed: Option<u32>,
    pub pin_count: u32,
    pub created_at: String,
    pub updated_at: String,
}

#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct UpsertMapInput {
    pub name: String,
    pub scope_location_id: Option<String>,
    pub parent_map_id: Option<String>,
    pub width: u32,
    pub height: u32,
    pub background: Option<String>,
    pub terrain: Option<GeneratedMapDraft>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct MapPin {
    pub id: String,
    pub map_id: String,
    pub location_id: String,
    pub location_name: String,
    pub location_kind: String,
    pub label: String,
    pub x: f64,
    pub y: f64,
    pub icon: String,
    pub color: String,
}

#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct UpsertPinInput {
    pub map_id: String,
    pub location_id: String,
    pub label: Option<String>,
    pub x: f64,
    pub y: f64,
    pub icon: Option<String>,
    pub color: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct MapConnection {
    pub id: String,
    pub map_id: String,
    pub from_location_id: String,
    pub from_location_name: String,
    pub to_location_id: String,
    pub to_location_name: String,
    pub kind: String,
    pub label: String,
    pub color: String,
}

#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct UpsertConnectionInput {
    pub map_id: String,
    pub from_location_id: String,
    pub to_location_id: String,
    pub kind: String,
    pub label: Option<String>,
    pub color: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct MapPoint {
    pub x: f64,
    pub y: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct GeneratedLandmass {
    pub id: String,
    pub name: String,
    pub points: Vec<MapPoint>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct GeneratedMarker {
    pub id: String,
    pub name: String,
    pub kind: String,
    pub x: f64,
    pub y: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct GeneratedRiver {
    pub id: String,
    pub points: Vec<MapPoint>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct GeneratedMapDraft {
    pub seed: u32,
    pub name: String,
    pub width: u32,
    pub height: u32,
    pub ocean_ratio: f64,
    pub landmasses: Vec<GeneratedLandmass>,
    pub mountains: Vec<GeneratedMarker>,
    pub rivers: Vec<GeneratedRiver>,
    pub settlements: Vec<GeneratedMarker>,
}

#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct GenerateMapRequest {
    pub seed: u32,
    pub name: Option<String>,
    pub width: u32,
    pub height: u32,
    pub continents: u32,
    pub ocean_ratio: f64,
    pub mountain_density: f64,
    pub river_count: u32,
    pub settlement_count: u32,
}

#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AcceptGeneratedMapInput {
    pub draft: GeneratedMapDraft,
    pub map_name: String,
    pub create_locations: bool,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct AcceptGeneratedMapResult {
    pub map: AtlasMap,
    pub created_location_ids: Vec<String>,
}
