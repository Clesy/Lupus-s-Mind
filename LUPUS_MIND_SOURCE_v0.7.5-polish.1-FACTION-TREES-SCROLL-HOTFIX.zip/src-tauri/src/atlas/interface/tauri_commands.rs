use tauri::State;
use crate::{app_state::AppState, atlas::{application::{generator,use_cases}, domain::atlas::*}, shared::api_error::ApiError};

#[tauri::command] pub fn atlas_locations_list(state:State<'_,AppState>)->Result<Vec<Location>,ApiError>{use_cases::locations(&state.atlas).map_err(Into::into)}
#[tauri::command] pub fn atlas_location_get(state:State<'_,AppState>,id:String)->Result<Location,ApiError>{use_cases::location(&state.atlas,&id).map_err(Into::into)}
#[tauri::command] pub fn atlas_location_create(state:State<'_,AppState>,input:UpsertLocationInput)->Result<Location,ApiError>{use_cases::create_location(&state.atlas,input).map_err(Into::into)}
#[tauri::command] pub fn atlas_location_update(state:State<'_,AppState>,id:String,input:UpsertLocationInput)->Result<Location,ApiError>{use_cases::update_location(&state.atlas,&id,input).map_err(Into::into)}
#[tauri::command] pub fn atlas_location_delete(state:State<'_,AppState>,id:String)->Result<(),ApiError>{use_cases::delete_location(&state.atlas,&id).map_err(Into::into)}
#[tauri::command] pub fn atlas_maps_list(state:State<'_,AppState>)->Result<Vec<AtlasMap>,ApiError>{use_cases::maps(&state.atlas).map_err(Into::into)}
#[tauri::command] pub fn atlas_map_get(state:State<'_,AppState>,id:String)->Result<AtlasMap,ApiError>{use_cases::map(&state.atlas,&id).map_err(Into::into)}
#[tauri::command] pub fn atlas_map_create(state:State<'_,AppState>,input:UpsertMapInput)->Result<AtlasMap,ApiError>{use_cases::create_map(&state.atlas,input).map_err(Into::into)}
#[tauri::command] pub fn atlas_map_update(state:State<'_,AppState>,id:String,input:UpsertMapInput)->Result<AtlasMap,ApiError>{use_cases::update_map(&state.atlas,&id,input).map_err(Into::into)}
#[tauri::command] pub fn atlas_map_delete(state:State<'_,AppState>,id:String)->Result<(),ApiError>{use_cases::delete_map(&state.atlas,&id).map_err(Into::into)}
#[tauri::command] pub fn atlas_map_pins(state:State<'_,AppState>,map_id:String)->Result<Vec<MapPin>,ApiError>{use_cases::pins(&state.atlas,&map_id).map_err(Into::into)}
#[tauri::command] pub fn atlas_map_pin_upsert(state:State<'_,AppState>,input:UpsertPinInput)->Result<MapPin,ApiError>{use_cases::upsert_pin(&state.atlas,input).map_err(Into::into)}
#[tauri::command] pub fn atlas_map_pin_delete(state:State<'_,AppState>,id:String)->Result<(),ApiError>{use_cases::delete_pin(&state.atlas,&id).map_err(Into::into)}
#[tauri::command] pub fn atlas_map_connections(state:State<'_,AppState>,map_id:String)->Result<Vec<MapConnection>,ApiError>{use_cases::connections(&state.atlas,&map_id).map_err(Into::into)}
#[tauri::command] pub fn atlas_map_connection_upsert(state:State<'_,AppState>,input:UpsertConnectionInput)->Result<MapConnection,ApiError>{use_cases::upsert_connection(&state.atlas,input).map_err(Into::into)}
#[tauri::command] pub fn atlas_map_connection_delete(state:State<'_,AppState>,id:String)->Result<(),ApiError>{use_cases::delete_connection(&state.atlas,&id).map_err(Into::into)}
#[tauri::command] pub fn atlas_generate_map(input:GenerateMapRequest)->Result<GeneratedMapDraft,ApiError>{generator::generate(input).map_err(Into::into)}
#[tauri::command] pub fn atlas_accept_generated_map(state:State<'_,AppState>,input:AcceptGeneratedMapInput)->Result<AcceptGeneratedMapResult,ApiError>{use_cases::accept_generated(&state.atlas,input).map_err(Into::into)}
