use std::{cmp::Ordering, collections::HashSet, f64::consts::{PI, TAU}};

use crate::atlas::domain::{atlas::*, error::AtlasError};

/// Small deterministic PRNG. Generator output must depend only on the request.
#[derive(Clone)]
struct Rng(u32);
impl Rng {
    fn new(seed: u32) -> Self { Self(if seed == 0 { 0x6d2b79f5 } else { seed }) }
    fn next_u32(&mut self) -> u32 {
        let mut x = self.0;
        x ^= x << 13;
        x ^= x >> 17;
        x ^= x << 5;
        self.0 = x;
        x
    }
    fn unit(&mut self) -> f64 { self.next_u32() as f64 / u32::MAX as f64 }
    fn range(&mut self, min: f64, max: f64) -> f64 { min + (max - min) * self.unit() }
}

// Separate deterministic streams keep geography, hydrology and settlements stable when another
// layer changes its internal sampling count.
fn derived_seed(seed: u32, salt: u32) -> u32 {
    let mut x = seed ^ salt;
    x ^= x >> 16;
    x = x.wrapping_mul(0x7feb_352d);
    x ^= x >> 15;
    x = x.wrapping_mul(0x846c_a68b);
    x ^= x >> 16;
    if x == 0 { 0x6d2b79f5 } else { x }
}

const A: &[&str] = &["Aer","Ash","Bel","Cor","Dra","Ely","Fal","Gal","Ith","Kai","Lor","Mor","Nor","Rav","Syl","Val","Vor","Yar","Zel"];
const B: &[&str] = &["ador","aris","en","eth","ia","ion","ora","os","ryn","thal","um","vale","wyn","yr"];
fn raw_name(rng: &mut Rng) -> String {
    let a = A[(rng.next_u32() as usize) % A.len()];
    let b = B[(rng.next_u32() as usize) % B.len()];
    format!("{a}{b}")
}
fn unique_name(rng: &mut Rng, used: &mut HashSet<String>) -> String {
    for _ in 0..64 {
        let candidate = raw_name(rng);
        if used.insert(candidate.clone()) { return candidate; }
    }
    let stem = raw_name(rng);
    let mut suffix = 2u32;
    loop {
        let candidate = format!("{stem} {suffix}");
        if used.insert(candidate.clone()) { return candidate; }
        suffix += 1;
    }
}

fn dist(a: &MapPoint, b: &MapPoint) -> f64 { ((a.x-b.x).powi(2)+(a.y-b.y).powi(2)).sqrt() }
fn normalize(x:f64,y:f64)->(f64,f64){let d=(x*x+y*y).sqrt();if d<1e-12{(0.0,0.0)}else{(x/d,y/d)}}
fn rotate(x:f64,y:f64,a:f64)->(f64,f64){let c=a.cos();let s=a.sin();(x*c-y*s,x*s+y*c)}
fn angle_distance(a:f64,b:f64)->f64{((a-b+PI).rem_euclid(TAU)-PI).abs()}

fn polygon_center(poly:&[MapPoint])->MapPoint{
    let n=poly.len().max(1) as f64;
    let (x,y)=poly.iter().fold((0.0,0.0),|(x,y),p|(x+p.x,y+p.y));
    MapPoint{x:x/n,y:y/n}
}
fn polygon_area(poly:&[MapPoint])->f64{
    if poly.len()<3{return 0.0}
    let mut s=0.0;
    for i in 0..poly.len(){let a=&poly[i];let b=&poly[(i+1)%poly.len()];s+=a.x*b.y-b.x*a.y;}
    s.abs()*0.5
}
fn bbox(poly:&[MapPoint])->(f64,f64,f64,f64){
    poly.iter().fold((1.0,0.0,1.0,0.0),|(min_x,max_x,min_y,max_y),p|(min_x.min(p.x),max_x.max(p.x),min_y.min(p.y),max_y.max(p.y)))
}
fn point_in_polygon(p:&MapPoint,poly:&[MapPoint])->bool{
    if poly.len()<3{return false}
    let mut inside=false;let mut j=poly.len()-1;
    for i in 0..poly.len(){let a=&poly[i];let b=&poly[j];if (a.y>p.y)!=(b.y>p.y){let x=(b.x-a.x)*(p.y-a.y)/(b.y-a.y)+a.x;if p.x<x{inside=!inside}}j=i;}
    inside
}
fn segment_nearest(p:&MapPoint,a:&MapPoint,b:&MapPoint)->(f64,MapPoint){
    let vx=b.x-a.x;let vy=b.y-a.y;let wx=p.x-a.x;let wy=p.y-a.y;let vv=vx*vx+vy*vy;
    let t=if vv<1e-16{0.0}else{((wx*vx+wy*vy)/vv).clamp(0.0,1.0)};
    let q=MapPoint{x:a.x+t*vx,y:a.y+t*vy};(dist(p,&q),q)
}
fn nearest_coast(p:&MapPoint,poly:&[MapPoint])->(f64,MapPoint){
    let mut best=(f64::MAX,MapPoint{x:p.x,y:p.y});
    for i in 0..poly.len(){let hit=segment_nearest(p,&poly[i],&poly[(i+1)%poly.len()]);if hit.0<best.0{best=hit}}
    best
}
fn distance_to_polyline(p:&MapPoint,points:&[MapPoint])->f64{
    if points.len()<2{return f64::MAX}
    points.windows(2).map(|pair|segment_nearest(p,&pair[0],&pair[1]).0).fold(f64::MAX,f64::min)
}
fn random_interior(rng:&mut Rng,poly:&[MapPoint],trials:usize)->MapPoint{
    let (min_x,max_x,min_y,max_y)=bbox(poly);let fallback=polygon_center(poly);let mut best:Option<(f64,MapPoint)>=None;
    for _ in 0..trials{let p=MapPoint{x:rng.range(min_x,max_x),y:rng.range(min_y,max_y)};if !point_in_polygon(&p,poly){continue}let d=nearest_coast(&p,poly).0;if best.as_ref().map(|x|d>x.0).unwrap_or(true){best=Some((d,p))}}
    best.map(|x|x.1).unwrap_or(fallback)
}
fn allocate_counts(total:usize,weights:&[f64],guarantee_each:bool)->Vec<usize>{
    if weights.is_empty(){return vec![]}
    let n=weights.len();let base=if guarantee_each&&total>=n{1}else{0};let mut counts=vec![base;n];let remaining=total.saturating_sub(base*n);if remaining==0{return counts}
    let sum=weights.iter().sum::<f64>().max(1e-12);let raw:Vec<f64>=weights.iter().map(|w|remaining as f64*w/sum).collect();
    for (i,v) in raw.iter().enumerate(){counts[i]+=v.floor() as usize}
    let mut left=total.saturating_sub(counts.iter().sum());let mut order:Vec<usize>=(0..n).collect();order.sort_by(|&a,&b|((raw[b]-raw[b].floor()).partial_cmp(&(raw[a]-raw[a].floor())).unwrap_or(Ordering::Equal)));
    let mut i=0;while left>0{counts[order[i%order.len()]]+=1;i+=1;left-=1}counts
}

fn build_landmasses(input:&GenerateMapRequest)->Vec<GeneratedLandmass>{
    let mut rng=Rng::new(derived_seed(input.seed,0x0a17_a5c1));let mut names=Rng::new(derived_seed(input.seed,0x19ad_5e11));let mut used=HashSet::new();
    let n=input.continents as usize;let aspect=input.width as f64/input.height as f64;let cols=((n as f64*aspect*0.82).sqrt().round() as usize).clamp(1,n);let rows=(n+cols-1)/cols;
    let mut slots:Vec<(usize,usize)>=(0..rows).flat_map(|r|(0..cols).map(move|c|(c,r))).collect();for i in (1..slots.len()).rev(){let j=(rng.next_u32() as usize)%(i+1);slots.swap(i,j)}
    let cell_w=0.86/cols as f64;let cell_h=0.78/rows as f64;let land_scale=(1.0-input.ocean_ratio).powf(0.38);
    let mut result=Vec::with_capacity(n);
    for (i,(col,row)) in slots.into_iter().take(n).enumerate(){
        let cx=0.07+(col as f64+0.5)*cell_w+rng.range(-cell_w*0.11,cell_w*0.11);let cy=0.11+(row as f64+0.5)*cell_h+rng.range(-cell_h*0.11,cell_h*0.11);
        // Anisotropy is sampled independently from scale so continents are not all ellipse-like clones.
        let stretch=rng.range(0.72,1.38);let stretch_root=stretch.sqrt();
        let rx=cell_w*0.48*land_scale*rng.range(0.86,1.18)*stretch_root;let ry=cell_h*0.47*land_scale*rng.range(0.78,1.18)/stretch_root;let rotation=rng.range(-1.05,1.05);
        // Low/mid frequency bands define the silhouette; sparse high frequencies only add coastline texture.
        let harmonic_specs=[(1,0.050),(2,0.155),(3,0.125),(4,0.080),(5,0.060),(8,0.040),(13,0.024),(21,0.011)];
        let harmonics:Vec<(f64,f64,f64)>=harmonic_specs.iter().map(|(k,a)|(*k as f64,*a*rng.range(0.48,1.18),rng.range(0.0,TAU))).collect();
        let mut features:Vec<(f64,f64,f64)>=Vec::with_capacity(12);
        for _ in 0..4{features.push((rng.range(0.0,TAU),rng.range(0.13,0.32),rng.range(0.10,0.30)))}
        for _ in 0..4{features.push((rng.range(0.0,TAU),rng.range(-0.31,-0.12),rng.range(0.08,0.25)))}
        for _ in 0..4{features.push((rng.range(0.0,TAU),rng.range(-0.13,0.17),rng.range(0.07,0.19)))}
        let warp_phase_a=rng.range(0.0,TAU);let warp_phase_b=rng.range(0.0,TAU);let coast_phase=rng.range(0.0,TAU);
        let point_count=256usize;let mut points=Vec::with_capacity(point_count);
        for p in 0..point_count{
            let angle=TAU*p as f64/point_count as f64;
            let theta=angle+0.085*(2.0*angle+warp_phase_a).sin()+0.032*(5.0*angle+warp_phase_b).sin();
            let mut radius=1.0;
            for(k,amp,phase)in&harmonics{radius+=amp*(k*angle+phase).sin()}
            for(center,amp,width)in&features{let d=angle_distance(angle,*center);radius+=amp*(-0.5*(d/width).powi(2)).exp()}
            radius+=0.010*(29.0*angle+coast_phase).sin()+0.006*(37.0*angle+warp_phase_a).sin();
            radius=radius.clamp(0.50,1.62);
            let ux=theta.cos()*rx*radius;let uy=theta.sin()*ry*radius;
            points.push(MapPoint{x:cx+ux*rotation.cos()-uy*rotation.sin(),y:cy+ux*rotation.sin()+uy*rotation.cos()});
        }
        let mut scale:f64=1.0;
        for p in &points{let dx=p.x-cx;let dy=p.y-cy;if p.x<0.035&&dx<0.0{scale=scale.min((cx-0.035)/-dx)}if p.x>0.965&&dx>0.0{scale=scale.min((0.965-cx)/dx)}if p.y<0.045&&dy<0.0{scale=scale.min((cy-0.045)/-dy)}if p.y>0.955&&dy>0.0{scale=scale.min((0.955-cy)/dy)}}
        if scale<1.0{scale*=0.97;for p in&mut points{p.x=cx+(p.x-cx)*scale;p.y=cy+(p.y-cy)*scale}}
        // A light circular smoothing pass removes sampling spikes without erasing bays and peninsulas.
        let old=points.clone();for p in 0..point_count{let a=&old[(p+point_count-1)%point_count];let b=&old[p];let c=&old[(p+1)%point_count];points[p]=MapPoint{x:(a.x+10.0*b.x+c.x)/12.0,y:(a.y+10.0*b.y+c.y)/12.0};}
        result.push(GeneratedLandmass{id:format!("land-{i}"),name:unique_name(&mut names,&mut used),points});
    }
    result
}

fn build_mountains(input:&GenerateMapRequest,landmasses:&[GeneratedLandmass])->(Vec<GeneratedMarker>,Vec<Vec<MapPoint>>){
    let mut rng=Rng::new(derived_seed(input.seed,0xb4a1_7d09));let mut names=Rng::new(derived_seed(input.seed,0xb4a1_7e11));let mut used=HashSet::new();let total=(input.mountain_density*30.0).round() as usize;let areas:Vec<f64>=landmasses.iter().map(|l|polygon_area(&l.points)).collect();let counts=allocate_counts(total,&areas,total>=landmasses.len());let mut output=Vec::with_capacity(total);let mut by_land=vec![Vec::new();landmasses.len()];let mut serial=0usize;
    for (land_idx,(land,&count)) in landmasses.iter().zip(counts.iter()).enumerate(){if count==0{continue}let (min_x,max_x,min_y,max_y)=bbox(&land.points);let diag=(max_x-min_x).min(max_y-min_y);let ranges=(count+9)/10;let mut remaining=count;
        for range_idx in 0..ranges{let segment_count=(remaining+(ranges-range_idx)-1)/(ranges-range_idx);remaining-=segment_count;let center=random_interior(&mut rng,&land.points,120);let angle=rng.range(0.0,TAU);let length=diag*rng.range(0.42,0.76);let curve=rng.range(-0.11,0.11);
            for j in 0..segment_count{let t=if segment_count==1{0.0}else{j as f64/(segment_count-1)as f64-0.5};let along=t*length;let perp=((t+0.5)*PI).sin()*curve;let mut p=MapPoint{x:center.x+angle.cos()*along-angle.sin()*perp+rng.range(-0.005,0.005),y:center.y+angle.sin()*along+angle.cos()*perp+rng.range(-0.005,0.005)};for _ in 0..4{if point_in_polygon(&p,&land.points){break}p.x=(p.x+center.x)*0.5;p.y=(p.y+center.y)*0.5}if !point_in_polygon(&p,&land.points){p=random_interior(&mut rng,&land.points,80)}let base=unique_name(&mut names,&mut used);output.push(GeneratedMarker{id:format!("mount-{serial}"),name:format!("{base} Peaks"),kind:"mountain".into(),x:p.x,y:p.y});by_land[land_idx].push(p);serial+=1;}
        }
    }
    (output,by_land)
}

fn elevation(p:&MapPoint,land:&GeneratedLandmass,mountains:&[MapPoint])->f64{
    if !point_in_polygon(p,&land.points){return -0.05}let coast=nearest_coast(p,&land.points).0;let mut value=(coast/0.12).min(1.0)*0.42;for m in mountains{let d=dist(p,m);value+=0.55*(-0.5*(d/0.045).powi(2)).exp()}value
}
fn trace_river(rng:&mut Rng,source:MapPoint,land:&GeneratedLandmass,mountains:&[MapPoint],existing:&[GeneratedRiver],id:usize)->GeneratedRiver{
    let mut points=vec![source.clone()];let mut p=source;let mut previous=(0.0,0.0);let phase=rng.range(0.0,TAU);let candidate_angles=[0.0,0.18,-0.18,0.36,-0.36,0.55,-0.55];
    for step_idx in 0..50{let(coast,coast_point)=nearest_coast(&p,&land.points);if coast<0.007{points.push(coast_point);break}let eps=0.003;let px=MapPoint{x:p.x+eps,y:p.y};let nx=MapPoint{x:p.x-eps,y:p.y};let py=MapPoint{x:p.x,y:p.y+eps};let ny=MapPoint{x:p.x,y:p.y-eps};let gx=(elevation(&px,land,mountains)-elevation(&nx,land,mountains))/(2.0*eps);let gy=(elevation(&py,land,mountains)-elevation(&ny,land,mountains))/(2.0*eps);let(mut dx,mut dy)=normalize(-gx,-gy);if dx==0.0&&dy==0.0{(dx,dy)=normalize(coast_point.x-p.x,coast_point.y-p.y)}if previous!=(0.0,0.0){(dx,dy)=normalize(dx*0.75+previous.0*0.25,dy*0.75+previous.1*0.25)}let(perp_x,perp_y)=(-dy,dx);let wiggle=0.18*(phase+step_idx as f64*0.9).sin()+rng.range(-0.06,0.06);(dx,dy)=normalize(dx+perp_x*wiggle,dy+perp_y*wiggle);let stride=rng.range(0.010,0.015);let mut best:Option<(f64,MapPoint,(f64,f64))>=None;
        for angle in candidate_angles{let(ux,uy)=rotate(dx,dy,angle);let candidate=MapPoint{x:p.x+ux*stride,y:p.y+uy*stride};if !point_in_polygon(&candidate,&land.points){continue}let loop_penalty=points.iter().rev().skip(4).take(10).map(|old|dist(old,&candidate)).fold(f64::MAX,f64::min);if loop_penalty<0.006{continue}let score=elevation(&candidate,land,mountains)+angle.abs()*0.006;if best.as_ref().map(|x|score<x.0).unwrap_or(true){best=Some((score,candidate,(ux,uy)))}}
        let Some((_,candidate,direction))=best else{points.push(coast_point);break};let mut merged=None;if points.len()>4{for river in existing{for old in river.points.iter().skip(3){if dist(&candidate,old)<0.009{merged=Some(old.clone());break}}if merged.is_some(){break}}}if let Some(join)=merged{points.push(join);break}p=candidate;previous=direction;points.push(p.clone());if step_idx==49{points.push(nearest_coast(&p,&land.points).1)}
    }
    GeneratedRiver{id:format!("river-{id}"),points}
}
fn build_rivers(input:&GenerateMapRequest,landmasses:&[GeneratedLandmass],mountains_by_land:&[Vec<MapPoint>])->(Vec<GeneratedRiver>,Vec<Vec<GeneratedRiver>>){
    let mut rng=Rng::new(derived_seed(input.seed,0x71a3_51d2));let areas:Vec<f64>=landmasses.iter().map(|l|polygon_area(&l.points)).collect();let counts=allocate_counts(input.river_count as usize,&areas,input.river_count as usize>=landmasses.len());let mut all=Vec::new();let mut by_land=vec![Vec::new();landmasses.len()];let mut serial=0usize;
    for(land_idx,(land,&count))in landmasses.iter().zip(counts.iter()).enumerate(){if count==0{continue}let mut sources=mountains_by_land[land_idx].clone();sources.sort_by(|a,b|nearest_coast(b,&land.points).0.partial_cmp(&nearest_coast(a,&land.points).0).unwrap_or(Ordering::Equal));let mut used:Vec<MapPoint>=Vec::new();
        for _ in 0..count{let mut source=None;for candidate in&sources{if used.iter().all(|p|dist(p,candidate)>0.045){source=Some(candidate.clone());break}}let source=source.unwrap_or_else(||random_interior(&mut rng,&land.points,160));used.push(source.clone());let river=trace_river(&mut rng,source,land,&mountains_by_land[land_idx],&by_land[land_idx],serial);serial+=1;by_land[land_idx].push(river.clone());all.push(river);}
    }
    (all,by_land)
}

#[derive(Clone)]
struct SettlementCandidate{score:f64,point:MapPoint}
fn nearest_mountain(p:&MapPoint,mountains:&[MapPoint])->f64{mountains.iter().map(|m|dist(p,m)).fold(f64::MAX,f64::min)}
fn nearest_river(p:&MapPoint,rivers:&[GeneratedRiver])->f64{rivers.iter().map(|r|distance_to_polyline(p,&r.points)).fold(f64::MAX,f64::min)}
fn build_settlements(input:&GenerateMapRequest,landmasses:&[GeneratedLandmass],mountains_by_land:&[Vec<MapPoint>],rivers_by_land:&[Vec<GeneratedRiver>])->Vec<GeneratedMarker>{
    let mut rng=Rng::new(derived_seed(input.seed,0x5e77_1e42));let mut names=Rng::new(derived_seed(input.seed,0x5e77_1e91));let mut used_names=HashSet::new();let areas:Vec<f64>=landmasses.iter().map(|l|polygon_area(&l.points)).collect();let counts=allocate_counts(input.settlement_count as usize,&areas,input.settlement_count as usize>=landmasses.len());let mut output=Vec::with_capacity(input.settlement_count as usize);let mut serial=0usize;
    for(land_idx,(land,&count))in landmasses.iter().zip(counts.iter()).enumerate(){if count==0{continue}let(min_x,max_x,min_y,max_y)=bbox(&land.points);let trials=(count*120).max(360);let mut candidates=Vec::with_capacity(trials/2);
        for _ in 0..trials{let p=MapPoint{x:rng.range(min_x,max_x),y:rng.range(min_y,max_y)};if !point_in_polygon(&p,&land.points){continue}let coast=nearest_coast(&p,&land.points).0;let river=nearest_river(&p,&rivers_by_land[land_idx]);let mountain=nearest_mountain(&p,&mountains_by_land[land_idx]);let coast_score=(-0.5*((coast-0.018)/0.026).powi(2)).exp();let river_score=(-0.5*(river/0.028).powi(2)).exp();let inland=(coast/0.12).min(1.0);let mountain_penalty=(-0.5*(mountain/0.018).powi(2)).exp();let score=0.48*coast_score.max(river_score*0.95)+0.28*river_score+0.08*inland-0.28*mountain_penalty+rng.range(0.0,0.16);candidates.push(SettlementCandidate{score,point:p});}
        candidates.sort_by(|a,b|b.score.partial_cmp(&a.score).unwrap_or(Ordering::Equal));let min_distance=(0.19/((count+1)as f64).sqrt()).clamp(0.027,0.085);let mut selected:Vec<SettlementCandidate>=Vec::with_capacity(count);
        for relax in [1.0,0.85,0.70,0.55,0.40]{for candidate in&candidates{if selected.len()>=count{break}if selected.iter().all(|s|dist(&s.point,&candidate.point)>=min_distance*relax){selected.push(candidate.clone())}}if selected.len()>=count{break}}
        let mut fill_attempts=0usize;while selected.len()<count&&fill_attempts<count*300{let p=random_interior(&mut rng,&land.points,120);if selected.iter().all(|s|dist(&s.point,&p)>=min_distance*0.25){selected.push(SettlementCandidate{score:0.0,point:p})}fill_attempts+=1}
        while selected.len()<count{let p=random_interior(&mut rng,&land.points,80);selected.push(SettlementCandidate{score:0.0,point:p})}
        selected.truncate(count);let mut rank:Vec<usize>=(0..selected.len()).collect();rank.sort_by(|&a,&b|selected[b].score.partial_cmp(&selected[a].score).unwrap_or(Ordering::Equal));let city_count=if count>=9{2}else{1.min(count)};let town_count=((count as f64*0.40).round()as usize).min(count.saturating_sub(city_count));let mut kinds=vec!["village";count];for&idx in rank.iter().take(city_count){kinds[idx]="city"}for&idx in rank.iter().skip(city_count).take(town_count){kinds[idx]="town"}
        for(i,candidate)in selected.into_iter().enumerate(){output.push(GeneratedMarker{id:format!("settlement-{serial}"),name:unique_name(&mut names,&mut used_names),kind:kinds[i].into(),x:candidate.point.x,y:candidate.point.y});serial+=1;}
    }
    output
}

pub fn generate(input: GenerateMapRequest) -> Result<GeneratedMapDraft, AtlasError> {
    if !(320..=8192).contains(&input.width) || !(240..=8192).contains(&input.height) { return Err(AtlasError::Validation("map dimensions are out of range".into())); }
    if !(1..=8).contains(&input.continents) { return Err(AtlasError::Validation("continents must be between 1 and 8".into())); }
    if !(0.20..=0.90).contains(&input.ocean_ratio) { return Err(AtlasError::Validation("ocean ratio must be between 0.20 and 0.90".into())); }
    if !(0.0..=1.0).contains(&input.mountain_density) { return Err(AtlasError::Validation("mountain density must be between 0 and 1".into())); }
    if input.river_count > 30 || input.settlement_count > 80 { return Err(AtlasError::Validation("generator counts are too large".into())); }

    let landmasses=build_landmasses(&input);
    let(mountains,mountains_by_land)=build_mountains(&input,&landmasses);
    let(rivers,rivers_by_land)=build_rivers(&input,&landmasses,&mountains_by_land);
    let settlements=build_settlements(&input,&landmasses,&mountains_by_land,&rivers_by_land);
    Ok(GeneratedMapDraft{seed:input.seed,name:input.name.unwrap_or_else(||format!("Generated World {}",input.seed)),width:input.width,height:input.height,ocean_ratio:input.ocean_ratio,landmasses,mountains,rivers,settlements})
}

#[cfg(test)]
mod tests{
    use super::*;
    fn request(seed:u32)->GenerateMapRequest{GenerateMapRequest{seed,name:Some("Asterra".into()),width:1200,height:760,continents:3,ocean_ratio:0.55,mountain_density:0.55,river_count:6,settlement_count:12}}
    #[test]fn same_seed_is_stable(){let a=generate(request(482193)).expect("generator quality fixture");let b=generate(request(482193)).expect("generator quality fixture");assert_eq!(serde_json::to_string(&a).expect("serialize a"),serde_json::to_string(&b).expect("serialize b"));}
    #[test]fn coastlines_settlements_and_rivers_have_quality_invariants(){let d=generate(request(482193)).expect("generator quality fixture");assert!(d.landmasses.iter().all(|l|l.points.len()>=220));let mut names=HashSet::new();for s in&d.settlements{assert!(names.insert(s.name.clone()));assert!(d.landmasses.iter().any(|l|point_in_polygon(&MapPoint{x:s.x,y:s.y},&l.points)),"settlement must be on land");}for(i,r)in d.rivers.iter().enumerate(){assert!(r.points.len()>=2);let end=r.points.last().expect("river endpoint");let coast=d.landmasses.iter().map(|l|nearest_coast(end,&l.points).0).fold(f64::MAX,f64::min);let confluence=d.rivers.iter().enumerate().filter(|(j,_)|*j!=i).any(|(_,other)|other.points.iter().any(|p|dist(end,p)<0.012));assert!(coast<0.012||confluence,"river must terminate at a coast or another river");}}
    #[test]fn seed_changes_create_distinct_high_resolution_silhouettes(){let a=generate(request(11883)).expect("first seed");let b=generate(request(991271)).expect("second seed");assert!(a.landmasses.iter().all(|l|l.points.len()==256));assert!(b.landmasses.iter().all(|l|l.points.len()==256));let a0=serde_json::to_string(&a.landmasses[0].points).expect("serialize first coastline");let b0=serde_json::to_string(&b.landmasses[0].points).expect("serialize second coastline");assert_ne!(a0,b0,"different seeds should not collapse to the same silhouette");}
}
