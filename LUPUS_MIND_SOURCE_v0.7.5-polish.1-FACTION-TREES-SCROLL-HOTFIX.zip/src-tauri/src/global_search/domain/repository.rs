use crate::global_search::domain::{error::SearchError, search::SearchHit};
pub trait GlobalSearchRepository: Send + Sync { fn search(&self, query: &str, limit: u32) -> Result<Vec<SearchHit>, SearchError>; }
