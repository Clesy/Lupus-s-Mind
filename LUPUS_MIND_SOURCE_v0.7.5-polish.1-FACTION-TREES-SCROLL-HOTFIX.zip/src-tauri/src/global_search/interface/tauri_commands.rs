use tauri::State;
use crate::{app_state::AppState, global_search::{application::service, domain::search::SearchHit}, shared::api_error::ApiError};
#[tauri::command] pub fn global_search(state: State<'_, AppState>, query: String, limit: Option<u32>) -> Result<Vec<SearchHit>, ApiError> { service::search(&state.search, &query, limit.unwrap_or(20)).map_err(Into::into) }
