use crate::global_search::domain::{error::SearchError, repository::GlobalSearchRepository, search::SearchHit};
pub fn search(repo: &dyn GlobalSearchRepository, query: &str, limit: u32) -> Result<Vec<SearchHit>, SearchError> {
    let query = query.trim();
    if query.is_empty() { return Ok(Vec::new()); }
    if query.chars().count() > 180 { return Err(SearchError::Validation("search query must be 180 characters or fewer".into())); }
    repo.search(query, limit.clamp(1, 50))
}
