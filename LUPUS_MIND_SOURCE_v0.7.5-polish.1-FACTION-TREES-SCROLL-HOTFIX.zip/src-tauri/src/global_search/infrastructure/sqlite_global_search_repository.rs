use rusqlite::params;
use crate::{global_search::domain::{error::SearchError, repository::GlobalSearchRepository, search::SearchHit}, shared::database::SharedConnection};

#[derive(Clone)]
pub struct SqliteGlobalSearchRepository { conn: SharedConnection }
impl SqliteGlobalSearchRepository { pub fn new(conn: SharedConnection) -> Self { Self { conn } } }

impl GlobalSearchRepository for SqliteGlobalSearchRepository {
    fn search(&self, query: &str, limit: u32) -> Result<Vec<SearchHit>, SearchError> {
        let conn = self.conn.lock().map_err(|e| SearchError::Database(e.to_string()))?;
        let needle = format!("%{}%", query.replace('%', "\\%").replace('_', "\\_"));
        let sql = r#"
          SELECT id, kind, title, subtitle, route FROM (
            SELECT id, 'character' AS kind, name AS title,
                   trim(COALESCE(class_label,'') || CASE WHEN alias IS NULL OR alias='' THEN '' ELSE ' · ' || alias END) AS subtitle,
                   'characters' AS route
              FROM characters WHERE name LIKE ?1 ESCAPE '\' COLLATE NOCASE OR COALESCE(alias,'') LIKE ?1 ESCAPE '\' COLLATE NOCASE OR biography LIKE ?1 ESCAPE '\' COLLATE NOCASE OR tags LIKE ?1 ESCAPE '\' COLLATE NOCASE
            UNION ALL
            SELECT id, 'item', name, item_type || ' · ' || rarity, 'items'
              FROM items WHERE name LIKE ?1 ESCAPE '\' COLLATE NOCASE OR description LIKE ?1 ESCAPE '\' COLLATE NOCASE OR tags LIKE ?1 ESCAPE '\' COLLATE NOCASE
            UNION ALL
            SELECT id, 'skill', name, kind || ' · ' || CAST(base_power AS TEXT) || ' power', 'skills'
              FROM skills WHERE name LIKE ?1 ESCAPE '\' COLLATE NOCASE OR description LIKE ?1 ESCAPE '\' COLLATE NOCASE OR tags LIKE ?1 ESCAPE '\' COLLATE NOCASE
            UNION ALL
            SELECT id, 'timeline', title, 'Chapter ' || CAST(start_chapter AS TEXT) || ' · ' || kind, 'timeline'
              FROM timeline_events WHERE title LIKE ?1 ESCAPE '\' COLLATE NOCASE OR description LIKE ?1 ESCAPE '\' COLLATE NOCASE OR tags LIKE ?1 ESCAPE '\' COLLATE NOCASE OR COALESCE(location_label,'') LIKE ?1 ESCAPE '\' COLLATE NOCASE
            UNION ALL
            SELECT id, 'chapter', CASE WHEN title='' THEN 'Chapter ' || CAST(chapter_number AS TEXT) ELSE title END,
                   'Chapter ' || CAST(chapter_number AS TEXT) || ' · ' || status, 'manuscript'
              FROM manuscript_chapters WHERE title LIKE ?1 ESCAPE '\' COLLATE NOCASE OR content LIKE ?1 ESCAPE '\' COLLATE NOCASE OR notes LIKE ?1 ESCAPE '\' COLLATE NOCASE OR tags LIKE ?1 ESCAPE '\' COLLATE NOCASE
            UNION ALL
            SELECT id, 'lore', title, category || CASE WHEN summary='' THEN '' ELSE ' · ' || summary END, 'lore'
              FROM lore_pages WHERE title LIKE ?1 ESCAPE '\' COLLATE NOCASE OR category LIKE ?1 ESCAPE '\' COLLATE NOCASE OR summary LIKE ?1 ESCAPE '\' COLLATE NOCASE OR content LIKE ?1 ESCAPE '\' COLLATE NOCASE OR tags LIKE ?1 ESCAPE '\' COLLATE NOCASE
            UNION ALL
            SELECT id, 'faction', name, kind || CASE WHEN motto='' THEN '' ELSE ' · ' || motto END, 'factions'
              FROM factions WHERE name LIKE ?1 ESCAPE '\' COLLATE NOCASE OR description LIKE ?1 ESCAPE '\' COLLATE NOCASE OR motto LIKE ?1 ESCAPE '\' COLLATE NOCASE OR tags LIKE ?1 ESCAPE '\' COLLATE NOCASE
            UNION ALL
            SELECT id, 'quest', title, status || CASE WHEN summary='' THEN '' ELSE ' · ' || summary END, 'quests'
              FROM quests WHERE title LIKE ?1 ESCAPE '\' COLLATE NOCASE OR summary LIKE ?1 ESCAPE '\' COLLATE NOCASE OR description LIKE ?1 ESCAPE '\' COLLATE NOCASE OR tags LIKE ?1 ESCAPE '\' COLLATE NOCASE
            UNION ALL
            SELECT id, 'secret', title, importance || CASE WHEN description='' THEN '' ELSE ' · ' || description END, 'secrets'
              FROM secrets WHERE title LIKE ?1 ESCAPE '\' COLLATE NOCASE OR description LIKE ?1 ESCAPE '\' COLLATE NOCASE OR tags LIKE ?1 ESCAPE '\' COLLATE NOCASE
            UNION ALL
            SELECT id, 'location', name, kind || CASE WHEN description='' THEN '' ELSE ' · ' || description END, 'atlas'
              FROM locations WHERE name LIKE ?1 ESCAPE '\' COLLATE NOCASE OR kind LIKE ?1 ESCAPE '\' COLLATE NOCASE OR description LIKE ?1 ESCAPE '\' COLLATE NOCASE OR tags LIKE ?1 ESCAPE '\' COLLATE NOCASE
            UNION ALL
            SELECT id, 'map', name, background || CASE WHEN generator_seed IS NULL THEN '' ELSE ' · seed ' || CAST(generator_seed AS TEXT) END, 'atlas'
              FROM atlas_maps WHERE name LIKE ?1 ESCAPE '\' COLLATE NOCASE OR background LIKE ?1 ESCAPE '\' COLLATE NOCASE
            UNION ALL
            SELECT r.id, 'relationship', c1.name || ' ↔ ' || c2.name, rt.forward_label, 'relationships'
              FROM relationships r JOIN characters c1 ON c1.id=r.source_character_id JOIN characters c2 ON c2.id=r.target_character_id JOIN relationship_types rt ON rt.id=r.type_id
             WHERE c1.name LIKE ?1 ESCAPE '\' COLLATE NOCASE OR c2.name LIKE ?1 ESCAPE '\' COLLATE NOCASE OR rt.forward_label LIKE ?1 ESCAPE '\' COLLATE NOCASE OR rt.inverse_label LIKE ?1 ESCAPE '\' COLLATE NOCASE
          ) LIMIT ?2
        "#;
        let mut stmt = conn.prepare(sql).map_err(|e| SearchError::Database(e.to_string()))?;
        let rows = stmt.query_map(params![needle, i64::from(limit)], |row| Ok((row.get::<_, String>(0)?, row.get::<_, String>(1)?, row.get::<_, String>(2)?, row.get::<_, String>(3)?, row.get::<_, String>(4)?))).map_err(|e| SearchError::Database(e.to_string()))?;
        let query_lower = query.to_lowercase();
        let mut out = Vec::new();
        for row in rows {
            let (id, kind, title, subtitle, route) = row.map_err(|e| SearchError::Database(e.to_string()))?;
            let title_lower = title.to_lowercase();
            let score = if title_lower == query_lower { 100 } else if title_lower.starts_with(&query_lower) { 80 } else if title_lower.contains(&query_lower) { 60 } else { 30 };
            out.push(SearchHit { id, kind, title, subtitle, route, score });
        }
        out.sort_by(|a,b| b.score.cmp(&a.score).then_with(|| a.title.cmp(&b.title)));
        out.truncate(limit as usize);
        Ok(out)
    }
}
