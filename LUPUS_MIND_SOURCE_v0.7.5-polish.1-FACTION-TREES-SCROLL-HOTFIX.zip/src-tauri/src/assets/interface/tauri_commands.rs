use tauri::State;
use crate::{app_state::AppState, assets::application::service::{self, PortraitAssetDto}, shared::api_error::ApiError};

#[tauri::command]
pub fn character_portrait_get(state: State<'_, AppState>, character_id: String) -> Result<Option<PortraitAssetDto>, ApiError> {
    service::get(&state.characters, &state.assets, &character_id).map_err(|error| ApiError::new("asset_error", error.to_string()))
}

#[tauri::command]
pub fn character_portrait_put(state: State<'_, AppState>, character_id: String, mime_type: String, bytes: Vec<u8>) -> Result<PortraitAssetDto, ApiError> {
    service::put(&state.characters, &state.assets, &character_id, &mime_type, bytes).map_err(|error| ApiError::new("asset_error", error.to_string()))
}

#[tauri::command]
pub fn character_portrait_delete(state: State<'_, AppState>, character_id: String) -> Result<(), ApiError> {
    service::delete(&state.characters, &state.assets, &character_id).map_err(|error| ApiError::new("asset_error", error.to_string()))
}

#[tauri::command]
pub fn item_artwork_get(state: State<'_, AppState>, item_id: String) -> Result<Option<PortraitAssetDto>, ApiError> {
    service::get_item_artwork(&state.items, &state.assets, &item_id).map_err(|error| ApiError::new("asset_error", error.to_string()))
}

#[tauri::command]
pub fn item_artwork_put(state: State<'_, AppState>, item_id: String, mime_type: String, bytes: Vec<u8>) -> Result<PortraitAssetDto, ApiError> {
    service::put_item_artwork(&state.items, &state.assets, &item_id, &mime_type, bytes).map_err(|error| ApiError::new("asset_error", error.to_string()))
}

#[tauri::command]
pub fn item_artwork_delete(state: State<'_, AppState>, item_id: String) -> Result<(), ApiError> {
    service::delete_item_artwork(&state.items, &state.assets, &item_id).map_err(|error| ApiError::new("asset_error", error.to_string()))
}
