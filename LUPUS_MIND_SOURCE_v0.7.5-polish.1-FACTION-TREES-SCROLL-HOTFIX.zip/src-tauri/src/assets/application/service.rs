use serde::Serialize;
use crate::{
    assets::{application::port::{CharacterPortraitStorage, ItemArtworkStorage}, domain::error::AssetError},
    characters::{domain::{character::CharacterId, repository::CharacterRepository}},
    items::domain::{item::ItemId, repository::ItemRepository},
};

const MAX_PORTRAIT_BYTES: usize = 2 * 1024 * 1024;
const ALLOWED_MIME: [&str; 3] = ["image/jpeg", "image/png", "image/webp"];

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct PortraitAssetDto {
    pub mime_type: String,
    pub bytes: Vec<u8>,
}

fn validate_asset(mime_type: &str, bytes: &[u8], label: &str) -> Result<(), AssetError> {
    if !ALLOWED_MIME.contains(&mime_type) {
        return Err(AssetError::Validation(format!("{label} must be JPEG, PNG or WebP")));
    }
    if bytes.is_empty() || bytes.len() > MAX_PORTRAIT_BYTES {
        return Err(AssetError::Validation(format!("{label} must be between 1 byte and {MAX_PORTRAIT_BYTES} bytes")));
    }
    Ok(())
}

fn ensure_character(characters: &dyn CharacterRepository, character_id: &str) -> Result<(), AssetError> {
    let id = CharacterId(character_id.to_string());
    let exists = characters.get(&id).map_err(|error| AssetError::Filesystem(error.to_string()))?.is_some();
    if exists { Ok(()) } else { Err(AssetError::CharacterNotFound(character_id.to_string())) }
}

fn ensure_item(items: &dyn ItemRepository, item_id: &str) -> Result<(), AssetError> {
    let id = ItemId(item_id.to_string());
    let exists = items.get(&id).map_err(|error| AssetError::Filesystem(error.to_string()))?.is_some();
    if exists { Ok(()) } else { Err(AssetError::ItemNotFound(item_id.to_string())) }
}

pub fn get(characters: &dyn CharacterRepository, storage: &dyn CharacterPortraitStorage, character_id: &str) -> Result<Option<PortraitAssetDto>, AssetError> {
    ensure_character(characters, character_id)?;
    storage.get(character_id).map(|value| value.map(|asset| PortraitAssetDto { mime_type: asset.mime_type, bytes: asset.bytes }))
}

pub fn put(characters: &dyn CharacterRepository, storage: &dyn CharacterPortraitStorage, character_id: &str, mime_type: &str, bytes: Vec<u8>) -> Result<PortraitAssetDto, AssetError> {
    ensure_character(characters, character_id)?;
    validate_asset(mime_type, &bytes, "portrait")?;
    let asset = storage.put(character_id, mime_type, &bytes)?;
    Ok(PortraitAssetDto { mime_type: asset.mime_type, bytes: asset.bytes })
}

pub fn delete(characters: &dyn CharacterRepository, storage: &dyn CharacterPortraitStorage, character_id: &str) -> Result<(), AssetError> {
    ensure_character(characters, character_id)?;
    storage.delete(character_id)
}

pub fn get_item_artwork(items: &dyn ItemRepository, storage: &dyn ItemArtworkStorage, item_id: &str) -> Result<Option<PortraitAssetDto>, AssetError> {
    ensure_item(items, item_id)?;
    storage.get_item_artwork(item_id).map(|value| value.map(|asset| PortraitAssetDto { mime_type: asset.mime_type, bytes: asset.bytes }))
}

pub fn put_item_artwork(items: &dyn ItemRepository, storage: &dyn ItemArtworkStorage, item_id: &str, mime_type: &str, bytes: Vec<u8>) -> Result<PortraitAssetDto, AssetError> {
    ensure_item(items, item_id)?;
    validate_asset(mime_type, &bytes, "item artwork")?;
    let asset = storage.put_item_artwork(item_id, mime_type, &bytes)?;
    Ok(PortraitAssetDto { mime_type: asset.mime_type, bytes: asset.bytes })
}

pub fn delete_item_artwork(items: &dyn ItemRepository, storage: &dyn ItemArtworkStorage, item_id: &str) -> Result<(), AssetError> {
    ensure_item(items, item_id)?;
    storage.delete_item_artwork(item_id)
}
