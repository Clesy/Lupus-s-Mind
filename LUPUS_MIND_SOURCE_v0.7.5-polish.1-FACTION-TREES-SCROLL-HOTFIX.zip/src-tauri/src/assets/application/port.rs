use crate::assets::domain::error::AssetError;

#[derive(Debug, Clone)]
pub struct StoredAsset {
    pub mime_type: String,
    pub bytes: Vec<u8>,
}

pub trait CharacterPortraitStorage: Send + Sync {
    fn get(&self, character_id: &str) -> Result<Option<StoredAsset>, AssetError>;
    fn put(&self, character_id: &str, mime_type: &str, bytes: &[u8]) -> Result<StoredAsset, AssetError>;
    fn delete(&self, character_id: &str) -> Result<(), AssetError>;
}

pub trait ItemArtworkStorage: Send + Sync {
    fn get_item_artwork(&self, item_id: &str) -> Result<Option<StoredAsset>, AssetError>;
    fn put_item_artwork(&self, item_id: &str, mime_type: &str, bytes: &[u8]) -> Result<StoredAsset, AssetError>;
    fn delete_item_artwork(&self, item_id: &str) -> Result<(), AssetError>;
}
