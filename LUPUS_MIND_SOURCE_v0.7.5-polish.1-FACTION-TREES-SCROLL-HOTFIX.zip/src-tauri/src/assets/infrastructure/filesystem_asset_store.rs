use std::{fs, path::{Path, PathBuf}};
use crate::{
    assets::{application::port::{CharacterPortraitStorage, ItemArtworkStorage, StoredAsset}, domain::error::AssetError},
    projects::infrastructure::project_registry::SharedDatabasePath,
};

#[derive(Clone)]
pub struct FileSystemAssetStore {
    active_database_path: SharedDatabasePath,
}

impl FileSystemAssetStore {
    pub fn new(active_database_path: SharedDatabasePath) -> Self { Self { active_database_path } }

    fn validate_id(id: &str) -> Result<(), AssetError> {
        if id.is_empty() || !id.chars().all(|ch| ch.is_ascii_alphanumeric() || ch == '-' || ch == '_') {
            return Err(AssetError::Validation("invalid id for asset storage".into()));
        }
        Ok(())
    }

    fn asset_dir(&self, category: &str) -> Result<PathBuf, AssetError> {
        let database = self.active_database_path.lock().map_err(|error| AssetError::Filesystem(error.to_string()))?.clone();
        let parent = database.parent().unwrap_or_else(|| Path::new("."));
        let stem = database.file_stem().and_then(|value| value.to_str()).unwrap_or("workspace");
        Ok(parent.join(format!("{stem}-assets")).join(category))
    }

    fn extension(mime_type: &str) -> Result<&'static str, AssetError> {
        match mime_type {
            "image/jpeg" => Ok("jpg"),
            "image/png" => Ok("png"),
            "image/webp" => Ok("webp"),
            _ => Err(AssetError::Validation("unsupported artwork MIME type".into())),
        }
    }

    fn candidates(dir: &Path, id: &str) -> [PathBuf; 3] {
        [dir.join(format!("{id}.jpg")), dir.join(format!("{id}.png")), dir.join(format!("{id}.webp"))]
    }

    fn mime_from_path(path: &Path) -> &'static str {
        match path.extension().and_then(|value| value.to_str()).unwrap_or_default().to_ascii_lowercase().as_str() {
            "png" => "image/png",
            "webp" => "image/webp",
            _ => "image/jpeg",
        }
    }

    fn get_asset(&self, category: &str, id: &str) -> Result<Option<StoredAsset>, AssetError> {
        Self::validate_id(id)?;
        let dir = self.asset_dir(category)?;
        for path in Self::candidates(&dir, id) {
            if path.is_file() {
                let bytes = fs::read(&path).map_err(|error| AssetError::Filesystem(error.to_string()))?;
                return Ok(Some(StoredAsset { mime_type: Self::mime_from_path(&path).into(), bytes }));
            }
        }
        Ok(None)
    }

    fn put_asset(&self, category: &str, id: &str, mime_type: &str, bytes: &[u8]) -> Result<StoredAsset, AssetError> {
        Self::validate_id(id)?;
        let extension = Self::extension(mime_type)?;
        let dir = self.asset_dir(category)?;
        fs::create_dir_all(&dir).map_err(|error| AssetError::Filesystem(error.to_string()))?;
        for candidate in Self::candidates(&dir, id) {
            if candidate.extension().and_then(|value| value.to_str()) != Some(extension) && candidate.exists() {
                fs::remove_file(candidate).map_err(|error| AssetError::Filesystem(error.to_string()))?;
            }
        }
        let target = dir.join(format!("{id}.{extension}"));
        let temporary = dir.join(format!(".{id}.{extension}.tmp"));
        fs::write(&temporary, bytes).map_err(|error| AssetError::Filesystem(error.to_string()))?;
        if target.exists() { fs::remove_file(&target).map_err(|error| AssetError::Filesystem(error.to_string()))?; }
        fs::rename(&temporary, &target).map_err(|error| AssetError::Filesystem(error.to_string()))?;
        Ok(StoredAsset { mime_type: mime_type.to_string(), bytes: bytes.to_vec() })
    }

    fn delete_asset(&self, category: &str, id: &str) -> Result<(), AssetError> {
        Self::validate_id(id)?;
        let dir = self.asset_dir(category)?;
        for path in Self::candidates(&dir, id) {
            if path.exists() { fs::remove_file(path).map_err(|error| AssetError::Filesystem(error.to_string()))?; }
        }
        Ok(())
    }
}

impl CharacterPortraitStorage for FileSystemAssetStore {
    fn get(&self, character_id: &str) -> Result<Option<StoredAsset>, AssetError> { self.get_asset("characters", character_id) }
    fn put(&self, character_id: &str, mime_type: &str, bytes: &[u8]) -> Result<StoredAsset, AssetError> { self.put_asset("characters", character_id, mime_type, bytes) }
    fn delete(&self, character_id: &str) -> Result<(), AssetError> { self.delete_asset("characters", character_id) }
}

impl ItemArtworkStorage for FileSystemAssetStore {
    fn get_item_artwork(&self, item_id: &str) -> Result<Option<StoredAsset>, AssetError> { self.get_asset("items", item_id) }
    fn put_item_artwork(&self, item_id: &str, mime_type: &str, bytes: &[u8]) -> Result<StoredAsset, AssetError> { self.put_asset("items", item_id, mime_type, bytes) }
    fn delete_item_artwork(&self, item_id: &str) -> Result<(), AssetError> { self.delete_asset("items", item_id) }
}
