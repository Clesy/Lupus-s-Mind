use thiserror::Error;

#[derive(Debug, Error)]
pub enum AssetError {
    #[error("asset validation failed: {0}")]
    Validation(String),
    #[error("asset filesystem error: {0}")]
    Filesystem(String),
    #[error("character not found: {0}")]
    CharacterNotFound(String),
    #[error("item not found: {0}")]
    ItemNotFound(String),
}
