use std::collections::HashMap;
use serde::Serialize;
use crate::{
    characters::domain::repository::CharacterRepository,
    relationships::domain::{
        error::RelationshipError,
        relationship::Directionality,
        repository::{RelationshipRepository, RelationshipTypeRepository},
    },
};

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all="camelCase")]
pub struct RelationshipNodeDto { pub id:String,pub name:String,pub alias:Option<String>,pub level:u32,pub class_label:Option<String> }

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all="camelCase")]
pub struct RelationshipEdgeDto {
    pub relationship_id:String,
    pub type_id:String,
    pub type_key:String,
    pub source_character_id:String,
    pub target_character_id:String,
    pub forward_label:String,
    pub inverse_label:String,
    pub directionality:Directionality,
    pub intensity:u8,
    pub note:String,
    pub valid_from_chapter:u32,
    pub valid_to_chapter:Option<u32>,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all="camelCase")]
pub struct RelationshipGraphSnapshotDto { pub chapter:u32,pub nodes:Vec<RelationshipNodeDto>,pub edges:Vec<RelationshipEdgeDto> }

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all="camelCase")]
pub struct RelationshipMatrixCellDto { pub row_character_id:String,pub column_character_id:String,pub relationship_id:String,pub label:String,pub intensity:u8,pub type_key:String }

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all="camelCase")]
pub struct RelationshipMatrixSnapshotDto { pub chapter:u32,pub nodes:Vec<RelationshipNodeDto>,pub cells:Vec<RelationshipMatrixCellDto> }

fn build(
    characters:&dyn CharacterRepository,
    types:&dyn RelationshipTypeRepository,
    relationships:&dyn RelationshipRepository,
    chapter:u32,
)->Result<(Vec<RelationshipNodeDto>,Vec<RelationshipEdgeDto>),RelationshipError>{
    if chapter==0{return Err(RelationshipError::Validation("chapter must be > 0".into()));}
    let nodes=characters.list().map_err(|e|RelationshipError::Database(e.to_string()))?.into_iter().map(|c|RelationshipNodeDto{id:c.id.0,name:c.name,alias:c.alias,level:c.level,class_label:c.class_label}).collect::<Vec<_>>();
    let type_map=types.list_types()?.into_iter().map(|t|(t.id.0.clone(),t)).collect::<HashMap<_,_>>();
    let mut edges=Vec::new();
    for (relationship,state) in relationships.list_all_at(chapter)? {
        let ty=type_map.get(&relationship.type_id.0).ok_or_else(||RelationshipError::Mapping(format!("missing relationship type: {}",relationship.type_id.0)))?;
        edges.push(RelationshipEdgeDto{relationship_id:relationship.id.0,type_id:ty.id.0.clone(),type_key:ty.key.clone(),source_character_id:relationship.source_character_id.0,target_character_id:relationship.target_character_id.0,forward_label:ty.forward_label.clone(),inverse_label:ty.inverse_label.clone(),directionality:ty.directionality,intensity:state.intensity,note:state.note,valid_from_chapter:state.valid_from_chapter,valid_to_chapter:state.valid_to_chapter});
    }
    Ok((nodes,edges))
}

pub fn graph_at_chapter(characters:&dyn CharacterRepository,types:&dyn RelationshipTypeRepository,relationships:&dyn RelationshipRepository,chapter:u32)->Result<RelationshipGraphSnapshotDto,RelationshipError>{let(nodes,edges)=build(characters,types,relationships,chapter)?;Ok(RelationshipGraphSnapshotDto{chapter,nodes,edges})}

pub fn matrix_at_chapter(characters:&dyn CharacterRepository,types:&dyn RelationshipTypeRepository,relationships:&dyn RelationshipRepository,chapter:u32)->Result<RelationshipMatrixSnapshotDto,RelationshipError>{
    let(nodes,edges)=build(characters,types,relationships,chapter)?;let mut cells=Vec::new();
    for edge in &edges {
        cells.push(RelationshipMatrixCellDto{row_character_id:edge.source_character_id.clone(),column_character_id:edge.target_character_id.clone(),relationship_id:edge.relationship_id.clone(),label:edge.forward_label.clone(),intensity:edge.intensity,type_key:edge.type_key.clone()});
        cells.push(RelationshipMatrixCellDto{row_character_id:edge.target_character_id.clone(),column_character_id:edge.source_character_id.clone(),relationship_id:edge.relationship_id.clone(),label:if edge.directionality==Directionality::Symmetric{edge.forward_label.clone()}else{edge.inverse_label.clone()},intensity:edge.intensity,type_key:edge.type_key.clone()});
    }
    Ok(RelationshipMatrixSnapshotDto{chapter,nodes,cells})
}
