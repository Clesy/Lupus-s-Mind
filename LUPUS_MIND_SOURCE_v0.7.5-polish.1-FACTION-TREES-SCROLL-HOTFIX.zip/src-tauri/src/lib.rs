pub mod app_state;
pub mod assets;
pub mod workspace;
pub mod projects;
pub mod manuscript;
pub mod global_search;
pub mod lore;
pub mod knowledge_links;
pub mod authoring;
pub mod factions;
pub mod inventory;
pub mod quests;
pub mod secrets;
pub mod atlas;
pub mod creative_generators;
pub mod combat_replay;
pub mod combat;
pub mod status_effects;
pub mod character_sheet;
pub mod characters;
pub mod equipment;
pub mod items;
pub mod shared;
pub mod skills;
pub mod skill_evaluation;
pub mod relationships;
pub mod relationship_graph;
pub mod timeline;
pub mod timeline_projection;

use tauri::Manager;

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .setup(|app| {
            let dir = app.path().app_data_dir()?;
            std::fs::create_dir_all(&dir)?;
            let state = app_state::AppState::open_managed(&dir).map_err(|error| std::io::Error::other(error.to_string()))?;
            app.manage(state);
            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            assets::interface::tauri_commands::character_portrait_get,
            assets::interface::tauri_commands::character_portrait_put,
            assets::interface::tauri_commands::character_portrait_delete,
            assets::interface::tauri_commands::item_artwork_get,
            assets::interface::tauri_commands::item_artwork_put,
            assets::interface::tauri_commands::item_artwork_delete,
            projects::interface::tauri_commands::projects_list,
            projects::interface::tauri_commands::projects_current,
            projects::interface::tauri_commands::projects_create,
            projects::interface::tauri_commands::projects_switch,
            global_search::interface::tauri_commands::global_search,
            lore::interface::tauri_commands::lore_pages_list,
            lore::interface::tauri_commands::lore_page_get,
            lore::interface::tauri_commands::lore_page_create,
            lore::interface::tauri_commands::lore_page_update,
            lore::interface::tauri_commands::lore_page_delete,
            knowledge_links::interface::tauri_commands::knowledge_mentions_for_source,
            knowledge_links::interface::tauri_commands::knowledge_backlinks_for_target,
            authoring::interface::tauri_commands::character_arc_list,
            authoring::interface::tauri_commands::character_arc_create,
            authoring::interface::tauri_commands::character_arc_update,
            authoring::interface::tauri_commands::character_arc_delete,
            authoring::interface::tauri_commands::scene_plans_list,
            authoring::interface::tauri_commands::scene_plan_create,
            authoring::interface::tauri_commands::scene_plan_update,
            authoring::interface::tauri_commands::scene_plan_delete,
            factions::interface::tauri_commands::factions_list,
            factions::interface::tauri_commands::faction_get,
            factions::interface::tauri_commands::faction_create,
            factions::interface::tauri_commands::faction_update,
            factions::interface::tauri_commands::faction_delete,
            factions::interface::tauri_commands::faction_memberships_list,
            factions::interface::tauri_commands::faction_membership_add,
            factions::interface::tauri_commands::faction_membership_end,
            factions::interface::tauri_commands::faction_relations_at,
            factions::interface::tauri_commands::faction_relation_set,
            factions::interface::tauri_commands::faction_hierarchy_roles_list,
            factions::interface::tauri_commands::faction_hierarchy_role_create,
            factions::interface::tauri_commands::faction_hierarchy_role_update,
            factions::interface::tauri_commands::faction_hierarchy_role_delete,
            factions::interface::tauri_commands::faction_hierarchy_seed_defaults,
            factions::interface::tauri_commands::faction_role_assignments_at,
            factions::interface::tauri_commands::faction_role_assign,
            factions::interface::tauri_commands::faction_role_assignment_end,
            factions::interface::tauri_commands::lineages_list,
            factions::interface::tauri_commands::lineage_create,
            factions::interface::tauri_commands::lineage_update,
            factions::interface::tauri_commands::lineage_delete,
            factions::interface::tauri_commands::lineage_memberships_at,
            factions::interface::tauri_commands::lineage_membership_add,
            factions::interface::tauri_commands::lineage_membership_end,
            inventory::interface::tauri_commands::inventory_list_at,
            inventory::interface::tauri_commands::inventory_transfer,
            inventory::interface::tauri_commands::inventory_release,
            quests::interface::tauri_commands::quests_list,
            quests::interface::tauri_commands::quest_get,
            quests::interface::tauri_commands::quest_create,
            quests::interface::tauri_commands::quest_update,
            quests::interface::tauri_commands::quest_delete,
            quests::interface::tauri_commands::quest_objective_add,
            quests::interface::tauri_commands::quest_objective_update,
            quests::interface::tauri_commands::quest_objective_delete,
            quests::interface::tauri_commands::quest_links_set,
            secrets::interface::tauri_commands::secrets_list,
            secrets::interface::tauri_commands::secret_get,
            secrets::interface::tauri_commands::secret_create,
            secrets::interface::tauri_commands::secret_update,
            secrets::interface::tauri_commands::secret_delete,
            secrets::interface::tauri_commands::secret_knowledge_at,
            secrets::interface::tauri_commands::secret_matrix_at,
            secrets::interface::tauri_commands::secret_knowledge_set,
            secrets::interface::tauri_commands::secret_knowledge_forget,
            atlas::interface::tauri_commands::atlas_locations_list,
            atlas::interface::tauri_commands::atlas_location_get,
            atlas::interface::tauri_commands::atlas_location_create,
            atlas::interface::tauri_commands::atlas_location_update,
            atlas::interface::tauri_commands::atlas_location_delete,
            atlas::interface::tauri_commands::atlas_maps_list,
            atlas::interface::tauri_commands::atlas_map_get,
            atlas::interface::tauri_commands::atlas_map_create,
            atlas::interface::tauri_commands::atlas_map_update,
            atlas::interface::tauri_commands::atlas_map_delete,
            atlas::interface::tauri_commands::atlas_map_pins,
            atlas::interface::tauri_commands::atlas_map_pin_upsert,
            atlas::interface::tauri_commands::atlas_map_pin_delete,
            atlas::interface::tauri_commands::atlas_map_connections,
            atlas::interface::tauri_commands::atlas_map_connection_upsert,
            atlas::interface::tauri_commands::atlas_map_connection_delete,
            atlas::interface::tauri_commands::atlas_generate_map,
            atlas::interface::tauri_commands::atlas_accept_generated_map,
            manuscript::interface::tauri_commands::manuscript_chapters_list,
            manuscript::interface::tauri_commands::manuscript_chapter_get,
            manuscript::interface::tauri_commands::manuscript_chapter_create,
            manuscript::interface::tauri_commands::manuscript_chapter_update,
            manuscript::interface::tauri_commands::manuscript_chapter_delete,
            manuscript::interface::tauri_commands::manuscript_notes_list,
            manuscript::interface::tauri_commands::manuscript_note_create,
            manuscript::interface::tauri_commands::manuscript_note_update,
            manuscript::interface::tauri_commands::manuscript_note_delete,
            workspace::interface::tauri_commands::workspace_health,
            workspace::interface::tauri_commands::workspace_settings_get,
            workspace::interface::tauri_commands::workspace_settings_save,
            workspace::interface::tauri_commands::workspace_settings_reset,
            workspace::interface::tauri_commands::workspace_backup_create,
            workspace::interface::tauri_commands::workspace_export_json,
            workspace::interface::tauri_commands::workspace_artifacts_list,
            workspace::interface::tauri_commands::workspace_artifact_restore,
            creative_generators::interface::tauri_commands::creative_generate,
            characters::interface::tauri_commands::characters_list,
            characters::interface::tauri_commands::characters_get,
            characters::interface::tauri_commands::characters_create,
            characters::interface::tauri_commands::characters_update,
            characters::interface::tauri_commands::characters_delete,
            items::interface::tauri_commands::items_list,
            items::interface::tauri_commands::items_get,
            items::interface::tauri_commands::items_create,
            items::interface::tauri_commands::items_update,
            items::interface::tauri_commands::items_delete,
            equipment::interface::tauri_commands::equipment_list,
            equipment::interface::tauri_commands::equipment_compatible_items,
            equipment::interface::tauri_commands::equipment_equip,
            equipment::interface::tauri_commands::equipment_unequip,
            equipment::interface::tauri_commands::character_sheet_get,
            skills::interface::tauri_commands::skills_list,
            skills::interface::tauri_commands::skills_get,
            skills::interface::tauri_commands::skills_create,
            skills::interface::tauri_commands::skills_update,
            skills::interface::tauri_commands::skills_delete,
            skills::interface::tauri_commands::skills_teach,
            skills::interface::tauri_commands::skills_forget,
            skills::interface::tauri_commands::skills_list_for_character,
            skills::interface::tauri_commands::skills_preview,
            relationships::interface::tauri_commands::relationship_types_list,
            relationships::interface::tauri_commands::relationships_create,
            relationships::interface::tauri_commands::relationships_change_state,
            relationships::interface::tauri_commands::relationships_end,
            relationships::interface::tauri_commands::relationships_reopen,
            relationships::interface::tauri_commands::relationships_get_at,
            relationships::interface::tauri_commands::relationships_for_character_at,
            relationships::interface::tauri_commands::relationships_history,
            relationships::interface::tauri_commands::relationships_graph_at,
            relationships::interface::tauri_commands::relationships_matrix_at,
            status_effects::interface::tauri_commands::status_effects_list,
            status_effects::interface::tauri_commands::status_effects_for_skill,
            status_effects::interface::tauri_commands::status_effects_set_for_skill,
            combat::interface::tauri_commands::combat_start,
            combat::interface::tauri_commands::combat_get,
            combat::interface::tauri_commands::combat_list_running,
            combat::interface::tauri_commands::combat_list_all,
            combat::interface::tauri_commands::combat_delete,
            combat::interface::tauri_commands::combat_use_skill,
            combat::interface::tauri_commands::combat_preview_impact,
            combat_replay::interface::tauri_commands::combat_replay_start,
            combat_replay::interface::tauri_commands::combat_replay_at_sequence,
            combat_replay::interface::tauri_commands::combat_replay_at_execution,
            combat_replay::interface::tauri_commands::combat_replay_latest,
            combat_replay::interface::tauri_commands::combat_replay_turns,
            combat_replay::interface::tauri_commands::combat_replay_verify_latest,
            timeline::interface::tauri_commands::timeline_create,
            timeline::interface::tauri_commands::timeline_update,
            timeline::interface::tauri_commands::timeline_get,
            timeline::interface::tauri_commands::timeline_delete,
            timeline::interface::tauri_commands::timeline_at,
            timeline::interface::tauri_commands::timeline_between,
            timeline::interface::tauri_commands::timeline_for_character,
            timeline::interface::tauri_commands::timeline_projection_between,
            timeline::interface::tauri_commands::timeline_character_thread,
            timeline::interface::tauri_commands::timeline_bounds,
        ])
        .run(tauri::generate_context!())
        .expect("error while running LUPUS'S MIND")
}
