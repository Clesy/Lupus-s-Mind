use rusqlite::{params, Connection};
use std::{fs, path::{Path, PathBuf}, sync::{Arc, Mutex}, time::{SystemTime, UNIX_EPOCH}};

pub type SharedConnection = Arc<Mutex<Connection>>;

pub const LATEST_SCHEMA_VERSION: u32 = 14;

#[derive(Clone)]
pub struct Database { conn: SharedConnection }

impl Database {
    pub fn open(path: &Path) -> Result<Self, rusqlite::Error> {
        let conn = Self::open_configured_connection(path)?;
        Ok(Self { conn: Arc::new(Mutex::new(conn)) })
    }

    pub fn open_in_memory() -> Result<Self, rusqlite::Error> {
        let conn = Connection::open_in_memory()?;
        conn.execute_batch("PRAGMA foreign_keys=ON; PRAGMA journal_mode=MEMORY;")?;
        Self::migrate_connection(&conn, None)?;
        Ok(Self { conn: Arc::new(Mutex::new(conn)) })
    }

    pub fn shared(&self) -> SharedConnection { self.conn.clone() }

    pub fn open_configured_connection(path: &Path) -> Result<Connection, rusqlite::Error> {
        if let Some(parent) = path.parent() { fs::create_dir_all(parent).map_err(|_| rusqlite::Error::InvalidPath(parent.to_path_buf()))?; }
        let conn = Connection::open(path)?;
        conn.execute_batch("PRAGMA foreign_keys=ON; PRAGMA journal_mode=WAL;")?;
        Self::migrate_connection(&conn, Some(path))?;
        Ok(conn)
    }

    pub fn open_configured_connection_for_restore(path: &Path) -> Result<Connection, rusqlite::Error> {
        if let Some(parent) = path.parent() { fs::create_dir_all(parent).map_err(|_| rusqlite::Error::InvalidPath(parent.to_path_buf()))?; }
        let conn = Connection::open(path)?;
        conn.execute_batch("PRAGMA foreign_keys=ON; PRAGMA journal_mode=WAL;")?;
        Self::migrate_connection(&conn, None)?;
        Ok(conn)
    }

    pub fn replace_shared_connection(shared: &SharedConnection, path: &Path) -> Result<(), rusqlite::Error> {
        let replacement = Self::open_configured_connection(path)?;
        let mut current = match shared.lock() { Ok(conn) => conn, Err(poisoned) => poisoned.into_inner() };
        let _ = current.execute_batch("PRAGMA wal_checkpoint(TRUNCATE);");
        *current = replacement;
        Ok(())
    }

    fn recovery_snapshot(conn: &Connection, database_path: &Path, current: i64, latest: i64) -> Result<(), rusqlite::Error> {
        if current == 0 { return Ok(()); }
        let parent = database_path.parent().unwrap_or_else(|| Path::new("."));
        let file_name = database_path.file_name().and_then(|value| value.to_str()).unwrap_or("");
        let artifact_dir: PathBuf = if file_name.eq_ignore_ascii_case("lupus-mind.sqlite") {
            parent.join("workspace-artifacts")
        } else {
            let stem = database_path.file_stem().and_then(|value| value.to_str()).unwrap_or("workspace");
            parent.join(format!("{}-artifacts", stem))
        };
        fs::create_dir_all(&artifact_dir).map_err(|_| rusqlite::Error::InvalidPath(artifact_dir.clone()))?;
        let stamp = SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_millis();
        let target = artifact_dir.join(format!("lupus-mind-pre-migration-v{}-to-v{}-{}.sqlite", current, latest, stamp));
        let escaped = target.to_string_lossy().replace('\'', "''");
        conn.execute_batch(&format!("VACUUM INTO '{}';", escaped))?;
        Ok(())
    }

    fn migrate_connection(conn: &Connection, disk_path: Option<&Path>) -> Result<(), rusqlite::Error> {
        let migrations = [
            (1, include_str!("../../migrations/001_initial_schema.sql")),
            (2, include_str!("../../migrations/002_items_and_equipment.sql")),
            (3, include_str!("../../migrations/003_skills.sql")),
            (4, include_str!("../../migrations/004_relationships.sql")),
            (5, include_str!("../../migrations/005_timeline.sql")),
            (6, include_str!("../../migrations/006_combat_runtime.sql")),
            (7, include_str!("../../migrations/007_status_effects.sql")),
            (8, include_str!("../../migrations/008_combat_replay.sql")),
            (9, include_str!("../../migrations/009_desktop_hardening.sql")),
            (10, include_str!("../../migrations/010_authoring_and_search.sql")),
            (11, include_str!("../../migrations/011_lore_authoring_links.sql")),
            (12, include_str!("../../migrations/012_world_systems.sql")),
            (13, include_str!("../../migrations/013_hierarchies_and_lineages.sql")),
            (14, include_str!("../../migrations/014_atlas.sql")),
        ];
        conn.execute_batch("CREATE TABLE IF NOT EXISTS schema_migrations(version INTEGER PRIMARY KEY, applied_at TEXT NOT NULL);")?;
        let current: i64 = conn.query_row("SELECT COALESCE(MAX(version),0) FROM schema_migrations", [], |r| r.get(0))?;
        debug_assert_eq!(migrations.last().map(|(v,_)| *v as u32).unwrap_or(0), LATEST_SCHEMA_VERSION);
        let latest = i64::from(LATEST_SCHEMA_VERSION);
        if current < latest {
            if let Some(path) = disk_path { Self::recovery_snapshot(conn, path, current, latest)?; }
        }
        for (version, sql) in migrations {
            let exists: i64 = conn.query_row("SELECT COUNT(*) FROM schema_migrations WHERE version=?", params![version], |r| r.get(0))?;
            if exists == 0 {
                let tx = conn.unchecked_transaction()?;
                tx.execute_batch(sql)?;
                tx.execute("INSERT INTO schema_migrations(version,applied_at) VALUES(?,strftime('%Y-%m-%dT%H:%M:%fZ','now'))", params![version])?;
                tx.commit()?;
            }
        }
        Ok(())
    }
}
