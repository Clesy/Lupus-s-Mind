use tauri::State;
use crate::{
    app_state::AppState,
    combat::{
        application::{
            preview::{CombatImpactPreviewDto, CombatImpactPreviewInput, CombatImpactPreviewServices},
            use_cases::{self,CombatSessionDto,StartCombatInput,StartCombatServices},
        },
        domain::{combat::{CombatSession,UseSkillCommand},error::CombatError},
    },
    shared::api_error::ApiError,
};
fn api(error:CombatError)->ApiError{ApiError{code:"combat_error".into(),message:error.to_string()}}

#[tauri::command]
pub fn combat_start(state:State<'_,AppState>,input:StartCombatInput)->Result<CombatSessionDto,ApiError>{StartCombatServices{characters:&state.characters,items:&state.items,equipment:&state.equipment,skills:&state.skills,assignments:&state.skills,status_effects:&state.status_effects,sessions:&state.combat}.execute(input).map_err(api)}
#[tauri::command]
pub fn combat_get(state:State<'_,AppState>,id:String)->Result<CombatSessionDto,ApiError>{use_cases::get_session(&state.combat,id).map_err(api)}
#[tauri::command]
pub fn combat_list_running(state:State<'_,AppState>)->Result<Vec<CombatSessionDto>,ApiError>{use_cases::list_running(&state.combat).map_err(api)}
#[tauri::command]
pub fn combat_list_all(state:State<'_,AppState>)->Result<Vec<CombatSessionDto>,ApiError>{use_cases::list_all(&state.combat).map_err(api)}
#[tauri::command]
pub fn combat_delete(state:State<'_,AppState>,id:String)->Result<(),ApiError>{use_cases::delete_session(&state.combat,id).map_err(api)}
#[tauri::command]
pub fn combat_use_skill(state:State<'_,AppState>,command:UseSkillCommand)->Result<CombatSessionDto,ApiError>{let session:CombatSession=use_cases::use_skill(&state.combat,command).map_err(api)?;let actions=crate::combat::domain::repository::CombatSessionRepository::list_actions(&state.combat,&session.id).map_err(api)?;Ok(CombatSessionDto{session,actions})}
#[tauri::command]
pub fn combat_preview_impact(state:State<'_,AppState>,input:CombatImpactPreviewInput)->Result<CombatImpactPreviewDto,ApiError>{CombatImpactPreviewServices{characters:&state.characters,items:&state.items,equipment:&state.equipment,skills:&state.skills,assignments:&state.skills}.execute(input).map_err(api)}
