use serde::Serialize;
use thiserror::Error;

#[derive(Debug, Error, Serialize)]
#[serde(tag = "kind", content = "detail", rename_all = "snake_case")]
pub enum CombatError {
    #[error("Combat session not found: {0}")]
    SessionNotFound(String),
    #[error("Combatant not found: {0}")]
    CombatantNotFound(String),
    #[error("Skill is not available in the frozen combat snapshot: {0}")]
    SkillNotFound(String),
    #[error("It is not this combatant's turn")]
    NotYourTurn,
    #[error("Combat session is not running")]
    SessionNotRunning,
    #[error("Defeated combatants cannot act")]
    ActorDefeated,
    #[error("Target is already defeated")]
    TargetDefeated,
    #[error("Not enough resource for skill {0}")]
    InsufficientResource(String),
    #[error("Skill is on cooldown for {0} more turn(s)")]
    Cooldown(u32),
    #[error("Validation error: {0}")]
    Validation(String),
    #[error("Mapping error: {0}")]
    Mapping(String),
    #[error("Database error: {0}")]
    Database(String),
    #[error("Canonical source error: {0}")]
    CanonicalSource(String),
}
