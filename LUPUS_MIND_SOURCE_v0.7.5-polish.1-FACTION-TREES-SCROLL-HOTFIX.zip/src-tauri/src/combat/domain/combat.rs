use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use crate::skills::domain::skill::{ResourceKind, ScalingTerm, SkillKind};

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, Hash)] pub struct CombatSessionId(pub String);
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, Hash)] pub struct CombatantId(pub String);
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, Hash)] pub struct CombatActionId(pub String);
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, Hash)] pub struct CombatTurnExecutionId(pub String);

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum CombatStatus { Running, Completed, Abandoned }
impl CombatStatus {
    pub fn as_db(self)->&'static str{match self{Self::Running=>"running",Self::Completed=>"completed",Self::Abandoned=>"abandoned"}}
    pub fn from_db(value:&str)->Option<Self>{Some(match value{"running"=>Self::Running,"completed"=>Self::Completed,"abandoned"=>Self::Abandoned,_=>return None})}
}

#[derive(Debug, Clone, Serialize, Deserialize, Default, PartialEq)]
#[serde(rename_all = "camelCase")]
pub struct CombatStats { pub strength:f64,pub agility:f64,pub vitality:f64,pub intelligence:f64,pub mind:f64,pub weapon_damage:f64,pub armor:f64,pub armor_penetration:f64,pub magic_penetration:f64,pub critical_chance:f64,pub damage_reduction:f64 }

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all="snake_case")]
pub enum CombatStatusEffectKind { DamageOverTime, HealOverTime, Stun, StatModifier }
#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all="snake_case")]
pub enum CombatStackingPolicy { Refresh }
#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all="snake_case")]
pub enum RuntimeModifierKind { ArmorMultiplier, DamageMultiplier }
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(rename_all="camelCase")]
pub struct RuntimeModifier { pub kind:RuntimeModifierKind,pub multiplier:f64 }

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(rename_all="camelCase")]
pub struct CombatStatusEffectSpec {
    pub definition_id:String,
    pub name:String,
    pub kind:CombatStatusEffectKind,
    pub stacking_policy:CombatStackingPolicy,
    pub duration_turns:u32,
    pub power:f64,
    pub modifier:Option<RuntimeModifier>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "camelCase")]
pub struct CombatSkillSnapshot { pub skill_id:String,pub name:String,pub kind:SkillKind,pub resource_kind:ResourceKind,pub base_power:f64,pub resource_cost:u32,pub cooldown_turns:u32,pub scaling:Vec<ScalingTerm>,#[serde(default)] pub effects:Vec<CombatStatusEffectSpec> }

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "camelCase")]
pub struct CombatantSnapshot { pub source_character_id:String,pub display_name:String,pub effective_stats:CombatStats,pub max_hp:u32,pub max_mana:u32,pub skills:Vec<CombatSkillSnapshot> }

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "camelCase")]
pub struct CooldownState { pub skill_id:String,pub remaining_turns:u32 }

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(rename_all="camelCase")]
pub struct ActiveStatusEffect {
    pub instance_id:String,
    pub definition_id:String,
    pub name:String,
    pub source_combatant_id:CombatantId,
    pub kind:CombatStatusEffectKind,
    pub stacking_policy:CombatStackingPolicy,
    pub power:f64,
    pub duration_remaining:u32,
    pub modifier:Option<RuntimeModifier>,
    pub applied_sequence:u64,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "camelCase")]
pub struct CombatantRuntimeState { pub current_hp:u32,pub current_mana:u32,pub is_defeated:bool,pub cooldowns:Vec<CooldownState>,#[serde(default)] pub active_effects:Vec<ActiveStatusEffect> }
impl CombatantRuntimeState {
    pub fn fresh(snapshot:&CombatantSnapshot)->Self{Self{current_hp:snapshot.max_hp,current_mana:snapshot.max_mana,is_defeated:false,cooldowns:vec![],active_effects:vec![]}}
    pub fn cooldown_for(&self,skill_id:&str)->u32{self.cooldowns.iter().find(|c|c.skill_id==skill_id).map(|c|c.remaining_turns).unwrap_or(0)}
    pub fn set_cooldown(&mut self,skill_id:String,turns:u32){self.cooldowns.retain(|c|c.skill_id!=skill_id);if turns>0{self.cooldowns.push(CooldownState{skill_id,remaining_turns:turns});}}
    pub fn tick_cooldowns(&mut self){for c in &mut self.cooldowns{c.remaining_turns=c.remaining_turns.saturating_sub(1);}self.cooldowns.retain(|c|c.remaining_turns>0);}
    pub fn armor_multiplier(&self)->f64{self.active_effects.iter().filter_map(|e|e.modifier.as_ref()).filter(|m|m.kind==RuntimeModifierKind::ArmorMultiplier).fold(1.0,|a,m|a*m.multiplier)}
    pub fn damage_multiplier(&self)->f64{self.active_effects.iter().filter_map(|e|e.modifier.as_ref()).filter(|m|m.kind==RuntimeModifierKind::DamageMultiplier).fold(1.0,|a,m|a*m.multiplier)}
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "camelCase")]
pub struct Combatant { pub id:CombatantId,pub position:u32,pub snapshot:CombatantSnapshot,pub runtime_state:CombatantRuntimeState }

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "camelCase")]
pub struct CombatSession { pub id:CombatSessionId,pub status:CombatStatus,pub rng_seed:u64,pub round_number:u32,pub turn_index:u32,pub next_action_sequence:u64,pub combatants:Vec<Combatant>,pub created_at:DateTime<Utc>,pub updated_at:DateTime<Utc>,pub completed_at:Option<DateTime<Utc>> }
impl CombatSession {
    pub fn current_actor(&self)->Option<&Combatant>{self.combatants.get(self.turn_index as usize)}
    pub fn current_actor_mut(&mut self)->Option<&mut Combatant>{self.combatants.get_mut(self.turn_index as usize)}
    pub fn alive_count(&self)->usize{self.combatants.iter().filter(|c|!c.runtime_state.is_defeated).count()}
    pub fn advance_turn(&mut self){if self.combatants.is_empty(){return;}let original=self.turn_index as usize;let mut idx=original;loop{idx=(idx+1)%self.combatants.len();if idx==0{self.round_number+=1;}if !self.combatants[idx].runtime_state.is_defeated{break;}if idx==original{break;}}self.turn_index=idx as u32;if let Some(next)=self.current_actor_mut(){next.runtime_state.tick_cooldowns();}}
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "camelCase")]
pub struct UseSkillCommand { pub session_id:String,pub actor_combatant_id:String,pub target_combatant_id:String,pub skill_id:String }

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "camelCase")]
pub struct CombatResolution { pub raw_power:f64,pub resolved_power:f64,pub hp_delta:i32,pub mana_delta:i32,pub was_critical:bool,pub was_dodged:bool,pub roll_critical:f64,pub roll_dodge:f64 }

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(rename_all="camelCase")]
pub struct StatusTick { pub effect_instance_id:String,pub definition_id:String,pub effect_name:String,pub hp_delta:i32,pub prevents_action:bool }

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all="snake_case")]
pub enum CombatActionKind { UseSkill, EffectTick, EffectApplied, EffectRefreshed, EffectExpired, TurnSkipped }
impl CombatActionKind { pub fn as_db(self)->&'static str{match self{Self::UseSkill=>"use_skill",Self::EffectTick=>"effect_tick",Self::EffectApplied=>"effect_applied",Self::EffectRefreshed=>"effect_refreshed",Self::EffectExpired=>"effect_expired",Self::TurnSkipped=>"turn_skipped"}} pub fn from_db(v:&str)->Option<Self>{Some(match v{"use_skill"=>Self::UseSkill,"effect_tick"=>Self::EffectTick,"effect_applied"=>Self::EffectApplied,"effect_refreshed"=>Self::EffectRefreshed,"effect_expired"=>Self::EffectExpired,"turn_skipped"=>Self::TurnSkipped,_=>return None})} }

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(tag="type",content="data",rename_all="snake_case")]
pub enum CombatActionInput { UseSkill(UseSkillCommand), StatusEffect{effect_instance_id:String,definition_id:String}, System{reason:String} }

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(tag="type",content="data",rename_all="snake_case")]
pub enum CombatActionResolution { Skill(CombatResolution), StatusTick(StatusTick), EffectLifecycle{definition_id:String,effect_name:String,duration_remaining:u32}, TurnSkipped{reason:String} }

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "camelCase")]
pub struct CombatAction {
    pub id:CombatActionId,
    pub session_id:CombatSessionId,
    pub turn_execution_id:CombatTurnExecutionId,
    pub sequence_number:u64,
    pub round_number:u32,
    pub turn_index:u32,
    pub actor_combatant_id:CombatantId,
    pub target_combatant_id:Option<CombatantId>,
    pub action_kind:CombatActionKind,
    pub input:CombatActionInput,
    pub resolution:CombatActionResolution,
    pub created_at:DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(rename_all="camelCase")]
pub struct CombatTurnExecution { pub id:CombatTurnExecutionId,pub session_id:CombatSessionId,pub round_number:u32,pub turn_index:u32,pub actor_combatant_id:CombatantId,pub created_at:DateTime<Utc> }
