use super::{combat::{CombatAction,CombatSession,CombatSessionId,CombatTurnExecution},error::CombatError};

pub trait CombatSessionRepository: Send + Sync {
    fn insert(&self, session:&CombatSession)->Result<(),CombatError>;
    fn get(&self,id:&CombatSessionId)->Result<Option<CombatSession>,CombatError>;
    fn list_running(&self)->Result<Vec<CombatSession>,CombatError>;
    fn list_all(&self)->Result<Vec<CombatSession>,CombatError>;
    fn list_actions(&self,id:&CombatSessionId)->Result<Vec<CombatAction>,CombatError>;
    fn delete(&self,id:&CombatSessionId)->Result<(),CombatError>;
}

/// Infrastructure owns BEGIN/COMMIT/ROLLBACK. Application resolves an entire turn
/// into one TurnExecution plus zero-or-more ordered CombatActions.
pub trait CombatUnitOfWork: Send + Sync {
    fn with_turn_transaction(
        &self,
        id:&CombatSessionId,
        operation:&mut dyn FnMut(&mut CombatSession)->Result<(CombatTurnExecution,Vec<CombatAction>),CombatError>,
    )->Result<CombatSession,CombatError>;
}
