use chrono::Utc;
use serde::{Deserialize, Serialize};
use uuid::Uuid;

use crate::{
    character_sheet::application::get_character_sheet::{get_sheet, EffectiveStats},
    characters::domain::{character::CharacterId, repository::CharacterRepository},
    combat::domain::{
        combat::{
            ActiveStatusEffect, CombatAction, CombatActionId, CombatActionInput, CombatActionKind,
            CombatActionResolution, CombatResolution, CombatSession, CombatSessionId, CombatSkillSnapshot,
            CombatStackingPolicy, CombatStats, CombatStatus, CombatStatusEffectKind, CombatStatusEffectSpec,
            CombatTurnExecution, CombatTurnExecutionId, Combatant, CombatantId, CombatantRuntimeState,
            CombatantSnapshot, RuntimeModifier, RuntimeModifierKind, StatusTick, UseSkillCommand,
        },
        error::CombatError,
        repository::{CombatSessionRepository, CombatUnitOfWork},
    },
    equipment::domain::repository::EquipmentRepository,
    items::domain::repository::ItemRepository,
    skill_evaluation::domain::evaluator::{
        DeterministicSkillEvaluator, EvaluationStats, SkillEvaluator,
    },
    skills::domain::{
        repository::{CharacterSkillRepository, SkillRepository},
        skill::{ResourceKind, ScalingStat, ScalingTerm, Skill, SkillId, SkillKind},
    },
    status_effects::domain::{
        repository::StatusEffectDefinitionRepository,
        status_effect::{
            StackingPolicy, StatusEffectDefinition, StatusEffectKind, StatusModifierKind,
        },
    },
};

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct StartCombatInput {
    pub character_ids: Vec<String>,
    pub rng_seed: u64,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct CombatSessionDto {
    pub session: CombatSession,
    pub actions: Vec<CombatAction>,
}

pub(crate) fn map_stats(e: &EffectiveStats) -> CombatStats {
    CombatStats {
        strength: e.strength,
        agility: e.agility,
        vitality: e.vitality,
        intelligence: e.intelligence,
        mind: e.mind,
        weapon_damage: e.weapon_damage,
        armor: e.armor,
        armor_penetration: e.armor_penetration,
        magic_penetration: e.magic_penetration,
        critical_chance: e.critical_chance,
        damage_reduction: e.damage_reduction,
    }
}

fn eval_stats(e: &CombatStats) -> EvaluationStats {
    EvaluationStats {
        strength: e.strength,
        agility: e.agility,
        vitality: e.vitality,
        intelligence: e.intelligence,
        mind: e.mind,
        weapon_damage: e.weapon_damage,
        armor: e.armor,
    }
}

pub const BASIC_ATTACK_SKILL_ID: &str = "runtime:basic_attack";

pub(crate) fn basic_attack_snapshot() -> CombatSkillSnapshot {
    CombatSkillSnapshot {
        skill_id: BASIC_ATTACK_SKILL_ID.into(),
        name: "Basic Attack".into(),
        kind: SkillKind::Physical,
        resource_kind: ResourceKind::None,
        base_power: 5.0,
        resource_cost: 0,
        cooldown_turns: 0,
        scaling: vec![
            ScalingTerm { stat: ScalingStat::Strength, coefficient: 1.25 },
            ScalingTerm { stat: ScalingStat::WeaponDamage, coefficient: 1.0 },
        ],
        effects: vec![],
    }
}

fn frozen_skill(s: &CombatSkillSnapshot) -> Skill {
    let now = Utc::now();
    Skill {
        id: SkillId(s.skill_id.clone()),
        name: s.name.clone(),
        description: String::new(),
        kind: s.kind,
        resource_kind: s.resource_kind,
        base_power: s.base_power,
        resource_cost: s.resource_cost,
        cooldown_turns: s.cooldown_turns,
        scaling: s.scaling.clone(),
        tags: vec![],
        created_at: now,
        updated_at: now,
    }
}

fn frozen_effect(definition: StatusEffectDefinition) -> CombatStatusEffectSpec {
    CombatStatusEffectSpec {
        definition_id: definition.id.0,
        name: definition.name,
        kind: match definition.kind {
            StatusEffectKind::DamageOverTime => CombatStatusEffectKind::DamageOverTime,
            StatusEffectKind::HealOverTime => CombatStatusEffectKind::HealOverTime,
            StatusEffectKind::Stun => CombatStatusEffectKind::Stun,
            StatusEffectKind::StatModifier => CombatStatusEffectKind::StatModifier,
        },
        stacking_policy: match definition.stacking_policy {
            StackingPolicy::Refresh => CombatStackingPolicy::Refresh,
        },
        duration_turns: definition.duration_turns,
        power: definition.power,
        modifier: definition.modifier.map(|m| RuntimeModifier {
            kind: match m.kind {
                StatusModifierKind::ArmorMultiplier => RuntimeModifierKind::ArmorMultiplier,
                StatusModifierKind::DamageMultiplier => RuntimeModifierKind::DamageMultiplier,
            },
            multiplier: m.multiplier,
        }),
    }
}

pub struct StartCombatServices<'a> {
    pub characters: &'a dyn CharacterRepository,
    pub items: &'a dyn ItemRepository,
    pub equipment: &'a dyn EquipmentRepository,
    pub skills: &'a dyn SkillRepository,
    pub assignments: &'a dyn CharacterSkillRepository,
    pub status_effects: &'a dyn StatusEffectDefinitionRepository,
    pub sessions: &'a dyn CombatSessionRepository,
}

impl<'a> StartCombatServices<'a> {
    pub fn execute(&self, input: StartCombatInput) -> Result<CombatSessionDto, CombatError> {
        if input.character_ids.len() < 2 {
            return Err(CombatError::Validation("at least two combatants are required".into()));
        }
        if input.rng_seed > 9_007_199_254_740_991 {
            return Err(CombatError::Validation("rngSeed must fit JavaScript safe integer range".into()));
        }
        let mut unique = std::collections::HashSet::new();
        if !input.character_ids.iter().all(|id| unique.insert(id.clone())) {
            return Err(CombatError::Validation("duplicate character in combat".into()));
        }

        let now = Utc::now();
        let mut combatants = Vec::new();
        for character_id in input.character_ids {
            let character = self
                .characters
                .get(&CharacterId(character_id.clone()))
                .map_err(|e| CombatError::CanonicalSource(e.to_string()))?
                .ok_or_else(|| CombatError::CanonicalSource(format!("character not found: {character_id}")))?;
            let sheet = get_sheet(self.characters, self.items, self.equipment, character_id.clone())
                .map_err(|e| CombatError::CanonicalSource(e.to_string()))?;
            let skill_ids = self
                .assignments
                .list_skill_ids(&character.id)
                .map_err(|e| CombatError::CanonicalSource(e.to_string()))?;
            let mut frozen_skills = vec![basic_attack_snapshot()];
            for skill_id in skill_ids {
                let skill = self
                    .skills
                    .get(&skill_id)
                    .map_err(|e| CombatError::CanonicalSource(e.to_string()))?
                    .ok_or_else(|| CombatError::CanonicalSource(format!("skill missing: {}", skill_id.0)))?;
                let effects = self
                    .status_effects
                    .list_for_skill(&skill.id)
                    .map_err(|e| CombatError::CanonicalSource(e.to_string()))?
                    .into_iter()
                    .map(frozen_effect)
                    .collect();
                frozen_skills.push(CombatSkillSnapshot {
                    skill_id: skill.id.0,
                    name: skill.name,
                    kind: skill.kind,
                    resource_kind: skill.resource_kind,
                    base_power: skill.base_power,
                    resource_cost: skill.resource_cost,
                    cooldown_turns: skill.cooldown_turns,
                    scaling: skill.scaling,
                    effects,
                });
            }
            let stats = map_stats(&sheet.effective_stats);
            let max_hp = ((stats.vitality * 25.0) + (character.level as f64 * 50.0))
                .max(1.0)
                .round() as u32;
            let max_mana = ((stats.mind * 20.0) + (character.level as f64 * 40.0))
                .max(0.0)
                .round() as u32;
            let snapshot = CombatantSnapshot {
                source_character_id: character.id.0,
                display_name: character.name,
                effective_stats: stats,
                max_hp,
                max_mana,
                skills: frozen_skills,
            };
            combatants.push(Combatant {
                id: CombatantId(Uuid::new_v4().to_string()),
                position: 0,
                runtime_state: CombatantRuntimeState::fresh(&snapshot),
                snapshot,
            });
        }

        combatants.sort_by(|a, b| {
            b.snapshot
                .effective_stats
                .agility
                .total_cmp(&a.snapshot.effective_stats.agility)
                .then_with(|| a.id.0.cmp(&b.id.0))
        });
        for (i, c) in combatants.iter_mut().enumerate() {
            c.position = i as u32;
        }
        let session = CombatSession {
            id: CombatSessionId(Uuid::new_v4().to_string()),
            status: CombatStatus::Running,
            rng_seed: input.rng_seed,
            round_number: 1,
            turn_index: 0,
            next_action_sequence: 1,
            combatants,
            created_at: now,
            updated_at: now,
            completed_at: None,
        };
        self.sessions.insert(&session)?;
        Ok(CombatSessionDto { session, actions: vec![] })
    }
}

pub fn get_session(repo: &dyn CombatSessionRepository, id: String) -> Result<CombatSessionDto, CombatError> {
    let sid = CombatSessionId(id.clone());
    let session = repo.get(&sid)?.ok_or(CombatError::SessionNotFound(id))?;
    let actions = repo.list_actions(&sid)?;
    Ok(CombatSessionDto { session, actions })
}

pub fn list_running(repo: &dyn CombatSessionRepository) -> Result<Vec<CombatSessionDto>, CombatError> {
    repo.list_running()?
        .into_iter()
        .map(|s| {
            let actions = repo.list_actions(&s.id)?;
            Ok(CombatSessionDto { session: s, actions })
        })
        .collect()
}

pub fn list_all(repo: &dyn CombatSessionRepository) -> Result<Vec<CombatSessionDto>, CombatError> {
    repo.list_all()?
        .into_iter()
        .map(|s| {
            let actions = repo.list_actions(&s.id)?;
            Ok(CombatSessionDto { session: s, actions })
        })
        .collect()
}

pub fn delete_session(repo: &dyn CombatSessionRepository, id: String) -> Result<(), CombatError> {
    repo.delete(&CombatSessionId(id))
}

fn stable_u64(seed: u64, sequence: u64, salt: u64) -> u64 {
    let mut z = seed ^ sequence.wrapping_mul(0x9E3779B97F4A7C15) ^ salt;
    z = z.wrapping_add(0x9E3779B97F4A7C15);
    z = (z ^ (z >> 30)).wrapping_mul(0xBF58476D1CE4E5B9);
    z = (z ^ (z >> 27)).wrapping_mul(0x94D049BB133111EB);
    z ^ (z >> 31)
}
fn roll_percent(seed: u64, sequence: u64, salt: u64) -> f64 {
    (stable_u64(seed, sequence, salt) as f64 / u64::MAX as f64) * 100.0
}

pub(crate) fn resolve_skill(
    session: &CombatSession,
    actor: &Combatant,
    target: &Combatant,
    skill: &CombatSkillSnapshot,
) -> Result<CombatResolution, CombatError> {
    resolve_skill_with_force_critical(session, actor, target, skill, false)
}

pub(crate) fn resolve_skill_with_force_critical(
    session: &CombatSession,
    actor: &Combatant,
    target: &Combatant,
    skill: &CombatSkillSnapshot,
    force_critical: bool,
) -> Result<CombatResolution, CombatError> {
    let evaluation = DeterministicSkillEvaluator.evaluate(&frozen_skill(skill), &eval_stats(&actor.snapshot.effective_stats));
    let base_raw = evaluation.theoretical_power.max(0.0);
    let raw = base_raw * actor.runtime_state.damage_multiplier();
    if skill.kind == SkillKind::Healing {
        return Ok(CombatResolution {
            raw_power: raw,
            resolved_power: raw,
            hp_delta: raw.round() as i32,
            mana_delta: -(skill.resource_cost as i32),
            was_critical: false,
            was_dodged: false,
            roll_critical: 0.0,
            roll_dodge: 0.0,
        });
    }
    if skill.kind == SkillKind::Utility {
        return Ok(CombatResolution {
            raw_power: raw,
            resolved_power: 0.0,
            hp_delta: 0,
            mana_delta: -(skill.resource_cost as i32),
            was_critical: false,
            was_dodged: false,
            roll_critical: 0.0,
            roll_dodge: 0.0,
        });
    }

    let sequence = session.next_action_sequence;
    let crit_roll = roll_percent(session.rng_seed, sequence, 0xC17C17);
    let dodge_roll = roll_percent(session.rng_seed, sequence, 0xD0D6E);
    let crit_chance = actor.snapshot.effective_stats.critical_chance.clamp(0.0, 100.0);
    let dodge_chance = (target.snapshot.effective_stats.agility / 15.0).clamp(0.0, 40.0);
    // Manual Arena may explicitly force a critical hit. Matching the legacy HTML arena,
    // a forced critical is also a guaranteed hit so the author can inspect the x2 result.
    let dodged = if force_critical { false } else { dodge_roll < dodge_chance };
    let critical = !dodged && (force_critical || crit_roll < crit_chance);
    let mut power = if critical { raw * 2.0 } else { raw };
    if skill.kind == SkillKind::Physical && !dodged {
        let pen = actor.snapshot.effective_stats.armor_penetration.clamp(0.0, 100.0) / 100.0;
        let runtime_armor = target.snapshot.effective_stats.armor * target.runtime_state.armor_multiplier();
        let effective_armor = (runtime_armor * (1.0 - pen)).max(0.0);
        power *= 100.0 / (100.0 + effective_armor);
    }
    if dodged {
        power = 0.0;
    }
    power *= 1.0 - (target.snapshot.effective_stats.damage_reduction.clamp(0.0, 100.0) / 100.0);
    if !dodged { power = power.max(1.0); }
    Ok(CombatResolution {
        raw_power: raw,
        resolved_power: power,
        hp_delta: -(power.round() as i32),
        mana_delta: -(skill.resource_cost as i32),
        was_critical: critical,
        was_dodged: dodged,
        roll_critical: crit_roll,
        roll_dodge: dodge_roll,
    })
}

fn apply_resource(actor: &mut Combatant, skill: &CombatSkillSnapshot) -> Result<(), CombatError> {
    match skill.resource_kind {
        ResourceKind::None => Ok(()),
        ResourceKind::Mana => {
            if actor.runtime_state.current_mana < skill.resource_cost {
                return Err(CombatError::InsufficientResource(skill.name.clone()));
            }
            actor.runtime_state.current_mana -= skill.resource_cost;
            Ok(())
        }
        _ => Err(CombatError::Validation(
            "C2.2 supports only mana or no-resource skills; stamina/health are deferred".into(),
        )),
    }
}

fn next_action(
    session: &mut CombatSession,
    execution_id: &CombatTurnExecutionId,
    actor: &CombatantId,
    target: Option<CombatantId>,
    kind: CombatActionKind,
    input: CombatActionInput,
    resolution: CombatActionResolution,
) -> CombatAction {
    let action = CombatAction {
        id: CombatActionId(Uuid::new_v4().to_string()),
        session_id: session.id.clone(),
        turn_execution_id: execution_id.clone(),
        sequence_number: session.next_action_sequence,
        round_number: session.round_number,
        turn_index: session.turn_index,
        actor_combatant_id: actor.clone(),
        target_combatant_id: target,
        action_kind: kind,
        input,
        resolution,
        created_at: Utc::now(),
    };
    session.next_action_sequence += 1;
    action
}

fn resolve_pre_turn_effects(
    session: &mut CombatSession,
    actor_index: usize,
    execution_id: &CombatTurnExecutionId,
) -> Vec<CombatAction> {
    let actor_id = session.combatants[actor_index].id.clone();
    let mut ordered = session.combatants[actor_index].runtime_state.active_effects.clone();
    ordered.sort_by(|a, b| a.applied_sequence.cmp(&b.applied_sequence).then_with(|| a.definition_id.cmp(&b.definition_id)));
    let mut actions = Vec::new();
    for effect in ordered {
        if session.combatants[actor_index].runtime_state.is_defeated { break; }
        let (hp_delta, prevents_action) = match effect.kind {
            CombatStatusEffectKind::DamageOverTime => (-(effect.power.round() as i32), false),
            CombatStatusEffectKind::HealOverTime => (effect.power.round() as i32, false),
            CombatStatusEffectKind::Stun => (0, true),
            CombatStatusEffectKind::StatModifier => continue,
        };
        {
            let actor = &mut session.combatants[actor_index];
            if hp_delta < 0 {
                actor.runtime_state.current_hp = actor.runtime_state.current_hp.saturating_sub((-hp_delta) as u32);
            } else if hp_delta > 0 {
                actor.runtime_state.current_hp = actor.runtime_state.current_hp.saturating_add(hp_delta as u32).min(actor.snapshot.max_hp);
            }
            actor.runtime_state.is_defeated = actor.runtime_state.current_hp == 0;
        }
        let tick = StatusTick {
            effect_instance_id: effect.instance_id.clone(),
            definition_id: effect.definition_id.clone(),
            effect_name: effect.name.clone(),
            hp_delta,
            prevents_action,
        };
        actions.push(next_action(
            session,
            execution_id,
            &actor_id,
            Some(actor_id.clone()),
            CombatActionKind::EffectTick,
            CombatActionInput::StatusEffect { effect_instance_id: effect.instance_id, definition_id: effect.definition_id },
            CombatActionResolution::StatusTick(tick),
        ));
    }
    actions
}

fn apply_skill_effects(
    session: &mut CombatSession,
    target_index: usize,
    source_id: &CombatantId,
    specs: &[CombatStatusEffectSpec],
    execution_id: &CombatTurnExecutionId,
) -> Vec<CombatAction> {
    let target_id = session.combatants[target_index].id.clone();
    let mut actions = Vec::new();
    for spec in specs {
        match spec.stacking_policy {
            CombatStackingPolicy::Refresh => {
                let existing_index = session.combatants[target_index]
                    .runtime_state
                    .active_effects
                    .iter()
                    .position(|e| e.definition_id == spec.definition_id);
                let action_kind;
                let instance_id;
                if let Some(index) = existing_index {
                    let applied_sequence = session.next_action_sequence;
                    let effect = &mut session.combatants[target_index].runtime_state.active_effects[index];
                    effect.source_combatant_id = source_id.clone();
                    effect.kind = spec.kind;
                    effect.stacking_policy = spec.stacking_policy;
                    effect.power = spec.power;
                    effect.duration_remaining = spec.duration_turns;
                    effect.modifier = spec.modifier.clone();
                    effect.applied_sequence = applied_sequence;
                    effect.name = spec.name.clone();
                    instance_id = effect.instance_id.clone();
                    action_kind = CombatActionKind::EffectRefreshed;
                } else {
                    instance_id = Uuid::new_v4().to_string();
                    session.combatants[target_index].runtime_state.active_effects.push(ActiveStatusEffect {
                        instance_id: instance_id.clone(),
                        definition_id: spec.definition_id.clone(),
                        name: spec.name.clone(),
                        source_combatant_id: source_id.clone(),
                        kind: spec.kind,
                        stacking_policy: spec.stacking_policy,
                        power: spec.power,
                        duration_remaining: spec.duration_turns,
                        modifier: spec.modifier.clone(),
                        applied_sequence: session.next_action_sequence,
                    });
                    action_kind = CombatActionKind::EffectApplied;
                }
                actions.push(next_action(
                    session,
                    execution_id,
                    source_id,
                    Some(target_id.clone()),
                    action_kind,
                    CombatActionInput::StatusEffect { effect_instance_id: instance_id, definition_id: spec.definition_id.clone() },
                    CombatActionResolution::EffectLifecycle {
                        definition_id: spec.definition_id.clone(),
                        effect_name: spec.name.clone(),
                        duration_remaining: spec.duration_turns,
                    },
                ));
            }
        }
    }
    actions
}

fn resolve_post_turn_effects(
    session: &mut CombatSession,
    actor_index: usize,
    execution_id: &CombatTurnExecutionId,
    turn_start_sequence: u64,
) -> Vec<CombatAction> {
    let actor_id = session.combatants[actor_index].id.clone();
    let mut expired = Vec::new();
    {
        let active = &mut session.combatants[actor_index].runtime_state.active_effects;
        for effect in active.iter_mut() {
            // Effects applied or refreshed during this same turn keep their full incoming duration.
            if effect.applied_sequence < turn_start_sequence {
                effect.duration_remaining = effect.duration_remaining.saturating_sub(1);
                if effect.duration_remaining == 0 { expired.push(effect.clone()); }
            }
        }
        active.retain(|effect| effect.duration_remaining > 0);
    }
    expired
        .into_iter()
        .map(|effect| {
            next_action(
                session,
                execution_id,
                &actor_id,
                Some(actor_id.clone()),
                CombatActionKind::EffectExpired,
                CombatActionInput::StatusEffect { effect_instance_id: effect.instance_id, definition_id: effect.definition_id.clone() },
                CombatActionResolution::EffectLifecycle { definition_id: effect.definition_id, effect_name: effect.name, duration_remaining: 0 },
            )
        })
        .collect()
}

pub fn use_skill(uow: &dyn CombatUnitOfWork, cmd: UseSkillCommand) -> Result<CombatSession, CombatError> {
    let sid = CombatSessionId(cmd.session_id.clone());
    let command = cmd.clone();
    let mut operation = move |session: &mut CombatSession| -> Result<(CombatTurnExecution, Vec<CombatAction>), CombatError> {
        if session.status != CombatStatus::Running { return Err(CombatError::SessionNotRunning); }
        let current = session.current_actor().ok_or_else(|| CombatError::Validation("session has no current combatant".into()))?;
        if current.id.0 != command.actor_combatant_id { return Err(CombatError::NotYourTurn); }
        let actor_index = session.combatants.iter().position(|c| c.id.0 == command.actor_combatant_id).ok_or_else(|| CombatError::CombatantNotFound(command.actor_combatant_id.clone()))?;
        if session.combatants[actor_index].runtime_state.is_defeated { return Err(CombatError::ActorDefeated); }

        let actor_id = session.combatants[actor_index].id.clone();
        let turn_start_sequence = session.next_action_sequence;
        let execution_id = CombatTurnExecutionId(Uuid::new_v4().to_string());
        let execution = CombatTurnExecution {
            id: execution_id.clone(),
            session_id: session.id.clone(),
            round_number: session.round_number,
            turn_index: session.turn_index,
            actor_combatant_id: actor_id.clone(),
            created_at: Utc::now(),
        };
        let mut actions = resolve_pre_turn_effects(session, actor_index, &execution_id);
        let stunned = session.combatants[actor_index].runtime_state.active_effects.iter().any(|e| e.kind == CombatStatusEffectKind::Stun);
        let defeated = session.combatants[actor_index].runtime_state.is_defeated;

        if defeated || stunned {
            let reason = if defeated { "defeated_by_start_of_turn_effect" } else { "stunned" }.to_string();
            actions.push(next_action(
                session,
                &execution_id,
                &actor_id,
                Some(actor_id.clone()),
                CombatActionKind::TurnSkipped,
                CombatActionInput::System { reason: reason.clone() },
                CombatActionResolution::TurnSkipped { reason },
            ));
        } else {
            let target_index = session.combatants.iter().position(|c| c.id.0 == command.target_combatant_id).ok_or_else(|| CombatError::CombatantNotFound(command.target_combatant_id.clone()))?;
            if session.combatants[target_index].runtime_state.is_defeated { return Err(CombatError::TargetDefeated); }
            let skill = session.combatants[actor_index].snapshot.skills.iter().find(|s| s.skill_id == command.skill_id).cloned().ok_or_else(|| CombatError::SkillNotFound(command.skill_id.clone()))?;
            let cooldown = session.combatants[actor_index].runtime_state.cooldown_for(&skill.skill_id);
            if cooldown > 0 { return Err(CombatError::Cooldown(cooldown)); }
            if skill.resource_kind == ResourceKind::Mana && session.combatants[actor_index].runtime_state.current_mana < skill.resource_cost { return Err(CombatError::InsufficientResource(skill.name.clone())); }

            let resolution = resolve_skill(session, &session.combatants[actor_index], &session.combatants[target_index], &skill)?;
            {
                let actor = &mut session.combatants[actor_index];
                apply_resource(actor, &skill)?;
                actor.runtime_state.set_cooldown(skill.skill_id.clone(), skill.cooldown_turns);
            }
            {
                let target = &mut session.combatants[target_index];
                if resolution.hp_delta < 0 { target.runtime_state.current_hp = target.runtime_state.current_hp.saturating_sub((-resolution.hp_delta) as u32); }
                else if resolution.hp_delta > 0 { target.runtime_state.current_hp = target.runtime_state.current_hp.saturating_add(resolution.hp_delta as u32).min(target.snapshot.max_hp); }
                target.runtime_state.is_defeated = target.runtime_state.current_hp == 0;
            }
            let target_id = session.combatants[target_index].id.clone();
            actions.push(next_action(
                session,
                &execution_id,
                &actor_id,
                Some(target_id),
                CombatActionKind::UseSkill,
                CombatActionInput::UseSkill(command.clone()),
                CombatActionResolution::Skill(resolution),
            ));
            if !session.combatants[target_index].runtime_state.is_defeated {
                actions.extend(apply_skill_effects(session, target_index, &actor_id, &skill.effects, &execution_id));
            }
        }

        actions.extend(resolve_post_turn_effects(session, actor_index, &execution_id, turn_start_sequence));
        session.updated_at = Utc::now();
        if session.alive_count() <= 1 {
            session.status = CombatStatus::Completed;
            session.completed_at = Some(Utc::now());
        } else {
            session.advance_turn();
        }
        Ok((execution, actions))
    };
    uow.with_turn_transaction(&sid, &mut operation)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn seeded_roll_is_reproducible() { for i in 1..1000 { assert_eq!(stable_u64(42, i, 7), stable_u64(42, i, 7)); } }
    #[test]
    fn different_sequences_change_rng_stream() { assert_ne!(stable_u64(42, 1, 7), stable_u64(42, 2, 7)); }
    #[test]
    fn basic_attack_is_always_free_and_deterministic() {
        let skill = basic_attack_snapshot();
        assert_eq!(skill.skill_id, BASIC_ATTACK_SKILL_ID);
        assert_eq!(skill.resource_kind, ResourceKind::None);
        assert_eq!(skill.resource_cost, 0);
        assert_eq!(skill.cooldown_turns, 0);
        assert!(skill.effects.is_empty());
    }
}
