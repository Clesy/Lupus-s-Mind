use chrono::Utc;
use serde::{Deserialize, Serialize};

use crate::{
    character_sheet::application::get_character_sheet::get_sheet,
    characters::domain::{character::{Character, CharacterId}, repository::CharacterRepository},
    combat::{
        application::use_cases::{
            basic_attack_snapshot, map_stats, resolve_skill_with_force_critical, BASIC_ATTACK_SKILL_ID,
        },
        domain::{
            combat::{
                CombatResolution, CombatSession, CombatSessionId, CombatSkillSnapshot, CombatStatus,
                Combatant, CombatantId, CombatantRuntimeState, CombatantSnapshot,
            },
            error::CombatError,
        },
    },
    equipment::domain::repository::EquipmentRepository,
    items::domain::repository::ItemRepository,
    skills::domain::{
        repository::{CharacterSkillRepository, SkillRepository},
        skill::{ResourceKind, SkillId, SkillKind},
    },
};

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct CombatImpactPreviewInput {
    pub attacker_character_id: String,
    pub target_character_id: String,
    pub skill_id: String,
    pub rng_seed: u64,
    #[serde(default)]
    pub force_critical: bool,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct CombatImpactPreviewDto {
    pub attacker_character_id: String,
    pub attacker_name: String,
    pub attacker_max_hp: u32,
    pub attacker_max_mana: u32,
    pub target_character_id: String,
    pub target_name: String,
    pub target_max_hp: u32,
    pub target_max_mana: u32,
    pub skill_id: String,
    pub skill_name: String,
    pub kind: SkillKind,
    pub resource_kind: ResourceKind,
    pub resource_cost: u32,
    pub cooldown_turns: u32,
    pub learned_by_attacker: bool,
    pub target_armor: f64,
    pub target_damage_reduction: f64,
    pub attacker_critical_chance: f64,
    pub target_dodge_chance: f64,
    pub resolution: CombatResolution,
}

pub struct CombatImpactPreviewServices<'a> {
    pub characters: &'a dyn CharacterRepository,
    pub items: &'a dyn ItemRepository,
    pub equipment: &'a dyn EquipmentRepository,
    pub skills: &'a dyn SkillRepository,
    pub assignments: &'a dyn CharacterSkillRepository,
}

impl<'a> CombatImpactPreviewServices<'a> {
    pub fn execute(&self, input: CombatImpactPreviewInput) -> Result<CombatImpactPreviewDto, CombatError> {
        if input.rng_seed > 9_007_199_254_740_991 {
            return Err(CombatError::Validation("rngSeed must fit JavaScript safe integer range".into()));
        }
        if input.attacker_character_id == input.target_character_id {
            return Err(CombatError::Validation("attacker and target must be different characters".into()));
        }
        let attacker = self.character(&input.attacker_character_id)?;
        let target = self.character(&input.target_character_id)?;

        let (frozen, learned_by_attacker) = if input.skill_id == BASIC_ATTACK_SKILL_ID {
            (basic_attack_snapshot(), true)
        } else {
            let skill = self
                .skills
                .get(&SkillId(input.skill_id.clone()))
                .map_err(|e| CombatError::CanonicalSource(e.to_string()))?
                .ok_or_else(|| CombatError::CanonicalSource(format!("skill not found: {}", input.skill_id)))?;
            let learned = self
                .assignments
                .is_learned(&attacker.id, &skill.id)
                .map_err(|e| CombatError::CanonicalSource(e.to_string()))?;
            (
                CombatSkillSnapshot {
                    skill_id: skill.id.0.clone(),
                    name: skill.name.clone(),
                    kind: skill.kind,
                    resource_kind: skill.resource_kind,
                    base_power: skill.base_power,
                    resource_cost: skill.resource_cost,
                    cooldown_turns: skill.cooldown_turns,
                    scaling: skill.scaling.clone(),
                    effects: vec![],
                },
                learned,
            )
        };

        let attacker_combatant = self.combatant(&attacker)?;
        let target_combatant = self.combatant(&target)?;
        let session = CombatSession {
            id: CombatSessionId("manual-arena-preview".into()),
            status: CombatStatus::Running,
            rng_seed: input.rng_seed,
            round_number: 1,
            turn_index: 0,
            next_action_sequence: 1,
            combatants: vec![attacker_combatant.clone(), target_combatant.clone()],
            created_at: Utc::now(),
            updated_at: Utc::now(),
            completed_at: None,
        };
        let resolution = resolve_skill_with_force_critical(
            &session,
            &attacker_combatant,
            &target_combatant,
            &frozen,
            input.force_critical,
        )?;
        let target_dodge_chance = (target_combatant.snapshot.effective_stats.agility / 15.0).clamp(0.0, 40.0);

        Ok(CombatImpactPreviewDto {
            attacker_character_id: attacker.id.0,
            attacker_name: attacker.name,
            attacker_max_hp: attacker_combatant.snapshot.max_hp,
            attacker_max_mana: attacker_combatant.snapshot.max_mana,
            target_character_id: target.id.0,
            target_name: target.name,
            target_max_hp: target_combatant.snapshot.max_hp,
            target_max_mana: target_combatant.snapshot.max_mana,
            skill_id: frozen.skill_id,
            skill_name: frozen.name,
            kind: frozen.kind,
            resource_kind: frozen.resource_kind,
            resource_cost: frozen.resource_cost,
            cooldown_turns: frozen.cooldown_turns,
            learned_by_attacker,
            target_armor: target_combatant.snapshot.effective_stats.armor,
            target_damage_reduction: target_combatant.snapshot.effective_stats.damage_reduction,
            attacker_critical_chance: attacker_combatant.snapshot.effective_stats.critical_chance,
            target_dodge_chance,
            resolution,
        })
    }

    fn character(&self, id: &str) -> Result<Character, CombatError> {
        self.characters
            .get(&CharacterId(id.to_string()))
            .map_err(|e| CombatError::CanonicalSource(e.to_string()))?
            .ok_or_else(|| CombatError::CanonicalSource(format!("character not found: {id}")))
    }

    fn combatant(&self, character: &Character) -> Result<Combatant, CombatError> {
        let sheet = get_sheet(self.characters, self.items, self.equipment, character.id.0.clone())
            .map_err(|e| CombatError::CanonicalSource(e.to_string()))?;
        let stats = map_stats(&sheet.effective_stats);
        let max_hp = ((stats.vitality * 25.0) + (character.level as f64 * 50.0)).max(1.0).round() as u32;
        let max_mana = ((stats.mind * 20.0) + (character.level as f64 * 40.0)).max(0.0).round() as u32;
        let snapshot = CombatantSnapshot {
            source_character_id: character.id.0.clone(),
            display_name: character.name.clone(),
            effective_stats: stats,
            max_hp,
            max_mana,
            skills: vec![],
        };
        Ok(Combatant {
            id: CombatantId(format!("manual-arena-{}", character.id.0)),
            position: 0,
            runtime_state: CombatantRuntimeState::fresh(&snapshot),
            snapshot,
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn basic_attack_id_is_reserved_for_manual_arena() {
        assert_eq!(BASIC_ATTACK_SKILL_ID, "runtime:basic_attack");
        let skill = basic_attack_snapshot();
        assert_eq!(skill.skill_id, BASIC_ATTACK_SKILL_ID);
        assert_eq!(skill.name, "Basic Attack");
    }
}
