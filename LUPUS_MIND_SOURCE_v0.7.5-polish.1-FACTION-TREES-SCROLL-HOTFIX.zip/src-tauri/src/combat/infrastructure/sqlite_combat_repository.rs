use chrono::{DateTime, Utc};
use rusqlite::{params, Connection, OptionalExtension};

use crate::{
    combat::domain::{
        combat::{
            CombatAction, CombatActionId, CombatActionInput, CombatActionKind,
            CombatActionResolution, CombatResolution, CombatSession, CombatSessionId, CombatStatus,
            Combatant, CombatantId, CombatantRuntimeState, CombatantSnapshot, CombatTurnExecution,
            UseSkillCommand,
        },
        error::CombatError,
        repository::{CombatSessionRepository, CombatUnitOfWork},
    },
    combat_replay::domain::{reconstructor::derive_turn_mutations, replay::CombatReplayState},
    shared::database::SharedConnection,
};

pub struct SqliteCombatRepository {
    conn: SharedConnection,
}

impl SqliteCombatRepository {
    pub fn new(conn: SharedConnection) -> Self {
        Self { conn }
    }
}

fn db(e: impl std::fmt::Display) -> CombatError {
    CombatError::Database(e.to_string())
}

fn parse_time(s: String) -> Result<DateTime<Utc>, CombatError> {
    DateTime::parse_from_rfc3339(&s)
        .map(|d| d.with_timezone(&Utc))
        .map_err(|e| CombatError::Mapping(e.to_string()))
}

fn json<T: serde::Serialize>(v: &T) -> Result<String, CombatError> {
    serde_json::to_string(v).map_err(|e| CombatError::Mapping(e.to_string()))
}

fn from_json<T: for<'de> serde::Deserialize<'de>>(v: &str) -> Result<T, CombatError> {
    serde_json::from_str(v).map_err(|e| CombatError::Mapping(e.to_string()))
}

// SQLite INTEGER is signed 64-bit. Keep the domain on u64, but make the
// storage boundary explicit and fail rather than silently wrapping.
fn sqlite_i64(value: u64, field: &str) -> Result<i64, CombatError> {
    i64::try_from(value)
        .map_err(|_| CombatError::Mapping(format!("{field} exceeds SQLite INTEGER range: {value}")))
}

fn domain_u64(value: i64, field: &str) -> Result<u64, CombatError> {
    u64::try_from(value)
        .map_err(|_| CombatError::Mapping(format!("negative SQLite INTEGER for {field}: {value}")))
}

fn load_session(conn: &Connection, id: &CombatSessionId) -> Result<Option<CombatSession>, CombatError> {
    let row = conn
        .query_row(
            "SELECT status,rng_seed,round_number,turn_index,next_action_sequence,created_at,updated_at,completed_at FROM combat_sessions WHERE id=?",
            params![id.0],
            |r| {
                Ok((
                    r.get::<_, String>(0)?,
                    r.get::<_, String>(1)?,
                    r.get::<_, u32>(2)?,
                    r.get::<_, u32>(3)?,
                    r.get::<_, i64>(4)?,
                    r.get::<_, String>(5)?,
                    r.get::<_, String>(6)?,
                    r.get::<_, Option<String>>(7)?,
                ))
            },
        )
        .optional()
        .map_err(db)?;

    let Some((status, seed, round, turn, next_seq_db, created, updated, completed)) = row else {
        return Ok(None);
    };

    let status = CombatStatus::from_db(&status)
        .ok_or_else(|| CombatError::Mapping(format!("unknown combat status: {status}")))?;
    let rng_seed = seed
        .parse::<u64>()
        .map_err(|e| CombatError::Mapping(format!("invalid rng seed: {e}")))?;
    let next_action_sequence = domain_u64(next_seq_db, "combat_sessions.next_action_sequence")?;

    let mut stmt = conn
        .prepare("SELECT id,position,snapshot,runtime_state FROM combatants WHERE session_id=? ORDER BY position")
        .map_err(db)?;
    let rows = stmt
        .query_map(params![id.0], |r| {
            Ok((
                r.get::<_, String>(0)?,
                r.get::<_, u32>(1)?,
                r.get::<_, String>(2)?,
                r.get::<_, String>(3)?,
            ))
        })
        .map_err(db)?;

    let mut combatants = Vec::new();
    for row in rows {
        let (cid, position, snapshot, runtime) = row.map_err(db)?;
        combatants.push(Combatant {
            id: CombatantId(cid),
            position,
            snapshot: from_json::<CombatantSnapshot>(&snapshot)?,
            runtime_state: from_json::<CombatantRuntimeState>(&runtime)?,
        });
    }

    Ok(Some(CombatSession {
        id: id.clone(),
        status,
        rng_seed,
        round_number: round,
        turn_index: turn,
        next_action_sequence,
        combatants,
        created_at: parse_time(created)?,
        updated_at: parse_time(updated)?,
        completed_at: completed.map(parse_time).transpose()?,
    }))
}

fn parse_action_input(kind: CombatActionKind, raw: &str) -> Result<CombatActionInput, CombatError> {
    if let Ok(value) = from_json::<CombatActionInput>(raw) {
        return Ok(value);
    }
    if kind == CombatActionKind::UseSkill {
        return Ok(CombatActionInput::UseSkill(from_json::<UseSkillCommand>(raw)?));
    }
    Err(CombatError::Mapping("invalid combat action input payload".into()))
}

fn parse_action_resolution(
    kind: CombatActionKind,
    raw: &str,
) -> Result<CombatActionResolution, CombatError> {
    if let Ok(value) = from_json::<CombatActionResolution>(raw) {
        return Ok(value);
    }
    if kind == CombatActionKind::UseSkill {
        return Ok(CombatActionResolution::Skill(from_json::<CombatResolution>(raw)?));
    }
    Err(CombatError::Mapping(
        "invalid combat action resolution payload".into(),
    ))
}

impl CombatSessionRepository for SqliteCombatRepository {
    fn insert(&self, session: &CombatSession) -> Result<(), CombatError> {
        let conn = match self.conn.lock() {
            Ok(c) => c,
            Err(p) => p.into_inner(),
        };
        let tx = conn.unchecked_transaction().map_err(db)?;
        let next_action_sequence = sqlite_i64(
            session.next_action_sequence,
            "combat_sessions.next_action_sequence",
        )?;

        tx.execute(
            "INSERT INTO combat_sessions(id,status,rng_seed,round_number,turn_index,next_action_sequence,created_at,updated_at,completed_at) VALUES(?,?,?,?,?,?,?,?,?)",
            params![
                session.id.0,
                session.status.as_db(),
                session.rng_seed.to_string(),
                session.round_number,
                session.turn_index,
                next_action_sequence,
                session.created_at.to_rfc3339(),
                session.updated_at.to_rfc3339(),
                session.completed_at.as_ref().map(|d| d.to_rfc3339())
            ],
        )
        .map_err(db)?;

        for c in &session.combatants {
            tx.execute(
                "INSERT INTO combatants(id,session_id,source_character_id,position,snapshot,runtime_state) VALUES(?,?,?,?,?,?)",
                params![
                    c.id.0,
                    session.id.0,
                    c.snapshot.source_character_id,
                    c.position,
                    json(&c.snapshot)?,
                    json(&c.runtime_state)?
                ],
            )
            .map_err(db)?;
        }

        let origin = CombatReplayState::from_live(session);
        tx.execute(
            "INSERT INTO combat_replay_origins(session_id,origin_sequence,state_json,created_at) VALUES(?,?,?,?)",
            params![
                session.id.0,
                0i64,
                json(&origin)?,
                session.created_at.to_rfc3339()
            ],
        )
        .map_err(db)?;

        tx.commit().map_err(db)
    }

    fn get(&self, id: &CombatSessionId) -> Result<Option<CombatSession>, CombatError> {
        let conn = match self.conn.lock() {
            Ok(c) => c,
            Err(p) => p.into_inner(),
        };
        load_session(&conn, id)
    }

    fn list_running(&self) -> Result<Vec<CombatSession>, CombatError> {
        let conn = match self.conn.lock() {
            Ok(c) => c,
            Err(p) => p.into_inner(),
        };
        let mut stmt = conn
            .prepare("SELECT id FROM combat_sessions WHERE status='running' ORDER BY updated_at DESC")
            .map_err(db)?;
        let ids = stmt
            .query_map([], |r| r.get::<_, String>(0))
            .map_err(db)?;
        let mut out = Vec::new();
        for id in ids {
            let sid = CombatSessionId(id.map_err(db)?);
            if let Some(s) = load_session(&conn, &sid)? {
                out.push(s);
            }
        }
        Ok(out)
    }

    fn list_all(&self) -> Result<Vec<CombatSession>, CombatError> {
        let conn = match self.conn.lock() {
            Ok(c) => c,
            Err(p) => p.into_inner(),
        };
        let mut stmt = conn
            .prepare("SELECT id FROM combat_sessions ORDER BY updated_at DESC, created_at DESC")
            .map_err(db)?;
        let ids = stmt.query_map([], |r| r.get::<_, String>(0)).map_err(db)?;
        let mut out = Vec::new();
        for id in ids {
            let sid = CombatSessionId(id.map_err(db)?);
            if let Some(session) = load_session(&conn, &sid)? { out.push(session); }
        }
        Ok(out)
    }

    fn list_actions(&self, id: &CombatSessionId) -> Result<Vec<CombatAction>, CombatError> {
        let conn = match self.conn.lock() {
            Ok(c) => c,
            Err(p) => p.into_inner(),
        };
        let mut stmt = conn
            .prepare("SELECT id,turn_execution_id,sequence_number,round_number,turn_index,actor_combatant_id,target_combatant_id,action_kind,input_json,resolution_json,created_at FROM combat_actions WHERE session_id=? ORDER BY sequence_number")
            .map_err(db)?;
        let rows = stmt
            .query_map(params![id.0], |r| {
                Ok((
                    r.get::<_, String>(0)?,
                    r.get::<_, String>(1)?,
                    r.get::<_, i64>(2)?,
                    r.get::<_, u32>(3)?,
                    r.get::<_, u32>(4)?,
                    r.get::<_, String>(5)?,
                    r.get::<_, Option<String>>(6)?,
                    r.get::<_, String>(7)?,
                    r.get::<_, String>(8)?,
                    r.get::<_, String>(9)?,
                    r.get::<_, String>(10)?,
                ))
            })
            .map_err(db)?;

        let mut out = Vec::new();
        for row in rows {
            let (aid, execution_id, seq_db, round, turn, actor, target, kind_raw, input_raw, resolution_raw, created) =
                row.map_err(db)?;
            let seq = domain_u64(seq_db, "combat_actions.sequence_number")?;
            let kind = CombatActionKind::from_db(&kind_raw)
                .ok_or_else(|| CombatError::Mapping(format!("unknown action kind: {kind_raw}")))?;
            out.push(CombatAction {
                id: CombatActionId(aid),
                session_id: id.clone(),
                turn_execution_id: crate::combat::domain::combat::CombatTurnExecutionId(execution_id),
                sequence_number: seq,
                round_number: round,
                turn_index: turn,
                actor_combatant_id: CombatantId(actor),
                target_combatant_id: target.map(CombatantId),
                action_kind: kind,
                input: parse_action_input(kind, &input_raw)?,
                resolution: parse_action_resolution(kind, &resolution_raw)?,
                created_at: parse_time(created)?,
            });
        }
        Ok(out)
    }

    fn delete(&self, id: &CombatSessionId) -> Result<(), CombatError> {
        let conn = match self.conn.lock() {
            Ok(c) => c,
            Err(p) => p.into_inner(),
        };
        let affected = conn.execute("DELETE FROM combat_sessions WHERE id=?", params![id.0]).map_err(db)?;
        if affected == 0 { return Err(CombatError::SessionNotFound(id.0.clone())); }
        Ok(())
    }
}

impl CombatUnitOfWork for SqliteCombatRepository {
    fn with_turn_transaction(
        &self,
        id: &CombatSessionId,
        operation: &mut dyn FnMut(
            &mut CombatSession,
        ) -> Result<(CombatTurnExecution, Vec<CombatAction>), CombatError>,
    ) -> Result<CombatSession, CombatError> {
        let conn = match self.conn.lock() {
            Ok(c) => c,
            Err(p) => p.into_inner(),
        };
        let tx = conn.unchecked_transaction().map_err(db)?;
        let mut session = load_session(&tx, id)?
            .ok_or_else(|| CombatError::SessionNotFound(id.0.clone()))?;
        let before_session = session.clone();
        let (execution, actions) = operation(&mut session)?;

        if execution.session_id != session.id {
            return Err(CombatError::Validation(
                "turn execution belongs to another session".into(),
            ));
        }

        let last_sequence = actions
            .last()
            .map(|a| a.sequence_number)
            .ok_or_else(|| CombatError::Validation("turn execution produced no durable actions".into()))?;
        let last_sequence_db = sqlite_i64(last_sequence, "combat_replay_events.sequence_number")?;
        let replay_mutations = derive_turn_mutations(&before_session, &session);

        tx.execute(
            "INSERT INTO combat_turn_executions(id,session_id,round_number,turn_index,actor_combatant_id,created_at) VALUES(?,?,?,?,?,?)",
            params![
                execution.id.0,
                execution.session_id.0,
                execution.round_number,
                execution.turn_index,
                execution.actor_combatant_id.0,
                execution.created_at.to_rfc3339()
            ],
        )
        .map_err(db)?;

        for action in &actions {
            if action.turn_execution_id != execution.id {
                return Err(CombatError::Validation(
                    "combat action escaped its turn execution".into(),
                ));
            }
            let sequence_number = sqlite_i64(action.sequence_number, "combat_actions.sequence_number")?;
            tx.execute(
                "INSERT INTO combat_actions(id,session_id,turn_execution_id,sequence_number,round_number,turn_index,actor_combatant_id,target_combatant_id,action_kind,input_json,resolution_json,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                params![
                    action.id.0,
                    action.session_id.0,
                    action.turn_execution_id.0,
                    sequence_number,
                    action.round_number,
                    action.turn_index,
                    action.actor_combatant_id.0,
                    action.target_combatant_id.as_ref().map(|x| x.0.clone()),
                    action.action_kind.as_db(),
                    json(&action.input)?,
                    json(&action.resolution)?,
                    action.created_at.to_rfc3339()
                ],
            )
            .map_err(db)?;
        }

        for (event_index, mutation) in replay_mutations.iter().enumerate() {
            tx.execute(
                "INSERT INTO combat_replay_events(id,session_id,turn_execution_id,sequence_number,event_index,event_kind,payload_json,created_at) VALUES(?,?,?,?,?,?,?,?)",
                params![
                    uuid::Uuid::new_v4().to_string(),
                    session.id.0,
                    execution.id.0,
                    last_sequence_db,
                    event_index as u32,
                    mutation.kind(),
                    json(mutation)?,
                    Utc::now().to_rfc3339()
                ],
            )
            .map_err(db)?;
        }

        for c in &session.combatants {
            let affected = tx
                .execute(
                    "UPDATE combatants SET runtime_state=? WHERE id=? AND session_id=?",
                    params![json(&c.runtime_state)?, c.id.0, session.id.0],
                )
                .map_err(db)?;
            if affected != 1 {
                return Err(CombatError::Database(format!(
                    "combatant runtime update affected {affected} rows"
                )));
            }
        }

        let next_action_sequence = sqlite_i64(
            session.next_action_sequence,
            "combat_sessions.next_action_sequence",
        )?;
        tx.execute(
            "UPDATE combat_sessions SET status=?,round_number=?,turn_index=?,next_action_sequence=?,updated_at=?,completed_at=? WHERE id=?",
            params![
                session.status.as_db(),
                session.round_number,
                session.turn_index,
                next_action_sequence,
                session.updated_at.to_rfc3339(),
                session.completed_at.as_ref().map(|d| d.to_rfc3339()),
                session.id.0
            ],
        )
        .map_err(db)?;

        tx.commit().map_err(db)?;
        Ok(session)
    }
}
