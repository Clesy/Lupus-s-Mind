use crate::characters::domain::character::CharacterId;
use super::{
    error::RelationshipError,
    relationship::{Relationship, RelationshipId, RelationshipState, RelationshipTransition, RelationshipType, RelationshipTypeId},
};

pub trait RelationshipTypeRepository: Send + Sync {
    fn list_types(&self) -> Result<Vec<RelationshipType>, RelationshipError>;
    fn get_type(&self, id: &RelationshipTypeId) -> Result<Option<RelationshipType>, RelationshipError>;
}

pub trait RelationshipRepository: Send + Sync {
    fn get(&self, id: &RelationshipId) -> Result<Option<Relationship>, RelationshipError>;
    fn get_state_at(&self, id: &RelationshipId, chapter: u32) -> Result<Option<RelationshipState>, RelationshipError>;
    fn open_state(&self, id: &RelationshipId) -> Result<Option<RelationshipState>, RelationshipError>;
    fn latest_state(&self, id: &RelationshipId) -> Result<Option<RelationshipState>, RelationshipError>;
    fn history(&self, id: &RelationshipId) -> Result<Vec<RelationshipTransition>, RelationshipError>;
    fn states(&self, id: &RelationshipId) -> Result<Vec<RelationshipState>, RelationshipError>;
    fn list_for_character_at(&self, character: &CharacterId, chapter: u32) -> Result<Vec<(Relationship, RelationshipState)>, RelationshipError>;
    fn list_all_at(&self, chapter: u32) -> Result<Vec<(Relationship, RelationshipState)>, RelationshipError>;
    fn exists_equivalent(&self, type_id: &RelationshipTypeId, source: &CharacterId, target: &CharacterId, symmetric: bool) -> Result<bool, RelationshipError>;

    fn create_atomic(&self, relationship: &Relationship, state: &RelationshipState, transition: &RelationshipTransition) -> Result<(), RelationshipError>;
    fn change_state_atomic(&self, current: &RelationshipState, next: &RelationshipState, transition: &RelationshipTransition) -> Result<(), RelationshipError>;
    fn end_atomic(&self, current: &RelationshipState, chapter: u32, transition: &RelationshipTransition) -> Result<(), RelationshipError>;
    fn reopen_atomic(&self, next: &RelationshipState, transition: &RelationshipTransition) -> Result<(), RelationshipError>;
}
