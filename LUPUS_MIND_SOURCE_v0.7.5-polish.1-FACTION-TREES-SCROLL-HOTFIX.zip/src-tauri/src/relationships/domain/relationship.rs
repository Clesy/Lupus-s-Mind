use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use crate::characters::domain::character::CharacterId;

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, Hash)]
pub struct RelationshipId(pub String);

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, Hash)]
pub struct RelationshipTypeId(pub String);

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, Hash)]
pub struct RelationshipStateId(pub String);

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, Hash)]
pub struct RelationshipTransitionId(pub String);

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum Directionality {
    Directed,
    Symmetric,
}
impl Directionality {
    pub fn as_db(self) -> &'static str { match self { Self::Directed => "directed", Self::Symmetric => "symmetric" } }
    pub fn from_db(value: &str) -> Option<Self> { Some(match value { "directed" => Self::Directed, "symmetric" => Self::Symmetric, _ => return None }) }
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum RelationshipCategory {
    Affinity,
    Conflict,
    Kinship,
    Authority,
    Knowledge,
    Social,
}
impl RelationshipCategory {
    pub fn as_db(self) -> &'static str { match self { Self::Affinity=>"affinity", Self::Conflict=>"conflict", Self::Kinship=>"kinship", Self::Authority=>"authority", Self::Knowledge=>"knowledge", Self::Social=>"social" } }
    pub fn from_db(value: &str) -> Option<Self> { Some(match value { "affinity"=>Self::Affinity, "conflict"=>Self::Conflict, "kinship"=>Self::Kinship, "authority"=>Self::Authority, "knowledge"=>Self::Knowledge, "social"=>Self::Social, _=>return None }) }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RelationshipType {
    pub id: RelationshipTypeId,
    pub key: String,
    pub forward_label: String,
    pub inverse_label: String,
    pub directionality: Directionality,
    pub category: RelationshipCategory,
    pub created_at: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Relationship {
    pub id: RelationshipId,
    pub type_id: RelationshipTypeId,
    pub source_character_id: CharacterId,
    pub target_character_id: CharacterId,
    pub created_at: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RelationshipState {
    pub id: RelationshipStateId,
    pub relationship_id: RelationshipId,
    pub valid_from_chapter: u32,
    pub valid_to_chapter: Option<u32>,
    pub intensity: u8,
    pub note: String,
    pub tags: Vec<String>,
    pub created_at: DateTime<Utc>,
}

impl RelationshipState {
    pub fn is_valid_at(&self, chapter: u32) -> bool {
        self.valid_from_chapter <= chapter && match self.valid_to_chapter { Some(to) => chapter < to, None => true }
    }
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum RelationshipTransitionKind {
    Created,
    StateChanged,
    Ended,
    Reopened,
}
impl RelationshipTransitionKind {
    pub fn as_db(self) -> &'static str { match self { Self::Created=>"created", Self::StateChanged=>"state_changed", Self::Ended=>"ended", Self::Reopened=>"reopened" } }
    pub fn from_db(value: &str) -> Option<Self> { Some(match value { "created"=>Self::Created, "state_changed"=>Self::StateChanged, "ended"=>Self::Ended, "reopened"=>Self::Reopened, _=>return None }) }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RelationshipTransition {
    pub id: RelationshipTransitionId,
    pub relationship_id: RelationshipId,
    pub chapter: u32,
    pub kind: RelationshipTransitionKind,
    pub before_state_id: Option<RelationshipStateId>,
    pub after_state_id: Option<RelationshipStateId>,
    pub created_at: DateTime<Utc>,
}
