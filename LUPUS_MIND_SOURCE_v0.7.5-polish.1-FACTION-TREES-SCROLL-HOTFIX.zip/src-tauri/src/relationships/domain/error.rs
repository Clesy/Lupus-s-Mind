use serde::Serialize;
use thiserror::Error;

#[derive(Debug, Error, Serialize)]
#[serde(tag = "kind", content = "message", rename_all = "snake_case")]
pub enum RelationshipError {
    #[error("Relationship not found: {0}")]
    NotFound(String),
    #[error("Relationship type not found: {0}")]
    TypeNotFound(String),
    #[error("Character not found: {0}")]
    CharacterNotFound(String),
    #[error("Relationship already exists: {0}")]
    Duplicate(String),
    #[error("Relationship has no open state: {0}")]
    NoOpenState(String),
    #[error("Relationship is already active: {0}")]
    AlreadyActive(String),
    #[error("Validation error: {0}")]
    Validation(String),
    #[error("Temporal conflict: {0}")]
    TemporalConflict(String),
    #[error("Database error: {0}")]
    Database(String),
    #[error("Mapping error: {0}")]
    Mapping(String),
}
