use chrono::Utc;
use serde::{Deserialize, Serialize};
use uuid::Uuid;
use crate::{
    characters::domain::{character::CharacterId, repository::CharacterRepository},
    relationships::domain::{
        error::RelationshipError,
        relationship::{
            Directionality, Relationship, RelationshipId, RelationshipState, RelationshipStateId,
            RelationshipTransition, RelationshipTransitionId, RelationshipTransitionKind,
            RelationshipType, RelationshipTypeId,
        },
        repository::{RelationshipRepository, RelationshipTypeRepository},
    },
};

#[derive(Debug, Deserialize)]
#[serde(rename_all="camelCase")]
pub struct CreateRelationshipInput {
    pub type_id: String,
    pub source_character_id: String,
    pub target_character_id: String,
    pub chapter: u32,
    pub intensity: u8,
    pub note: Option<String>,
    pub tags: Vec<String>,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all="camelCase")]
pub struct ChangeRelationshipStateInput {
    pub relationship_id: String,
    pub chapter: u32,
    pub intensity: u8,
    pub note: Option<String>,
    pub tags: Vec<String>,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all="camelCase")]
pub struct EndRelationshipInput { pub relationship_id:String, pub chapter:u32 }

#[derive(Debug, Deserialize)]
#[serde(rename_all="camelCase")]
pub struct ReopenRelationshipInput {
    pub relationship_id:String,
    pub chapter:u32,
    pub intensity:u8,
    pub note:Option<String>,
    pub tags:Vec<String>,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all="camelCase")]
pub struct RelationshipTypeDto { pub id:String,pub key:String,pub forward_label:String,pub inverse_label:String,pub directionality:Directionality,pub category:String }

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all="camelCase")]
pub struct RelationshipStateDto { pub id:String,pub valid_from_chapter:u32,pub valid_to_chapter:Option<u32>,pub intensity:u8,pub note:String,pub tags:Vec<String> }

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all="camelCase")]
pub struct RelationshipDto {
    pub id:String,
    pub type_id:String,
    pub source_character_id:String,
    pub target_character_id:String,
    pub state:RelationshipStateDto,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all="camelCase")]
pub struct PerspectiveRelationshipDto {
    pub id:String,
    pub type_id:String,
    pub type_key:String,
    pub other_character_id:String,
    pub label:String,
    pub outbound:bool,
    pub directionality:Directionality,
    pub state:RelationshipStateDto,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all="camelCase")]
pub struct TransitionDto { pub id:String,pub chapter:u32,pub kind:String,pub before_state_id:Option<String>,pub after_state_id:Option<String>,pub created_at:String }

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all="camelCase")]
pub struct RelationshipHistoryDto { pub relationship_id:String,pub type_id:String,pub source_character_id:String,pub target_character_id:String,pub states:Vec<RelationshipStateDto>,pub transitions:Vec<TransitionDto> }

fn validate_chapter(chapter:u32)->Result<(),RelationshipError>{if chapter==0{Err(RelationshipError::Validation("chapter must be > 0".into()))}else{Ok(())}}
fn validate_intensity(intensity:u8)->Result<(),RelationshipError>{if intensity>100{Err(RelationshipError::Validation("intensity must be between 0 and 100".into()))}else{Ok(())}}
fn state_dto(state:RelationshipState)->RelationshipStateDto{RelationshipStateDto{id:state.id.0,valid_from_chapter:state.valid_from_chapter,valid_to_chapter:state.valid_to_chapter,intensity:state.intensity,note:state.note,tags:state.tags}}
fn type_dto(value:RelationshipType)->RelationshipTypeDto{RelationshipTypeDto{id:value.id.0,key:value.key,forward_label:value.forward_label,inverse_label:value.inverse_label,directionality:value.directionality,category:value.category.as_db().into()}}

pub fn list_types(types:&dyn RelationshipTypeRepository)->Result<Vec<RelationshipTypeDto>,RelationshipError>{Ok(types.list_types()?.into_iter().map(type_dto).collect())}

pub fn create(
    characters:&dyn CharacterRepository,
    types:&dyn RelationshipTypeRepository,
    relationships:&dyn RelationshipRepository,
    input:CreateRelationshipInput,
)->Result<RelationshipDto,RelationshipError>{
    validate_chapter(input.chapter)?;validate_intensity(input.intensity)?;
    if input.source_character_id==input.target_character_id{return Err(RelationshipError::Validation("self relationships are not allowed".into()));}
    let source=CharacterId(input.source_character_id.clone());let target=CharacterId(input.target_character_id.clone());
    if characters.get(&source).map_err(|e|RelationshipError::Database(e.to_string()))?.is_none(){return Err(RelationshipError::CharacterNotFound(source.0));}
    if characters.get(&target).map_err(|e|RelationshipError::Database(e.to_string()))?.is_none(){return Err(RelationshipError::CharacterNotFound(target.0));}
    let type_id=RelationshipTypeId(input.type_id.clone());let relationship_type=types.get_type(&type_id)?.ok_or(RelationshipError::TypeNotFound(input.type_id))?;
    let symmetric=relationship_type.directionality==Directionality::Symmetric;
    if relationships.exists_equivalent(&type_id,&source,&target,symmetric)?{return Err(RelationshipError::Duplicate(format!("{} relationship already exists for these characters",relationship_type.key)));}
    let now=Utc::now();let relationship_id=RelationshipId(Uuid::new_v4().to_string());let state_id=RelationshipStateId(Uuid::new_v4().to_string());
    let relationship=Relationship{id:relationship_id.clone(),type_id:type_id.clone(),source_character_id:source,target_character_id:target,created_at:now};
    let state=RelationshipState{id:state_id.clone(),relationship_id:relationship_id.clone(),valid_from_chapter:input.chapter,valid_to_chapter:None,intensity:input.intensity,note:input.note.unwrap_or_default(),tags:input.tags,created_at:now};
    let transition=RelationshipTransition{id:RelationshipTransitionId(Uuid::new_v4().to_string()),relationship_id:relationship_id.clone(),chapter:input.chapter,kind:RelationshipTransitionKind::Created,before_state_id:None,after_state_id:Some(state_id),created_at:now};
    relationships.create_atomic(&relationship,&state,&transition)?;
    Ok(RelationshipDto{id:relationship.id.0,type_id:type_id.0,source_character_id:relationship.source_character_id.0,target_character_id:relationship.target_character_id.0,state:state_dto(state)})
}

pub fn change_state(relationships:&dyn RelationshipRepository,input:ChangeRelationshipStateInput)->Result<RelationshipStateDto,RelationshipError>{
    validate_chapter(input.chapter)?;validate_intensity(input.intensity)?;let id=RelationshipId(input.relationship_id.clone());relationships.get(&id)?.ok_or(RelationshipError::NotFound(input.relationship_id.clone()))?;
    let current=relationships.open_state(&id)?.ok_or(RelationshipError::NoOpenState(input.relationship_id.clone()))?;
    if input.chapter<=current.valid_from_chapter{return Err(RelationshipError::TemporalConflict(format!("state change chapter {} must be greater than current validFrom {}",input.chapter,current.valid_from_chapter)));}
    let now=Utc::now();let next=RelationshipState{id:RelationshipStateId(Uuid::new_v4().to_string()),relationship_id:id.clone(),valid_from_chapter:input.chapter,valid_to_chapter:None,intensity:input.intensity,note:input.note.unwrap_or_default(),tags:input.tags,created_at:now};
    let transition=RelationshipTransition{id:RelationshipTransitionId(Uuid::new_v4().to_string()),relationship_id:id,chapter:input.chapter,kind:RelationshipTransitionKind::StateChanged,before_state_id:Some(current.id.clone()),after_state_id:Some(next.id.clone()),created_at:now};
    relationships.change_state_atomic(&current,&next,&transition)?;Ok(state_dto(next))
}

pub fn end(relationships:&dyn RelationshipRepository,input:EndRelationshipInput)->Result<(),RelationshipError>{
    validate_chapter(input.chapter)?;let id=RelationshipId(input.relationship_id.clone());relationships.get(&id)?.ok_or(RelationshipError::NotFound(input.relationship_id.clone()))?;
    let current=relationships.open_state(&id)?.ok_or(RelationshipError::NoOpenState(input.relationship_id.clone()))?;
    if input.chapter<=current.valid_from_chapter{return Err(RelationshipError::TemporalConflict(format!("end chapter {} must be greater than current validFrom {}",input.chapter,current.valid_from_chapter)));}
    let transition=RelationshipTransition{id:RelationshipTransitionId(Uuid::new_v4().to_string()),relationship_id:id,chapter:input.chapter,kind:RelationshipTransitionKind::Ended,before_state_id:Some(current.id.clone()),after_state_id:None,created_at:Utc::now()};
    relationships.end_atomic(&current,input.chapter,&transition)
}

pub fn reopen(relationships:&dyn RelationshipRepository,input:ReopenRelationshipInput)->Result<RelationshipStateDto,RelationshipError>{
    validate_chapter(input.chapter)?;validate_intensity(input.intensity)?;let id=RelationshipId(input.relationship_id.clone());relationships.get(&id)?.ok_or(RelationshipError::NotFound(input.relationship_id.clone()))?;
    if relationships.open_state(&id)?.is_some(){return Err(RelationshipError::AlreadyActive(input.relationship_id));}
    let latest=relationships.latest_state(&id)?.ok_or_else(||RelationshipError::TemporalConflict("relationship has no state history".into()))?;
    let ended_at=latest.valid_to_chapter.ok_or_else(||RelationshipError::AlreadyActive(id.0.clone()))?;
    if input.chapter<ended_at{return Err(RelationshipError::TemporalConflict(format!("reopen chapter {} cannot precede end chapter {}",input.chapter,ended_at)));}
    let now=Utc::now();let next=RelationshipState{id:RelationshipStateId(Uuid::new_v4().to_string()),relationship_id:id.clone(),valid_from_chapter:input.chapter,valid_to_chapter:None,intensity:input.intensity,note:input.note.unwrap_or_default(),tags:input.tags,created_at:now};
    let transition=RelationshipTransition{id:RelationshipTransitionId(Uuid::new_v4().to_string()),relationship_id:id,chapter:input.chapter,kind:RelationshipTransitionKind::Reopened,before_state_id:Some(latest.id),after_state_id:Some(next.id.clone()),created_at:now};
    relationships.reopen_atomic(&next,&transition)?;Ok(state_dto(next))
}

pub fn get_at(relationships:&dyn RelationshipRepository,id:String,chapter:u32)->Result<Option<RelationshipDto>,RelationshipError>{
    validate_chapter(chapter)?;let rid=RelationshipId(id.clone());let relationship=relationships.get(&rid)?.ok_or(RelationshipError::NotFound(id))?;
    Ok(relationships.get_state_at(&rid,chapter)?.map(|state|RelationshipDto{id:relationship.id.0,type_id:relationship.type_id.0,source_character_id:relationship.source_character_id.0,target_character_id:relationship.target_character_id.0,state:state_dto(state)}))
}

pub fn list_for_character_at(
    characters:&dyn CharacterRepository,types:&dyn RelationshipTypeRepository,relationships:&dyn RelationshipRepository,character_id:String,chapter:u32,
)->Result<Vec<PerspectiveRelationshipDto>,RelationshipError>{
    validate_chapter(chapter)?;let character=CharacterId(character_id.clone());if characters.get(&character).map_err(|e|RelationshipError::Database(e.to_string()))?.is_none(){return Err(RelationshipError::CharacterNotFound(character_id));}
    let rows=relationships.list_for_character_at(&character,chapter)?;let mut out=Vec::new();
    for (relationship,state) in rows { let ty=types.get_type(&relationship.type_id)?.ok_or_else(||RelationshipError::Mapping(format!("missing relationship type: {}",relationship.type_id.0)))?;let outbound=relationship.source_character_id==character;let other=if outbound{relationship.target_character_id.0}else{relationship.source_character_id.0};let label=if ty.directionality==Directionality::Symmetric||outbound{ty.forward_label}else{ty.inverse_label};out.push(PerspectiveRelationshipDto{id:relationship.id.0,type_id:ty.id.0,type_key:ty.key,other_character_id:other,label,outbound,directionality:ty.directionality,state:state_dto(state)}); }
    Ok(out)
}

pub fn history(relationships:&dyn RelationshipRepository,id:String)->Result<RelationshipHistoryDto,RelationshipError>{
    let rid=RelationshipId(id.clone());let relationship=relationships.get(&rid)?.ok_or(RelationshipError::NotFound(id.clone()))?;let states=relationships.states(&rid)?.into_iter().map(state_dto).collect();let transitions=relationships.history(&rid)?.into_iter().map(|t|TransitionDto{id:t.id.0,chapter:t.chapter,kind:t.kind.as_db().into(),before_state_id:t.before_state_id.map(|v|v.0),after_state_id:t.after_state_id.map(|v|v.0),created_at:t.created_at.to_rfc3339()}).collect();Ok(RelationshipHistoryDto{relationship_id:id,type_id:relationship.type_id.0,source_character_id:relationship.source_character_id.0,target_character_id:relationship.target_character_id.0,states,transitions})
}
