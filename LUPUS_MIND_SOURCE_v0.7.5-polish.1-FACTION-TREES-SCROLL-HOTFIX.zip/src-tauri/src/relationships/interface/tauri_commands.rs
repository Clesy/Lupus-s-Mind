use tauri::State;
use crate::{
    app_state::AppState,
    relationship_graph::application::graph_at_chapter::{self, RelationshipGraphSnapshotDto, RelationshipMatrixSnapshotDto},
    relationships::application::use_cases::{
        self, ChangeRelationshipStateInput, CreateRelationshipInput, EndRelationshipInput,
        PerspectiveRelationshipDto, RelationshipDto, RelationshipHistoryDto, RelationshipStateDto,
        RelationshipTypeDto, ReopenRelationshipInput,
    },
    shared::api_error::ApiError,
};

#[tauri::command]
pub fn relationship_types_list(state:State<'_,AppState>)->Result<Vec<RelationshipTypeDto>,ApiError>{use_cases::list_types(&state.relationships).map_err(Into::into)}
#[tauri::command]
pub fn relationships_create(state:State<'_,AppState>,input:CreateRelationshipInput)->Result<RelationshipDto,ApiError>{use_cases::create(&state.characters,&state.relationships,&state.relationships,input).map_err(Into::into)}
#[tauri::command]
pub fn relationships_change_state(state:State<'_,AppState>,input:ChangeRelationshipStateInput)->Result<RelationshipStateDto,ApiError>{use_cases::change_state(&state.relationships,input).map_err(Into::into)}
#[tauri::command]
pub fn relationships_end(state:State<'_,AppState>,input:EndRelationshipInput)->Result<(),ApiError>{use_cases::end(&state.relationships,input).map_err(Into::into)}
#[tauri::command]
pub fn relationships_reopen(state:State<'_,AppState>,input:ReopenRelationshipInput)->Result<RelationshipStateDto,ApiError>{use_cases::reopen(&state.relationships,input).map_err(Into::into)}
#[tauri::command]
pub fn relationships_get_at(state:State<'_,AppState>,id:String,chapter:u32)->Result<Option<RelationshipDto>,ApiError>{use_cases::get_at(&state.relationships,id,chapter).map_err(Into::into)}
#[tauri::command]
pub fn relationships_for_character_at(state:State<'_,AppState>,character_id:String,chapter:u32)->Result<Vec<PerspectiveRelationshipDto>,ApiError>{use_cases::list_for_character_at(&state.characters,&state.relationships,&state.relationships,character_id,chapter).map_err(Into::into)}
#[tauri::command]
pub fn relationships_history(state:State<'_,AppState>,id:String)->Result<RelationshipHistoryDto,ApiError>{use_cases::history(&state.relationships,id).map_err(Into::into)}
#[tauri::command]
pub fn relationships_graph_at(state:State<'_,AppState>,chapter:u32)->Result<RelationshipGraphSnapshotDto,ApiError>{graph_at_chapter::graph_at_chapter(&state.characters,&state.relationships,&state.relationships,chapter).map_err(Into::into)}
#[tauri::command]
pub fn relationships_matrix_at(state:State<'_,AppState>,chapter:u32)->Result<RelationshipMatrixSnapshotDto,ApiError>{graph_at_chapter::matrix_at_chapter(&state.characters,&state.relationships,&state.relationships,chapter).map_err(Into::into)}
