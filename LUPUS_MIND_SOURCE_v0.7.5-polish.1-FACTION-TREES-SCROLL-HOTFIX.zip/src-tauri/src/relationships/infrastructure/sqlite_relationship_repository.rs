use chrono::{DateTime, Utc};
use rusqlite::{params, OptionalExtension, Row};
use crate::{
    characters::domain::character::CharacterId,
    shared::database::SharedConnection,
    relationships::domain::{
        error::RelationshipError,
        relationship::{
            Directionality, Relationship, RelationshipCategory, RelationshipId, RelationshipState,
            RelationshipStateId, RelationshipTransition, RelationshipTransitionId,
            RelationshipTransitionKind, RelationshipType, RelationshipTypeId,
        },
        repository::{RelationshipRepository, RelationshipTypeRepository},
    },
};

pub struct SqliteRelationshipRepository { conn: SharedConnection }
impl SqliteRelationshipRepository { pub fn new(conn: SharedConnection) -> Self { Self { conn } } }

struct RawType { id:String,key:String,forward:String,inverse:String,directionality:String,category:String,created_at:String }
struct RawRelationship { id:String,type_id:String,source:String,target:String,created_at:String }
struct RawState { id:String,relationship_id:String,from:u32,to:Option<u32>,intensity:u8,note:String,tags:String,created_at:String }
struct RawTransition { id:String,relationship_id:String,chapter:u32,kind:String,before:Option<String>,after:Option<String>,created_at:String }

impl SqliteRelationshipRepository {
    fn db(error: rusqlite::Error) -> RelationshipError {
        let message = error.to_string();
        if message.contains("symmetric relationship already exists") || message.contains("UNIQUE constraint failed: relationships") {
            return RelationshipError::Duplicate(message);
        }
        if message.contains("relationship state interval overlap") || message.contains("idx_relationship_open_state") {
            return RelationshipError::TemporalConflict(message);
        }
        RelationshipError::Database(message)
    }
    fn lock(&self) -> Result<std::sync::MutexGuard<'_, rusqlite::Connection>, RelationshipError> {
        self.conn.lock().map_err(|e| RelationshipError::Database(e.to_string()))
    }
    fn parse_time(value:&str) -> Result<DateTime<Utc>, RelationshipError> {
        DateTime::parse_from_rfc3339(value).map(|dt| dt.with_timezone(&Utc)).map_err(|e| RelationshipError::Mapping(e.to_string()))
    }
    fn raw_type(row:&Row<'_>) -> rusqlite::Result<RawType> { Ok(RawType{id:row.get(0)?,key:row.get(1)?,forward:row.get(2)?,inverse:row.get(3)?,directionality:row.get(4)?,category:row.get(5)?,created_at:row.get(6)?}) }
    fn map_type(raw:RawType)->Result<RelationshipType,RelationshipError>{
        Ok(RelationshipType{id:RelationshipTypeId(raw.id),key:raw.key,forward_label:raw.forward,inverse_label:raw.inverse,directionality:Directionality::from_db(&raw.directionality).ok_or_else(||RelationshipError::Mapping(format!("unknown directionality: {}",raw.directionality)))?,category:RelationshipCategory::from_db(&raw.category).ok_or_else(||RelationshipError::Mapping(format!("unknown relationship category: {}",raw.category)))?,created_at:Self::parse_time(&raw.created_at)?})
    }
    fn raw_rel(row:&Row<'_>)->rusqlite::Result<RawRelationship>{Ok(RawRelationship{id:row.get(0)?,type_id:row.get(1)?,source:row.get(2)?,target:row.get(3)?,created_at:row.get(4)?})}
    fn map_rel(raw:RawRelationship)->Result<Relationship,RelationshipError>{Ok(Relationship{id:RelationshipId(raw.id),type_id:RelationshipTypeId(raw.type_id),source_character_id:CharacterId(raw.source),target_character_id:CharacterId(raw.target),created_at:Self::parse_time(&raw.created_at)?})}
    fn raw_state(row:&Row<'_>)->rusqlite::Result<RawState>{Ok(RawState{id:row.get(0)?,relationship_id:row.get(1)?,from:row.get(2)?,to:row.get(3)?,intensity:row.get(4)?,note:row.get(5)?,tags:row.get(6)?,created_at:row.get(7)?})}
    fn map_state(raw:RawState)->Result<RelationshipState,RelationshipError>{Ok(RelationshipState{id:RelationshipStateId(raw.id),relationship_id:RelationshipId(raw.relationship_id),valid_from_chapter:raw.from,valid_to_chapter:raw.to,intensity:raw.intensity,note:raw.note,tags:serde_json::from_str(&raw.tags).map_err(|e|RelationshipError::Mapping(e.to_string()))?,created_at:Self::parse_time(&raw.created_at)?})}
    fn raw_transition(row:&Row<'_>)->rusqlite::Result<RawTransition>{Ok(RawTransition{id:row.get(0)?,relationship_id:row.get(1)?,chapter:row.get(2)?,kind:row.get(3)?,before:row.get(4)?,after:row.get(5)?,created_at:row.get(6)?})}
    fn map_transition(raw:RawTransition)->Result<RelationshipTransition,RelationshipError>{Ok(RelationshipTransition{id:RelationshipTransitionId(raw.id),relationship_id:RelationshipId(raw.relationship_id),chapter:raw.chapter,kind:RelationshipTransitionKind::from_db(&raw.kind).ok_or_else(||RelationshipError::Mapping(format!("unknown transition kind: {}",raw.kind)))?,before_state_id:raw.before.map(RelationshipStateId),after_state_id:raw.after.map(RelationshipStateId),created_at:Self::parse_time(&raw.created_at)?})}
    fn state_tags(state:&RelationshipState)->Result<String,RelationshipError>{serde_json::to_string(&state.tags).map_err(|e|RelationshipError::Mapping(e.to_string()))}
    fn insert_state(tx:&rusqlite::Transaction<'_>, state:&RelationshipState)->Result<(),RelationshipError>{
        tx.execute("INSERT INTO relationship_states(id,relationship_id,valid_from_chapter,valid_to_chapter,intensity,note,tags,created_at) VALUES(?,?,?,?,?,?,?,?)",params![&state.id.0,&state.relationship_id.0,state.valid_from_chapter,state.valid_to_chapter,state.intensity,&state.note,Self::state_tags(state)?,state.created_at.to_rfc3339()]).map_err(Self::db)?;Ok(())
    }
    fn insert_transition(tx:&rusqlite::Transaction<'_>, transition:&RelationshipTransition)->Result<(),RelationshipError>{
        tx.execute("INSERT INTO relationship_transitions(id,relationship_id,chapter,kind,before_state_id,after_state_id,created_at) VALUES(?,?,?,?,?,?,?)",params![&transition.id.0,&transition.relationship_id.0,transition.chapter,transition.kind.as_db(),transition.before_state_id.as_ref().map(|v|&v.0),transition.after_state_id.as_ref().map(|v|&v.0),transition.created_at.to_rfc3339()]).map_err(Self::db)?;Ok(())
    }
}

impl RelationshipTypeRepository for SqliteRelationshipRepository {
    fn list_types(&self)->Result<Vec<RelationshipType>,RelationshipError>{
        let conn=self.lock()?;let mut stmt=conn.prepare("SELECT id,key,forward_label,inverse_label,directionality,category,created_at FROM relationship_types ORDER BY category,key").map_err(Self::db)?;let rows=stmt.query_map([],Self::raw_type).map_err(Self::db)?;let mut out=Vec::new();for row in rows{out.push(Self::map_type(row.map_err(Self::db)?)?);}Ok(out)
    }
    fn get_type(&self,id:&RelationshipTypeId)->Result<Option<RelationshipType>,RelationshipError>{
        let conn=self.lock()?;let raw=conn.query_row("SELECT id,key,forward_label,inverse_label,directionality,category,created_at FROM relationship_types WHERE id=?",params![&id.0],Self::raw_type).optional().map_err(Self::db)?;raw.map(Self::map_type).transpose()
    }
}

impl RelationshipRepository for SqliteRelationshipRepository {
    fn get(&self,id:&RelationshipId)->Result<Option<Relationship>,RelationshipError>{let conn=self.lock()?;let raw=conn.query_row("SELECT id,type_id,source_character_id,target_character_id,created_at FROM relationships WHERE id=?",params![&id.0],Self::raw_rel).optional().map_err(Self::db)?;raw.map(Self::map_rel).transpose()}
    fn get_state_at(&self,id:&RelationshipId,chapter:u32)->Result<Option<RelationshipState>,RelationshipError>{let conn=self.lock()?;let raw=conn.query_row("SELECT id,relationship_id,valid_from_chapter,valid_to_chapter,intensity,note,tags,created_at FROM relationship_states WHERE relationship_id=? AND valid_from_chapter<=? AND (valid_to_chapter IS NULL OR ?<valid_to_chapter) ORDER BY valid_from_chapter DESC LIMIT 1",params![&id.0,chapter,chapter],Self::raw_state).optional().map_err(Self::db)?;raw.map(Self::map_state).transpose()}
    fn open_state(&self,id:&RelationshipId)->Result<Option<RelationshipState>,RelationshipError>{let conn=self.lock()?;let raw=conn.query_row("SELECT id,relationship_id,valid_from_chapter,valid_to_chapter,intensity,note,tags,created_at FROM relationship_states WHERE relationship_id=? AND valid_to_chapter IS NULL LIMIT 1",params![&id.0],Self::raw_state).optional().map_err(Self::db)?;raw.map(Self::map_state).transpose()}
    fn latest_state(&self,id:&RelationshipId)->Result<Option<RelationshipState>,RelationshipError>{let conn=self.lock()?;let raw=conn.query_row("SELECT id,relationship_id,valid_from_chapter,valid_to_chapter,intensity,note,tags,created_at FROM relationship_states WHERE relationship_id=? ORDER BY valid_from_chapter DESC LIMIT 1",params![&id.0],Self::raw_state).optional().map_err(Self::db)?;raw.map(Self::map_state).transpose()}
    fn history(&self,id:&RelationshipId)->Result<Vec<RelationshipTransition>,RelationshipError>{let conn=self.lock()?;let mut stmt=conn.prepare("SELECT id,relationship_id,chapter,kind,before_state_id,after_state_id,created_at FROM relationship_transitions WHERE relationship_id=? ORDER BY chapter,created_at").map_err(Self::db)?;let rows=stmt.query_map(params![&id.0],Self::raw_transition).map_err(Self::db)?;let mut out=Vec::new();for row in rows{out.push(Self::map_transition(row.map_err(Self::db)?)?);}Ok(out)}
    fn states(&self,id:&RelationshipId)->Result<Vec<RelationshipState>,RelationshipError>{let conn=self.lock()?;let mut stmt=conn.prepare("SELECT id,relationship_id,valid_from_chapter,valid_to_chapter,intensity,note,tags,created_at FROM relationship_states WHERE relationship_id=? ORDER BY valid_from_chapter").map_err(Self::db)?;let rows=stmt.query_map(params![&id.0],Self::raw_state).map_err(Self::db)?;let mut out=Vec::new();for row in rows{out.push(Self::map_state(row.map_err(Self::db)?)?);}Ok(out)}
    fn list_for_character_at(&self,character:&CharacterId,chapter:u32)->Result<Vec<(Relationship,RelationshipState)>,RelationshipError>{
        let conn=self.lock()?;let mut stmt=conn.prepare("SELECT r.id,r.type_id,r.source_character_id,r.target_character_id,r.created_at,s.id,s.relationship_id,s.valid_from_chapter,s.valid_to_chapter,s.intensity,s.note,s.tags,s.created_at FROM relationships r JOIN relationship_states s ON s.relationship_id=r.id WHERE (r.source_character_id=? OR r.target_character_id=?) AND s.valid_from_chapter<=? AND (s.valid_to_chapter IS NULL OR ?<s.valid_to_chapter) ORDER BY r.id").map_err(Self::db)?;
        let rows=stmt.query_map(params![&character.0,&character.0,chapter,chapter],|row|{let rel=RawRelationship{id:row.get(0)?,type_id:row.get(1)?,source:row.get(2)?,target:row.get(3)?,created_at:row.get(4)?};let st=RawState{id:row.get(5)?,relationship_id:row.get(6)?,from:row.get(7)?,to:row.get(8)?,intensity:row.get(9)?,note:row.get(10)?,tags:row.get(11)?,created_at:row.get(12)?};Ok((rel,st))}).map_err(Self::db)?;let mut out=Vec::new();for row in rows{let(r,s)=row.map_err(Self::db)?;out.push((Self::map_rel(r)?,Self::map_state(s)?));}Ok(out)
    }
    fn list_all_at(&self,chapter:u32)->Result<Vec<(Relationship,RelationshipState)>,RelationshipError>{
        let conn=self.lock()?;let mut stmt=conn.prepare("SELECT r.id,r.type_id,r.source_character_id,r.target_character_id,r.created_at,s.id,s.relationship_id,s.valid_from_chapter,s.valid_to_chapter,s.intensity,s.note,s.tags,s.created_at FROM relationships r JOIN relationship_states s ON s.relationship_id=r.id WHERE s.valid_from_chapter<=? AND (s.valid_to_chapter IS NULL OR ?<s.valid_to_chapter) ORDER BY r.id").map_err(Self::db)?;
        let rows=stmt.query_map(params![chapter,chapter],|row|{let rel=RawRelationship{id:row.get(0)?,type_id:row.get(1)?,source:row.get(2)?,target:row.get(3)?,created_at:row.get(4)?};let st=RawState{id:row.get(5)?,relationship_id:row.get(6)?,from:row.get(7)?,to:row.get(8)?,intensity:row.get(9)?,note:row.get(10)?,tags:row.get(11)?,created_at:row.get(12)?};Ok((rel,st))}).map_err(Self::db)?;let mut out=Vec::new();for row in rows{let(r,s)=row.map_err(Self::db)?;out.push((Self::map_rel(r)?,Self::map_state(s)?));}Ok(out)
    }
    fn exists_equivalent(&self,type_id:&RelationshipTypeId,source:&CharacterId,target:&CharacterId,symmetric:bool)->Result<bool,RelationshipError>{let conn=self.lock()?;let count:i64=if symmetric{conn.query_row("SELECT COUNT(*) FROM relationships WHERE type_id=? AND ((source_character_id=? AND target_character_id=?) OR (source_character_id=? AND target_character_id=?))",params![&type_id.0,&source.0,&target.0,&target.0,&source.0],|r|r.get(0)).map_err(Self::db)?}else{conn.query_row("SELECT COUNT(*) FROM relationships WHERE type_id=? AND source_character_id=? AND target_character_id=?",params![&type_id.0,&source.0,&target.0],|r|r.get(0)).map_err(Self::db)?};Ok(count>0)}

    fn create_atomic(&self,relationship:&Relationship,state:&RelationshipState,transition:&RelationshipTransition)->Result<(),RelationshipError>{let mut conn=self.lock()?;let tx=conn.transaction().map_err(Self::db)?;tx.execute("INSERT INTO relationships(id,type_id,source_character_id,target_character_id,created_at) VALUES(?,?,?,?,?)",params![&relationship.id.0,&relationship.type_id.0,&relationship.source_character_id.0,&relationship.target_character_id.0,relationship.created_at.to_rfc3339()]).map_err(Self::db)?;Self::insert_state(&tx,state)?;Self::insert_transition(&tx,transition)?;tx.commit().map_err(Self::db)}
    fn change_state_atomic(&self,current:&RelationshipState,next:&RelationshipState,transition:&RelationshipTransition)->Result<(),RelationshipError>{let mut conn=self.lock()?;let tx=conn.transaction().map_err(Self::db)?;let affected=tx.execute("UPDATE relationship_states SET valid_to_chapter=? WHERE id=? AND valid_to_chapter IS NULL",params![next.valid_from_chapter,&current.id.0]).map_err(Self::db)?;if affected!=1{return Err(RelationshipError::TemporalConflict("open state changed concurrently".into()));}Self::insert_state(&tx,next)?;Self::insert_transition(&tx,transition)?;tx.commit().map_err(Self::db)}
    fn end_atomic(&self,current:&RelationshipState,chapter:u32,transition:&RelationshipTransition)->Result<(),RelationshipError>{let mut conn=self.lock()?;let tx=conn.transaction().map_err(Self::db)?;let affected=tx.execute("UPDATE relationship_states SET valid_to_chapter=? WHERE id=? AND valid_to_chapter IS NULL",params![chapter,&current.id.0]).map_err(Self::db)?;if affected!=1{return Err(RelationshipError::TemporalConflict("open state changed concurrently".into()));}Self::insert_transition(&tx,transition)?;tx.commit().map_err(Self::db)}
    fn reopen_atomic(&self,next:&RelationshipState,transition:&RelationshipTransition)->Result<(),RelationshipError>{let mut conn=self.lock()?;let tx=conn.transaction().map_err(Self::db)?;Self::insert_state(&tx,next)?;Self::insert_transition(&tx,transition)?;tx.commit().map_err(Self::db)}
}
