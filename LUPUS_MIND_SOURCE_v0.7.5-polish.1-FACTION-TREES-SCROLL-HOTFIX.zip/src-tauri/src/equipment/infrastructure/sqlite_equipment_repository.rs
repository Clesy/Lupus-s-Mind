use rusqlite::{params, OptionalExtension};
use crate::{
    characters::domain::character::CharacterId,
    items::domain::item::{ItemId, ItemType},
    shared::database::SharedConnection,
};
use crate::equipment::domain::{
    equipment::{compatible, EquippedItem, EquipmentSlot},
    error::EquipmentError,
    repository::EquipmentRepository,
};

#[derive(Clone)]
pub struct SqliteEquipmentRepository {
    conn: SharedConnection,
}

impl SqliteEquipmentRepository {
    pub fn new(conn: SharedConnection) -> Self {
        Self { conn }
    }

    fn map_relation(
        character_id: String,
        item_id: String,
        slot: String,
    ) -> Result<EquippedItem, EquipmentError> {
        let slot = EquipmentSlot::from_db(&slot)
            .ok_or_else(|| EquipmentError::Mapping(format!("unknown slot {slot}")))?;
        Ok(EquippedItem {
            character_id: CharacterId(character_id),
            item_id: ItemId(item_id),
            slot,
        })
    }
}

impl EquipmentRepository for SqliteEquipmentRepository {
    fn list_for_character(&self, id: &CharacterId) -> Result<Vec<EquippedItem>, EquipmentError> {
        let conn = self
            .conn
            .lock()
            .map_err(|error| EquipmentError::Database(error.to_string()))?;
        let mut statement = conn
            .prepare(
                "SELECT character_id, item_id, slot FROM character_equipment WHERE character_id = ? ORDER BY slot",
            )
            .map_err(|error| EquipmentError::Database(error.to_string()))?;
        let rows = statement
            .query_map(params![&id.0], |row| {
                Ok((
                    row.get::<_, String>(0)?,
                    row.get::<_, String>(1)?,
                    row.get::<_, String>(2)?,
                ))
            })
            .map_err(|error| EquipmentError::Database(error.to_string()))?;

        rows.map(|row| {
            let (character_id, item_id, slot) =
                row.map_err(|error| EquipmentError::Database(error.to_string()))?;
            Self::map_relation(character_id, item_id, slot)
        })
        .collect()
    }

    fn find_by_item(&self, id: &ItemId) -> Result<Option<EquippedItem>, EquipmentError> {
        let conn = self
            .conn
            .lock()
            .map_err(|error| EquipmentError::Database(error.to_string()))?;
        let relation: Option<(String, String, String)> = conn
            .query_row(
                "SELECT character_id, item_id, slot FROM character_equipment WHERE item_id = ?",
                params![&id.0],
                |row| Ok((row.get(0)?, row.get(1)?, row.get(2)?)),
            )
            .optional()
            .map_err(|error| EquipmentError::Database(error.to_string()))?;

        relation
            .map(|(character_id, item_id, slot)| Self::map_relation(character_id, item_id, slot))
            .transpose()
    }

    fn replace_slot_atomic(
        &self,
        character: &CharacterId,
        item: &ItemId,
        slot: EquipmentSlot,
    ) -> Result<(), EquipmentError> {
        let conn = self
            .conn
            .lock()
            .map_err(|error| EquipmentError::Database(error.to_string()))?;
        let transaction = conn
            .unchecked_transaction()
            .map_err(|error| EquipmentError::Database(error.to_string()))?;

        let character_exists: i64 = transaction
            .query_row(
                "SELECT COUNT(*) FROM characters WHERE id = ?",
                params![&character.0],
                |row| row.get(0),
            )
            .map_err(|error| EquipmentError::Database(error.to_string()))?;
        if character_exists == 0 {
            return Err(EquipmentError::CharacterNotFound(character.0.clone()));
        }

        let item_type: Option<String> = transaction
            .query_row(
                "SELECT item_type FROM items WHERE id = ?",
                params![&item.0],
                |row| row.get(0),
            )
            .optional()
            .map_err(|error| EquipmentError::Database(error.to_string()))?;
        let item_type = item_type.ok_or_else(|| EquipmentError::ItemNotFound(item.0.clone()))?;
        let parsed_item_type = ItemType::from_db(&item_type)
            .ok_or_else(|| EquipmentError::Mapping(format!("unknown item type {item_type}")))?;
        if !compatible(parsed_item_type, slot) {
            return Err(EquipmentError::IncompatibleSlot {
                item_type,
                slot: slot.as_db().into(),
            });
        }

        let occupied: Option<(String, String)> = transaction
            .query_row(
                "SELECT character_id, slot FROM character_equipment WHERE item_id = ?",
                params![&item.0],
                |row| Ok((row.get(0)?, row.get(1)?)),
            )
            .optional()
            .map_err(|error| EquipmentError::Database(error.to_string()))?;
        if let Some((character_id, occupied_slot)) = occupied {
            if character_id != character.0 || occupied_slot != slot.as_db() {
                return Err(EquipmentError::ItemAlreadyEquipped(item.0.clone()));
            }
            return Ok(());
        }

        transaction
            .execute(
                "DELETE FROM character_equipment WHERE character_id = ? AND slot = ?",
                params![&character.0, slot.as_db()],
            )
            .map_err(|error| EquipmentError::Database(error.to_string()))?;
        transaction
            .execute(
                "INSERT INTO character_equipment(character_id, slot, item_id) VALUES(?, ?, ?)",
                params![&character.0, slot.as_db(), &item.0],
            )
            .map_err(|error| EquipmentError::Database(error.to_string()))?;
        transaction
            .commit()
            .map_err(|error| EquipmentError::Database(error.to_string()))?;
        Ok(())
    }

    fn unequip_atomic(
        &self,
        character: &CharacterId,
        slot: EquipmentSlot,
    ) -> Result<(), EquipmentError> {
        let conn = self
            .conn
            .lock()
            .map_err(|error| EquipmentError::Database(error.to_string()))?;
        let transaction = conn
            .unchecked_transaction()
            .map_err(|error| EquipmentError::Database(error.to_string()))?;
        let exists: i64 = transaction
            .query_row(
                "SELECT COUNT(*) FROM characters WHERE id = ?",
                params![&character.0],
                |row| row.get(0),
            )
            .map_err(|error| EquipmentError::Database(error.to_string()))?;
        if exists == 0 {
            return Err(EquipmentError::CharacterNotFound(character.0.clone()));
        }
        transaction
            .execute(
                "DELETE FROM character_equipment WHERE character_id = ? AND slot = ?",
                params![&character.0, slot.as_db()],
            )
            .map_err(|error| EquipmentError::Database(error.to_string()))?;
        transaction
            .commit()
            .map_err(|error| EquipmentError::Database(error.to_string()))?;
        Ok(())
    }
}
