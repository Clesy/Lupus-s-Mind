use tauri::State;
use crate::{
    app_state::AppState,
    character_sheet::application::get_character_sheet::{
        self, CharacterSheetDto, EquippedItemDto, SheetError,
    },
    equipment::{
        application::use_cases::{
            CompatibleItemDto, EquipItemInput, EquipmentServices,
        },
        domain::equipment::EquipmentSlot,
    },
    shared::api_error::ApiError,
};

fn api(error: SheetError) -> ApiError {
    ApiError {
        code: "character_sheet_error".into(),
        message: error.to_string(),
    }
}

fn services(state: &AppState) -> EquipmentServices<'_> {
    EquipmentServices {
        characters: &state.characters,
        items: &state.items,
        equipment: &state.equipment,
    }
}

#[tauri::command]
pub fn equipment_list(
    state: State<'_, AppState>,
    character_id: String,
) -> Result<Vec<EquippedItemDto>, ApiError> {
    services(state.inner()).list(character_id).map_err(api)
}

#[tauri::command]
pub fn equipment_compatible_items(
    state: State<'_, AppState>,
    character_id: String,
    slot: EquipmentSlot,
) -> Result<Vec<CompatibleItemDto>, ApiError> {
    services(state.inner())
        .compatible_items(character_id, slot)
        .map_err(api)
}

#[tauri::command]
pub fn equipment_equip(
    state: State<'_, AppState>,
    input: EquipItemInput,
) -> Result<CharacterSheetDto, ApiError> {
    services(state.inner()).equip(input).map_err(api)
}

#[tauri::command]
pub fn equipment_unequip(
    state: State<'_, AppState>,
    character_id: String,
    slot: EquipmentSlot,
) -> Result<CharacterSheetDto, ApiError> {
    services(state.inner())
        .unequip(character_id, slot)
        .map_err(api)
}

#[tauri::command]
pub fn character_sheet_get(
    state: State<'_, AppState>,
    character_id: String,
) -> Result<CharacterSheetDto, ApiError> {
    get_character_sheet::get_sheet(
        &state.characters,
        &state.items,
        &state.equipment,
        character_id,
    )
    .map_err(api)
}
