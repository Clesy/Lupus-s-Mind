use serde::{Deserialize, Serialize};
use crate::{
    character_sheet::application::get_character_sheet::{
        self, CharacterSheetDto, EquippedItemDto, ItemSnapshotDto, SheetError,
    },
    characters::domain::{character::CharacterId, repository::CharacterRepository},
    equipment::domain::{
        equipment::{compatible, EquipmentSlot},
        repository::EquipmentRepository,
    },
    items::{
        application::use_cases::{dto as item_dto, ItemDto},
        domain::{item::ItemId, repository::ItemRepository},
    },
};

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct EquipItemInput {
    pub character_id: String,
    pub item_id: String,
    pub slot: EquipmentSlot,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct CompatibleItemDto {
    pub item: ItemDto,
    pub available: bool,
    pub equipped_by_character_id: Option<String>,
    pub equipped_slot: Option<EquipmentSlot>,
    pub equipped_here: bool,
}

pub struct EquipmentServices<'a> {
    pub characters: &'a dyn CharacterRepository,
    pub items: &'a dyn ItemRepository,
    pub equipment: &'a dyn EquipmentRepository,
}

impl<'a> EquipmentServices<'a> {
    pub fn list(&self, character_id: String) -> Result<Vec<EquippedItemDto>, SheetError> {
        let relations = self
            .equipment
            .list_for_character(&CharacterId(character_id))?;
        let mut output = Vec::new();
        for relation in relations {
            let item = self
                .items
                .get(&relation.item_id)
                .map_err(|error| SheetError::Item(error.to_string()))?
                .ok_or_else(|| SheetError::MissingItem(relation.item_id.0.clone()))?;
            output.push(EquippedItemDto {
                slot: relation.slot,
                item: ItemSnapshotDto::from(item),
            });
        }
        Ok(output)
    }

    pub fn compatible_items(
        &self,
        character_id: String,
        slot: EquipmentSlot,
    ) -> Result<Vec<CompatibleItemDto>, SheetError> {
        let character_id = CharacterId(character_id);
        self.characters
            .get(&character_id)?
            .ok_or_else(|| crate::characters::domain::error::CharacterError::NotFound(character_id.0.clone()))?;

        let items = self
            .items
            .list()
            .map_err(|error| SheetError::Item(error.to_string()))?;
        let mut candidates = Vec::new();

        for item in items.into_iter().filter(|item| compatible(item.item_type, slot)) {
            let occupancy = self.equipment.find_by_item(&item.id)?;
            let equipped_here = occupancy.as_ref().is_some_and(|relation| {
                relation.character_id == character_id && relation.slot == slot
            });
            let available = occupancy.is_none() || equipped_here;
            let equipped_by_character_id = occupancy
                .as_ref()
                .map(|relation| relation.character_id.0.clone());
            let equipped_slot = occupancy.as_ref().map(|relation| relation.slot);

            candidates.push(CompatibleItemDto {
                item: item_dto(item),
                available,
                equipped_by_character_id,
                equipped_slot,
                equipped_here,
            });
        }

        candidates.sort_by(|left, right| left.item.name.cmp(&right.item.name));
        Ok(candidates)
    }

    pub fn equip(&self, input: EquipItemInput) -> Result<CharacterSheetDto, SheetError> {
        self.equipment.replace_slot_atomic(
            &CharacterId(input.character_id.clone()),
            &ItemId(input.item_id),
            input.slot,
        )?;
        get_character_sheet::get_sheet(
            self.characters,
            self.items,
            self.equipment,
            input.character_id,
        )
    }

    pub fn unequip(
        &self,
        character_id: String,
        slot: EquipmentSlot,
    ) -> Result<CharacterSheetDto, SheetError> {
        self.equipment
            .unequip_atomic(&CharacterId(character_id.clone()), slot)?;
        get_character_sheet::get_sheet(
            self.characters,
            self.items,
            self.equipment,
            character_id,
        )
    }
}
