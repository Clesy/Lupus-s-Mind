use crate::characters::domain::character::CharacterId;
use crate::items::domain::item::ItemId;
use super::{
    equipment::{EquippedItem, EquipmentSlot},
    error::EquipmentError,
};

pub trait EquipmentRepository: Send + Sync {
    fn list_for_character(&self, id: &CharacterId) -> Result<Vec<EquippedItem>, EquipmentError>;
    fn find_by_item(&self, id: &ItemId) -> Result<Option<EquippedItem>, EquipmentError>;
    fn replace_slot_atomic(
        &self,
        character: &CharacterId,
        item: &ItemId,
        slot: EquipmentSlot,
    ) -> Result<(), EquipmentError>;
    fn unequip_atomic(
        &self,
        character: &CharacterId,
        slot: EquipmentSlot,
    ) -> Result<(), EquipmentError>;
}
