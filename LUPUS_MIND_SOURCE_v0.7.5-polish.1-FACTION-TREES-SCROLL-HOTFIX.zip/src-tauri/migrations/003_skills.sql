CREATE TABLE IF NOT EXISTS skills (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    kind TEXT NOT NULL CHECK (kind IN ('physical','magical','healing','utility')),
    resource_kind TEXT NOT NULL CHECK (resource_kind IN ('none','mana','stamina','health')),
    base_power REAL NOT NULL CHECK (base_power >= 0),
    resource_cost INTEGER NOT NULL CHECK (resource_cost >= 0),
    cooldown_turns INTEGER NOT NULL CHECK (cooldown_turns >= 0),
    scaling TEXT NOT NULL DEFAULT '[]',
    tags TEXT NOT NULL DEFAULT '[]',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS character_skills (
    character_id TEXT NOT NULL,
    skill_id TEXT NOT NULL,
    learned_at TEXT NOT NULL,
    PRIMARY KEY (character_id, skill_id),
    FOREIGN KEY (character_id) REFERENCES characters(id) ON DELETE CASCADE,
    FOREIGN KEY (skill_id) REFERENCES skills(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_character_skills_character ON character_skills(character_id);
CREATE INDEX IF NOT EXISTS idx_character_skills_skill ON character_skills(skill_id);
