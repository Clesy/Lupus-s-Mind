CREATE TABLE IF NOT EXISTS timeline_events (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL CHECK(length(trim(title)) > 0),
    description TEXT NOT NULL DEFAULT '',
    kind TEXT NOT NULL CHECK(kind IN ('personal','conflict','political','discovery','death','birth','journey','alliance','betrayal','battle','catastrophe','revelation')),
    importance TEXT NOT NULL CHECK(importance IN ('minor','standard','major','critical')),
    temporal_kind TEXT NOT NULL CHECK(temporal_kind IN ('point','span')),
    start_chapter INTEGER NOT NULL CHECK(start_chapter > 0),
    end_chapter INTEGER,
    world_time_start TEXT,
    world_time_end TEXT,
    location_label TEXT,
    tags TEXT NOT NULL DEFAULT '[]',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    CHECK(
      (temporal_kind = 'point' AND end_chapter IS NULL)
      OR
      (temporal_kind = 'span' AND end_chapter IS NOT NULL AND end_chapter > start_chapter)
    )
);

CREATE TABLE IF NOT EXISTS timeline_event_characters (
    event_id TEXT NOT NULL,
    character_id TEXT NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('actor','target','witness','victim','beneficiary','commander','participant')),
    PRIMARY KEY(event_id, character_id, role),
    FOREIGN KEY(event_id) REFERENCES timeline_events(id) ON DELETE CASCADE,
    FOREIGN KEY(character_id) REFERENCES characters(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS timeline_event_sources (
    event_id TEXT NOT NULL,
    source_kind TEXT NOT NULL CHECK(source_kind IN ('relationship_transition','manual')),
    source_id TEXT NOT NULL CHECK(length(trim(source_id)) > 0),
    PRIMARY KEY(event_id, source_kind, source_id),
    FOREIGN KEY(event_id) REFERENCES timeline_events(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_timeline_start ON timeline_events(start_chapter);
CREATE INDEX IF NOT EXISTS idx_timeline_span ON timeline_events(start_chapter, end_chapter);
CREATE INDEX IF NOT EXISTS idx_timeline_character ON timeline_event_characters(character_id);
CREATE INDEX IF NOT EXISTS idx_timeline_source ON timeline_event_sources(source_kind, source_id);
