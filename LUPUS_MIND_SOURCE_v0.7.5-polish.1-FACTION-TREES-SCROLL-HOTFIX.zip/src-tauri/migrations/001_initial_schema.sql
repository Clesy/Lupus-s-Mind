CREATE TABLE IF NOT EXISTS schema_migrations (
  version INTEGER PRIMARY KEY,
  applied_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS characters (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  alias TEXT,
  class_label TEXT,
  level INTEGER NOT NULL CHECK(level >= 1),
  stat_str INTEGER NOT NULL CHECK(stat_str >= 0),
  stat_agi INTEGER NOT NULL CHECK(stat_agi >= 0),
  stat_vit INTEGER NOT NULL CHECK(stat_vit >= 0),
  stat_int INTEGER NOT NULL CHECK(stat_int >= 0),
  stat_mnd INTEGER NOT NULL CHECK(stat_mnd >= 0),
  biography TEXT NOT NULL DEFAULT '',
  tags TEXT NOT NULL DEFAULT '[]',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
