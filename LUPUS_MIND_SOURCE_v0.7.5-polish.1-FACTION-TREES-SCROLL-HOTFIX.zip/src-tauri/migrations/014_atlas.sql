CREATE TABLE IF NOT EXISTS locations (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL CHECK(length(trim(name)) > 0),
    kind TEXT NOT NULL DEFAULT 'location' CHECK(kind IN (
        'world','continent','country','region','province','city','town','village',
        'district','building','landmark','dungeon','biome','location'
    )),
    parent_location_id TEXT,
    description TEXT NOT NULL DEFAULT '',
    color TEXT NOT NULL DEFAULT '#70b7c4',
    tags TEXT NOT NULL DEFAULT '[]',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY(parent_location_id) REFERENCES locations(id) ON DELETE SET NULL,
    CHECK(parent_location_id IS NULL OR parent_location_id <> id)
);
CREATE INDEX IF NOT EXISTS idx_locations_parent ON locations(parent_location_id, name COLLATE NOCASE);
CREATE INDEX IF NOT EXISTS idx_locations_name ON locations(name COLLATE NOCASE);

CREATE TRIGGER IF NOT EXISTS trg_location_no_cycle_update
BEFORE UPDATE OF parent_location_id ON locations
WHEN NEW.parent_location_id IS NOT NULL AND EXISTS (
    WITH RECURSIVE descendants(id) AS (
        SELECT id FROM locations WHERE parent_location_id=OLD.id
        UNION ALL
        SELECT l.id FROM locations l JOIN descendants d ON l.parent_location_id=d.id
    )
    SELECT 1 FROM descendants WHERE id=NEW.parent_location_id
)
BEGIN
    SELECT RAISE(ABORT, 'location hierarchy cycle is not allowed');
END;

CREATE TABLE IF NOT EXISTS atlas_maps (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL CHECK(length(trim(name)) > 0),
    scope_location_id TEXT,
    parent_map_id TEXT,
    width INTEGER NOT NULL DEFAULT 1200 CHECK(width BETWEEN 320 AND 8192),
    height INTEGER NOT NULL DEFAULT 760 CHECK(height BETWEEN 240 AND 8192),
    background TEXT NOT NULL DEFAULT 'ocean',
    terrain_json TEXT NOT NULL DEFAULT '',
    generator_seed INTEGER,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY(scope_location_id) REFERENCES locations(id) ON DELETE SET NULL,
    FOREIGN KEY(parent_map_id) REFERENCES atlas_maps(id) ON DELETE SET NULL,
    CHECK(parent_map_id IS NULL OR parent_map_id <> id)
);
CREATE INDEX IF NOT EXISTS idx_atlas_maps_scope ON atlas_maps(scope_location_id, name COLLATE NOCASE);

CREATE TRIGGER IF NOT EXISTS trg_atlas_map_no_cycle_update
BEFORE UPDATE OF parent_map_id ON atlas_maps
WHEN NEW.parent_map_id IS NOT NULL AND EXISTS (
    WITH RECURSIVE descendants(id) AS (
        SELECT id FROM atlas_maps WHERE parent_map_id=OLD.id
        UNION ALL
        SELECT m.id FROM atlas_maps m JOIN descendants d ON m.parent_map_id=d.id
    )
    SELECT 1 FROM descendants WHERE id=NEW.parent_map_id
)
BEGIN
    SELECT RAISE(ABORT, 'nested map cycle is not allowed');
END;

CREATE TABLE IF NOT EXISTS map_pins (
    id TEXT PRIMARY KEY,
    map_id TEXT NOT NULL,
    location_id TEXT NOT NULL,
    label TEXT NOT NULL DEFAULT '',
    x REAL NOT NULL CHECK(x >= 0.0 AND x <= 1.0),
    y REAL NOT NULL CHECK(y >= 0.0 AND y <= 1.0),
    icon TEXT NOT NULL DEFAULT 'pin',
    color TEXT NOT NULL DEFAULT '#d9b45b',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY(map_id) REFERENCES atlas_maps(id) ON DELETE CASCADE,
    FOREIGN KEY(location_id) REFERENCES locations(id) ON DELETE CASCADE,
    UNIQUE(map_id, location_id)
);
CREATE INDEX IF NOT EXISTS idx_map_pins_map ON map_pins(map_id);

CREATE TABLE IF NOT EXISTS map_connections (
    id TEXT PRIMARY KEY,
    map_id TEXT NOT NULL,
    from_location_id TEXT NOT NULL,
    to_location_id TEXT NOT NULL,
    kind TEXT NOT NULL DEFAULT 'road' CHECK(kind IN ('road','sea_route','portal','border','path')),
    label TEXT NOT NULL DEFAULT '',
    color TEXT NOT NULL DEFAULT '#7d8b98',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY(map_id) REFERENCES atlas_maps(id) ON DELETE CASCADE,
    FOREIGN KEY(from_location_id) REFERENCES locations(id) ON DELETE CASCADE,
    FOREIGN KEY(to_location_id) REFERENCES locations(id) ON DELETE CASCADE,
    CHECK(from_location_id <> to_location_id),
    UNIQUE(map_id, from_location_id, to_location_id, kind)
);
CREATE INDEX IF NOT EXISTS idx_map_connections_map ON map_connections(map_id);
