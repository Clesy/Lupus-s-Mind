CREATE TABLE IF NOT EXISTS items (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  item_type TEXT NOT NULL CHECK(item_type IN ('weapon','armor','accessory','material','consumable')),
  rarity TEXT NOT NULL CHECK(rarity IN ('standard','rare','epic','legendary','ancient')),
  modifiers TEXT NOT NULL DEFAULT '[]',
  tags TEXT NOT NULL DEFAULT '[]',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS character_equipment (
  character_id TEXT NOT NULL,
  slot TEXT NOT NULL CHECK(slot IN ('main_hand','off_hand','head','chest','hands','legs','feet','accessory_1','accessory_2')),
  item_id TEXT NOT NULL,
  PRIMARY KEY (character_id, slot),
  FOREIGN KEY (character_id) REFERENCES characters(id) ON DELETE CASCADE,
  FOREIGN KEY (item_id) REFERENCES items(id) ON DELETE RESTRICT
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_equipment_item ON character_equipment(item_id);
CREATE INDEX IF NOT EXISTS idx_equipment_character ON character_equipment(character_id);
