CREATE TABLE IF NOT EXISTS lore_pages (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL CHECK(length(trim(title)) > 0),
    category TEXT NOT NULL DEFAULT 'General',
    summary TEXT NOT NULL DEFAULT '',
    content TEXT NOT NULL DEFAULT '',
    tags TEXT NOT NULL DEFAULT '[]',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS entity_mentions (
    source_kind TEXT NOT NULL CHECK(source_kind IN ('chapter','lore')),
    source_id TEXT NOT NULL,
    target_kind TEXT NOT NULL CHECK(target_kind IN ('character','item','skill','lore')),
    target_id TEXT NOT NULL,
    display_text TEXT NOT NULL,
    start_offset INTEGER NOT NULL CHECK(start_offset >= 0),
    end_offset INTEGER NOT NULL CHECK(end_offset > start_offset),
    PRIMARY KEY(source_kind, source_id, start_offset, target_kind, target_id)
);

CREATE TABLE IF NOT EXISTS character_arc_points (
    id TEXT PRIMARY KEY,
    character_id TEXT NOT NULL,
    chapter_number INTEGER NOT NULL CHECK(chapter_number > 0),
    title TEXT NOT NULL CHECK(length(trim(title)) > 0),
    phase TEXT NOT NULL DEFAULT '',
    description TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY(character_id) REFERENCES characters(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS scene_plans (
    id TEXT PRIMARY KEY,
    chapter_id TEXT NOT NULL,
    scene_order INTEGER NOT NULL CHECK(scene_order > 0),
    title TEXT NOT NULL DEFAULT '',
    goal TEXT NOT NULL DEFAULT '',
    obstacle TEXT NOT NULL DEFAULT '',
    outcome TEXT NOT NULL DEFAULT '',
    pov_character_id TEXT,
    location_label TEXT NOT NULL DEFAULT '',
    participant_character_ids TEXT NOT NULL DEFAULT '[]',
    notes TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY(chapter_id) REFERENCES manuscript_chapters(id) ON DELETE CASCADE,
    FOREIGN KEY(pov_character_id) REFERENCES characters(id) ON DELETE SET NULL,
    UNIQUE(chapter_id, scene_order)
);

ALTER TABLE quick_notes ADD COLUMN link_kind TEXT CHECK(link_kind IS NULL OR link_kind IN ('chapter','character','item','skill','lore'));
ALTER TABLE quick_notes ADD COLUMN link_id TEXT;
ALTER TABLE quick_notes ADD COLUMN link_label TEXT;

CREATE INDEX IF NOT EXISTS idx_lore_title ON lore_pages(title COLLATE NOCASE);
CREATE INDEX IF NOT EXISTS idx_lore_updated ON lore_pages(updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_entity_mentions_source ON entity_mentions(source_kind, source_id, start_offset);
CREATE INDEX IF NOT EXISTS idx_entity_mentions_target ON entity_mentions(target_kind, target_id);
CREATE INDEX IF NOT EXISTS idx_arc_character_chapter ON character_arc_points(character_id, chapter_number);
CREATE INDEX IF NOT EXISTS idx_scene_chapter_order ON scene_plans(chapter_id, scene_order);

CREATE TRIGGER IF NOT EXISTS trg_mentions_delete_chapter_source
AFTER DELETE ON manuscript_chapters
BEGIN
    DELETE FROM entity_mentions WHERE source_kind='chapter' AND source_id=OLD.id;
END;

CREATE TRIGGER IF NOT EXISTS trg_mentions_delete_lore
AFTER DELETE ON lore_pages
BEGIN
    DELETE FROM entity_mentions WHERE (source_kind='lore' AND source_id=OLD.id) OR (target_kind='lore' AND target_id=OLD.id);
END;

CREATE TRIGGER IF NOT EXISTS trg_mentions_delete_character_target
AFTER DELETE ON characters
BEGIN
    DELETE FROM entity_mentions WHERE target_kind='character' AND target_id=OLD.id;
END;

CREATE TRIGGER IF NOT EXISTS trg_mentions_delete_item_target
AFTER DELETE ON items
BEGIN
    DELETE FROM entity_mentions WHERE target_kind='item' AND target_id=OLD.id;
END;

CREATE TRIGGER IF NOT EXISTS trg_mentions_delete_skill_target
AFTER DELETE ON skills
BEGIN
    DELETE FROM entity_mentions WHERE target_kind='skill' AND target_id=OLD.id;
END;

CREATE TRIGGER IF NOT EXISTS trg_quick_notes_unlink_deleted_chapter
AFTER DELETE ON manuscript_chapters
BEGIN
    UPDATE quick_notes SET link_kind=NULL, link_id=NULL, link_label=NULL
    WHERE link_kind='chapter' AND link_id=OLD.id;
END;

CREATE TRIGGER IF NOT EXISTS trg_quick_notes_unlink_deleted_character
AFTER DELETE ON characters
BEGIN
    UPDATE quick_notes SET link_kind=NULL, link_id=NULL, link_label=NULL
    WHERE link_kind='character' AND link_id=OLD.id;
END;

CREATE TRIGGER IF NOT EXISTS trg_quick_notes_unlink_deleted_item
AFTER DELETE ON items
BEGIN
    UPDATE quick_notes SET link_kind=NULL, link_id=NULL, link_label=NULL
    WHERE link_kind='item' AND link_id=OLD.id;
END;

CREATE TRIGGER IF NOT EXISTS trg_quick_notes_unlink_deleted_skill
AFTER DELETE ON skills
BEGIN
    UPDATE quick_notes SET link_kind=NULL, link_id=NULL, link_label=NULL
    WHERE link_kind='skill' AND link_id=OLD.id;
END;

CREATE TRIGGER IF NOT EXISTS trg_quick_notes_unlink_deleted_lore
AFTER DELETE ON lore_pages
BEGIN
    UPDATE quick_notes SET link_kind=NULL, link_id=NULL, link_label=NULL
    WHERE link_kind='lore' AND link_id=OLD.id;
END;
