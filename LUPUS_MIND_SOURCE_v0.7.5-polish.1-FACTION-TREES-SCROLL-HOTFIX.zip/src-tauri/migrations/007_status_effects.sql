-- C2.2: canonical status-effect definitions + skill bindings + durable turn-execution grouping.
CREATE TABLE IF NOT EXISTS status_effect_definitions (
    id TEXT PRIMARY KEY,
    effect_key TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    kind TEXT NOT NULL CHECK(kind IN ('damage_over_time','heal_over_time','stun','stat_modifier')),
    stacking_policy TEXT NOT NULL CHECK(stacking_policy IN ('refresh')),
    duration_turns INTEGER NOT NULL CHECK(duration_turns > 0),
    power REAL NOT NULL DEFAULT 0 CHECK(power >= 0),
    modifier_kind TEXT CHECK(modifier_kind IS NULL OR modifier_kind IN ('armor_multiplier','damage_multiplier')),
    modifier_multiplier REAL CHECK(modifier_multiplier IS NULL OR modifier_multiplier > 0),
    created_at TEXT NOT NULL,
    CHECK(
      (kind = 'stat_modifier' AND modifier_kind IS NOT NULL AND modifier_multiplier IS NOT NULL)
      OR
      (kind <> 'stat_modifier' AND modifier_kind IS NULL AND modifier_multiplier IS NULL)
    )
);

CREATE TABLE IF NOT EXISTS skill_status_effects (
    skill_id TEXT NOT NULL,
    effect_definition_id TEXT NOT NULL,
    PRIMARY KEY(skill_id, effect_definition_id),
    FOREIGN KEY(skill_id) REFERENCES skills(id) ON DELETE CASCADE,
    FOREIGN KEY(effect_definition_id) REFERENCES status_effect_definitions(id) ON DELETE RESTRICT
);

CREATE INDEX IF NOT EXISTS idx_skill_status_effects_skill ON skill_status_effects(skill_id);

INSERT OR IGNORE INTO status_effect_definitions(id,effect_key,name,kind,stacking_policy,duration_turns,power,modifier_kind,modifier_multiplier,created_at) VALUES
('effect-burn','burn','Burn','damage_over_time','refresh',3,25,NULL,NULL,strftime('%Y-%m-%dT%H:%M:%fZ','now')),
('effect-poison','poison','Poison','damage_over_time','refresh',3,20,NULL,NULL,strftime('%Y-%m-%dT%H:%M:%fZ','now')),
('effect-regeneration','regeneration','Regeneration','heal_over_time','refresh',3,20,NULL,NULL,strftime('%Y-%m-%dT%H:%M:%fZ','now')),
('effect-stun','stun','Stun','stun','refresh',1,0,NULL,NULL,strftime('%Y-%m-%dT%H:%M:%fZ','now')),
('effect-armor-break','armor_break','Armor Break','stat_modifier','refresh',2,0,'armor_multiplier',0.5,strftime('%Y-%m-%dT%H:%M:%fZ','now')),
('effect-weakness','weakness','Weakness','stat_modifier','refresh',2,0,'damage_multiplier',0.8,strftime('%Y-%m-%dT%H:%M:%fZ','now'));

CREATE TABLE IF NOT EXISTS combat_turn_executions (
    id TEXT PRIMARY KEY,
    session_id TEXT NOT NULL,
    round_number INTEGER NOT NULL CHECK(round_number > 0),
    turn_index INTEGER NOT NULL CHECK(turn_index >= 0),
    actor_combatant_id TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY(session_id) REFERENCES combat_sessions(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_turn_executions_session ON combat_turn_executions(session_id, created_at);

-- Rebuild C2.1 combat_actions so a single turn can persist multiple typed actions.
ALTER TABLE combat_actions RENAME TO combat_actions_c2_1;

CREATE TABLE combat_actions (
    id TEXT PRIMARY KEY,
    session_id TEXT NOT NULL,
    turn_execution_id TEXT NOT NULL,
    sequence_number INTEGER NOT NULL CHECK(sequence_number > 0),
    round_number INTEGER NOT NULL CHECK(round_number > 0),
    turn_index INTEGER NOT NULL CHECK(turn_index >= 0),
    actor_combatant_id TEXT NOT NULL,
    target_combatant_id TEXT,
    action_kind TEXT NOT NULL CHECK(action_kind IN ('use_skill','effect_tick','effect_applied','effect_refreshed','effect_expired','turn_skipped')),
    input_json TEXT NOT NULL,
    resolution_json TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY(session_id) REFERENCES combat_sessions(id) ON DELETE CASCADE,
    FOREIGN KEY(turn_execution_id) REFERENCES combat_turn_executions(id) ON DELETE CASCADE,
    UNIQUE(session_id, sequence_number)
);

INSERT INTO combat_turn_executions(id,session_id,round_number,turn_index,actor_combatant_id,created_at)
SELECT 'legacy:' || session_id || ':' || sequence_number, session_id, round_number, turn_index, actor_combatant_id, created_at
FROM combat_actions_c2_1;

INSERT INTO combat_actions(id,session_id,turn_execution_id,sequence_number,round_number,turn_index,actor_combatant_id,target_combatant_id,action_kind,input_json,resolution_json,created_at)
SELECT id,session_id,'legacy:' || session_id || ':' || sequence_number,sequence_number,round_number,turn_index,actor_combatant_id,target_combatant_id,action_kind,input_json,resolution_json,created_at
FROM combat_actions_c2_1;

DROP TABLE combat_actions_c2_1;

CREATE INDEX IF NOT EXISTS idx_combat_actions_session_sequence ON combat_actions(session_id, sequence_number);
CREATE INDEX IF NOT EXISTS idx_combat_actions_turn_execution ON combat_actions(turn_execution_id, sequence_number);

CREATE TRIGGER IF NOT EXISTS trg_combat_action_requires_running_session_c2_2
BEFORE INSERT ON combat_actions
WHEN (SELECT status FROM combat_sessions WHERE id = NEW.session_id) <> 'running'
BEGIN
    SELECT RAISE(ABORT, 'cannot append action to terminal combat session');
END;

CREATE TRIGGER IF NOT EXISTS trg_turn_execution_requires_running_session
BEFORE INSERT ON combat_turn_executions
WHEN (SELECT status FROM combat_sessions WHERE id = NEW.session_id) <> 'running'
BEGIN
    SELECT RAISE(ABORT, 'cannot begin turn execution on terminal combat session');
END;
