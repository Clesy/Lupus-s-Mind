CREATE TABLE IF NOT EXISTS relationship_types (
    id TEXT PRIMARY KEY,
    key TEXT NOT NULL UNIQUE,
    forward_label TEXT NOT NULL,
    inverse_label TEXT NOT NULL,
    directionality TEXT NOT NULL CHECK(directionality IN ('directed', 'symmetric')),
    category TEXT NOT NULL CHECK(category IN ('affinity', 'conflict', 'kinship', 'authority', 'knowledge', 'social')),
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS relationships (
    id TEXT PRIMARY KEY,
    type_id TEXT NOT NULL,
    source_character_id TEXT NOT NULL,
    target_character_id TEXT NOT NULL,
    created_at TEXT NOT NULL,
    CHECK(source_character_id <> target_character_id),
    UNIQUE(type_id, source_character_id, target_character_id),
    FOREIGN KEY(type_id) REFERENCES relationship_types(id) ON DELETE RESTRICT,
    FOREIGN KEY(source_character_id) REFERENCES characters(id) ON DELETE CASCADE,
    FOREIGN KEY(target_character_id) REFERENCES characters(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS relationship_states (
    id TEXT PRIMARY KEY,
    relationship_id TEXT NOT NULL,
    valid_from_chapter INTEGER NOT NULL CHECK(valid_from_chapter > 0),
    valid_to_chapter INTEGER,
    intensity INTEGER NOT NULL CHECK(intensity BETWEEN 0 AND 100),
    note TEXT NOT NULL DEFAULT '',
    tags TEXT NOT NULL DEFAULT '[]',
    created_at TEXT NOT NULL,
    CHECK(valid_to_chapter IS NULL OR valid_to_chapter > valid_from_chapter),
    UNIQUE(relationship_id, valid_from_chapter),
    FOREIGN KEY(relationship_id) REFERENCES relationships(id) ON DELETE CASCADE
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_relationship_open_state
ON relationship_states(relationship_id)
WHERE valid_to_chapter IS NULL;

CREATE INDEX IF NOT EXISTS idx_relationship_state_interval
ON relationship_states(relationship_id, valid_from_chapter, valid_to_chapter);

CREATE INDEX IF NOT EXISTS idx_relationship_source
ON relationships(source_character_id);

CREATE INDEX IF NOT EXISTS idx_relationship_target
ON relationships(target_character_id);

CREATE TABLE IF NOT EXISTS relationship_transitions (
    id TEXT PRIMARY KEY,
    relationship_id TEXT NOT NULL,
    chapter INTEGER NOT NULL CHECK(chapter > 0),
    kind TEXT NOT NULL CHECK(kind IN ('created', 'state_changed', 'ended', 'reopened')),
    before_state_id TEXT,
    after_state_id TEXT,
    created_at TEXT NOT NULL,
    FOREIGN KEY(relationship_id) REFERENCES relationships(id) ON DELETE CASCADE,
    FOREIGN KEY(before_state_id) REFERENCES relationship_states(id) ON DELETE SET NULL,
    FOREIGN KEY(after_state_id) REFERENCES relationship_states(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_relationship_transition_history
ON relationship_transitions(relationship_id, chapter, created_at);

-- Canonical relationship identity is immutable; a type change means a new relationship.
CREATE TRIGGER IF NOT EXISTS trg_relationship_identity_immutable
BEFORE UPDATE ON relationships
BEGIN
    SELECT RAISE(ABORT, 'relationship identity is immutable');
END;

-- Transition rows are append-only audit records.
CREATE TRIGGER IF NOT EXISTS trg_relationship_transition_immutable
BEFORE UPDATE ON relationship_transitions
BEGIN
    SELECT RAISE(ABORT, 'relationship transition is immutable');
END;

-- Symmetric types cannot be stored twice in reverse orientation.
CREATE TRIGGER IF NOT EXISTS trg_relationship_symmetric_reverse_insert
BEFORE INSERT ON relationships
WHEN (SELECT directionality FROM relationship_types WHERE id = NEW.type_id) = 'symmetric'
 AND EXISTS (
    SELECT 1 FROM relationships r
    WHERE r.type_id = NEW.type_id
      AND r.source_character_id = NEW.target_character_id
      AND r.target_character_id = NEW.source_character_id
 )
BEGIN
    SELECT RAISE(ABORT, 'symmetric relationship already exists in reverse orientation');
END;

-- Temporal intervals for a relationship may never overlap. [from, to) semantics.
CREATE TRIGGER IF NOT EXISTS trg_relationship_state_no_overlap_insert
BEFORE INSERT ON relationship_states
WHEN EXISTS (
    SELECT 1 FROM relationship_states s
    WHERE s.relationship_id = NEW.relationship_id
      AND NEW.valid_from_chapter < COALESCE(s.valid_to_chapter, 9223372036854775807)
      AND s.valid_from_chapter < COALESCE(NEW.valid_to_chapter, 9223372036854775807)
)
BEGIN
    SELECT RAISE(ABORT, 'relationship state interval overlap');
END;

-- State payload is immutable. The only legal update is closing an open interval once.
CREATE TRIGGER IF NOT EXISTS trg_relationship_state_immutable_update
BEFORE UPDATE ON relationship_states
WHEN NOT (
    OLD.valid_to_chapter IS NULL
    AND NEW.valid_to_chapter IS NOT NULL
    AND NEW.valid_to_chapter > OLD.valid_from_chapter
    AND NEW.id = OLD.id
    AND NEW.relationship_id = OLD.relationship_id
    AND NEW.valid_from_chapter = OLD.valid_from_chapter
    AND NEW.intensity = OLD.intensity
    AND NEW.note = OLD.note
    AND NEW.tags = OLD.tags
    AND NEW.created_at = OLD.created_at
)
BEGIN
    SELECT RAISE(ABORT, 'relationship state is immutable');
END;

INSERT OR IGNORE INTO relationship_types(id, key, forward_label, inverse_label, directionality, category, created_at) VALUES
('reltype-trust', 'trust', 'Trusts', 'Trusted by', 'directed', 'affinity', strftime('%Y-%m-%dT%H:%M:%fZ','now')),
('reltype-mentor', 'mentor', 'Mentor of', 'Student of', 'directed', 'authority', strftime('%Y-%m-%dT%H:%M:%fZ','now')),
('reltype-ally', 'ally', 'Ally', 'Ally', 'symmetric', 'affinity', strftime('%Y-%m-%dT%H:%M:%fZ','now')),
('reltype-hostile', 'hostile', 'Hostile to', 'Hostile to', 'symmetric', 'conflict', strftime('%Y-%m-%dT%H:%M:%fZ','now')),
('reltype-rival', 'rival', 'Rival', 'Rival', 'symmetric', 'conflict', strftime('%Y-%m-%dT%H:%M:%fZ','now')),
('reltype-sibling', 'sibling', 'Sibling', 'Sibling', 'symmetric', 'kinship', strftime('%Y-%m-%dT%H:%M:%fZ','now'));
