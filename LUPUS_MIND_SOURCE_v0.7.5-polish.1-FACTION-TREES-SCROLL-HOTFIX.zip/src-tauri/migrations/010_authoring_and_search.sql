CREATE TABLE IF NOT EXISTS manuscript_chapters (
    id TEXT PRIMARY KEY,
    chapter_number INTEGER NOT NULL CHECK(chapter_number > 0),
    title TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'draft' CHECK(status IN ('draft','revised','final')),
    content TEXT NOT NULL DEFAULT '',
    notes TEXT NOT NULL DEFAULT '',
    tags TEXT NOT NULL DEFAULT '[]',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    UNIQUE(chapter_number)
);

CREATE TABLE IF NOT EXISTS quick_notes (
    id TEXT PRIMARY KEY,
    body TEXT NOT NULL CHECK(length(trim(body)) > 0),
    pinned INTEGER NOT NULL DEFAULT 0 CHECK(pinned IN (0,1)),
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_manuscript_status ON manuscript_chapters(status);
CREATE INDEX IF NOT EXISTS idx_manuscript_updated ON manuscript_chapters(updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_quick_notes_pinned ON quick_notes(pinned DESC, updated_at DESC);
