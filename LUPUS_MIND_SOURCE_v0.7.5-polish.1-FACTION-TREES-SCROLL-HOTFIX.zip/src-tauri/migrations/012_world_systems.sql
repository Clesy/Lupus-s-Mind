CREATE TABLE IF NOT EXISTS factions (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL CHECK(length(trim(name)) > 0),
    kind TEXT NOT NULL DEFAULT 'faction' CHECK(kind IN ('faction','clan','guild','kingdom','order','house')),
    description TEXT NOT NULL DEFAULT '',
    motto TEXT NOT NULL DEFAULT '',
    color TEXT NOT NULL DEFAULT '#8b7cf6',
    tags TEXT NOT NULL DEFAULT '[]',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS faction_memberships (
    id TEXT PRIMARY KEY,
    faction_id TEXT NOT NULL,
    character_id TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'Member',
    rank TEXT NOT NULL DEFAULT '',
    joined_chapter INTEGER NOT NULL DEFAULT 1 CHECK(joined_chapter > 0),
    left_chapter INTEGER CHECK(left_chapter IS NULL OR left_chapter > joined_chapter),
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY(faction_id) REFERENCES factions(id) ON DELETE CASCADE,
    FOREIGN KEY(character_id) REFERENCES characters(id) ON DELETE CASCADE
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_faction_membership_open
    ON faction_memberships(faction_id, character_id) WHERE left_chapter IS NULL;
CREATE INDEX IF NOT EXISTS idx_faction_membership_character ON faction_memberships(character_id, joined_chapter);
CREATE INDEX IF NOT EXISTS idx_faction_membership_faction ON faction_memberships(faction_id, joined_chapter);

CREATE TABLE IF NOT EXISTS faction_relationship_states (
    id TEXT PRIMARY KEY,
    faction_a_id TEXT NOT NULL,
    faction_b_id TEXT NOT NULL,
    relation_type TEXT NOT NULL CHECK(relation_type IN ('allied','friendly','neutral','tense','hostile','war','vassal')),
    valid_from_chapter INTEGER NOT NULL CHECK(valid_from_chapter > 0),
    valid_to_chapter INTEGER CHECK(valid_to_chapter IS NULL OR valid_to_chapter > valid_from_chapter),
    notes TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    FOREIGN KEY(faction_a_id) REFERENCES factions(id) ON DELETE CASCADE,
    FOREIGN KEY(faction_b_id) REFERENCES factions(id) ON DELETE CASCADE,
    CHECK(faction_a_id < faction_b_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_faction_relation_open
    ON faction_relationship_states(faction_a_id, faction_b_id) WHERE valid_to_chapter IS NULL;
CREATE INDEX IF NOT EXISTS idx_faction_relation_window ON faction_relationship_states(faction_a_id, faction_b_id, valid_from_chapter, valid_to_chapter);

CREATE TABLE IF NOT EXISTS item_ownerships (
    id TEXT PRIMARY KEY,
    item_id TEXT NOT NULL,
    owner_character_id TEXT,
    owner_faction_id TEXT,
    acquired_chapter INTEGER NOT NULL CHECK(acquired_chapter > 0),
    released_chapter INTEGER CHECK(released_chapter IS NULL OR released_chapter > acquired_chapter),
    note TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY(item_id) REFERENCES items(id) ON DELETE CASCADE,
    FOREIGN KEY(owner_character_id) REFERENCES characters(id) ON DELETE CASCADE,
    FOREIGN KEY(owner_faction_id) REFERENCES factions(id) ON DELETE CASCADE,
    CHECK((owner_character_id IS NOT NULL AND owner_faction_id IS NULL) OR (owner_character_id IS NULL AND owner_faction_id IS NOT NULL))
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_item_ownership_open ON item_ownerships(item_id) WHERE released_chapter IS NULL;
CREATE INDEX IF NOT EXISTS idx_item_owner_character ON item_ownerships(owner_character_id, acquired_chapter);
CREATE INDEX IF NOT EXISTS idx_item_owner_faction ON item_ownerships(owner_faction_id, acquired_chapter);

CREATE TABLE IF NOT EXISTS quests (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL CHECK(length(trim(title)) > 0),
    status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('planned','active','completed','failed','abandoned')),
    summary TEXT NOT NULL DEFAULT '',
    description TEXT NOT NULL DEFAULT '',
    quest_giver_character_id TEXT,
    faction_id TEXT,
    start_chapter INTEGER CHECK(start_chapter IS NULL OR start_chapter > 0),
    completion_chapter INTEGER CHECK(completion_chapter IS NULL OR completion_chapter > 0),
    tags TEXT NOT NULL DEFAULT '[]',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY(quest_giver_character_id) REFERENCES characters(id) ON DELETE SET NULL,
    FOREIGN KEY(faction_id) REFERENCES factions(id) ON DELETE SET NULL,
    CHECK(completion_chapter IS NULL OR start_chapter IS NULL OR completion_chapter >= start_chapter)
);

CREATE TABLE IF NOT EXISTS quest_objectives (
    id TEXT PRIMARY KEY,
    quest_id TEXT NOT NULL,
    position INTEGER NOT NULL CHECK(position > 0),
    text TEXT NOT NULL CHECK(length(trim(text)) > 0),
    is_completed INTEGER NOT NULL DEFAULT 0 CHECK(is_completed IN (0,1)),
    completed_chapter INTEGER CHECK(completed_chapter IS NULL OR completed_chapter > 0),
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY(quest_id) REFERENCES quests(id) ON DELETE CASCADE,
    UNIQUE(quest_id, position)
);
CREATE INDEX IF NOT EXISTS idx_quest_objectives ON quest_objectives(quest_id, position);

CREATE TABLE IF NOT EXISTS quest_links (
    quest_id TEXT NOT NULL,
    target_kind TEXT NOT NULL CHECK(target_kind IN ('character','item','faction','lore','chapter')),
    target_id TEXT NOT NULL,
    label TEXT NOT NULL DEFAULT '',
    PRIMARY KEY(quest_id, target_kind, target_id),
    FOREIGN KEY(quest_id) REFERENCES quests(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS secrets (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL CHECK(length(trim(title)) > 0),
    description TEXT NOT NULL DEFAULT '',
    importance TEXT NOT NULL DEFAULT 'major' CHECK(importance IN ('minor','major','critical')),
    origin_chapter INTEGER CHECK(origin_chapter IS NULL OR origin_chapter > 0),
    tags TEXT NOT NULL DEFAULT '[]',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS secret_knowledge_states (
    id TEXT PRIMARY KEY,
    secret_id TEXT NOT NULL,
    character_id TEXT NOT NULL,
    knowledge_state TEXT NOT NULL CHECK(knowledge_state IN ('knows','suspects','misinformed')),
    learned_chapter INTEGER NOT NULL CHECK(learned_chapter > 0),
    lost_chapter INTEGER CHECK(lost_chapter IS NULL OR lost_chapter > learned_chapter),
    source_note TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY(secret_id) REFERENCES secrets(id) ON DELETE CASCADE,
    FOREIGN KEY(character_id) REFERENCES characters(id) ON DELETE CASCADE
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_secret_knowledge_open ON secret_knowledge_states(secret_id, character_id) WHERE lost_chapter IS NULL;
CREATE INDEX IF NOT EXISTS idx_secret_knowledge_window ON secret_knowledge_states(secret_id, learned_chapter, lost_chapter);
CREATE INDEX IF NOT EXISTS idx_secret_knowledge_character ON secret_knowledge_states(character_id, learned_chapter);

CREATE INDEX IF NOT EXISTS idx_factions_name ON factions(name COLLATE NOCASE);
CREATE INDEX IF NOT EXISTS idx_quests_title ON quests(title COLLATE NOCASE);
CREATE INDEX IF NOT EXISTS idx_secrets_title ON secrets(title COLLATE NOCASE);

CREATE TRIGGER IF NOT EXISTS trg_quest_links_delete_character
AFTER DELETE ON characters BEGIN DELETE FROM quest_links WHERE target_kind='character' AND target_id=OLD.id; END;
CREATE TRIGGER IF NOT EXISTS trg_quest_links_delete_item
AFTER DELETE ON items BEGIN DELETE FROM quest_links WHERE target_kind='item' AND target_id=OLD.id; END;
CREATE TRIGGER IF NOT EXISTS trg_quest_links_delete_faction
AFTER DELETE ON factions BEGIN DELETE FROM quest_links WHERE target_kind='faction' AND target_id=OLD.id; END;
CREATE TRIGGER IF NOT EXISTS trg_quest_links_delete_lore
AFTER DELETE ON lore_pages BEGIN DELETE FROM quest_links WHERE target_kind='lore' AND target_id=OLD.id; END;
CREATE TRIGGER IF NOT EXISTS trg_quest_links_delete_chapter
AFTER DELETE ON manuscript_chapters BEGIN DELETE FROM quest_links WHERE target_kind='chapter' AND target_id=OLD.id; END;
