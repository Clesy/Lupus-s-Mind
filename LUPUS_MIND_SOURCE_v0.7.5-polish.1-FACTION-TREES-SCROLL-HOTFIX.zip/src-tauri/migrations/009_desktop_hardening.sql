CREATE TABLE IF NOT EXISTS workspace_settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

INSERT OR IGNORE INTO workspace_settings(key,value,updated_at) VALUES
('compact_navigation','false',strftime('%Y-%m-%dT%H:%M:%fZ','now')),
('reduce_motion','false',strftime('%Y-%m-%dT%H:%M:%fZ','now')),
('confirm_destructive_actions','true',strftime('%Y-%m-%dT%H:%M:%fZ','now')),
('restore_last_route','true',strftime('%Y-%m-%dT%H:%M:%fZ','now')),
('default_generator_count','8',strftime('%Y-%m-%dT%H:%M:%fZ','now'));
