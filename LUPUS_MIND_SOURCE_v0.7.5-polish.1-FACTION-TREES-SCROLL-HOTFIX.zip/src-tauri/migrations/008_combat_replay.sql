CREATE TABLE IF NOT EXISTS combat_replay_origins (
    session_id TEXT PRIMARY KEY,
    origin_sequence INTEGER NOT NULL DEFAULT 0 CHECK(origin_sequence >= 0),
    state_json TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY(session_id) REFERENCES combat_sessions(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS combat_replay_events (
    id TEXT PRIMARY KEY,
    session_id TEXT NOT NULL,
    turn_execution_id TEXT NOT NULL,
    sequence_number INTEGER NOT NULL CHECK(sequence_number > 0),
    event_index INTEGER NOT NULL CHECK(event_index >= 0),
    event_kind TEXT NOT NULL CHECK(event_kind IN (
        'hp_changed','mana_changed','defeated_changed','cooldowns_changed',
        'active_effects_changed','turn_advanced','session_status_changed'
    )),
    payload_json TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY(session_id) REFERENCES combat_sessions(id) ON DELETE CASCADE,
    FOREIGN KEY(turn_execution_id) REFERENCES combat_turn_executions(id) ON DELETE CASCADE,
    UNIQUE(session_id, sequence_number, event_index)
);

CREATE INDEX IF NOT EXISTS idx_combat_replay_events_session_sequence
ON combat_replay_events(session_id, sequence_number, event_index);

CREATE INDEX IF NOT EXISTS idx_combat_replay_events_execution
ON combat_replay_events(turn_execution_id, event_index);

-- Replay history is append-only. Session deletion may still cascade the audit stream.
CREATE TRIGGER IF NOT EXISTS trg_combat_replay_events_no_update
BEFORE UPDATE ON combat_replay_events
BEGIN
    SELECT RAISE(ABORT, 'combat replay events are append-only');
END;

CREATE TRIGGER IF NOT EXISTS trg_combat_replay_events_no_delete
BEFORE DELETE ON combat_replay_events
WHEN EXISTS (SELECT 1 FROM combat_sessions WHERE id = OLD.session_id)
BEGIN
    SELECT RAISE(ABORT, 'combat replay events are append-only');
END;

-- Existing C2.2 sessions cannot be reconstructed before migration with state-complete fidelity.
-- They receive a truthful replay origin at their current committed state. New sessions are seeded
-- at sequence 0 by SqliteCombatRepository::insert and therefore support full-history replay.
INSERT OR IGNORE INTO combat_replay_origins(session_id, origin_sequence, state_json, created_at)
SELECT
    s.id,
    COALESCE((SELECT MAX(a.sequence_number) FROM combat_actions a WHERE a.session_id=s.id), 0),
    json_object(
        'sessionId', s.id,
        'status', s.status,
        'rngSeed', CAST(s.rng_seed AS INTEGER),
        'roundNumber', s.round_number,
        'turnIndex', s.turn_index,
        'nextActionSequence', s.next_action_sequence,
        'combatants', json(COALESCE((
            SELECT json_group_array(json_object(
                'id', ordered.id,
                'position', ordered.position,
                'snapshot', json(ordered.snapshot),
                'runtimeState', json(ordered.runtime_state)
            ))
            FROM (
                SELECT id, position, snapshot, runtime_state
                FROM combatants
                WHERE session_id=s.id
                ORDER BY position
            ) ordered
        ), '[]'))
    ),
    strftime('%Y-%m-%dT%H:%M:%fZ','now')
FROM combat_sessions s;
