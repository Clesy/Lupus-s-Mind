CREATE TABLE IF NOT EXISTS faction_hierarchy_roles (
    id TEXT PRIMARY KEY,
    faction_id TEXT NOT NULL,
    name TEXT NOT NULL CHECK(length(trim(name)) > 0),
    parent_role_id TEXT,
    tier INTEGER NOT NULL DEFAULT 1 CHECK(tier > 0),
    capacity INTEGER CHECK(capacity IS NULL OR capacity > 0),
    color TEXT NOT NULL DEFAULT '#8b7cf6',
    sort_order INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY(faction_id) REFERENCES factions(id) ON DELETE CASCADE,
    FOREIGN KEY(parent_role_id) REFERENCES faction_hierarchy_roles(id) ON DELETE SET NULL,
    UNIQUE(faction_id, name),
    CHECK(parent_role_id IS NULL OR parent_role_id <> id)
);
CREATE INDEX IF NOT EXISTS idx_faction_hierarchy_roles_faction
    ON faction_hierarchy_roles(faction_id, tier, sort_order, name);

CREATE TABLE IF NOT EXISTS faction_role_assignments (
    id TEXT PRIMARY KEY,
    role_id TEXT NOT NULL,
    character_id TEXT NOT NULL,
    valid_from_chapter INTEGER NOT NULL CHECK(valid_from_chapter > 0),
    valid_to_chapter INTEGER CHECK(valid_to_chapter IS NULL OR valid_to_chapter > valid_from_chapter),
    title_override TEXT NOT NULL DEFAULT '',
    notes TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY(role_id) REFERENCES faction_hierarchy_roles(id) ON DELETE CASCADE,
    FOREIGN KEY(character_id) REFERENCES characters(id) ON DELETE CASCADE
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_faction_role_assignment_open
    ON faction_role_assignments(role_id, character_id) WHERE valid_to_chapter IS NULL;
CREATE INDEX IF NOT EXISTS idx_faction_role_assignment_window
    ON faction_role_assignments(role_id, valid_from_chapter, valid_to_chapter);
CREATE INDEX IF NOT EXISTS idx_faction_role_assignment_character
    ON faction_role_assignments(character_id, valid_from_chapter, valid_to_chapter);

CREATE TRIGGER IF NOT EXISTS trg_faction_role_parent_same_faction_insert
BEFORE INSERT ON faction_hierarchy_roles
WHEN NEW.parent_role_id IS NOT NULL
 AND (SELECT faction_id FROM faction_hierarchy_roles WHERE id=NEW.parent_role_id) <> NEW.faction_id
BEGIN
    SELECT RAISE(ABORT, 'hierarchy parent role must belong to same faction');
END;

CREATE TRIGGER IF NOT EXISTS trg_faction_role_parent_same_faction_update
BEFORE UPDATE OF parent_role_id,faction_id ON faction_hierarchy_roles
WHEN NEW.parent_role_id IS NOT NULL
 AND (SELECT faction_id FROM faction_hierarchy_roles WHERE id=NEW.parent_role_id) <> NEW.faction_id
BEGIN
    SELECT RAISE(ABORT, 'hierarchy parent role must belong to same faction');
END;

CREATE TRIGGER IF NOT EXISTS trg_faction_role_no_cycle_update
BEFORE UPDATE OF parent_role_id ON faction_hierarchy_roles
WHEN NEW.parent_role_id IS NOT NULL AND EXISTS (
    WITH RECURSIVE descendants(id) AS (
        SELECT id FROM faction_hierarchy_roles WHERE parent_role_id=OLD.id
        UNION ALL
        SELECT r.id FROM faction_hierarchy_roles r JOIN descendants d ON r.parent_role_id=d.id
    )
    SELECT 1 FROM descendants WHERE id=NEW.parent_role_id
)
BEGIN
    SELECT RAISE(ABORT, 'hierarchy role cycle is not allowed');
END;

CREATE TRIGGER IF NOT EXISTS trg_faction_role_capacity_insert
BEFORE INSERT ON faction_role_assignments
WHEN (SELECT capacity FROM faction_hierarchy_roles WHERE id=NEW.role_id) IS NOT NULL
 AND (
    SELECT COUNT(*) FROM faction_role_assignments a
    WHERE a.role_id=NEW.role_id
      AND a.valid_to_chapter IS NULL
 ) >= (SELECT capacity FROM faction_hierarchy_roles WHERE id=NEW.role_id)
BEGIN
    SELECT RAISE(ABORT, 'hierarchy role capacity reached');
END;

CREATE TABLE IF NOT EXISTS lineages (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL CHECK(length(trim(name)) > 0),
    kind TEXT NOT NULL DEFAULT 'family' CHECK(kind IN ('family','dynasty','bloodline','house')),
    description TEXT NOT NULL DEFAULT '',
    color TEXT NOT NULL DEFAULT '#c9a35a',
    tags TEXT NOT NULL DEFAULT '[]',
    affiliated_faction_id TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY(affiliated_faction_id) REFERENCES factions(id) ON DELETE SET NULL
);
CREATE INDEX IF NOT EXISTS idx_lineages_name ON lineages(name COLLATE NOCASE);
CREATE INDEX IF NOT EXISTS idx_lineages_faction ON lineages(affiliated_faction_id);

CREATE TABLE IF NOT EXISTS lineage_memberships (
    id TEXT PRIMARY KEY,
    lineage_id TEXT NOT NULL,
    character_id TEXT NOT NULL,
    branch_label TEXT NOT NULL DEFAULT '',
    title TEXT NOT NULL DEFAULT '',
    joined_chapter INTEGER NOT NULL DEFAULT 1 CHECK(joined_chapter > 0),
    left_chapter INTEGER CHECK(left_chapter IS NULL OR left_chapter > joined_chapter),
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY(lineage_id) REFERENCES lineages(id) ON DELETE CASCADE,
    FOREIGN KEY(character_id) REFERENCES characters(id) ON DELETE CASCADE
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_lineage_membership_open
    ON lineage_memberships(lineage_id, character_id) WHERE left_chapter IS NULL;
CREATE INDEX IF NOT EXISTS idx_lineage_membership_window
    ON lineage_memberships(lineage_id, joined_chapter, left_chapter);
CREATE INDEX IF NOT EXISTS idx_lineage_membership_character
    ON lineage_memberships(character_id, joined_chapter, left_chapter);

-- Family Tree remains a read model over canonical temporal relationships.
INSERT OR IGNORE INTO relationship_types(id, key, forward_label, inverse_label, directionality, category, created_at) VALUES
('reltype-parent', 'parent', 'Parent of', 'Child of', 'directed', 'kinship', strftime('%Y-%m-%dT%H:%M:%fZ','now')),
('reltype-adoptive-parent', 'adoptive_parent', 'Adoptive parent of', 'Adopted child of', 'directed', 'kinship', strftime('%Y-%m-%dT%H:%M:%fZ','now')),
('reltype-spouse', 'spouse', 'Spouse', 'Spouse', 'symmetric', 'kinship', strftime('%Y-%m-%dT%H:%M:%fZ','now')),
('reltype-betrothed', 'betrothed', 'Betrothed', 'Betrothed', 'symmetric', 'kinship', strftime('%Y-%m-%dT%H:%M:%fZ','now'));
