CREATE TABLE IF NOT EXISTS combat_sessions (
    id TEXT PRIMARY KEY,
    status TEXT NOT NULL CHECK(status IN ('running','completed','abandoned')),
    rng_seed TEXT NOT NULL,
    round_number INTEGER NOT NULL DEFAULT 1 CHECK(round_number > 0),
    turn_index INTEGER NOT NULL DEFAULT 0 CHECK(turn_index >= 0),
    next_action_sequence INTEGER NOT NULL DEFAULT 1 CHECK(next_action_sequence > 0),
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    completed_at TEXT
);

CREATE TABLE IF NOT EXISTS combatants (
    id TEXT PRIMARY KEY,
    session_id TEXT NOT NULL,
    source_character_id TEXT NOT NULL,
    position INTEGER NOT NULL CHECK(position >= 0),
    snapshot TEXT NOT NULL,
    runtime_state TEXT NOT NULL,
    FOREIGN KEY(session_id) REFERENCES combat_sessions(id) ON DELETE CASCADE,
    UNIQUE(session_id, source_character_id),
    UNIQUE(session_id, position)
);

CREATE TABLE IF NOT EXISTS combat_actions (
    id TEXT PRIMARY KEY,
    session_id TEXT NOT NULL,
    sequence_number INTEGER NOT NULL CHECK(sequence_number > 0),
    round_number INTEGER NOT NULL CHECK(round_number > 0),
    turn_index INTEGER NOT NULL CHECK(turn_index >= 0),
    actor_combatant_id TEXT NOT NULL,
    target_combatant_id TEXT,
    action_kind TEXT NOT NULL CHECK(action_kind IN ('use_skill')),
    input_json TEXT NOT NULL,
    resolution_json TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY(session_id) REFERENCES combat_sessions(id) ON DELETE CASCADE,
    UNIQUE(session_id, sequence_number)
);

CREATE INDEX IF NOT EXISTS idx_combat_sessions_status ON combat_sessions(status, updated_at);
CREATE INDEX IF NOT EXISTS idx_combatants_session ON combatants(session_id, position);
CREATE INDEX IF NOT EXISTS idx_combat_actions_session_sequence ON combat_actions(session_id, sequence_number);

-- A terminal session is frozen. The only permitted terminal transition is running -> completed/abandoned.
CREATE TRIGGER IF NOT EXISTS trg_combat_terminal_session_immutable
BEFORE UPDATE ON combat_sessions
WHEN OLD.status <> 'running'
BEGIN
    SELECT RAISE(ABORT, 'terminal combat session is immutable');
END;

CREATE TRIGGER IF NOT EXISTS trg_combatant_updates_require_running_session
BEFORE UPDATE ON combatants
WHEN (SELECT status FROM combat_sessions WHERE id = OLD.session_id) <> 'running'
BEGIN
    SELECT RAISE(ABORT, 'combatant runtime state belongs to a terminal session');
END;

CREATE TRIGGER IF NOT EXISTS trg_combat_action_requires_running_session
BEFORE INSERT ON combat_actions
WHEN (SELECT status FROM combat_sessions WHERE id = NEW.session_id) <> 'running'
BEGIN
    SELECT RAISE(ABORT, 'cannot append action to terminal combat session');
END;
