use std::{error::Error, fs, path::PathBuf};
use chrono::Utc;
use uuid::Uuid;
use lupus_mind_lib::{
    app_state::AppState,
    characters::domain::{character::{Character, CharacterId, CharacterStats}, repository::CharacterRepository},
    global_search::application::service as search_service,
    manuscript::{application::use_cases as manuscript_use_cases, domain::manuscript::{ChapterStatus, UpsertChapterInput}},
    projects::{application::{port::ProjectOperations, service as project_service}, domain::project::CreateProjectInput},
};

fn temp_workspace() -> PathBuf {
    std::env::temp_dir().join(format!("lupus-mind-v0-7-test-{}", Uuid::new_v4()))
}

fn aren() -> Character {
    let now = Utc::now();
    Character {
        id: CharacterId(Uuid::new_v4().to_string()),
        name: "Aren".into(),
        alias: Some("Wolf".into()),
        class_label: Some("Warrior".into()),
        level: 42,
        base_stats: CharacterStats { str: 91, agi: 64, vit: 78, int: 42, mnd: 55 },
        biography: "Aren of Elysium".into(),
        tags: vec!["main-cast".into()],
        created_at: now,
        updated_at: now,
    }
}

#[test]
fn project_switch_isolates_world_and_manuscript_state() -> Result<(), Box<dyn Error>> {
    let base = temp_workspace();
    fs::create_dir_all(&base)?;

    {
        let state = AppState::open_managed(&base)?;
        let project_a = project_service::current(&state.projects)?;

        let character = aren();
        state.characters.insert(&character)?;
        let chapter = manuscript_use_cases::create(&state.manuscript, UpsertChapterInput {
            chapter_number: 184,
            title: "The Return".into(),
            status: ChapterStatus::Draft,
            content: "Aren entered Elysium.".into(),
            notes: "Continuity checkpoint".into(),
            tags: vec!["aren".into()],
        })?;

        let a_hits = search_service::search(&state.search, "Aren", 20)?;
        assert!(a_hits.iter().any(|hit| hit.kind == "character" && hit.id == character.id.0));
        assert!(a_hits.iter().any(|hit| hit.kind == "chapter" && hit.id == chapter.id));

        let project_b = project_service::create(&state.projects, CreateProjectInput { name: "Ashen Crown".into() })?;
        project_service::switch(&state.projects, &project_b.id)?;

        assert!(state.characters.list()?.is_empty());
        assert!(manuscript_use_cases::list(&state.manuscript)?.is_empty());
        assert!(search_service::search(&state.search, "Aren", 20)?.is_empty());

        let b_character = Character { name: "Kael".into(), ..aren() };
        state.characters.insert(&b_character)?;
        assert_eq!(state.characters.list()?.len(), 1);

        project_service::switch(&state.projects, &project_a.id)?;
        let restored = state.characters.list()?;
        assert_eq!(restored.len(), 1);
        assert_eq!(restored[0].name, "Aren");
        let restored_chapters = manuscript_use_cases::list(&state.manuscript)?;
        assert_eq!(restored_chapters.len(), 1);
        assert_eq!(restored_chapters[0].chapter_number, 184);
        assert!(search_service::search(&state.search, "Kael", 20)?.is_empty());
    }

    let _ = fs::remove_dir_all(&base);
    Ok(())
}

#[test]
fn missing_registered_project_database_fails_closed() -> Result<(), Box<dyn Error>> {
    let base = temp_workspace();
    fs::create_dir_all(&base)?;

    {
        let state = AppState::open_managed(&base)?;
        let created = project_service::create(&state.projects, CreateProjectInput { name: "Disposable".into() })?;
        let registry: serde_json::Value = serde_json::from_slice(&fs::read(base.join("projects.json"))?)?;
        let projects = registry.get("projects").and_then(|v| v.as_array()).ok_or("projects missing")?;
        let entry = projects.iter().find(|project| project.get("id").and_then(|v| v.as_str()) == Some(&created.id)).ok_or("created project missing")?;
        let relative = entry.get("databaseFile").and_then(|v| v.as_str()).ok_or("database file missing")?;
        fs::remove_file(base.join(relative))?;
        let result = state.projects.switch(&created.id);
        assert!(result.is_err());
    }

    let _ = fs::remove_dir_all(&base);
    Ok(())
}
