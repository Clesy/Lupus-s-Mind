use chrono::Utc;
use lupus_mind_lib::{
    app_state::AppState,
    characters::domain::{character::{Character, CharacterId, CharacterStats}, repository::CharacterRepository},
    factions::domain::{
        faction::UpsertFactionInput,
        hierarchy::{AddLineageMembershipInput, AssignRoleInput, UpsertLineageInput},
        hierarchy_repository::FactionHierarchyRepository,
        repository::FactionRepository,
    },
    relationships::domain::repository::RelationshipTypeRepository,
};

fn character(id:&str,name:&str)->Character{
    let now=Utc::now();
    Character{id:CharacterId(id.into()),name:name.into(),alias:None,class_label:None,level:1,
        base_stats:CharacterStats{str:10,agi:10,vit:10,int:10,mnd:10},biography:String::new(),tags:vec![],created_at:now,updated_at:now}
}

#[test]
fn hierarchy_lineage_and_family_types_are_temporal_and_separate(){
    let state=AppState::in_memory().expect("state");
    state.characters.insert(&character("kael","Kael")).expect("kael");
    state.characters.insert(&character("aren","Aren")).expect("aren");

    let clan=state.factions.create(UpsertFactionInput{name:"Shadow Wolves".into(),kind:"clan".into(),description:None,motto:None,color:None,tags:vec![]}).expect("clan");
    let roles=state.factions.seed_default_hierarchy(&clan.id).expect("seed hierarchy");
    let leader=roles.iter().find(|r|r.name=="Clan Leader").expect("leader role");

    let kael_term=state.factions.assign_role(AssignRoleInput{role_id:leader.id.clone(),character_id:"kael".into(),valid_from_chapter:1,title_override:None,notes:None}).expect("kael leader");
    assert_eq!(state.factions.role_assignments(&clan.id,30).expect("chapter 30")[0].character_name,"Kael");
    state.factions.end_role_assignment(&kael_term.id,50).expect("end term");
    state.factions.assign_role(AssignRoleInput{role_id:leader.id.clone(),character_id:"aren".into(),valid_from_chapter:50,title_override:Some("Second Clan Leader".into()),notes:None}).expect("aren leader");
    assert_eq!(state.factions.role_assignments(&clan.id,50).expect("chapter 50")[0].character_name,"Aren");

    let dynasty=state.factions.create_lineage(UpsertLineageInput{name:"House Valerius".into(),kind:"dynasty".into(),description:None,color:None,tags:vec!["royal".into()],affiliated_faction_id:Some(clan.id.clone())}).expect("dynasty");
    state.factions.add_lineage_membership(AddLineageMembershipInput{lineage_id:dynasty.id.clone(),character_id:"aren".into(),branch_label:Some("Main".into()),title:Some("Heir".into()),joined_chapter:10}).expect("lineage member");
    let members=state.factions.lineage_memberships(&dynasty.id,20).expect("lineage members");
    assert_eq!(members.len(),1);assert_eq!(members[0].title,"Heir");

    let types=state.relationships.list_types().expect("relationship types");
    for key in ["parent","adoptive_parent","spouse","betrothed","sibling"]{
        assert!(types.iter().any(|t|t.key==key),"missing family relationship type: {key}");
    }
}
