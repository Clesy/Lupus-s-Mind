use lupus_mind_lib::{
    app_state::AppState,
    characters::{application::use_cases::{self as character_use_cases, UpsertCharacterInput},domain::character::CharacterStats},
    relationship_graph::application::graph_at_chapter,
    relationships::application::use_cases::{self, ChangeRelationshipStateInput, CreateRelationshipInput, EndRelationshipInput},
};

fn character(state:&AppState,name:&str)->String{
    character_use_cases::create(&state.characters,UpsertCharacterInput{name:name.into(),alias:None,class_label:None,level:1,base_stats:CharacterStats{str:10,agi:10,vit:10,int:10,mnd:10},biography:None,tags:vec![]}).expect("character create").id
}

#[test]
fn golden_temporal_relationship_boundaries_are_half_open(){
    let state=AppState::in_memory().expect("state");
    let aren=character(&state,"Aren");let elysia=character(&state,"Elysia");
    let created=use_cases::create(&state.characters,&state.relationships,&state.relationships,CreateRelationshipInput{type_id:"reltype-trust".into(),source_character_id:aren,target_character_id:elysia,chapter:10,intensity:90,note:None,tags:vec![]}).expect("create relationship");
    use_cases::change_state(&state.relationships,ChangeRelationshipStateInput{relationship_id:created.id.clone(),chapter:50,intensity:35,note:Some("Trust fractured".into()),tags:vec![]}).expect("change");
    use_cases::end(&state.relationships,EndRelationshipInput{relationship_id:created.id.clone(),chapter:80}).expect("end");
    let expected=[(9,None),(10,Some(90)),(49,Some(90)),(50,Some(35)),(79,Some(35)),(80,None),(999,None)];
    for (chapter,intensity) in expected { let actual=use_cases::get_at(&state.relationships,created.id.clone(),chapter).expect("snapshot").map(|r|r.state.intensity);assert_eq!(actual,intensity,"chapter {chapter}"); }
}

#[test]
fn symmetric_reverse_duplicate_is_rejected_but_directed_reverse_is_allowed(){
    let state=AppState::in_memory().expect("state");let a=character(&state,"A");let b=character(&state,"B");
    use_cases::create(&state.characters,&state.relationships,&state.relationships,CreateRelationshipInput{type_id:"reltype-ally".into(),source_character_id:a.clone(),target_character_id:b.clone(),chapter:1,intensity:70,note:None,tags:vec![]}).expect("ally");
    assert!(use_cases::create(&state.characters,&state.relationships,&state.relationships,CreateRelationshipInput{type_id:"reltype-ally".into(),source_character_id:b.clone(),target_character_id:a.clone(),chapter:1,intensity:70,note:None,tags:vec![]}).is_err());
    use_cases::create(&state.characters,&state.relationships,&state.relationships,CreateRelationshipInput{type_id:"reltype-trust".into(),source_character_id:a.clone(),target_character_id:b.clone(),chapter:1,intensity:90,note:None,tags:vec![]}).expect("directed A->B");
    use_cases::create(&state.characters,&state.relationships,&state.relationships,CreateRelationshipInput{type_id:"reltype-trust".into(),source_character_id:b,target_character_id:a,chapter:1,intensity:20,note:None,tags:vec![]}).expect("directed B->A");
}

#[test]
fn graph_snapshot_is_derived_from_chapter_state(){
    let state=AppState::in_memory().expect("state");let a=character(&state,"Aren");let b=character(&state,"Elysia");
    let relation=use_cases::create(&state.characters,&state.relationships,&state.relationships,CreateRelationshipInput{type_id:"reltype-mentor".into(),source_character_id:a,target_character_id:b,chapter:42,intensity:78,note:None,tags:vec![]}).expect("relation");
    let before=graph_at_chapter::graph_at_chapter(&state.characters,&state.relationships,&state.relationships,41).expect("before");assert!(before.edges.is_empty());
    let at=graph_at_chapter::graph_at_chapter(&state.characters,&state.relationships,&state.relationships,42).expect("at");assert_eq!(at.edges.len(),1);assert_eq!(at.edges[0].relationship_id,relation.id);assert_eq!(at.edges[0].intensity,78);
}
