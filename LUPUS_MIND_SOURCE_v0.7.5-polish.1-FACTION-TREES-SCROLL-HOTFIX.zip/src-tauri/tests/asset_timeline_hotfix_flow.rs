use lupus_mind_lib::{
    app_state::AppState,
    assets::application::service as asset_service,
    characters::{application::use_cases as character_use_cases, domain::character::CharacterStats},
    projects::{application::service as project_service, domain::project::CreateProjectInput},
    items::{application::use_cases as item_use_cases, domain::item::{ItemRarity, ItemType}},
    timeline::{application::use_cases as timeline_use_cases, domain::timeline::{EventImportance, TemporalKind, TimelineEventKind}},
};
use uuid::Uuid;

fn character(state: &AppState, name: &str) -> String {
    character_use_cases::create(&state.characters, character_use_cases::UpsertCharacterInput {
        name: name.into(), alias: None, class_label: Some("Tester".into()), level: 1,
        base_stats: CharacterStats { str: 10, agi: 10, vit: 10, int: 10, mnd: 10 }, biography: None, tags: vec![],
    }).expect("character").id
}

fn item(state: &AppState, name: &str) -> String {
    item_use_cases::create(&state.items, item_use_cases::UpsertItemInput {
        name: name.into(), description: Some("Artwork test".into()), item_type: ItemType::Weapon,
        rarity: ItemRarity::Rare, modifiers: vec![], tags: vec![],
    }).expect("item").id
}

fn event(title: &str, start: u32, end: Option<u32>) -> timeline_use_cases::UpsertTimelineEventInput {
    timeline_use_cases::UpsertTimelineEventInput {
        title: title.into(), description: None, kind: TimelineEventKind::Personal, importance: EventImportance::Standard,
        temporal_kind: if end.is_some() { TemporalKind::Span } else { TemporalKind::Point }, start_chapter: start, end_chapter: end,
        world_time_start: None, world_time_end: None, location_label: None, tags: vec![], participants: vec![], sources: vec![],
    }
}

#[test]
fn portrait_files_are_isolated_by_active_project_database() {
    let base = std::env::temp_dir().join(format!("lupus-mind-asset-test-{}", Uuid::new_v4()));
    {
        let state = AppState::open_managed(&base).expect("state");
        let project_a = project_service::current(&state.projects).expect("project A");
        let aren = character(&state, "Aren");
        let first = vec![1_u8, 2, 3, 4];
        asset_service::put(&state.characters, &state.assets, &aren, "image/webp", first.clone()).expect("portrait A");
        assert_eq!(asset_service::get(&state.characters, &state.assets, &aren).expect("get A").expect("asset A").bytes, first);

        let project_b = project_service::create(&state.projects, CreateProjectInput { name: "Ashen Crown".into() }).expect("create B");
        project_service::switch(&state.projects, &project_b.id).expect("switch B");
        let elysia = character(&state, "Elysia");
        let second = vec![9_u8, 8, 7];
        asset_service::put(&state.characters, &state.assets, &elysia, "image/png", second.clone()).expect("portrait B");
        assert_eq!(asset_service::get(&state.characters, &state.assets, &elysia).expect("get B").expect("asset B").bytes, second);

        project_service::switch(&state.projects, &project_a.id).expect("switch A");
        assert_eq!(asset_service::get(&state.characters, &state.assets, &aren).expect("get A again").expect("asset A again").bytes, first);
    }
    let _ = std::fs::remove_dir_all(base);
}

#[test]
fn item_artwork_files_are_isolated_by_active_project_database() {
    let base = std::env::temp_dir().join(format!("lupus-mind-item-art-test-{}", Uuid::new_v4()));
    {
        let state = AppState::open_managed(&base).expect("state");
        let project_a = project_service::current(&state.projects).expect("project A");
        let sword = item(&state, "Voidfang");
        let first = vec![4_u8, 3, 2, 1];
        asset_service::put_item_artwork(&state.items, &state.assets, &sword, "image/webp", first.clone()).expect("art A");
        assert_eq!(asset_service::get_item_artwork(&state.items, &state.assets, &sword).expect("get A").expect("asset A").bytes, first);

        let project_b = project_service::create(&state.projects, CreateProjectInput { name: "Second World".into() }).expect("create B");
        project_service::switch(&state.projects, &project_b.id).expect("switch B");
        let crown = item(&state, "Ashen Crown");
        let second = vec![8_u8, 8, 8];
        asset_service::put_item_artwork(&state.items, &state.assets, &crown, "image/png", second.clone()).expect("art B");
        assert_eq!(asset_service::get_item_artwork(&state.items, &state.assets, &crown).expect("get B").expect("asset B").bytes, second);

        project_service::switch(&state.projects, &project_a.id).expect("switch A");
        assert_eq!(asset_service::get_item_artwork(&state.items, &state.assets, &sword).expect("get A again").expect("asset A again").bytes, first);
    }
    let _ = std::fs::remove_dir_all(base);
}

#[test]
fn timeline_bounds_cover_point_and_half_open_span_events() {
    let state = AppState::in_memory().expect("state");
    timeline_use_cases::create(&state.characters, &state.timeline, &state.timeline, event("Arrival", 10, None)).expect("arrival");
    timeline_use_cases::create(&state.characters, &state.timeline, &state.timeline, event("Siege", 50, Some(80))).expect("siege");
    let bounds = timeline_use_cases::bounds(&state.timeline).expect("bounds").expect("non-empty bounds");
    assert_eq!(bounds.start_chapter, 10);
    assert_eq!(bounds.end_chapter, 80);
}
