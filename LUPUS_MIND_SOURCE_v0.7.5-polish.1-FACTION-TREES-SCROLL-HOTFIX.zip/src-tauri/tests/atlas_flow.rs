use std::collections::HashSet;
use lupus_mind_lib::{
    app_state::AppState,
    atlas::{
        application::generator,
        domain::{atlas::{AcceptGeneratedMapInput, GenerateMapRequest, MapPoint, UpsertConnectionInput, UpsertLocationInput, UpsertMapInput, UpsertPinInput}, repository::AtlasRepository},
    },
};

fn request(seed:u32)->GenerateMapRequest{
    GenerateMapRequest{seed,name:Some("Asterra".into()),width:1200,height:760,continents:3,ocean_ratio:0.55,mountain_density:0.5,river_count:5,settlement_count:10}
}


fn point_in_polygon(point:&MapPoint,poly:&[MapPoint])->bool{
    if poly.len()<3{return false}
    let mut inside=false;let mut j=poly.len()-1;
    for i in 0..poly.len(){let a=&poly[i];let b=&poly[j];if (a.y>point.y)!=(b.y>point.y){let x=(b.x-a.x)*(point.y-a.y)/(b.y-a.y)+a.x;if point.x<x{inside=!inside}}j=i;}
    inside
}

#[test]
fn atlas_locations_maps_and_generator_preserve_canonical_boundary(){
    let state=AppState::in_memory().expect("state");
    let world=state.atlas.create_location(UpsertLocationInput{name:"Asterra".into(),kind:"world".into(),parent_location_id:None,description:None,color:None,tags:vec![]}).expect("world");
    let city=state.atlas.create_location(UpsertLocationInput{name:"Elysium City".into(),kind:"city".into(),parent_location_id:Some(world.id.clone()),description:None,color:None,tags:vec!["capital".into()]}).expect("city");
    let gate=state.atlas.create_location(UpsertLocationInput{name:"North Gate".into(),kind:"landmark".into(),parent_location_id:Some(city.id.clone()),description:None,color:None,tags:vec![]}).expect("gate");
    assert_eq!(state.atlas.locations().expect("locations").len(),3);

    let map=state.atlas.create_map(UpsertMapInput{name:"World Map".into(),scope_location_id:Some(world.id.clone()),parent_map_id:None,width:1200,height:760,background:None,terrain:None}).expect("map");
    state.atlas.upsert_pin(UpsertPinInput{map_id:map.id.clone(),location_id:city.id.clone(),label:Some("Capital".into()),x:0.4,y:0.5,icon:None,color:None}).expect("city pin");
    state.atlas.upsert_pin(UpsertPinInput{map_id:map.id.clone(),location_id:gate.id.clone(),label:None,x:0.55,y:0.48,icon:None,color:None}).expect("gate pin");
    state.atlas.upsert_connection(UpsertConnectionInput{map_id:map.id.clone(),from_location_id:city.id.clone(),to_location_id:gate.id.clone(),kind:"road".into(),label:Some("Royal Road".into()),color:None}).expect("road");
    assert_eq!(state.atlas.pins(&map.id).expect("pins").len(),2);
    assert_eq!(state.atlas.connections(&map.id).expect("connections").len(),1);

    let before_maps=state.atlas.maps().expect("before maps").len();
    let before_locations=state.atlas.locations().expect("before locations").len();
    let a=generator::generate(request(482193)).expect("draft a");
    let b=generator::generate(request(482193)).expect("draft b");
    assert_eq!(serde_json::to_string(&a).unwrap(),serde_json::to_string(&b).unwrap(),"same seed must be deterministic");
    assert!(a.landmasses.iter().all(|land|land.points.len()>=128),"coastlines need high-resolution geometry");
    assert!(a.rivers.iter().all(|river|river.points.len()>=2),"rivers need real traced paths");
    let mut settlement_names=HashSet::new();
    for settlement in &a.settlements{
        assert!(settlement_names.insert(settlement.name.clone()),"generated settlement names must be unique");
        let point=MapPoint{x:settlement.x,y:settlement.y};
        assert!(a.landmasses.iter().any(|land|point_in_polygon(&point,&land.points)),"settlements must be placed on land");
    }
    let city_count=a.settlements.iter().filter(|s|s.kind=="city").count();
    assert!(city_count>=a.landmasses.len(),"each generated continent should receive a primary city when capacity allows");
    for i in 0..a.settlements.len(){for j in i+1..a.settlements.len(){let dx=a.settlements[i].x-a.settlements[j].x;let dy=a.settlements[i].y-a.settlements[j].y;assert!((dx*dx+dy*dy).sqrt()>0.012,"settlements should not stack on top of each other");}}
    assert_eq!(state.atlas.maps().expect("after preview maps").len(),before_maps,"preview generation must not write canon");
    assert_eq!(state.atlas.locations().expect("after preview locations").len(),before_locations,"preview generation must not create locations");

    let accepted=state.atlas.accept_generated_map(AcceptGeneratedMapInput{draft:a,map_name:"Generated Asterra".into(),create_locations:true}).expect("accept");
    assert_eq!(accepted.map.generator_seed,Some(482193));
    assert!(accepted.map.terrain.is_some());
    assert!(!accepted.created_location_ids.is_empty());
    assert!(state.atlas.maps().expect("maps after accept").len()>before_maps);
    assert!(state.atlas.locations().expect("locations after accept").len()>before_locations);
    let generated_pins=state.atlas.pins(&accepted.map.id).expect("generated pins");
    assert!(!generated_pins.is_empty());
    assert!(generated_pins.iter().any(|p|p.location_kind=="city"&&p.icon=="city"),"accepted settlement pins should preserve settlement visual kind");
}
