use chrono::Utc;
use lupus_mind_lib::{
    app_state::AppState,
    characters::domain::{character::{Character, CharacterId, CharacterStats}, repository::CharacterRepository},
    equipment::domain::{equipment::EquipmentSlot, repository::EquipmentRepository},
    factions::domain::{faction::{AddMembershipInput, SetFactionRelationInput, UpsertFactionInput}, repository::FactionRepository},
    inventory::domain::{inventory::TransferOwnershipInput, repository::InventoryRepository},
    items::domain::{item::{Item, ItemId, ItemRarity, ItemType}, repository::ItemRepository},
    quests::domain::{quest::{UpsertObjectiveInput, UpsertQuestInput}, repository::QuestRepository},
    secrets::domain::{secret::{SetSecretKnowledgeInput, UpsertSecretInput}, repository::SecretRepository},
};

fn character(id: &str, name: &str) -> Character {
    let now = Utc::now();
    Character { id: CharacterId(id.into()), name: name.into(), alias: None, class_label: None, level: 1,
        base_stats: CharacterStats { str: 10, agi: 10, vit: 10, int: 10, mnd: 10 }, biography: String::new(), tags: vec![], created_at: now, updated_at: now }
}
fn item(id: &str, name: &str) -> Item {
    let now = Utc::now();
    Item { id: ItemId(id.into()), name: name.into(), description: String::new(), item_type: ItemType::Weapon,
        rarity: ItemRarity::Legendary, modifiers: vec![], tags: vec![], created_at: now, updated_at: now }
}

#[test]
fn faction_inventory_quest_and_secret_flow_remain_separate_but_queryable() {
    let state = AppState::in_memory().expect("state");
    state.characters.insert(&character("aren", "Aren")).expect("aren");
    state.characters.insert(&character("elysia", "Elysia")).expect("elysia");
    state.items.insert(&item("voidfang", "Voidfang")).expect("item");

    let elysium = state.factions.create(UpsertFactionInput { name: "Elysium".into(), kind: "kingdom".into(), description: None, motto: None, color: None, tags: vec![] }).expect("elysium");
    let empire = state.factions.create(UpsertFactionInput { name: "Empire".into(), kind: "kingdom".into(), description: None, motto: None, color: None, tags: vec![] }).expect("empire");
    state.factions.add_membership(AddMembershipInput { faction_id: elysium.id.clone(), character_id: "aren".into(), role: "Captain".into(), rank: "III".into(), joined_chapter: 10 }).expect("membership");
    state.factions.set_relation(SetFactionRelationInput { faction_a_id: elysium.id.clone(), faction_b_id: empire.id.clone(), relation_type: "allied".into(), chapter: 10, notes: None }).expect("allied");
    state.factions.set_relation(SetFactionRelationInput { faction_a_id: elysium.id.clone(), faction_b_id: empire.id.clone(), relation_type: "war".into(), chapter: 50, notes: None }).expect("war");
    assert_eq!(state.factions.relations_at(30).expect("rel30")[0].relation_type, "allied");
    assert_eq!(state.factions.relations_at(50).expect("rel50")[0].relation_type, "war");

    state.inventory.transfer(TransferOwnershipInput { item_id: "voidfang".into(), owner_kind: "character".into(), owner_id: "aren".into(), chapter: 20, note: None }).expect("ownership");
    state.equipment.replace_slot_atomic(&CharacterId("aren".into()), &ItemId("voidfang".into()), EquipmentSlot::MainHand).expect("equip");
    state.inventory.transfer(TransferOwnershipInput { item_id: "voidfang".into(), owner_kind: "faction".into(), owner_id: elysium.id.clone(), chapter: 100, note: Some("Treasury".into()) }).expect("transfer");
    assert_eq!(state.inventory.list_at(100, Some("faction"), Some(&elysium.id)).expect("inventory").len(), 1);
    assert_eq!(state.equipment.list_for_character(&CharacterId("aren".into())).expect("equipment").len(), 1, "ownership must not mutate equipment");

    let quest = state.quests.create(UpsertQuestInput { title: "Broken Crown".into(), status: "active".into(), summary: None, description: None, quest_giver_character_id: Some("elysia".into()), faction_id: Some(elysium.id.clone()), start_chapter: Some(120), completion_chapter: None, tags: vec![] }).expect("quest");
    let objective = state.quests.objective_add(&quest.id, UpsertObjectiveInput { text: "Recover the Crown".into(), position: 1, is_completed: false, completed_chapter: None }).expect("objective");
    state.quests.objective_update(&objective.id, UpsertObjectiveInput { text: objective.text, position: 1, is_completed: true, completed_chapter: Some(184) }).expect("complete objective");
    assert!(state.quests.get(&quest.id).expect("quest get").expect("quest exists").objectives[0].is_completed);

    let secret = state.secrets.create(UpsertSecretInput { title: "The Emperor is Aren's father".into(), description: None, importance: "critical".into(), origin_chapter: Some(1), tags: vec![] }).expect("secret");
    state.secrets.set_knowledge(SetSecretKnowledgeInput { secret_id: secret.id.clone(), character_id: "elysia".into(), knowledge_state: "knows".into(), chapter: 430, source_note: None }).expect("elysia knows");
    state.secrets.set_knowledge(SetSecretKnowledgeInput { secret_id: secret.id.clone(), character_id: "aren".into(), knowledge_state: "knows".into(), chapter: 810, source_note: None }).expect("aren knows");
    let at_500 = state.secrets.knowledge_for_secret(&secret.id, 500).expect("knowledge 500");
    assert_eq!(at_500.len(), 1); assert_eq!(at_500[0].character_name, "Elysia");
    assert_eq!(state.secrets.knowledge_for_secret(&secret.id, 900).expect("knowledge 900").len(), 2);
}
