use chrono::Utc;use lupus_mind_lib::{app_state::AppState,character_sheet::application::get_character_sheet,characters::domain::{character::{Character,CharacterId,CharacterStats},repository::CharacterRepository},equipment::domain::{equipment::EquipmentSlot,error::EquipmentError,repository::EquipmentRepository},items::domain::{item::{Item,ItemId,ItemRarity,ItemType,StatKey,StatModifier},repository::ItemRepository}};
fn character(id:&str,name:&str)->Character{let now=Utc::now();Character{id:CharacterId(id.into()),name:name.into(),alias:None,class_label:None,level:1,base_stats:CharacterStats{str:10,agi:10,vit:10,int:10,mnd:10},biography:"".into(),tags:vec![],created_at:now,updated_at:now}}
fn item(id:&str,t:ItemType,mods:Vec<StatModifier>)->Item{let now=Utc::now();Item{id:ItemId(id.into()),name:id.into(),description:"".into(),item_type:t,rarity:ItemRarity::Legendary,modifiers:mods,tags:vec![],created_at:now,updated_at:now}}
#[test]fn equip_updates_sheet_without_mutating_base_stats(){let s=AppState::in_memory().unwrap();s.characters.insert(&character("c1","Talion")).unwrap();s.items.insert(&item("i1",ItemType::Weapon,vec![StatModifier{stat:StatKey::Strength,value:10.0},StatModifier{stat:StatKey::WeaponDamage,value:120.0}])).unwrap();s.equipment.replace_slot_atomic(&CharacterId("c1".into()),&ItemId("i1".into()),EquipmentSlot::MainHand).unwrap();let sheet=get_character_sheet::get_sheet(&s.characters,&s.items,&s.equipment,"c1".into()).unwrap();assert_eq!(sheet.base_stats.str,10);assert_eq!(sheet.effective_stats.strength,20.0);assert_eq!(sheet.effective_stats.weapon_damage,120.0);let persisted=s.characters.get(&CharacterId("c1".into())).unwrap().unwrap();assert_eq!(persisted.base_stats.str,10);}
#[test]fn item_cannot_be_equipped_by_two_characters(){let s=AppState::in_memory().unwrap();s.characters.insert(&character("c1","A")).unwrap();s.characters.insert(&character("c2","B")).unwrap();s.items.insert(&item("i1",ItemType::Weapon,vec![])).unwrap();s.equipment.replace_slot_atomic(&CharacterId("c1".into()),&ItemId("i1".into()),EquipmentSlot::MainHand).unwrap();let err=s.equipment.replace_slot_atomic(&CharacterId("c2".into()),&ItemId("i1".into()),EquipmentSlot::MainHand).unwrap_err();assert!(matches!(err,EquipmentError::ItemAlreadyEquipped(_)));}
#[test]fn incompatible_replace_keeps_previous_slot_item(){let s=AppState::in_memory().unwrap();s.characters.insert(&character("c1","A")).unwrap();s.items.insert(&item("weapon",ItemType::Weapon,vec![])).unwrap();s.items.insert(&item("material",ItemType::Material,vec![])).unwrap();s.equipment.replace_slot_atomic(&CharacterId("c1".into()),&ItemId("weapon".into()),EquipmentSlot::MainHand).unwrap();assert!(matches!(s.equipment.replace_slot_atomic(&CharacterId("c1".into()),&ItemId("material".into()),EquipmentSlot::MainHand),Err(EquipmentError::IncompatibleSlot{..})));let list=s.equipment.list_for_character(&CharacterId("c1".into())).unwrap();assert_eq!(list.len(),1);assert_eq!(list[0].item_id.0.as_str(),"weapon");}


#[test]
fn compatibility_picker_reports_availability_from_domain_state() {
    use lupus_mind_lib::equipment::application::use_cases::EquipmentServices;
    let state = AppState::in_memory().unwrap();
    state.characters.insert(&character("c1", "Talion")).unwrap();
    state.characters.insert(&character("c2", "Aren")).unwrap();
    state.items.insert(&item("weapon-a", ItemType::Weapon, vec![])).unwrap();
    state.items.insert(&item("weapon-b", ItemType::Weapon, vec![])).unwrap();
    state.items.insert(&item("armor-a", ItemType::Armor, vec![])).unwrap();
    state.equipment.replace_slot_atomic(
        &CharacterId("c2".into()),
        &ItemId("weapon-b".into()),
        EquipmentSlot::MainHand,
    ).unwrap();

    let services = EquipmentServices {
        characters: &state.characters,
        items: &state.items,
        equipment: &state.equipment,
    };
    let candidates = services.compatible_items("c1".into(), EquipmentSlot::MainHand).unwrap();
    assert_eq!(candidates.len(), 2);
    let available = candidates.iter().find(|candidate| candidate.item.id == "weapon-a").unwrap();
    let occupied = candidates.iter().find(|candidate| candidate.item.id == "weapon-b").unwrap();
    assert!(available.available);
    assert!(!occupied.available);
    assert_eq!(occupied.equipped_by_character_id.as_deref(), Some("c2"));
}
