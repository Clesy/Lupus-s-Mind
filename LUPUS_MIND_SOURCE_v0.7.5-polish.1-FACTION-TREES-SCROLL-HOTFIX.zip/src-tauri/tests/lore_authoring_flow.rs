use lupus_mind_lib::{
    app_state::AppState,
    authoring::domain::{authoring::{UpsertArcPointInput, UpsertScenePlanInput}, repository::AuthoringRepository},
    characters::{application::use_cases as character_use_cases, domain::character::CharacterStats},
    knowledge_links::domain::repository::KnowledgeLinkRepository,
    lore::{application::use_cases as lore_use_cases, domain::lore::UpsertLoreInput},
    manuscript::{application::use_cases as manuscript_use_cases, domain::manuscript::{ChapterStatus, UpsertChapterInput, UpsertQuickNoteInput}},
};

fn character(state: &AppState, name: &str) -> String {
    character_use_cases::create(&state.characters, character_use_cases::UpsertCharacterInput {
        name: name.into(), alias: None, class_label: Some("Authoring test".into()), level: 1,
        base_stats: CharacterStats { str: 10, agi: 10, vit: 10, int: 10, mnd: 10 }, biography: None, tags: vec![],
    }).expect("character").id
}

#[test]
fn lore_mentions_backlinks_scene_arc_and_note_links_round_trip() {
    let state = AppState::in_memory().expect("state");
    let aren = character(&state, "Aren");

    let chapter = manuscript_use_cases::create(&state.manuscript, UpsertChapterInput {
        chapter_number: 184, title: "The Return".into(), status: ChapterStatus::Draft,
        content: "@Aren enters the citadel.".into(), notes: String::new(), tags: vec!["return".into()],
    }).expect("chapter");
    state.links.refresh_source("chapter", &chapter.id, &chapter.content).expect("chapter mentions");

    let lore = lore_use_cases::create(&state.lore, UpsertLoreInput {
        title: "Ashen Prophecy".into(), category: "History".into(), summary: "A prophecy about @Aren.".into(),
        content: "The final verse names @Aren.".into(), tags: vec!["prophecy".into()],
    }).expect("lore");
    state.links.refresh_source("lore", &lore.id, &format!("{}\n{}", lore.summary, lore.content)).expect("lore mentions");

    let backlinks = state.links.backlinks_for_target("character", &aren).expect("backlinks");
    assert_eq!(backlinks.len(), 2);
    assert!(backlinks.iter().any(|link| link.source_kind == "chapter" && link.source_id == chapter.id));
    assert!(backlinks.iter().any(|link| link.source_kind == "lore" && link.source_id == lore.id));

    let arc = state.authoring.create_arc(&UpsertArcPointInput {
        character_id: aren.clone(), chapter_number: 430, title: "Exile".into(), phase: "Fall".into(), description: "Aren loses his place.".into(),
    }).expect("arc");
    assert_eq!(state.authoring.arc_for_character(&aren).expect("arc list")[0].id, arc.id);

    let scene = state.authoring.create_scene(&UpsertScenePlanInput {
        chapter_id: chapter.id.clone(), scene_order: 1, title: "The Gate".into(), goal: "Enter the citadel".into(),
        obstacle: "The gate is sealed".into(), outcome: "Aren finds another route".into(), pov_character_id: Some(aren.clone()),
        location_label: "North Gate".into(), participant_character_ids: vec![aren.clone()], notes: String::new(),
    }).expect("scene");
    assert_eq!(state.authoring.scenes_for_chapter(&chapter.id).expect("scenes")[0].id, scene.id);

    let note = manuscript_use_cases::create_note(&state.manuscript, UpsertQuickNoteInput {
        body: "Remember the gate reveal".into(), pinned: true, link_kind: Some("chapter".into()), link_id: Some(chapter.id.clone()), link_label: Some("Chapter 184".into()),
    }).expect("note");
    assert_eq!(note.link_id.as_deref(), Some(chapter.id.as_str()));
}

#[test]
fn deleting_parent_records_cascades_scene_and_arc_but_mentions_remain_projection_managed() {
    let state = AppState::in_memory().expect("state");
    let aren = character(&state, "Aren");
    let chapter = manuscript_use_cases::create(&state.manuscript, UpsertChapterInput {
        chapter_number: 1, title: "One".into(), status: ChapterStatus::Draft, content: String::new(), notes: String::new(), tags: vec![],
    }).expect("chapter");
    state.authoring.create_arc(&UpsertArcPointInput { character_id: aren.clone(), chapter_number: 1, title: "Beginning".into(), phase: String::new(), description: String::new() }).expect("arc");
    state.authoring.create_scene(&UpsertScenePlanInput { chapter_id: chapter.id.clone(), scene_order: 1, title: String::new(), goal: String::new(), obstacle: String::new(), outcome: String::new(), pov_character_id: Some(aren.clone()), location_label: String::new(), participant_character_ids: vec![], notes: String::new() }).expect("scene");

    manuscript_use_cases::delete(&state.manuscript, &chapter.id).expect("delete chapter");
    assert!(state.authoring.scenes_for_chapter(&chapter.id).expect("scenes after delete").is_empty());
    character_use_cases::delete(&state.characters, aren.clone()).expect("delete character");
    assert!(state.authoring.arc_for_character(&aren).expect("arc after delete").is_empty());
}
