use chrono::Utc;
use lupus_mind_lib::{
    combat::{
        application::use_cases::use_skill,
        domain::{
            combat::{
                ActiveStatusEffect, CombatActionKind, CombatSession, CombatSessionId, CombatSkillSnapshot,
                CombatStackingPolicy, CombatStats, CombatStatus, CombatStatusEffectKind, CombatStatusEffectSpec,
                Combatant, CombatantId, CombatantRuntimeState, CombatantSnapshot, UseSkillCommand,
            },
            repository::CombatSessionRepository,
        },
        infrastructure::sqlite_combat_repository::SqliteCombatRepository,
    },
    shared::database::Database,
    skills::domain::skill::{ResourceKind, SkillKind},
};

fn wait_skill(effects:Vec<CombatStatusEffectSpec>)->CombatSkillSnapshot{
    CombatSkillSnapshot{skill_id:"wait".into(),name:"Wait".into(),kind:SkillKind::Utility,resource_kind:ResourceKind::None,base_power:0.0,resource_cost:0,cooldown_turns:0,scaling:vec![],effects}
}
fn burn(power:f64,duration:u32)->CombatStatusEffectSpec{CombatStatusEffectSpec{definition_id:"effect-burn".into(),name:"Burn".into(),kind:CombatStatusEffectKind::DamageOverTime,stacking_policy:CombatStackingPolicy::Refresh,duration_turns:duration,power,modifier:None}}
fn active_burn(power:f64,duration:u32)->ActiveStatusEffect{ActiveStatusEffect{instance_id:"burn-runtime".into(),definition_id:"effect-burn".into(),name:"Burn".into(),source_combatant_id:CombatantId("old-source".into()),kind:CombatStatusEffectKind::DamageOverTime,stacking_policy:CombatStackingPolicy::Refresh,power,duration_remaining:duration,modifier:None,applied_sequence:0}}
fn poison(power:f64,duration:u32)->ActiveStatusEffect{ActiveStatusEffect{instance_id:"poison-runtime".into(),definition_id:"effect-poison".into(),name:"Poison".into(),source_combatant_id:CombatantId("elysia".into()),kind:CombatStatusEffectKind::DamageOverTime,stacking_policy:CombatStackingPolicy::Refresh,power,duration_remaining:duration,modifier:None,applied_sequence:0}}
fn fighter(id:&str,name:&str,hp:u32,position:u32,skill:CombatSkillSnapshot,effects:Vec<ActiveStatusEffect>)->Combatant{
    let snapshot=CombatantSnapshot{source_character_id:format!("char-{id}"),display_name:name.into(),effective_stats:CombatStats::default(),max_hp:hp,max_mana:100,skills:vec![skill]};
    let mut runtime=CombatantRuntimeState::fresh(&snapshot);runtime.active_effects=effects;runtime.current_hp=hp;
    Combatant{id:CombatantId(id.into()),position,snapshot,runtime_state:runtime}
}
fn session(actor:Combatant,target:Combatant)->CombatSession{let now=Utc::now();CombatSession{id:CombatSessionId("effects-session".into()),status:CombatStatus::Running,rng_seed:42,round_number:1,turn_index:0,next_action_sequence:1,combatants:vec![actor,target],created_at:now,updated_at:now,completed_at:None}}
fn command(actor:&str,target:&str)->UseSkillCommand{UseSkillCommand{session_id:"effects-session".into(),actor_combatant_id:actor.into(),target_combatant_id:target.into(),skill_id:"wait".into()}}

#[test]
fn refresh_preserves_instance_and_replaces_payload(){
    let db=Database::open_in_memory().expect("db");let repo=SqliteCombatRepository::new(db.shared());
    let actor=fighter("aren","Aren",500,0,wait_skill(vec![burn(30.0,4)]),vec![]);
    let target=fighter("elysia","Elysia",400,1,wait_skill(vec![]),vec![active_burn(20.0,2)]);
    repo.insert(&session(actor,target)).expect("insert");let resolved=use_skill(&repo,command("aren","elysia")).expect("turn");
    let effects=&resolved.combatants[1].runtime_state.active_effects;assert_eq!(effects.len(),1);assert_eq!(effects[0].instance_id,"burn-runtime");assert_eq!(effects[0].power,30.0);assert_eq!(effects[0].duration_remaining,4);assert_eq!(effects[0].source_combatant_id.0,"aren");
    let actions=repo.list_actions(&resolved.id).expect("actions");assert!(actions.iter().any(|a|a.action_kind==CombatActionKind::EffectRefreshed));
}

#[test]
fn duration_two_ticks_exactly_twice_and_expires(){
    let db=Database::open_in_memory().expect("db");let repo=SqliteCombatRepository::new(db.shared());
    let actor=fighter("aren","Aren",100,0,wait_skill(vec![]),vec![active_burn(5.0,2)]);let target=fighter("elysia","Elysia",100,1,wait_skill(vec![]),vec![]);
    repo.insert(&session(actor,target)).expect("insert");
    use_skill(&repo,command("aren","elysia")).expect("aren first");
    use_skill(&repo,command("elysia","aren")).expect("elysia first");
    let resolved=use_skill(&repo,command("aren","elysia")).expect("aren second");
    assert_eq!(resolved.combatants[0].runtime_state.current_hp,90);assert!(resolved.combatants[0].runtime_state.active_effects.is_empty());
    let actions=repo.list_actions(&resolved.id).expect("actions");assert_eq!(actions.iter().filter(|a|a.action_kind==CombatActionKind::EffectTick).count(),2);assert_eq!(actions.iter().filter(|a|a.action_kind==CombatActionKind::EffectExpired).count(),1);
}

#[test]
fn poison_death_skips_main_action(){
    let db=Database::open_in_memory().expect("db");let repo=SqliteCombatRepository::new(db.shared());
    let actor=fighter("aren","Aren",15,0,wait_skill(vec![]),vec![poison(20.0,2)]);let target=fighter("elysia","Elysia",100,1,wait_skill(vec![]),vec![]);
    repo.insert(&session(actor,target)).expect("insert");let resolved=use_skill(&repo,command("aren","elysia")).expect("turn");
    assert_eq!(resolved.combatants[0].runtime_state.current_hp,0);assert!(resolved.combatants[0].runtime_state.is_defeated);assert_eq!(resolved.status,CombatStatus::Completed);
    let actions=repo.list_actions(&resolved.id).expect("actions");assert!(actions.iter().any(|a|a.action_kind==CombatActionKind::EffectTick));assert!(actions.iter().any(|a|a.action_kind==CombatActionKind::TurnSkipped));assert!(!actions.iter().any(|a|a.action_kind==CombatActionKind::UseSkill));
}

#[test]
fn status_turn_failure_rolls_back_execution_and_runtime(){
    let db=Database::open_in_memory().expect("db");let shared=db.shared();let repo=SqliteCombatRepository::new(shared.clone());
    let actor=fighter("aren","Aren",15,0,wait_skill(vec![]),vec![poison(20.0,2)]);let target=fighter("elysia","Elysia",100,1,wait_skill(vec![]),vec![]);repo.insert(&session(actor,target)).expect("insert");
    {let conn=shared.lock().expect("lock");conn.execute_batch("CREATE TEMP TRIGGER fail_effect_state BEFORE UPDATE OF runtime_state ON combatants WHEN OLD.id='aren' BEGIN SELECT RAISE(ABORT,'forced c2.2 failure'); END;").expect("trigger");}
    assert!(use_skill(&repo,command("aren","elysia")).is_err());let reloaded=repo.get(&CombatSessionId("effects-session".into())).expect("get").expect("session");assert_eq!(reloaded.combatants[0].runtime_state.current_hp,15);assert_eq!(reloaded.combatants[0].runtime_state.active_effects[0].duration_remaining,2);assert!(repo.list_actions(&reloaded.id).expect("actions").is_empty());
    let conn=shared.lock().expect("lock");let executions:i64=conn.query_row("SELECT COUNT(*) FROM combat_turn_executions WHERE session_id='effects-session'",[],|r|r.get(0)).expect("count");assert_eq!(executions,0);
}
