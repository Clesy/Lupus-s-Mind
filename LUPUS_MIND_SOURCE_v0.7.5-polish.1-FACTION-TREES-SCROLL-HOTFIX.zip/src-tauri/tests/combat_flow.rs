use chrono::Utc;
use lupus_mind_lib::{
    combat::{
        application::use_cases::use_skill,
        domain::{
            combat::{CombatSession,CombatSessionId,CombatSkillSnapshot,CombatStats,CombatStatus,Combatant,CombatantId,CombatantRuntimeState,CombatantSnapshot,UseSkillCommand},
            repository::CombatSessionRepository,
        },
        infrastructure::sqlite_combat_repository::SqliteCombatRepository,
    },
    shared::database::Database,
    skills::domain::skill::{ResourceKind,SkillKind},
};

fn fighter(id:&str,character:&str,name:&str,hp:u32,mana:u32,position:u32,skill:bool)->Combatant{
    let skills=if skill{vec![CombatSkillSnapshot{skill_id:"dragon".into(),name:"Dragon Strike".into(),kind:SkillKind::Physical,resource_kind:ResourceKind::Mana,base_power:120.0,resource_cost:20,cooldown_turns:2,scaling:vec![],effects:vec![]}]}else{vec![]};
    let snapshot=CombatantSnapshot{source_character_id:character.into(),display_name:name.into(),effective_stats:CombatStats::default(),max_hp:hp,max_mana:mana,skills};
    Combatant{id:CombatantId(id.into()),position,snapshot:snapshot.clone(),runtime_state:CombatantRuntimeState::fresh(&snapshot)}
}
fn session()->CombatSession{let now=Utc::now();CombatSession{id:CombatSessionId("session-42".into()),status:CombatStatus::Running,rng_seed:42,round_number:1,turn_index:0,next_action_sequence:1,combatants:vec![fighter("aren","char-aren","Aren",500,100,0,true),fighter("elysia","char-elysia","Elysia",400,80,1,false)],created_at:now,updated_at:now,completed_at:None}}
fn command()->UseSkillCommand{UseSkillCommand{session_id:"session-42".into(),actor_combatant_id:"aren".into(),target_combatant_id:"elysia".into(),skill_id:"dragon".into()}}

#[test]
fn golden_turn_is_durable_and_logged(){
    let db=Database::open_in_memory().expect("db");let repo=SqliteCombatRepository::new(db.shared());repo.insert(&session()).expect("insert");
    let resolved=use_skill(&repo,command()).expect("resolve");
    assert_eq!(resolved.combatants[0].runtime_state.current_mana,80);
    assert_eq!(resolved.combatants[1].runtime_state.current_hp,280);
    assert_eq!(resolved.turn_index,1);
    let reloaded=repo.get(&CombatSessionId("session-42".into())).expect("get").expect("session");
    assert_eq!(reloaded.combatants[0].runtime_state.current_mana,80);
    assert_eq!(reloaded.combatants[1].runtime_state.current_hp,280);
    let actions=repo.list_actions(&reloaded.id).expect("actions");assert_eq!(actions.len(),1);assert_eq!(actions[0].sequence_number,1);match &actions[0].resolution { lupus_mind_lib::combat::domain::combat::CombatActionResolution::Skill(r)=>assert_eq!(r.hp_delta,-120), other=>panic!("unexpected action resolution: {other:?}") };
}

#[test]
fn failed_target_write_rolls_back_entire_turn(){
    let db=Database::open_in_memory().expect("db");let shared=db.shared();let repo=SqliteCombatRepository::new(shared.clone());repo.insert(&session()).expect("insert");
    {let conn=shared.lock().expect("lock");conn.execute_batch("CREATE TEMP TRIGGER fail_target BEFORE UPDATE OF runtime_state ON combatants WHEN OLD.id='elysia' BEGIN SELECT RAISE(ABORT,'forced failure'); END;").expect("trigger");}
    assert!(use_skill(&repo,command()).is_err());
    let reloaded=repo.get(&CombatSessionId("session-42".into())).expect("get").expect("session");
    assert_eq!(reloaded.combatants[0].runtime_state.current_mana,100);
    assert_eq!(reloaded.combatants[1].runtime_state.current_hp,400);
    assert_eq!(reloaded.turn_index,0);
    assert!(repo.list_actions(&reloaded.id).expect("actions").is_empty());
}

#[test]
fn deleting_battle_cascades_runtime_actions_and_replay_history(){
    let db=Database::open_in_memory().expect("db");
    let shared=db.shared();
    let repo=SqliteCombatRepository::new(shared.clone());
    repo.insert(&session()).expect("insert");
    use_skill(&repo,command()).expect("resolve");
    repo.delete(&CombatSessionId("session-42".into())).expect("delete");
    assert!(repo.get(&CombatSessionId("session-42".into())).expect("get").is_none());
    let conn=shared.lock().expect("lock");
    for table in ["combat_sessions","combatants","combat_actions","combat_turn_executions","combat_replay_origins","combat_replay_events"] {
        let count:i64=conn.query_row(&format!("SELECT COUNT(*) FROM {table}"),[],|r|r.get(0)).expect("count");
        assert_eq!(count,0,"{table} should cascade delete");
    }
}
