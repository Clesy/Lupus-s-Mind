use lupus_mind_lib::{
    app_state::AppState,
    characters::application::use_cases::{self as character_use_cases, UpsertCharacterInput},
    characters::domain::character::CharacterStats,
    skill_evaluation::{
        application::preview_skill::PreviewSkillServices,
        domain::evaluator::{DeterministicSkillEvaluator, EvaluationStats, SkillEvaluator},
    },
    skills::{
        application::use_cases::{self, UpsertSkillInput},
        domain::skill::{ResourceKind, ScalingStat, ScalingTerm, Skill, SkillId, SkillKind},
    },
};
use chrono::Utc;

fn character(state: &AppState) -> String {
    character_use_cases::create(&state.characters, UpsertCharacterInput { name:"Talion".into(), alias:None, class_label:Some("Death God".into()), level:12, base_stats:CharacterStats{str:18,agi:24,vit:14,int:12,mnd:12}, biography:None, tags:vec![] }).expect("character create").id
}

#[test]
fn evaluator_is_deterministic_and_pure() {
    let now=Utc::now();
    let skill=Skill{id:SkillId("dragon".into()),name:"Dragon Strike".into(),description:String::new(),kind:SkillKind::Physical,resource_kind:ResourceKind::Mana,base_power:65.0,resource_cost:20,cooldown_turns:2,scaling:vec![ScalingTerm{stat:ScalingStat::Strength,coefficient:1.5},ScalingTerm{stat:ScalingStat::WeaponDamage,coefficient:0.8}],tags:vec![],created_at:now,updated_at:now};
    let stats=EvaluationStats{strength:18.0,weapon_damage:120.0,..Default::default()};
    let evaluator=DeterministicSkillEvaluator;
    let first=evaluator.evaluate(&skill,&stats);
    for _ in 0..100 { assert_eq!(first,evaluator.evaluate(&skill,&stats)); }
    assert!((first.theoretical_power-188.0).abs()<f64::EPSILON);
}

#[test]
fn teach_duplicate_forget_and_preview_flow() {
    let state=AppState::in_memory().expect("state");
    let character_id=character(&state);
    let skill=use_cases::create(&state.skills,UpsertSkillInput{name:"Dragon Strike".into(),description:None,kind:SkillKind::Physical,resource_kind:ResourceKind::Mana,base_power:65.0,resource_cost:20,cooldown_turns:2,scaling:vec![ScalingTerm{stat:ScalingStat::Strength,coefficient:1.5}],tags:vec!["melee".into()]}).expect("skill create");
    use_cases::teach(&state.characters,&state.skills,&state.skills,character_id.clone(),skill.id.clone()).expect("teach");
    assert!(use_cases::teach(&state.characters,&state.skills,&state.skills,character_id.clone(),skill.id.clone()).is_err());
    let learned=use_cases::list_for_character(&state.characters,&state.skills,&state.skills,character_id.clone()).expect("learned");
    assert_eq!(learned.len(),1);
    let evaluator=DeterministicSkillEvaluator;
    let preview=PreviewSkillServices{characters:&state.characters,items:&state.items,equipment:&state.equipment,skills:&state.skills,evaluator:&evaluator}.preview(character_id.clone(),skill.id.clone()).expect("preview");
    assert!((preview.theoretical_power-92.0).abs()<f64::EPSILON);
    use_cases::forget(&state.skills,character_id,skill.id).expect("forget");
}
