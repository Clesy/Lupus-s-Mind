use lupus_mind_lib::{
    app_state::AppState,
    characters::{
        application::use_cases::{self as character_use_cases, UpsertCharacterInput},
        domain::character::CharacterStats,
    },
    combat::application::{preview::{CombatImpactPreviewInput, CombatImpactPreviewServices}, use_cases::{self as combat_use_cases, BASIC_ATTACK_SKILL_ID}},
    skills::{
        application::use_cases::{self as skill_use_cases, UpsertSkillInput},
        domain::skill::{ResourceKind, SkillKind},
    },
};

fn create_character(state: &AppState, name: &str) -> String {
    character_use_cases::create(
        &state.characters,
        UpsertCharacterInput {
            name: name.into(),
            alias: None,
            class_label: None,
            level: 1,
            base_stats: CharacterStats { str: 10, agi: 0, vit: 10, int: 10, mnd: 10 },
            biography: None,
            tags: vec![],
        },
    )
    .expect("character create")
    .id
}

#[test]
fn impact_preview_is_read_only_and_can_inspect_unlearned_skill() {
    let state = AppState::in_memory().expect("state");
    let attacker = create_character(&state, "Aren");
    let target = create_character(&state, "Elysia");
    let skill = skill_use_cases::create(
        &state.skills,
        UpsertSkillInput {
            name: "Test Strike".into(),
            description: None,
            kind: SkillKind::Physical,
            resource_kind: ResourceKind::None,
            base_power: 100.0,
            resource_cost: 0,
            cooldown_turns: 0,
            scaling: vec![],
            tags: vec![],
        },
    )
    .expect("skill create");

    let services = CombatImpactPreviewServices {
        characters: &state.characters,
        items: &state.items,
        equipment: &state.equipment,
        skills: &state.skills,
        assignments: &state.skills,
    };
    let preview = services
        .execute(CombatImpactPreviewInput {
            attacker_character_id: attacker.clone(),
            target_character_id: target.clone(),
            skill_id: skill.id.clone(),
            rng_seed: 42,
            force_critical: false,
        })
        .expect("preview");

    assert!(!preview.learned_by_attacker);
    assert_eq!(preview.resolution.hp_delta, -100);
    assert_eq!(preview.resolution.raw_power, 100.0);
    assert_eq!(preview.resolution.resolved_power, 100.0);

    skill_use_cases::teach(&state.characters, &state.skills, &state.skills, attacker, skill.id.clone()).expect("teach");
    let learned = services
        .execute(CombatImpactPreviewInput {
            attacker_character_id: preview.attacker_character_id,
            target_character_id: target,
            skill_id: skill.id,
            rng_seed: 42,
            force_critical: false,
        })
        .expect("learned preview");
    assert!(learned.learned_by_attacker);
}


#[test]
fn manual_basic_attack_can_be_forced_critical_without_creating_a_session() {
    let state = AppState::in_memory().expect("state");
    let attacker = create_character(&state, "Aren");
    let target = create_character(&state, "Elysia");
    let services = CombatImpactPreviewServices {
        characters: &state.characters,
        items: &state.items,
        equipment: &state.equipment,
        skills: &state.skills,
        assignments: &state.skills,
    };
    let normal = services.execute(CombatImpactPreviewInput {
        attacker_character_id: attacker.clone(),
        target_character_id: target.clone(),
        skill_id: BASIC_ATTACK_SKILL_ID.into(),
        rng_seed: 42,
        force_critical: false,
    }).expect("normal basic attack");
    let critical = services.execute(CombatImpactPreviewInput {
        attacker_character_id: attacker,
        target_character_id: target,
        skill_id: BASIC_ATTACK_SKILL_ID.into(),
        rng_seed: 42,
        force_critical: true,
    }).expect("forced critical basic attack");

    assert!(critical.resolution.was_critical);
    assert!(!critical.resolution.was_dodged);
    assert_eq!(critical.resolution.raw_power, normal.resolution.raw_power);
    assert!(critical.resolution.resolved_power >= normal.resolution.resolved_power * 1.99);
    assert!(combat_use_cases::list_all(&state.combat).expect("sessions").is_empty());
}
