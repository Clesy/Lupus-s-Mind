# C2.1 — Combat Session & Deterministic Turn Resolver Freeze Contract

## Status

**Architecture / invariant freeze: PASS**  
**Full Rust + production bundle compile freeze: pending local toolchain**

C2.1 introduces a durable combat runtime without allowing simulation state to become canonical world state.

## Frozen semantic boundary

```text
CombatantSnapshot != CombatantRuntimeState != CombatAction != TimelineEvent
CombatSession      != Canonical World State
```

- `current_hp`, `current_mana`, cooldowns, turn order and defeat flags exist only inside Combat Runtime.
- A running session snapshots CharacterSheet + learned Skill definitions exactly once at combat start.
- Turn resolution never reads live Character / Item / Skill repositories after that snapshot boundary.
- `CombatAction` is session audit, not T1 narrative history.
- C2.1 contains no Apply-to-Canon path and no automatic Timeline / Relationship write.

## Durable runtime choice

SQLite is the durable source of truth for active simulations. RAM is only the working aggregate during one command.

`006_combat_runtime.sql` introduces:

- `combat_sessions`
- `combatants`
- `combat_actions`
- running/terminal status constraints
- unique source-character and initiative-position constraints per session
- monotonic `(session_id, sequence_number)` action log
- triggers that freeze terminal sessions

Combat tables deliberately contain **no foreign keys to canonical Character, Item, Skill, Relationship or Timeline tables**. `source_character_id` is a historical reference string backed by the frozen snapshot, not ownership of canonical data.

## Snapshot isolation

At `combat_start`:

```text
CharacterRepository + CharacterSheet + CharacterSkillRepository + SkillRepository
                               ↓
                     CombatantSnapshot[]
                               ↓
                        CombatSession
```

After session creation:

```text
UseSkillCommand
  -> CombatSession snapshot/runtime only
  -> DeterministicSkillEvaluator (consumer)
  -> Combat resolver
  -> CombatAction + runtime mutation
```

Editing canonical Character, Equipment or Skill records cannot alter an already running combat.

## Deterministic RNG

C2.1 forbids `thread_rng()` / ambient randomness.

```text
roll = stable_rng(session.rng_seed, action.sequence_number, salt)
```

The same seed + sequence + snapshot produces the same crit/dodge rolls after restart or replay. The UI/API constrains seeds to JavaScript's safe integer range so the seed survives IPC without numeric precision loss.

## Turn transaction

`CombatUnitOfWork::with_session_transaction` owns SQLite `BEGIN / COMMIT / ROLLBACK`.

One use-skill command is atomic:

```text
validate session / turn / actor / target / skill / resource / cooldown
    ↓
SkillEvaluator on frozen skill + frozen effective stats
    ↓
resolve crit / dodge / armor / damage-or-heal
    ↓
append CombatAction
    ↓
write actor resource + cooldown
    ↓
write target HP / defeated flag
    ↓
advance turn or complete session
    ↓
COMMIT
```

Any write failure rolls back **action log, mana, HP, cooldown, turn and session status together**.

## C2.1 scope

Included:

- durable combat sessions
- snapshot-isolated combatants
- HP / Mana runtime state
- deterministic AGI initiative
- seeded crit / dodge RNG infrastructure
- physical armor mitigation
- healing / utility handling
- mana cost
- cooldown state and turn ticking
- atomic `UseSkillCommand`
- ordered CombatAction audit log
- victory detection
- terminal-session lock
- resume running sessions
- Obsidian Combat Arena

Deliberately deferred:

- status effects / DoT / HoT
- AoE / multi-target actions
- reactions / counters
- loot / XP
- Apply Combat Results to canon
- automatic TimelineEvent generation
- automatic Relationship changes

## Golden durability test

```text
Seed: 42

before
Aren   HP 500   Mana 100
Elysia HP 400

Aren -> Dragon Strike -> Elysia
cost   20 mana
damage 120

after
Aren   HP 500   Mana 80
Elysia HP 280
Action #1 exists
Turn advances

restart application
Aren Mana 80
Elysia HP 280
Action #1 still exists
```

This passes in `tests/c2_1_invariants.py`. An equivalent Rust integration test is included at `src-tauri/tests/combat_flow.rs` for the local Cargo gate.

## Golden rollback test

The invariant suite deliberately inserts the action log and mutates Aren, then forces the Elysia runtime-state write to fail.

Expected after rollback:

```text
Aren Mana = 100
Elysia HP = 400
Turn = 0
CombatAction count = 0
```

This test passes.

## Clean Architecture boundary

```text
Obsidian Combat UI
  -> CombatGateway
    -> Tauri adapter
      -> Tauri command
        -> Combat application
          -> CombatSessionRepository / CombatUnitOfWork
            -> SqliteCombatRepository
```

Canonical repositories are read dependencies of `StartCombatServices` only. The live turn resolver is snapshot-only.

## Executed verification

```text
npm run verify                                PASS
TypeScript strict                            PASS
C1 / I1 / S1 / R1 / T1 regressions          PASS
Canonical-FK isolation                      PASS
Golden durable turn + restart               PASS
Forced mid-turn rollback                    PASS
Terminal-session immutability               PASS
Session combatant uniqueness                PASS
Seeded RNG reproducibility                  PASS
Snapshot-only resolver boundary             PASS
CombatGateway / IPC boundary                PASS
```

## Pending local compile seal

This packaging environment has no Rust toolchain and no installed Vite binary/package tree. Therefore these are intentionally not reported as passing:

```bash
npm install
npm run verify
npm run build

cd src-tauri
cargo test
```

When those commands pass locally, C2.1 receives its final compile seal.
