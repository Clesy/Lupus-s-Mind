# v0.7.4-alpha.1 — Windows Smoke Test

Run from the extracted project root in PowerShell.

## 1. Toolchain / regression gate

```powershell
npm.cmd install
npm.cmd run verify
npm.cmd run build
cargo test --manifest-path .\src-tauri\Cargo.toml
```

Expected: all commands PASS. The native suite should include `atlas_flow.rs`.

## 2. Launch

```powershell
npm.cmd run tauri:dev
```

Confirm the app opens the existing project without losing previous Characters, Items, Lore, Factions, Inventory, Quests, Secrets, Hierarchies or Relationships.

## 3. Location hierarchy

1. Open **Atlas -> Locations**.
2. Create `World`.
3. Create `North Continent` under World.
4. Create `Elysium` as a Country/Region under North Continent.
5. Create `Black Citadel` beneath Elysium.
6. Edit names/descriptions/tags and reload the route.

Expected: hierarchy persists. A Location must not be able to select itself or one of its descendants as Parent.

## 4. Blank map + pins

1. Open **Atlas**.
2. Create a blank map named `Elysium Atlas`.
3. Select `Elysium` as map scope.
4. Select an unpinned Location and click the canvas.
5. Add at least two pins.
6. Drag a pin somewhere else.
7. Navigate away and back.

Expected: pin positions persist. No duplicate pin for the same Location is created on the same map.

## 5. Connections

Connect two pinned Locations with a `road`, then create another connection type such as `portal` or `sea_route` when applicable.

Expected: connections render on canvas and survive navigation/reload. Deleting a connection must not delete either Location.

## 6. Nested map

1. Create a second map, e.g. `Black Citadel Interior`.
2. Set `Elysium Atlas` as Parent Map.
3. Save and reload.

Expected: parent-map relationship persists. A map must not be able to select itself or its descendants as parent.

## 7. Deterministic generator

Open **Atlas -> Generator** and use a fixed request, for example:

```text
Seed:              482193
Continents:        3
Ocean:             55%
Mountain density:  0.45
Rivers:            6
Settlements:       12
```

Generate it, note the preview, switch away or regenerate with different settings, then restore the exact request and seed.

Expected: the same request produces the same preview geometry/markers.

Also test mountain density `0` with rivers greater than `0`; generation must not crash.

## 8. Preview is not canon

Before pressing **Accept into World**, go to Locations/Atlas lists and verify the generated continent/settlement records were not added to canonical data.

Expected: Generate/Regenerate alone does not mutate the project database.

## 9. Accept into World

1. Generate a map.
2. Enable `Create continent & settlement locations on accept`.
3. Press **Accept into World**.

Expected:

- one canonical Atlas Map is created,
- accepted terrain survives reopening,
- generator seed is retained,
- generated continents become canonical Locations,
- generated settlements become canonical Locations,
- settlements receive the nearest generated continent as parent,
- corresponding pins exist on the new map.

## 10. Search

Use the top-right global search / `Ctrl+K` for a Location and for the accepted Atlas map.

Expected: both produce results that navigate to Atlas.

## 11. Project isolation

Create or accept Atlas data in Project A, switch to Project B, then return to Project A.

Expected: Project B does not see Project A's Locations/Maps/Pins; returning to A restores them.

## Promotion gate

Promote this checkpoint only if:

```text
npm run verify                 PASS
npm run build                  PASS
cargo test                     PASS
Location hierarchy             PASS
Pin persistence/drag           PASS
Nested maps                    PASS
Deterministic generation       PASS
No pre-Accept canonical writes PASS
Accept transaction             PASS
Global Search                  PASS
Project isolation              PASS
```
